[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Cultural Storytelling with Live Legends at OT Kun

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/211123_ENT%20Signature%20Project/LiveLegends%201.jpeg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fnightclub-design-otkun-vectorworks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Cultural%20Storytelling%20with%20Live%20Legends%20at%20OT%20Kun&url=https%3A%2F%2Fblog.vectorworks.net%2Fnightclub-design-otkun-vectorworks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fnightclub-design-otkun-vectorworks)

With the release of [Vectorworks 2022](https://www.vectorworks.net/2022), we’re celebrating a few projects that exemplify what Vectorworks is all about — _design without limits™_. The first two projects we highlighted were the [Asian Institute of Chartered Bankers](../../../net/vectorworks/blog/asian-institute-of-chartered-bankers-kuala-lumpur.html) and the site design of the [Vancouver Convention Center](../../../net/vectorworks/blog/vancouver-convention-center-pwl-partnership-vectorworks.html).

Now, we’d like to highlight [Live Legends’](https://www.livelegends.com/) design of [OT Kun](https://www.livelegends.com/projects/ot-kun/), a breathtaking nightclub in Kunming, China. 

![LiveLegends 1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211123_ENT%20Signature%20Project/LiveLegends%201.jpg?width=1440&name=LiveLegends%201.jpg)

###### Telling the Story of Kunming’s Culture

“We transform compelling stories into legendary live, online, and hybrid experiences,” reads Live Legends’ website. 

And, there’s probably no story _more_ compelling than that of our own, human history. Live Legends took inspiration from the culture of Yunnan, the Chinese province of which Kunming is the capital. According to [_The Culture Trip_](https://theculturetrip.com/asia/china/articles/8-facts-about-yunnanese-culture/), Kunming is known for a thriving culture of like-minded nonconformists such as artists and musicians. 

However, telling the story of a distant culture is a difficult and delicate task. So before a single sketch was drawn, Daan Oomen, Live Legends’ creative director, took multiple trips to Kunming during which he’d drink tea with the locals, learn the environment, and try to understand the local culture — all in the name of a great design for OT Kun.

The priority for Oomen’s experiential learning trips were echoed by Bas Knappers, a Live Legends lighting designer: “It’s very important to bring in the traditional Chinese culture into the design of the clubs. A lot of people recognize it, they love it, and it makes the club very special.” 

One cultural consideration is the centerpiece of the main room, as well as the decorative elements on the ceiling — inspired by the unique shape of Yunnan tribal necklaces and headpieces. 

Chinese culture can be seen in OT Kun’s design through pre-programmed glyphs that play across the club’s LED installations.

![LiveLegends 2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211123_ENT%20Signature%20Project/LiveLegends%202.png?width=400&name=LiveLegends%202.png)

The design’s use of natural, organic shapes is taken from Kunming’s history of botanical beauty — in fact, the city is known as [“Spring City”](https://www.chinahighlights.com/kunming/) for its climate and foliage. The juxtaposition between these shapes creates an energy that is surely palpable for those on the dance floor.

###### The Best One-Third of Your Life

If you spend eight hours of your day sleeping, and eight hours working, you’re still left with eight hours to do whatever it is you’d like.

Short for “One-Third Kunming,” OT Kun is Live Legends’ [second Chinese night club](https://www.livelegends.com/13-the-club-the-story-the-team/) promising that their designs can provide “the best one-third of your life.”

In fact, this message rotates across a screen when visitors enter the club’s main lobby. The lobby also features a stunning video floor that controls the area’s atmosphere as the night progresses.

![LiveLegends 3](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211123_ENT%20Signature%20Project/LiveLegends%203.jpg?width=1440&name=LiveLegends%203.jpg)

Once you’ve made it through the lobby and first seating areas — the design’s primary statement, you enter the main space, a spectacle that embraces the beauty of darkness. The 1,200-plus light fixtures and 800-meter LED installs make the space feel dramatic and exciting.

![LiveLegends 4](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211123_ENT%20Signature%20Project/LiveLegends%204.jpg?width=1440&name=LiveLegends%204.jpg)

While in the main area, visitors can sit to socialize, play games, and relax — as is customary in Chinese clubbing culture. But, if the cutting-edge EDM music inspires the club’s inhabitants, there’s also plenty of room to dance. The space for dancing is thanks to thoughtfully designed sitting areas that double as dance floors. Whatever you’re looking for in a night out, OT Kun can deliver.

![LiveLegends 5](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211123_ENT%20Signature%20Project/LiveLegends%205.jpg?width=1440&name=LiveLegends%205.jpg)

We’re not the only ones who believe that Live Legends delivered an exceptional design with OT Kun, either. For their 10th annual [Global Eventex Awards](https://eventex.co/?gclid=CjwKCAiAs92MBhAXEiwAXTi259tdX5OmBOgbIfevSVJGEtqHmNiRZSbo2lKQlnIaBdzFBnyUw-D%5FVxoCitcQAvD%5FBwE), Eventex awarded OT Kun “Venue of the Year.”

###### Live Legends’ Unique Design Workflow

Just as Live Legends started with the roots of Yunnan for their night club, they started with the roots of design for their drafting process.

At the begging of their design workflow, Stefan Peters, concept designer, starts the firm’s expression with a simple paper and pencil drawing. From here, Live Legends use the rendering capabilities of Cinema 4D.

![PNG-afbeelding-7BD8E436D54B-1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211123_ENT%20Signature%20Project/PNG-afbeelding-7BD8E436D54B-1.png?width=1440&name=PNG-afbeelding-7BD8E436D54B-1.png)

Where most design firms work _towards_ a rendering, Live Legends _start_ with one. This order of their workflow allows for a clear design intention before they enter [Vectorworks Spotlight](https://www.vectorworks.net/spotlight) for their technical drawings, paperwork, and beautiful PDF layouts.

Live Legends trust Vectorworks to clearly articulate their design vision to local installers. According to Knappers, the need of such paperwork and documentation is paramount when it comes to installing their design. If the documentation isn’t clear or logical, it may be installed incorrectly.

![LiveLegends 6](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211123_ENT%20Signature%20Project/LiveLegends%206.jpg?width=1440&name=LiveLegends%206.jpg)

Knappers emphasized the importance of Vectorworks, referring to software as the “central point” of Live Legends’ design workflow. Vectorworks can also be the central point of your entertainment design workflow. 

Click the button below to get the software that helps Live Legends _design without limits™._

_[![GET VECTORWORKS 2022](https://no-cache.hubspot.com/cta/default/3018241/4d106fd3-09da-4359-9a3e-44b3a13119d2.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/4d106fd3-09da-4359-9a3e-44b3a13119d2)_ 

_All images courtesy of Live Legends_.

 Topics: [Project Highlight](https://blog.vectorworks.net/topic/project-highlight) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.