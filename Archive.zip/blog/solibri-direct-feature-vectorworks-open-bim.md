[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Support Your Open BIM Process with Solibri Direct in Vectorworks

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Solibri.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fsolibri-direct-feature-vectorworks-open-bim)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Support%20Your%20Open%20BIM%20Process%20with%20Solibri%20Direct%20in%20Vectorworks&url=https%3A%2F%2Fblog.vectorworks.net%2Fsolibri-direct-feature-vectorworks-open-bim&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fsolibri-direct-feature-vectorworks-open-bim)

Model checking and validation is an essential part of an [Open BIM workflow](https://www.vectorworks.net/customer-showcase/a-successful-transition-to-open-bim). Whether it’s being done for your own benefit or to coordinate models with your consultants, there are many solutions out there that assist the process and make sure construction happens smoothly.

In this blog, we’ll talk about how you can use Vectorworks and [Solibri Office](https://www.solibri.com/) to save time and money in the Open BIM process. 

## What is Solibri Direct?

Solibri Direct is a Vectorworks feature that enables a connection to Solibri Office, the BIM quality assurance program by Nemetschek sister company Solibri. The innovative feature is offered to all Vectorworks [Architect](https://www.vectorworks.net/architect) and [Landmark](https://www.vectorworks.net/landmark) users. With this connection, you have access to the construction quality assurance capabilities of one of the most powerful industry foundation classes (IFC) data model checking services.

Changes made to the Vectorworks model geometry or data immediately synchronize with the IFC model in Solibri. Objects selected in Solibri can be isolated and selected in Vectorworks. And, with the release of [Vectorworks 2022](https://www.vectorworks.net/2022), you’ll have access to a live sync of the view changes when navigating your model in both Solibri and Vectorworks. Real-time connections yield real-time solutions for you and your collaborators.

Check out the [Vectorworks Partner Network](https://www.vectorworks.net/community/partner-network/find-partner) and platinum partner Solibri.

## How Can I Use Solibri Direct in My Open BIM Workflow?

To use Solibri Direct, you must have an active license of Solibri Office installed. From there, follow these steps:

1. Export your model to IFC.
2. When the export is complete, save your Vectorworks model.
3. Select “Solibri Direct” in the Tools menu.
4. Click “connect.”
5. Once your connection is established, the model check can begin in Solibri Model Checker.
6. If an issue is found, the issue can be selected to view in Solibri.
7. When the object is selected in Solibri, it’ll also be selected in Vectorworks.
8. Any changes then made in Vectorworks will instantly appear in Solibri.
9. From here, another model check can take place to validate changes.

As is the case with any Open BIM workflow, Solibri Direct establishes an intuitive communication between you, your design, and your collaborators.

## How Can Solibri Direct Save Me Time and Money?

We get it. The opportunity to save time _and_ money is a pretty big claim. But in design, time is money; and with the live sync between Vectorworks and Solibri, you’ll have a better model for coordination with consultants. This will save you time down the line.

You can also save time by avoiding the cumbersome process of exporting dozens of files. Your BIM model is continually connected to its corresponding IFC model for verification, checking, and coordination.

Using Solibri Direct, you have a direct connection to the leader in BIM quality assurance and quality control, providing out of the box tools for BIM validation, compliance control, design process coordination, design review, analysis, and code checking. This means that potential — and costly — errors in the construction process are dealt with before you’re even on site.

An improved connection to Solibri is one of the many ways Vectorworks 2022 will let you _design without limits_ _™_. Click the button below to download the newest version of the best design software for the architecture, landscape, and entertainment industries.

[![MEET VECTORWORKS 2022](https://no-cache.hubspot.com/cta/default/3018241/57d206f6-cbf5-4136-960c-1d46da994022.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/57d206f6-cbf5-4136-960c-1d46da994022) 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.