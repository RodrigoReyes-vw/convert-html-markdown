[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Design Summit 2021: Who, What, When, Where, Why

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/210907_Summit%20Announcement/Summit%20Announcement%20Featured%20Image.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fall-about-the-2021-vectorworks-design-summit)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Design%20Summit%202021:%20Who,%20What,%20When,%20Where,%20Why&url=https%3A%2F%2Fblog.vectorworks.net%2Fall-about-the-2021-vectorworks-design-summit&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fall-about-the-2021-vectorworks-design-summit)

Even though we look forward to each of our Design Summit events, last year [we had to cancel the in-person event and go virtual](../../../net/vectorworks/blog/watch-vectorworks-design-summit-virtual-presentations.html). The experience taught us a lot about hosting events online. So much, in fact, that we're doing it again. But _better_.

Vectorworks Design Summit 2021 will take place November 1-3, 2021 on a screen near you! The event is free and invites the global Vectorworks community to attend.

So let's look at the details and why this event is a must.

## What and When?

Vectorworks Design Summit is a training-focused conference for the entire Vectorworks community! It's an opportunity to interact with like-minded designers, make connections, and chat with Vectorworks product experts and partners.

This year's virtual event will span three days, each with a different theme:

Day 1 - Nov. 1, 2021

Keynote presentations and industry perspectives.

Day 2 - Nov. 2, 2021

Live & on-demand training.

Day 3 - Nov. 3, 2021

Networking open house.

![Summit Announcement Featured Image](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210907_Summit%20Announcement/Summit%20Announcement%20Featured%20Image.png?width=1440&name=Summit%20Announcement%20Featured%20Image.png)

## Who?

On November 1, Vectorworks leadership will give keynote presentations you won't want to miss. You'll hear from:

* CEO Dr. Biplab Sarkar.
* Chief Technology Officer Steve Johnson.
* Product Marketing Director Rubina Siddiqui.

On November 2, you'll have the opportunity to be a part of:

* Live training sessions with software experts.
* On-demand content from designers around the world.
* Exclusive content from the [Vectorworks Partner Network.](https://www.vectorworks.net/community/partner-network)

And on November 3, you can meet with a variety of Vectorworks product experts and parters in a day-long open house. Chat about anything from design workflows, industry trends, or even your latest project!

## Where?

On a screen near you! All you need is a stable internet connection and the latest version of [Zoom](https://zoom.us/).

## Why?

Why host such an event? And virtually, no less?

1. Because COVID-19 renders a virtual event safest to ensure the health of employees and attendees.
2. Because the Vectorworks community deserves a chance to come together. The idea is that a wealth of training options and opportunities to collaborate with like minds will aid career success.
3. Because virtual events fit with our global audience, so that Vectorworks users from all around the world can attend the event.
4. Because everyone at Vectorworks is proud to be transparent about what we're working on and how it might impact the community — [just look at our public development roadmap for proof](https://www.vectorworks.net/public-roadmap) — so an open house for anyone who'd like to attend really appeals to us.

## Registering for Design Summit

Registration is open now! Just follow the link below and enter your contact information to save your spot.

[![SAVE YOUR SPOT](https://no-cache.hubspot.com/cta/default/3018241/70efdd2a-179f-4bbf-bf8f-ff24a0e9496e.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/70efdd2a-179f-4bbf-bf8f-ff24a0e9496e) 

Once registered, you'll have access to our new swag store where you can get your hands on never-before-seen Vectorworks merchandise!

And remember — _the event is completely free_. 😲

 Topics: [Events](https://blog.vectorworks.net/topic/events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.