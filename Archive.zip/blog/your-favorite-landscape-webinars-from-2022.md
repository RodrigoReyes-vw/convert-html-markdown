[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Recap: 4 Landscape Webinars You Need to See

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/221121_November%20Webinar%20Blog/blog-1440x800_LND%20Webinar.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fyour-favorite-landscape-webinars-from-2022)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Recap:%204%20Landscape%20Webinars%20You%20Need%20to%20See&url=https%3A%2F%2Fblog.vectorworks.net%2Fyour-favorite-landscape-webinars-from-2022&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fyour-favorite-landscape-webinars-from-2022)

Vectorworks University is one the several resources at your fingertips that will help you design without limits. With free webinars, tech tips, and more, you’ll be able to expand your skills, perfect your workflows, and optimize your software for your creative process.

Let’s look back at some of the landscape webinars you may have missed this year.

#### 1\. Net-Zero Water Stormwater Landscapes

![August Webinar LND Blog](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220818_August%20Webinar/August%20Webinar%20LND%20Blog.png?width=1440&height=800&name=August%20Webinar%20LND%20Blog.png)

Broadly, this webinar is about managing stormwater to reach net-zero water landscapes. Specifically, you’ll get insight into how to use green infrastructure concepts like rain gardens and green roofs to achieve sustainability goals.

This webinar will help you:

* Learn how to define net-zero water landscapes
* Understand how to use rain gardens along with other green infrastructure concepts to reduce energy-dependent water use on sites
* Understand historical solutions such as water harvesting and cool benches as tools to use on the route to net-zero water usage

[Click here to watch “Net-Zero Water Stormwater Landscapes.”](https://university.vectorworks.net/course/view.php?id=2225)

This course is approved for 1 LA CES HSW PDH and 1 APLD CEU.

#### 2\. 3D Modeling for Landscape Analysis

![March Webinar 2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220315_March%20Webinars/March%20Webinar%202.jpg?width=839&height=800&name=March%20Webinar%202.jpg)

You’ll want to watch this webinar to help with your journey into 3D modeling. Landscape designer Danilo Maffei discusses the advantages of site modeling, the Heliodon tool, and saved views to create compelling reports and exhibits, both for internal use and for presentations to clients.

This webinar will help you:

* Use the site model tool to create slope and elevation analysis
* Use the Heliodon tool to create sun and shade studies
* Use the saved views tool to create viewshed studies
* Use 2D polygons, record formats, and worksheets to analyze and report spatial data

[Click here to watch “3D Modeling for Landscape Analysis.”](https://university.vectorworks.net/course/view.php?id=157)

This course is approved for 1 LA CES HSW PDH and 1 APLD CEU.

#### 3\. Social Media for Landscape Design Professionals

![2208-webinar-land-sept-design-images-landing-page-750x428](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220913_September%20Webinars%20Blog/2208-webinar-land-sept-design-images-landing-page-750x428.jpg?width=750&height=428&name=2208-webinar-land-sept-design-images-landing-page-750x428.jpg)

Using social media has the potential to bring in more business at very little cost to you. In this webinar, Senior Content Marketing Manager Joselyn Wojtalewicz (fun fact, she’s the manager behind this blog, too!) gives you the tools you need to get up and running with social media marketing.

This webinar will help you:

* Understand how to create an effective social media marketing plan to help grow your site design business
* Discover social media marketing tips and how creating a content calendar can help meet your goals
* Explore examples of site design firms that are successfully using multiple social media outlets
* Review the best social media platforms heighten your landscape design firm’s prominence

[Click here to watch “Social Media for Landscape Design Professionals,”](https://university.vectorworks.net/course/view.php?id=2279) and [here for a blog post about driving awareness to your business with social media.](../../../net/vectorworks/blog/social-media-guidelines-for-business-growth.html)

This course is approved for 1 LA CES PDH and 1 APLD CEU.

#### 4\. The Power of 3D Modeling 

![blog-1440x800_LND Webinar](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221121_November%20Webinar%20Blog/blog-1440x800_LND%20Webinar.png?width=1440&height=800&name=blog-1440x800_LND%20Webinar.png)

It’s no secret that 3D modeling has huge advantages to traditional 2D and CAD-based workflows. This webinar with landscape architect Tony Kostreski is all about the efficiencies you gain by using 3D modeling in landscape-specific BIM software.

This webinar will help you:

* Understand the benefits of using landscape-specific tools during your 3D modeling workflow
* Learn and master commonly used 3D modeling processes to create custom objects
* Explore how designers communicate with clients and contractors in a more immersive way using virtual reality with the Vectorworks Nomad app
* Recognize the benefit of reducing revision challenges by working in a single file through modeling and rendering

[Click here to watch “The Power of 3D Modeling.”](https://university.vectorworks.net/course/view.php?id=2086)

This course is approved for 1 LA CES PDH and 1 APLD CEU.

#### Make sure you don’t miss any of next year’s webinars!

We have even more webinar opportunities planned for 2023\. Each month, you’ll see a summary blog post that directs you to each of that month’s recordings. Make sure you’re subscribed to the blog so you don’t miss it.

[![Subscribe Now](https://no-cache.hubspot.com/cta/default/3018241/13fc3f24-f095-4e7e-a818-b6d0a408f3fb.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/13fc3f24-f095-4e7e-a818-b6d0a408f3fb) 

 Topics: [Landscapes](https://blog.vectorworks.net/topic/landscapes) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.