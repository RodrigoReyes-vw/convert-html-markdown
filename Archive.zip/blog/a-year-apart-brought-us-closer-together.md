[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# A Year Apart Brought Us Closer Together

 Posted by [Leslie Briggs](https://blog.vectorworks.net/author/leslie-briggs) | 8 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/201216_CompanyCulture/blog-images-resize.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fa-year-apart-brought-us-closer-together)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=A%20Year%20Apart%20Brought%20Us%20Closer%20Together&url=https%3A%2F%2Fblog.vectorworks.net%2Fa-year-apart-brought-us-closer-together&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fa-year-apart-brought-us-closer-together)

For 35 years, Vectorworks has worked to create and cultivate a culture of inclusion, balance, collaboration, and innovation within our company. Our values are reflected in our business practices — especially the ways we interact with our customers and each other. So, when [COVID-19](../../../net/vectorworks/blog/how-vectorworks-is-helping-customers-during-covid-19.html) changed our working environments, our culture was put to the test.

While we’ve been fortunate as a company to continue working remotely, 2020 has pushed us outside of our comfort zones, demanding that each of us re-evaluate the ways we engage with each other, both personally and professionally. Through the months of quarantine and isolation, many of us have been challenged in trying to achieve work/life balance in the “new normal” of staying and working at home.

###### **![Employees showing off their work-from-home setups, families, and pets.](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201216_CompanyCulture/blog-images-resize.jpg?width=600&name=blog-images-resize.jpg)**_Employees showing off their work-from-home setups, families, and pets._

## Maintaining Personal Connection

Whether we’re working while learning to cope with kids learning virtually, providing 24/7 toddler care, working around the same dining room table with our families, or facing the eerie solitude of living alone, Vectorworks ensured that employees had endless ways to stay connected and engaged.

The human resources team provided regular outlets for employees to engage on a personal level. They made use of Slack, our internal communication system, to connect employees with each other based on non-work hobbies and interests. Some of our favorites were the Vectorworks Test Kitchen, where people could put new recipes to the test, the Vectorgrams channel to thank hard-working co-workers, and of course those dedicated to our furry friends.

![blog-images-resize-01](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201216_CompanyCulture/blog-images-resize-01.jpg?width=365&name=blog-images-resize-01.jpg)![blog-images-resize-02](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201216_CompanyCulture/blog-images-resize-02.jpg?width=365&name=blog-images-resize-02.jpg)  
_Tyler French's dog, Elroy, and Dylan Rinker's cat, Mochi, show off their Vectorworks bandanas._

All in all, over the last nine months, Vectorworks has done so much to keep employees engaged with work and with each other:

* * #VW-events Slack channel with updates, brain breaks, and emoji polls.  
   * Monthly Happy Hour Trivia Games.  
   * Monday Morning Coffee & Tea Chats.  
   * Weekly Virtual Fitness Classes.  
   * VectorKnowledge Learning Sessions.  
   * Friday Dance Parties.  
   * Company Workshops.  
   * Three Different Drive-thru Events.  
   * And more!

## Keeping Skills Fresh

Much of 2020 has demanded a certain amount of personal innovation just to make the switch to remote work, but Vectorworks kept everyone learning during the work week with VectorKnowledge sessions every other Friday. Employees were encouraged to hone their unique skills and teach their co-workers new ways to approach their work with lessons on tools like Trello, 1Password, and Adobe InDesign as well as tips on using persuasion to boost skills or snapping the perfect photo. These sessions truly demonstrated the talent of Vectorworks employees.

## Encouraging Physical and Mental Wellness

And since the brain isn’t the only muscle we need to work out, Vectorworks maintained a twice-weekly virtual fitness class schedule to get employees up and moving. On Tuesdays, participants can find a moment of peace as they center themselves for the week with 30 minutes of beginner yoga. And on Thursdays, participants could get their heart rates up with other types of classes.

While we’re all used to collaborating on various projects, Vectorworks also hosted Happy Hour Trivia games every other Thursday. Employees could either join as a team or show up alone and get matched with others. The latter has been a great way for people to get to know new co-workers from other departments and even other countries.

![Vectorworks UK employees showing off their holiday jumpers in a festive happy hour.](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201216_CompanyCulture/Sarah%20Pearce%20UK%20Christmas%20Jumpers.png?width=600&name=Sarah%20Pearce%20UK%20Christmas%20Jumpers.png)_Vectorworks UK employees showing off their holiday jumpers in a festive happy hour._

Tamsin Slatter, UK director of customer success, enjoyed these fully virtual events. “I think because everyone was attending virtually, it made us feel more of a team than before,” she said. “Having so many online events has enabled members of the UK team to get to know people they otherwise wouldn't get the opportunity to meet.”

Kesoon Chance, UK entertainment industry specialist, echoed Slatter’s feelings. “I enjoy getting to know my American colleagues and it's always good learning something new from quizzes. It also helps break up the routine that 2020 has created.”

## Escaping the Remote Office

Lastly, many are sad to miss out on the in-person gatherings we usually hold to commemorate the launch of the year’s [latest version of Vectorworks](http://vectorworks.net/2021?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=121620companyculture) or to celebrate different holidays. This year, the Vectorworks headquarters parking lot was the landscape for three separate Drive-thru events for just that.

In September, we congratulated hardworking employees with a Launch Drive-thru full of games that could be played out of car windows, treats and trinkets to be won, and a box of mystery to help us prepare for the upcoming launch of Vectorworks 2021\. For many, this was the first time we’d seen our co-workers in person since March and the reunion was long-awaited.

![A look at the "Launch Box" employees received at the Launch Drive-thru.](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201216_CompanyCulture/blog-images-resize-03.jpg?width=600&name=blog-images-resize-03.jpg)_A look at the "Launch Box" employees received at the Launch Drive-thru._

Mario Chávez, localization specialist, commented, “When I went to the Launch Drive-thru, I didn't expect to feel so strongly emotional about seeing coworkers, even executives cheering us on as we drove through.”

Come October, many were excited for the opportunity to share their creative costumes through the online competition and others participated in the spooky spirit during the Halloween Drive-thru by setting up a display and handing out candy to trick-or-treaters who came by with their parents.

![A few inflatable friends from the Halloween Drive-thru.](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201216_CompanyCulture/blog-images-resize-04.jpg?width=600&name=blog-images-resize-04.jpg)_A few inflatable friends from the Halloween Drive-thru._

Iskra Nikolova, quality assurance manager, enjoyed the excitement. “Getting out of my home for a reason other than grocery shopping really lifted up my mood and brightened my days. I appreciated the opportunity to get a dose of cheer at a place that felt safe amid a raging pandemic.”

![A reminder from Woody, Buzz, and friends: you have a friend in Vectorworks.](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201216_CompanyCulture/blog-images-resize-05.jpg?width=600&name=blog-images-resize-05.jpg)_A reminder from Woody, Buzz, and friends: you have a friend in Vectorworks._

Finally, to close out the year, Vectorworks hosted a Holiday Drive-thru fit with an overhead snow machine, classic soundtracks, and ice sculptures of everyone’s holiday favorites — the Grinch, Charlie Brown, Frozen, and even Star Wars. The events team gave it their all this year despite the virus, and this last drive-through shows that innovation runs deep with each and every team at Vectorworks.

## Staying Strong Together, Even Apart

Even in a year where we must stay apart to keep each other safe, we’ve found new ways to come together to support and care for each other. The necessity of remote work has allowed employees to better connect across time zones, creating stronger ties between employees living all over the globe. Each activity and event held this year embodied the values we hold at Vectorworks: to innovate, to collaborate, to find balance, and to be inclusive. The changes brought on by a pandemic have forced us to think differently and challenge our pre-existing notions of work norms so we can be smarter about how we work. As a result, we’ve grown closer as a team and are proudly embodying the values that define our culture in Vectorworks.

Stay in the know with more company updates like this by subscribing to our blog:

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.