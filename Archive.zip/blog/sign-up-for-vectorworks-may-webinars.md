[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# May Webinars | Now Available On Demand

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/230503_May%20Webinars/rise-thumbnail-1680x945-4.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fsign-up-for-vectorworks-may-webinars)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=May%20Webinars%20|%20Now%20Available%20On%20Demand&url=https%3A%2F%2Fblog.vectorworks.net%2Fsign-up-for-vectorworks-may-webinars&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fsign-up-for-vectorworks-may-webinars)

When talking about the [2023 Vectorworks Design Scholarship](../../../net/vectorworks/blog/apply-for-the-2023-vectorworks-design-scholarship.html), Ashley Scheidel of [Ashley Scheidel Design Studio](https://www.ashleyscheideldesign.com/) encouraged design students to embrace design as "something to live and breath."

You don't have to be a student at a university to be a student of design. Design is a life-long study.

Learn something new by watching an on-demand webinar for your industry below:

#### Iterative design for interior Architecture

_Aired May 16 | Earn 1 AIA LU_

Given the iterative nature of interior architecture, you need a software that gives you the flexibility to explore design options throughout every stage of your project. In this webinar, Kesoon Chance, senior industry specialist — interior architecture, and Luis M. Ruiz, senior architect product specialist, discuss advanced techniques for spatial planning, modeling, visualization, and new approaches to develop your designs.

[REGISTER FOR THE INTERIORS WEBINAR](https://university.vectorworks.net/mod/scorm/view.php?id=5402). 

![23_webinar_BLDG_May_vimeo-thumbnail-1080x1920](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230503_May%20Webinars/23_webinar_BLDG_May_vimeo-thumbnail-1080x1920.png?width=1440&height=810&name=23_webinar_BLDG_May_vimeo-thumbnail-1080x1920.png)

#### Using Design Tech for Water-Conscious Landscapes

_Aired May 18 | Earn 1 LA CES PDH and 1 APLD CEU_

Designing landscapes with sustainability in mind is no longer a matter of preference but one of meeting jurisdictional requirements.   
  
Site designers can harness the power of design software, online resources, and other digital tools to meet new expectations in water-efficient irrigation and on-site water management. And with the help of GIS integrations, plant databases, and smart 2D/3D object design, creatively managing water in your proposed landscape is easier than ever.

[WATCH THE LANDSCAPE WEBINAR](https://university.vectorworks.net/course/view.php?id=2675). 

![rise-thumbnail-1680x945-5](https://blog.vectorworks.net/hs-fs/hubfs/rise-thumbnail-1680x945-5.png?width=1440&height=810&name=rise-thumbnail-1680x945-5.png)

#### COLLABORATIVE THEATRE DESIGN WITH VECTORWORKS

_Aired May 24_

With a request of little-to-no technical equipment in sight and the production taking place in a small venue, transferring Daniel Fish’s version of the classic musical _Oklahoma!_ from Broadway to the West End was never going to be easy. 

Set designer Grace Laubacher led a design team to bring the project to life with 3D modeling and Project Sharing in Vectorworks. 

Watch Laubacher, Fridthjofur Thorsteinsson (associate lighting designer,) Drew Levy (sound designer,) and Josh Thorson (video designer) lead a webinar on how Vectorworks helped create one of the smoothest collaborations the team has ever been through.

[REGISTER FOR THE ENTERTAINMENT WEBINAR](https://university.vectorworks.net/course/view.php?id=2684).

![rise-thumbnail-1680x945-4](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230503_May%20Webinars/rise-thumbnail-1680x945-4.png?width=1440&height=810&name=rise-thumbnail-1680x945-4.png)

#### VECTORWORKS 2023 SERVICE PACK 5 IS HERE

Service Pack 5 for Vectorworks 2023 is now available for download directly in the Vectorworks interface.

To install the service pack, select **Check for Updates** from the Vectorworks menu (Mac) or Help menu (Windows).

Click the button below to learn more about the latest update:

[![LEARN MORE ABOUT VECTORWORKS 2023 SERVICE PACK 5](https://no-cache.hubspot.com/cta/default/3018241/8a879609-7c78-459e-932e-43e636e27cbe.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/8a879609-7c78-459e-932e-43e636e27cbe) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.