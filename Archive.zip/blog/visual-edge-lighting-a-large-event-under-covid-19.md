[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Visual Edge: Lighting a Large Event Under COVID-19

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/210422_Visual%20Edge/6.jpeg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvisual-edge-lighting-a-large-event-under-covid-19)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Visual%20Edge:%20Lighting%20a%20Large%20Event%20Under%20COVID-19&url=https%3A%2F%2Fblog.vectorworks.net%2Fvisual-edge-lighting-a-large-event-under-covid-19&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvisual-edge-lighting-a-large-event-under-covid-19)

“Wow. You guys can do so much.”

Oneka McClellan, once a fashion designer, maintains her eye for glamour in her latest pursuit as co-pastor and creative director for [Shoreline City Church](https://www.shorelinecity.church/) in Dallas[](https://www.shorelinecity.church/), Texas, where she and her husband, Earl McClellan, have been growing community since January of 2012.

Earl McClellan is a well-known megachurch pastor in the United States. As of 2021, the Shoreline City Church has five separate locations, which comes as a contrast to where they began nine years prior as a 15-person bible study gathering in a nursing home. 

Now, with a congregation of almost 5,000, the church faces a challenge — hosting service under close contact restrictions of the coronavirus.

The couple cancelled in-person service for most of 2020, though as 2021 inched closer and vaccination began roll-out, they yearned to resume in-person service. But they wanted to return to normal — or as normal as they could — with a BANG.

![6](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210422_Visual%20Edge/6.jpeg?width=4000&name=6.jpeg)

_Shoreline City Church's holiday event | Courtesy of Belle Woelfel of Visual Edge | Photo by Danilo Lewis_

They looked to [Visual Edge](https://visualedge.co/), a design and production house from Houston, Texas who’ve worked on projects for high-profile clients like Justin Bieber, The Weeknd, Lorde, The Chainsmokers, and more.

[Learn more about Vectorworks Spotlight, the design tool of choice for Visual Edge. ](https://www.vectorworks.net/spotlight)

![1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210422_Visual%20Edge/1.jpeg?width=4032&name=1.jpeg)

_The Visual Edge Studio in Houston, Texas | Courtesy of Visual Edge_

The McClellans pushed to host the event around the December holidays, hoping to bring hope as the year dominated by COVID-19 came to a close. The problem — as of December 2020, Texas had a strict capacity limit of 25%, which necessitates a venue capable of seating 20,000 people, limiting them to a large multi-use arena such as Dallas's [American Airlines Center.](http://www.americanairlinescenter.com/)

“A big challenge for this event was that Shoreline had never done arena events before,” said Jacob VanVlymen, designer and draftsman at Visual Edge. “It required a lot of conversation up-front about how to do this in a COVID-friendly way.”

![7](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210422_Visual%20Edge/7.jpeg?width=1242&name=7.jpeg)

_Early hand drawing of the Shoreline event's stage and rigging | Courtesy of Visual Edge_

The Visual Edge team had to consider how a spread-out crowd could affect acoustics, and it was of course vital that each point in the crowd could see the stage and projection screens. Not only that, but Shoreline required that the entire crowd be visible from the stage.

“Providing a good image from distanced seating wasn’t something we’d ever had to do before. We had to make sure video screens were accessible from all points, and we had to test with a lot more lighting than we’d normally do for an arena event,” said Josh Beard, owner and lead designer at Visual Edge.

VanVlymen and Beard developed three different creative options for the church. Each design proposal was kinetic with lots of mobile trussing, offering the event a state-of-the-art, flashy-yet-polished feel.

> _“It’s so easy to draft in Vectorworks. The ease of the software allowed us test different concepts quickly, which made the entire process a lot smoother. I almost never close the software.” – Jacob VanVlymen, Visual Edge_ 

An event with such flair required close work with a rigging professional. The head rigger, [Charlie Pike of Beard-O-Mation](http://charliepike.com/), performed calculations and verified them in [Braceworks, the Vectorworks rigging module](https://www.vectorworks.net/braceworks). “It gave us peace-of-mind knowing Braceworks was there for us,” VanVlymen said.

![11](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210422_Visual%20Edge/11.png?width=2048&name=11.png)

_Rigging diagram | Courtesy of Jacob VanVlymen of Visual Edge_

Pre-pandemic, the congregation was centered around a diamond-shaped stage, and the church wanted to bring that look and feel of normalcy to their big return. 

“Placing a diamond stage into a square room definitely took up a lot of seating,” Beard said. “What was nice, though, was we were able to quickly test stage placements in the software to maximize the seating area. It was pretty easy to find the best way to do it.”

![3](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210422_Visual%20Edge/3.jpeg?width=4000&name=3.jpeg)

_Stage preparation for the Shoreline event | Courtesy of Visual Edge | Photo by Danilo Lewis_

Visual Edge collaborated with the production group [Upstaging](https://www.upstaging.com/) from Chicago. The group also worked in Vectorworks, and at the end of each workday the teams uploaded their files to Dropbox for the other to review. Being in different time zones, VanVlymen said, meant this process worked perfectly for the two teams. 

Of the final event, Beard is proud of the way it turned out: "I gotta say — the renderings were pretty on-point with the live event,” he said.

![4](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210422_Visual%20Edge/4.jpeg?width=4000&name=4.jpeg)

_Live photo courtesy of Visual Edge | Photo by Danilo Lewis_

Check out this video posted to Shoreline’s YouTube channel to see how Visual Edge’s work translated to the live event on the Eve of Christmas Eve, 2020.

 Topics: [Project Highlight](https://blog.vectorworks.net/topic/project-highlight), [Production & Lighting Design](https://blog.vectorworks.net/topic/production-lighting-design) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.