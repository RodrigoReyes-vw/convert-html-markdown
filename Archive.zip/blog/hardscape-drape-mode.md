[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Inside the Feature: Hardscape Drape Mode

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2023%20Blog%20Images/5_Drape%20Mode/blog-1440x800%20%283%29.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fhardscape-drape-mode)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Inside%20the%20Feature:%20Hardscape%20Drape%20Mode&url=https%3A%2F%2Fblog.vectorworks.net%2Fhardscape-drape-mode&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fhardscape-drape-mode)

If you read our [blog post about the release of Service Pack 4 for Vectorworks 2023](../../../net/vectorworks/blog/2023-service-pack-4.html), then you know we introduced a new mode to the Hardscape tool: Drape mode.

We’re quite proud of the name. It works exactly like it sounds like it would: Drape mode allows you to blanket — or drape — a site model with the hardscape material of your choice.

Here are a few things you might want to know about the new tool mode.

#### It acts like a texture bed but does so much more. 

Placing a texture bed over your site model to represent a hardscape is quick, easy, and looks great.

For landscape architects and other site design professionals who are using building information modeling (BIM), though, a texture bed lacks the detail and specificity of subsurface components needed to develop and document a collaborative 3D model.

These subsurface components — the 3D geometry associated with the hardscape — are present when using the Hardscape tool’s Drape mode, which means it’s perfect for cutting sections to include into presentation packages.

![Screenshot 2023-05-11 at 5.10.52 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/5_Drape%20Mode/Screenshot%202023-05-11%20at%205.10.52%20PM.png?width=1037&height=500&name=Screenshot%202023-05-11%20at%205.10.52%20PM.png)

#### It makes cutting the site model unbelievably fast.

With your hardscape selected and configured to Drape mode, you can find a **Cut the site** **model** option in the Object Info palette.

This option will cut the site model down to the bottom of the deepest component of the hardscape, as shown in the image below. This saves you extraordinary amounts of time when trying to accurately represent site excavation.

![Screenshot 2023-05-24 at 9.49.28 AM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/5_Drape%20Mode/Screenshot%202023-05-24%20at%209.49.28%20AM.png?width=1193&height=758&name=Screenshot%202023-05-24%20at%209.49.28%20AM.png)

#### Drape-configured hardscapes contain pertinent cut/fill information.

Representing site excavation is great, but what about documenting it?

After using the Cut the site model command, you can click the Site Modifier Information drop-down in the Object Info palette to see information such as projected area, surface area, volume, and cut/fill volume.

![Screenshot 2023-05-24 at 9.50.30 AM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/5_Drape%20Mode/Screenshot%202023-05-24%20at%209.50.30%20AM.png?width=1145&height=719&name=Screenshot%202023-05-24%20at%209.50.30%20AM.png)

#### It’s available in Vectorworks Landmark, Architect, and Design Suite.

If you’re using Vectorworks Architect or Design Suite, you can also take advantage of the new mode to speed up your creation of hardscapes over site models. The mode is of course available in Vectorworks Landmark.

You’ll need Service Pack 4 for Vectorworks 2023 installed to use the new mode. If you haven’t updated yet, be sure to do so to start working with the new feature. You can update to the service pack by clicking Check for Updates from the Vectorworks menu (Mac) or Help menu (Windows).

And if you're curious about updates in Service Pack 5, you can find more information below.

[![2023: Service Pack 5](https://no-cache.hubspot.com/cta/default/3018241/4d019a3c-e95b-4c3e-a370-accb56389625.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/4d019a3c-e95b-4c3e-a370-accb56389625) 

 Topics: [Landscapes](https://blog.vectorworks.net/topic/landscapes) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.