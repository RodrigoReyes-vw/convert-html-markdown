[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# WATCH | 6 Reasons Why You Need BIM for Landscape Architecture

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/230315_BIM%20for%20Land%20Video%20Repost/blog-1440x800_BIM%20for%20Land%20Video.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Flandscape-experts-give-6-reasons-why-you-need-bim)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=WATCH%20|%206%20Reasons%20Why%20You%20Need%20BIM%20for%20Landscape%20Architecture&url=https%3A%2F%2Fblog.vectorworks.net%2Flandscape-experts-give-6-reasons-why-you-need-bim&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Flandscape-experts-give-6-reasons-why-you-need-bim)

As our landscape architects note, there are six big reasons why the industry is evolving towards incorporating building information modeling (BIM) into their project workflows:

1. Informed site analysis
2. Greater creativity
3. Multifunctional, purpose-built tools
4. Smarter documentation
5. The need for intelligent coordination and collaboration
6. Flexibility offered by designing with data

In this video, Tony Kostreski and Eric Gilbey of Vectorworks sit down for a discussion on the benefits of BIM in landscape architecture and why they think it’ll be a part of each firm’s workflow.

After watching the video, review the summary below. This way, you'll have all the info you need to share what you've learned with teammates and contemporaries. 

## **1\. Informed Site Analysis**

Most practitioners don’t expect to use their design software for the predesign process. Vectorworks Landmark excels here with its ability to import Revit and DWG (standard and Civil 3D) files, as well as the range of site analysis features to fully understand the site and its needs before getting to work. The ability to import an existing tree survey, for example, allows you to start thinking about an informed tree preservation plan at the beginning phases of a project.

[READ | "Why BIM Is Taking Over Landscape Architecture"](../../../net/vectorworks/blog/why-bim-is-taking-over-landscape-architecture.html)

## 2\. BIM Leads to Greater Creativity

Maybe you've heard that BIM is too rigid and stifles your creativity. A BIM workflow helps automate tedious processes, so it actually affords you more time for creative endeavors. Automating data management processes and coordinating your file with others frees up time for you to focus on the more creative aspects of design with more informed decisions.

“BIM has allowed us to really straighten out our design process,” said Eric Berg of Pacific Coast Land Design. “Instead of committing tons of resources to Illustrator and InDesign and having to update the CAD drawing simultaneously — which was very tedious — we’re producing the CAD drawing in Vectorworks and producing renderings and reports directly from that drawing. It’s a much more linear process.

## 3\. Multifunctional, Purpose-Built BIM tools

You can start a project creating shapes and forms just as you always have, and then those objects can quickly be converted to smart BIM objects containing important data. For instance, you may draw a 2D shape in schematic design that you convert to an intelligent hardscape object in the design development phase.

Using the right BIM tools in this way allows you to reap the benefits in every design phase.

## 4\. Smarter Documentation

Creating a 3D model that operates as a project’s single source of truth allows you to generate multiple views and types of drawings directly from the model instead of having to create them separately, which is a _huge_ time saver.

## 5\. The Need for Coordination & Collaboration

The variety of import, export, and reference options makes [Vectorworks Landmark](http://vectorworks.net/landmark) a great collaboration tool. Automatic IFC designations on BIM objects sets you up to participate in Open BIM processes with other consultants.

## 6\. Simplified Revision Management

The “information” aspect of building information modeling grants you some tremendous benefits when it comes to revision management. In Vectorworks Landmark, appended data are editable later at any point in the design process, and changes will be automatically reflected across the entire file. It In this way, a BIM process with Landmark drastically lowers the time it takes you to make revisions.

## Do More with BIM in Vectorworks Landmark

It’s easier to get started with BIM than you might think. The webinar linked below expands on this concept — you’ll see plenty of tips for adopting these intelligent workflows. Check it out:

[![MORE STRATEGIES FOR ADOPTING BIM](https://no-cache.hubspot.com/cta/default/3018241/b060309b-f74f-41ca-bf39-1a29cc4be8b7.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/b060309b-f74f-41ca-bf39-1a29cc4be8b7) 

 Topics: [BIM (Landscape)](https://blog.vectorworks.net/topic/bim-landscape) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.