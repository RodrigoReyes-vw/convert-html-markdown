[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Architecture Webinars You May Have Missed

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 9 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/210113_JanuaryWebinars/blog-images-resize-jan-bldg-webinar.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Farchitecture-webinars-2021)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Architecture%20Webinars%20You%20May%20Have%20Missed&url=https%3A%2F%2Fblog.vectorworks.net%2Farchitecture-webinars-2021&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Farchitecture-webinars-2021)

When you look back on the past 12 months, what are you thankful for? What are you proud of? At Vectorworks, we’re proud of the learning opportunities we provided to the architecture, [site](../../../net/vectorworks/blog/landscape-design-webinars-2021.html), and [entertainment](../../../net/vectorworks/blog/entertainment-design-webinars-2021.html) design industries.

Many of these courses are also approved for continuing education credits, making them a great way to meet any requirements you might have by the end of the year!

 Without further ado, let’s take a look back at 2021’s architecture webinars. 

###### Experience Enscape & Enhance Your 3D Modeling and Rendering Workflow

Take your projects and presentations to the next level by creating high-quality renderings and visualization with Vectorworks and Enscape 2.9\. You’ll discover the benefits and how to visualize with this easy to use, seamless real-time rendering integration. Additionally, you’ll optimize and enhance your workflow. This way, you’ll have more time to create and innovate. 

Kaj Burival and Pourya Arami will lead you through incredible 3D design.

![blog-images-resize-jan-bldg-webinar](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210113_JanuaryWebinars/blog-images-resize-jan-bldg-webinar.jpg?width=1440&name=blog-images-resize-jan-bldg-webinar.jpg)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/41fe7070-b90f-4498-b2a0-a851beecad5b.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/41fe7070-b90f-4498-b2a0-a851beecad5b) 

###### Algorithmic Design in BIM Software

In this webinar, we go over some basics of algorithmic modeling, give examples of scripts that you can build in BIM software, and look at some real-world algorithmic modeling success stories.

This course is approved for one AIA LU.

![moveART-1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/180709_moveART/moveART-1.jpg?width=1440&name=moveART-1.jpg)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/b434ef4f-760c-40d6-91e0-fa61eb3bf32f.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/b434ef4f-760c-40d6-91e0-fa61eb3bf32f) 

###### Rendering for Everyday Architectural Drawing

Architects need to produce drawings that are both graphically accurate and full of information, so everyday documentation processes need to be adjusted to meet these requirements while saving time and money. 

Join Wes Gardner, Assoc. AIA, senior product specialist at Vectorworks, Inc., as he details how to not only impress your client, but also accurately communicate your design intent with contractors and project stakeholders.

This course is approved for one AIA LU, CORE AIBC, and AAA.

![4747-2003-webinar-bldg-april-design-rise-thumbnail-1680x945-1](https://blog.vectorworks.net/hs-fs/hubfs/4747-2003-webinar-bldg-april-design-rise-thumbnail-1680x945-1.jpg?width=1440&name=4747-2003-webinar-bldg-april-design-rise-thumbnail-1680x945-1.jpg)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/9631ffb6-efce-4ada-8bf5-239a6d6175dd.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/9631ffb6-efce-4ada-8bf5-239a6d6175dd) 

###### Improving Building Delivery with BIM

Deliver better buildings faster and for less money with BIM. The biggest advantage of BIM capabilities lies with the owner. Our industry needs to continue to develop our delivery methods through the use of BIM, which provides the ability to serve our clients better by establishing budgets much earlier in the process, reducing risk to the owner and virtually eliminating the “VE Stage” of a project. In this webinar, learn how to use BIM to accelerate schedules by involving sub-consultants earlier into our process and to reduce the cost through the elimination of the constant “round up” that takes place through the current system.

This course is approved for one AIA LU, CORE AIBC, AAA, OAA, ALBNL, AANB, and NSAA. 

![2104-us-april-webinar-blog-images-bldg](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210408_April%20Webinars/2104-us-april-webinar-blog-images-bldg.jpg?width=1440&name=2104-us-april-webinar-blog-images-bldg.jpg)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/ebb48638-cb6f-44bc-956f-6fde9f3cec97.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/ebb48638-cb6f-44bc-956f-6fde9f3cec97) 

###### Residential Interior Drawings: Home Theater

During COVID times, going out to movies and theaters has been put on hold. Just like home offices are a new trend, architects, designers, and contractors have seen a spike in new commissions based on renovating and transforming dead spaces into family entertainment rooms. In a new webinar series for residential interiors, Wes Gardner, senior product specialist at Vectorworks, Inc., shows how you can get these projects started in record time by adopting a new approach to producing drawings and takeoffs. If you are already familiar with digital drafting and have started integrating 3D modeling into your daily workflow, then this is the webinar for you.

This course is approved for one AIA LU, CORE AIBC, AAA, OAA, ALBNL, AANB, and NSAA. 

**![5427-2103-webinar-bldg-may-residential-interior-drawings-home-theater-rise-cover-image-1680x1120](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210506_May%20Webinars/5427-2103-webinar-bldg-may-residential-interior-drawings-home-theater-rise-cover-image-1680x1120.png?width=1440&name=5427-2103-webinar-bldg-may-residential-interior-drawings-home-theater-rise-cover-image-1680x1120.png)**

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/c622aeca-f94c-4032-9326-21b435982b90.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/c622aeca-f94c-4032-9326-21b435982b90) 

###### Streaming Workflows for Data-Driven Documentation

Spend more time designing and less time documenting by transitioning from a 2D to a 3D workflow. The benefits go beyond visualization aspects of 3D modeling. Creating a Building Information Model (BIM) will allow you to largely automate your workflow because BIM objects have built-in data that can be extracted using documentation tools. Sarah Barrett, Associate AIA and Senior Architect Product Specialist of Vectorworks will be explaining the purposes of the tools as well as how to efficiently document your model. Join this webinar to maximize your data automation and leverage smart tools for documentation and drawing. 

This course is approved for one AIA LU, CORE AIBC, AAA, OAA, ALBNL, AANB, and NSAA. 

![2105-june-bldg-webinar-rise-cover-image-1680x1120](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210609_June%20Webinars/2105-june-bldg-webinar-rise-cover-image-1680x1120.jpg?width=1440&name=2105-june-bldg-webinar-rise-cover-image-1680x1120.jpg)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/387f9f30-1f5d-4ab1-b221-1cdb80c5a602.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/387f9f30-1f5d-4ab1-b221-1cdb80c5a602) 

###### Residential Interior Drawings: Kitchen

Due to COVID-19, people are spending more time at home. Therefore, many have found inspiration to remodel and improve some of their most-used rooms. Kitchens, for example, have become a multifunctional space, and this webinar will help you work on those little details. 

As part of our new webinar series for residential interiors, join Kesoon Chance, industry specialist at Vectorworks, Inc. and Stephan Mönninghoff, co-owner of extragroup, to explore how to design your space to suit your needs. This webinar will showcase the process of custom designs from conceptual modeling with extrudes, development with the parametric cabinets, to construction details with interiorcad within Vectorworks.

![2106-july-bldg-webinar-images-rise-cover-image-1680x1120](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210707_July%20Webinar/2106-july-bldg-webinar-images-rise-cover-image-1680x1120.jpg?width=1440&name=2106-july-bldg-webinar-images-rise-cover-image-1680x1120.jpg)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/f303c2e6-4e84-44f2-9ba4-fe33dbb97239.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/f303c2e6-4e84-44f2-9ba4-fe33dbb97239) 

###### Energy Modeling in the Early Design Phase

Climate change and sustainable designs are at the forefront of today’s conversation. When doing sustainable and energy-efficient design, integrated design tools can help you be more efficient and make quicker decisions during design phases. In this webinar, you’ll learn how to assess the energy performance of a building very early on in an integrated design process — this gives architects the power to make informed design decisions, as well as the ability to back those decisions up.

This course is approved for one AIA HSW LU.

![blog-1440x800-3](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210729_August%20Webinar/blog-1440x800-3.png?width=1440&name=blog-1440x800-3.png)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/10269766-e542-4ac0-b766-18204e135770.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/10269766-e542-4ac0-b766-18204e135770) 

###### Site Planning and Modeling for Architects

Understanding site conditions and their relationship to the built environment is critical to successful architectural design. Having the ability to accurately represent, coordinate, and integrate site conditions into your workflow will increase opportunities for design and overall project success. You’ll examine various tools for successful planning and modeling of sites, from the planning phase all the way through to construction documentation.

This course is approved for one AIA LU.

**![5011-2006-webinar-bldg-july-rise-cover-image](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210827_September%20Webinar/5011-2006-webinar-bldg-july-rise-cover-image.jpg?width=1440&name=5011-2006-webinar-bldg-july-rise-cover-image.jpg)**

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/7c0c4046-b0ad-49d2-93b7-3c3d24d2cef8.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/7c0c4046-b0ad-49d2-93b7-3c3d24d2cef8) 

###### Model Validation and Collaboration Process for BIM

Model validation and coordination are a huge benefit of a BIM workflow. And such processes are becoming even more efficient, thanks to the construction industry rapidly adopting new technologies for better integrated project delivery. In this webinar, we’ll discuss the BIM adoption strategies used by Studio Partington, as well as how new technologies helped them provide better quality models for collaboration in their Open BIM process.

Vectorworks’ partnership with its Nemetschek sister company, Solibri, brings Vectorworks Architect users a new Solibri Direct connection. Discover how Solibri office can help you create more reliable and accurate models for validation, checking, and coordination.

![rise-cover-image-1680x1120 (1)](https://blog.vectorworks.net/hs-fs/hubfs/rise-cover-image-1680x1120%20(1).png?width=1440&name=rise-cover-image-1680x1120%20(1).png)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/7e620fc5-e1d4-4937-a41b-78459de97016.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/7e620fc5-e1d4-4937-a41b-78459de97016) 

###### Revolutionize Your Rendering with Vectorworks and Twinmotion

Join Jonathan Reeves, UK architect and real-time rendering expert, to see how easy it is to upgrade your presentations with renderings, animations, and interactive cloud presentations. Reeves will also show how Vectorworks’ 3D models can be developed, exported to Twinmotion, and easily updated to create interactive presentations for clients.

You’ll learn how to refine textures and lighting to produce photo-realistic renderings, as well as how to add context to high-quality animations with landscape, plantings, and entourage.

Those with Vectorworks 2022 can benefit from the new Twinmotion Direct Link with a free Twinmotion license. The offer is valid through March 31, 2022\. You can find the details and get your redemption code in the Vectorworks Customer Portal. 

![rise-thumbnail-1680x945](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211111_November%20Webinars/rise-thumbnail-1680x945.png?width=1440&name=rise-thumbnail-1680x945.png)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/685de9b2-bd5a-46ae-9aff-24de1e73eb81.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/685de9b2-bd5a-46ae-9aff-24de1e73eb81) 

###### BIM Has Always Been Here

Building Information Modeling (BIM) is often mistaken as a relatively new workflow, but it’s been around far longer than many of us know. BIM — at its most basic level — is a combination of geometry and data, which designers have been using for millennia.   
  
This webinar explores the history of BIM, examines the tools influencing current BIM workflows, and offers a glimpse into future technologies for designers.

This course is approved for one AIA LU, CORE AIBC, AAA, OAA, ALBNL, AANB, and NSAA. 

![December BLDG Webinar Image](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211208_December%20Webinar/December%20BLDG%20Webinar%20Image.png?width=1440&name=December%20BLDG%20Webinar%20Image.png)

[![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/c23b135c-f03e-4536-b7ec-106a002ecaed.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/c23b135c-f03e-4536-b7ec-106a002ecaed) 

With 2022 right around the corner, be sure to stay tuned-in to [Vectorworks University](https://university.vectorworks.net/) for a variety of webinars that’ll help you grow as a designer.

 Topics: [Resources](https://blog.vectorworks.net/topic/resources) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.