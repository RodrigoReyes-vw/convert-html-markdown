[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Underrated Vectorworks Features | Clip Cube

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2022%20PVW%20Images/08_Clip%20Cube/blog-1440x800%20%281%29%20copy%202.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fcould-this-be-the-coolest-vectorworks-feature)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Underrated%20Vectorworks%20Features%20|%20Clip%20Cube&url=https%3A%2F%2Fblog.vectorworks.net%2Fcould-this-be-the-coolest-vectorworks-feature&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fcould-this-be-the-coolest-vectorworks-feature)

Looking for some simple ways to be more efficient with Vectorworks? Then you’ll love the Clip Cube tool!

#### What Is Clip Cube?

The Clip Cube tool allows you to cut away at a 3D model through a see-through cube. Each face of the cube is draggable, giving you six distinct directions from which to clip the model. Clipping the model is strictly a viewing option, meaning anything you clip away will still be intact once you deactivate the tool. 

#### What Can I Do with Clip Cube?

###### Model Exploration

Clip Cube is simple way to explore a design; you can clip the model to focus on a particular spot, reducing clutter around the targeted area.

![Screen Shot 2022-07-15 at 10.23.23 AM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/08_Clip%20Cube/Screen%20Shot%202022-07-15%20at%2010.23.23%20AM.png?width=355&name=Screen%20Shot%202022-07-15%20at%2010.23.23%20AM.png)![Screen Shot 2022-07-15 at 10.22.09 AM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/08_Clip%20Cube/Screen%20Shot%202022-07-15%20at%2010.22.09%20AM.png?width=372&name=Screen%20Shot%202022-07-15%20at%2010.22.09%20AM.png)

Above, the left image shows the top face of the Clip Cube selected and the right image shows the building’s top floor after clipping away the roof.

###### TIP: Add Clip Cube to your toolbar at the top right of your screen to access it quickly. 

![Screen Shot 2022-07-29 at 8.49.00 AM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/08_Clip%20Cube/Screen%20Shot%202022-07-29%20at%208.49.00%20AM.png?width=495&name=Screen%20Shot%202022-07-29%20at%208.49.00%20AM.png) 

Only visible geometry is snappable when using the Clip Cube. This can give you greater control if you want to focus on a particular room of a large residential project like the pictured one.

The Clip Cube faces will automatically encompass the model in its entirety, or you can select a few objects before activating the tool to have the cube trim down to just those objects, granting you greater precision. Additionally, if you need to modify the positioning of the Clip Cube, you can click and drag the center of the cube or even rotate it for when your building is not following a standard 90-degree grid.

###### Create Saved Views

You can also use Clip Cube to quickly create focused views of your model and save them to reference later. Do so with View > Save View and select the Save View Orientation option. This is a fast way to essentially place a bookmark into the model.

###### Create Viewports

Clip Cube is also useful to create viewports of the model. Just clip away excess geometry, position the model how you want it to appear in the viewport, then create a viewport as normal with View -> Create Viewport. Make sure the Display with Clip Cube box is checked in the popup dialog box.

![Screen Shot 2022-07-28 at 12.14.16 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/08_Clip%20Cube/Screen%20Shot%202022-07-28%20at%2012.14.16%20PM.png?width=671&name=Screen%20Shot%202022-07-28%20at%2012.14.16%20PM.png)

###### Create Section Viewports

Clip Cube can help create section viewports quickly and easily. This is arguably the most underrated use of Clip Cube. Here’s how to do it:

1. Clip out geometry you don’t want showing in the section.
2. Select either a vertical or horizontal cube face.
3. Right click on the selected face and click the **Create Section Viewport** command from the pop-up menu.
4. Create the viewport on a sheet layer or a design layer.

![Screen Shot 2022-07-15 at 10.55.32 AM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/08_Clip%20Cube/Screen%20Shot%202022-07-15%20at%2010.55.32%20AM.png?width=653&name=Screen%20Shot%202022-07-15%20at%2010.55.32%20AM.png)

You can find more information about [creating vertical section viewports here](https://app-help.vectorworks.net/2019/eng/VW2019%5FGuide/Viewports1/Creating%5Fa%5FVertical%5FSection%5FViewport.htm#XREF%5F63407%5FCreating%5Fa) and more information about [creating horizontal section viewports here](https://app-help.vectorworks.net/2019/eng/VW2019%5FGuide/Viewports1/Creating%5Fa%5FHorizontal%5FSection%5FViewport.htm#XREF%5F64726%5FCreating%5Fa).

###### Modify Viewport Visibilities

Clip Cube functions within viewports as well. On a sheet layer, right click a viewport and click Edit. Make sure Display with Clip Cube is checked, then click OK. You’ll then be able to quickly clip away at the viewport geometry to optimize what you want showing.

#### Discover Other Hidden Gems in Vectorworks

There are plenty of other underrated and underused features in Vectorworks. Read about a few of them here and discover some fresh ways to increase your efficiency:

[![READ: HIDDEN TREASURES IN VECTORWORKS](https://no-cache.hubspot.com/cta/default/3018241/e0e3a41e-9123-46df-b155-0e5462597f08.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/e0e3a41e-9123-46df-b155-0e5462597f08) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.