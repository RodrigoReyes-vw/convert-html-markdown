[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Training & Insight on Vectorworks 2023 Features

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/221201_December%20Tech%20Round%20Up/blog-1440x800_December%20Tech%20Round%20Up.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fexperts-want-you-to-know-these-vectorworks-features)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Training%20&%20Insight%20on%20Vectorworks%202023%20Features&url=https%3A%2F%2Fblog.vectorworks.net%2Fexperts-want-you-to-know-these-vectorworks-features&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fexperts-want-you-to-know-these-vectorworks-features)

New features and upgrades in your design software can be intimidating. After all, you’ve worked so hard to develop your process that it can feel uncomfortable to modify it.

Vectorworks experts, however, are here to tell you that new features aren’t as difficult to incorporate as you might think — plus, they’ll bring you multiple efficiencies!

In this post, you’ll find videos explaining a few of the new [Vectorworks 2023](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) features and upgrades. You’ll also learn how these features can benefit you greatly on your next project.

## Kesoon Chance, Industry Specialist – Interior Architecture 

### Graphic Legends

“This new feature will become an essential part of your workflow, whatever industry you are in!

[Graphic legends](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Annotation2/Graphic%5Flegends.htm?rhsearch=graphics%20legend&rhhlterm=graphic%20legends%20legend), available in Design Series products, make it simple to create annotated graphic legends and schedules on sheet layers. The Recalculate button refreshes the legend whenever new criteria are specified or new resources are added to the drawing.

The tool is also a style-based resource, meaning you can generate customized looks to share across your team for different legend types — for example lighting legends, slab legends, window legends, or even symbol legends. Whatever you want to annotate, this tool will surely save you time!”

## Luis M. Ruiz, Senior Architect Product Specialist

### Shaded Rendering

“The improvements to our [shaded rendering options](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Rendering1/Shaded%5Foptions.htm?rhhlterm=shaded%20options%20option&rhsearch=shaded%20options) seem to be lots of designers’ favorite new upgrade. 

3D models are just so much fun to work with. We can now see the reflections from the materials, and we can also now appreciate the environmental light, the infinite number of light objects, the shadows, the amazing gobo shapes, and more! 

Typically, the first impression I get when I open a demo file and show it live is, ‘Wow!’ I purposely keep the old shader mode and slowly I start adding the new options and then proceed to navigate around the model.

People are stunned by the quality and how rich the designs look. ‘Is that still a rendering?’ they ask.”

## Jim Woodward, Entertainment Industry Specialist

### Offset Edge Tool 

“One new feature I think everyone should be using is [the new Offset Edge tool](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Shapes3/Direct%5Fmodeling%5Fwith%5Fthe%5FOffset%5FEdge%5Ftool.htm?rhhlterm=offset%20offsets%20offsetting%20edge%20edges&rhsearch=offset%20edge). It’s one of my favorite things in Vectorworks 2023!

If you’re a designer in the entertainment industry, the Offset Edge tool can quickly create things like custom steps, piping inserts for LED tape, and more. The tool allows you to model parts that would have previously been time-consuming to create.

It opens up a whole new level of creative freedom with amazing results that you can achieve quickly.”

## Katarina Ollikainen, Landmark Product Planner 

### Hedgerow Tool

“[The Hedgerow is the perfect new landscape tool](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Plants2/Creating%5Fa%5Fhedgerow.htm?rhsearch=hedgerow&rhhlterm=hedgerow) — it allows you to specify mixed hedging in a very intuitive way and works both in 2D and 3D. If you’re placing it over a site model, it automatically follows the surface, and you can specify the hedge in plants per linear meter instead of area. This means that you can visualize the hedge at mature width without changing the quantities.

Designers should use this new tool because it gives you a single solid 3D object (perfect for IFC export if you’re working in BIM), and it's exceedingly useful for illustration. It’s a perfect example of a simple tool that makes a huge change for our users when it comes to their everyday work.”

## Tom White, UK Spotlight Specialist

### ConnectCAD Improvements 

"Speed and user experience have been some of the main focuses of the 2023 release; now, you’ll be able to edit a device's socket directly from the design layer in [ConnectCAD](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/ConnectCAD/ConnectCAD.htm?rhhlterm=connectcad%20connectcad%C2%AE&rhsearch=connectcad).

Adapter objects can now be added into a socket or existing circuit with a single click, and created equipment can automatically place itself into the correct rooms within the model, saving you hours of time in moving equipment around." 

## Need Software Help? Visit the Vectorworks 2023 Online Help!

Whether you want more tips on specific tools, or help getting started in Vectorworks, the Vectorworks Online Help is a great place to visit. Click the button below to check it out:

[![HOW CAN WE HELP?](https://no-cache.hubspot.com/cta/default/3018241/0cf81699-5087-441b-bdfb-60caaab0d1e0.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/0cf81699-5087-441b-bdfb-60caaab0d1e0) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.