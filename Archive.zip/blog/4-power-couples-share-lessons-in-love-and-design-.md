[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# 4 Power Couples Share Lessons in Love — and Design 💕

 Posted by [Lauren Burke Meyer](https://blog.vectorworks.net/author/laurenburke) | 13 min read time 

![vw_valentines-day](https://blog.vectorworks.net/hubfs/vw_valentines-day.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2F4-power-couples-share-lessons-in-love-and-design-)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=4%20Power%20Couples%20Share%20Lessons%20in%20Love%20—%20and%20Design%20💕&url=https%3A%2F%2Fblog.vectorworks.net%2F4-power-couples-share-lessons-in-love-and-design-&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2F4-power-couples-share-lessons-in-love-and-design-)

This Valentine’s Day, we caught up with a handful of our users who work alongside their significant others. With stories sweeter than candy, we wanted to get you into the holiday spirit by showing how their partnerships translated to career success. You’ll also discover some secrets and tips to balancing a successful modern day working/personal relationship.

![vw_valentines-day](https://blog.vectorworks.net/hs-fs/hubfs/vw_valentines-day.jpg?width=600&name=vw_valentines-day.jpg)

## ROOTBOUND: GARTH & LANI

For Garth and Lani Woodruff, their love story began in high school when Lani was a sophomore and Garth was a junior. The high school sweethearts explored different professions in college. Garth studied landscape architecture, and Lani went for physical therapy, earning a BS degree in Health and Wellness before deciding it wasn’t the best fit for her career. She later went back for a BS degree in Horticulture with an emphasis in Landscape Design. 

Now, the two run [RootBound](http://www.rootbound.com/), a custom landscape design studio based in southwest Michigan. It’s a family affair for the Woodruffs with their two sons, Foster and Hudson. Their oldest, Foster, is even studying landscape architecture in college, just like his father.

“Having our own business and having our partnership while raising kids was just unbelievable,” said Lani. “It made it so much easier, the kids stayed with us all the time, and we were able to travel easily.”   
  
![Garth and Lani](https://blog.vectorworks.net/hs-fs/hubfs/Garth%20and%20Lani.png?width=399&name=Garth%20and%20Lani.png)

_Garth and Lani Woodruff of RootBound at the Chinese Garden in Portland._

Seven years ago, Garth was recruited to teach environmental and landscape design at Andrews University in Southwest Michigan, and the couple thought that it might be time to finally separate their working relationship — but there was no way to do it. 

According to Garth, “We both have unique contributions to the design role, so I suspect some of that is serendipity. Also, some of it might actually be learned because we grew up together, and then we learned a trade together later—filling roles that work for us to the point where now it makes more sense for us to be together than apart.” 

The couple uses two tools in particular to help with their collaboration: [Vectorworks Landmark design software](https://www.vectorworks.net/en/landmark?utm%5Fcampaign=blog&utm%5Fcontent=valentinesday021319&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext) and Google Drive. Through these technologies, they can maintain all of their client documents in order to share and work on documents simultaneously. 

In their twenty years of working together, the Woodruffs have learned valuable lessons in balancing their working and personal relationships. As far as advice for other couples, Garth explained how important transparency and communication are. “If you don’t want to talk about it, or you’re angry, it’s probably more important that you do talk about it,” Garth said. Lani agreed and added, “At the same time, boundaries are healthy too. And for us, that means agreeing to not bring the job home sometimes.”

## HAMILTON + AITKEN ARCHITECTS: CHAD & SUSAN

Founders and Principals at [Hamilton + Aitken Architects](http://haarchs.com/), Chad Hamilton, AIA, LEED AP BD+C, and Susan Aitken, AIA, LEED AP BD+C met in architecture school at California Polytechnic State University in San Luis Obispo, California, but didn't start dating until their last year of school. After moving to San Francisco, they had always worked at different firms. They later moved to New York while Chad worked on a master's degree at Columbia, then took advantage of a traveling fellowship to spend three months together in Europe. Returning to San Francisco, they both continued to work at different firms.

![IMG_5313](https://blog.vectorworks.net/hs-fs/hubfs/IMG_5313.jpg?width=588&name=IMG_5313.jpg)_Hamilton + Aitken Architects Founders and Principals_ _Chad Hamilton and Susan Aitken._ 

In 1992, the couple had the opportunity to renovate an office building in Palo Alto, and used that as a way to start their own firm, Hamilton + Aitken Architects. With two young children, Susan had already been working as a consultant, so the transition made a lot of sense. Even though the early days were difficult financially, Susan took advantage of an opportunity to work for several years with Lawrence Halprin on the FDR Memorial, while they were building their business. Later, Halprin became a client, and Hamilton + Aitken Architects designed architectural elements for several of his projects.

Fast forward to today. Chad and Susan recognize that like all good teams, it's important to balance each other's strengths and weaknesses, while giving each other space to work on their own projects without stepping on each other’s toes. They frequently collaborate to develop design ideas or solve design problems; however, they rarely work on the same project at the same time. Not only is it hard to staff a project with two principals, but also, more importantly, they like each partner to have their own projects. Susan explained, “Sometimes we change projects, usually to balance the workload or a partner’s skills, and we frequently share clients or project leads.”

“The best part of working together is spending time together and sharing the ups and downs of developing a design firm from the ground up,” said Susan. “We've grown from two people with a drafting board and one computer to an 18-person firm with large, complex projects. We share credit for design awards, because collaborating is such an important part of the way we work.”

In terms of advice for other couples, Chad and Susan have these words of wisdom:

* **It’s ok to take the job home with you**: most couples seem to talk with each other about what happened in their work day. It's nice to have someone who can understand and relate to what the other is going through.
* **Keep home life separate from the office**: We refer to each other as a partner in the firm and in our work lives, never as a spouse, and we behave professionally.
* **Understand each partner's diverse strengths**: good partners complement one another’s strengths and weaknesses. Use them to your advantage. With us, one partner is the strategist, and the other is the detail person.
* **Have fun and a sense of humor**: Everything won’t go right all the time. There will be ups and downs, people will make mistakes, there will be economic good times and bad. It helps to maintain perspective and not let it overwhelm you and sharing this with someone you love can make it easier.

## LAND2C: TIM & KAT

Tim and Kat King of [Land2c Landscape Architecture](https://www.land2c.com/) met in college. Kat was finishing a master’s degree in education while Tim was earning a degree in business administration. After both graduated, they married and moved to Seattle, Washington, where they have lived and worked for over 40 years. 

After working in the business sector for a few years, Tim shifted gears and went back to college to study Landscape Architecture at the University of Washington, working independently in the landscape architecture field shortly after earning his degree. Kat retired from teaching and went back to college for two years in horticultural design to join Tim at Land2c. In the 14 years they’ve worked together, Kat and Tim have built their business specializing in difficult sites and upscale residential garden design.

![Kat and Tim King](https://blog.vectorworks.net/hs-fs/hubfs/Kat%20and%20Tim%20King.png?width=414&name=Kat%20and%20Tim%20King.png) _Kat and Tim King of Land2c Landscape Architecture._

From brainstorming design concepts to dealing with clients and contractors, Kat and Tim work together, taking responsibility for different aspects of projects. Tim focuses on the engineering, architectural, and spatial aspects of the design, while Kat handles planting and color palettes, as well as visual details such as pots, furniture, and art. Even though they mostly work independently, their frequent discussions ensure that each project is cohesive, using Vectorworks Landmark to integrate their workflow. After Tim is finished with the site plan, the file is saved to their network for Kat to add the plant and detail work. Then the site plan, planting plan, and detail classes/layers are joined into a completed master plan. 

According to Tim, “We have separate design studios in our home, so although we collaborate on each project, we each have our own work space.” Kat added, “We limit the number of design projects we accept at any one time to keep from becoming overscheduled.” 

They find making time for individual experiences to be very important and refreshing. Both enjoy working on their personal garden, entertaining, and traveling. Tim regularly golfs with his friends, while Kat reads and enjoys time with her friends. 

The Kings have different design strengths but share a similar design philosophy: although designing independently can be quite lonely, having a partner whose talent you admire to bounce ideas off is stimulating and rarely dull. 

## SALSBURY-SCHWEYER: SAMUEL AND SABRENA

Samuel and Sabrena’s love story had a somewhat juicy start: Samuel was actually on a date with another girl when he met Sabrena and instantly knew she was the one for him. They were at a party at a lake that turned into a magical evening, complete with Samuel singing Beatle’s songs to Sabrena, marshmallow making over the fire, canoe riding, and cookie baking.

Once they were able to go on a date with just the two of them, the magic continued. Similar to the plot of a modern-day Disney movie, the couple was sitting on the deck that Samuel had built by an ancient tree when creatures came out to visit. During dinner, birds came down and perched on the balcony. A raccoon family came up onto the edge of the deck. As Sabrena was leaving, a white skunk even came up to say hello. Mother Nature clearly was on board with these love birds. 

![IMG_1390](https://blog.vectorworks.net/hs-fs/hubfs/IMG_1390.jpg?width=498&name=IMG_1390.jpg)

_Samuel and Sabrena Schweyer_ _of_ _Salsbury-Schweyer, Inc._ _Photo by_ _Perennial Plant Association._

They soon learned their interests complemented each other. Initially, they had their own businesses. Sabrena was a garden designer, and Samuel was a builder and developer. It wasn’t long before Samuel was helping Sabrena with her business and filling gaps she’d been struggling with. 

They had a common vision of creating beautiful landscape sanctuaries that touch people’s souls every time they walk out the door, look out their window, or walk up their driveway. They approached this vision from different backgrounds, however. Sabrena focused on plants, ecology, and garden history. Samuel’s expertise in construction shines through in their partnership, as well as his knowledge on how to manage water, work with crews, and write contracts. He also brings his more creative side to the picture, using line and space to enhance the sacredness of each site. 

By combining their strengths and talents, the couple has been able to create landscapes with much more depth than if they were working alone. They can create the entire landscape: from walls and water systems, all the way to the finishing touches of art and detailed perennials and lighting. 

Finally, their well-balanced relationship comes in handy in managing client relationships. Typically, Sabrena meets with clients first and does what Samuel calls “her fairy dance,” which involves brainstorming possibilities with the client. Conversely, Samuel approaches projects like Frank Lloyd Wright; he’ll go to a job site and be extremely quiet because he doesn’t want anyone to talk to him or give him any preconceived ideas. 

When asked what other couples can learn from their experience, Sabrena explained that it was a struggle for them at first. “By having a strong support staff that we can delegate to, it now takes some of the pressure off each of us. That is key.” 

Want more love stories sparked by design? Read about some of our other favorite Vectorworks power couples.

[![Feel the Love](https://no-cache.hubspot.com/cta/default/3018241/a1aa5df1-652e-4843-8505-59ed90e67e41.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/a1aa5df1-652e-4843-8505-59ed90e67e41) 

 Topics: [Landscapes](https://blog.vectorworks.net/topic/landscapes) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.