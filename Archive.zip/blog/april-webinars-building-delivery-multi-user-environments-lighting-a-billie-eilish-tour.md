[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# April Webinars: Building Delivery, Multi-user Environments, & Lighting a Billie Eilish Tour

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/210408_April%20Webinars/2104-us-april-webinar-blog-images-ent.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fapril-webinars-building-delivery-multi-user-environments-lighting-a-billie-eilish-tour)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=April%20Webinars:%20Building%20Delivery,%20Multi-user%20Environments,%20&%20Lighting%20a%20Billie%20Eilish%20Tour&url=https%3A%2F%2Fblog.vectorworks.net%2Fapril-webinars-building-delivery-multi-user-environments-lighting-a-billie-eilish-tour&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fapril-webinars-building-delivery-multi-user-environments-lighting-a-billie-eilish-tour)

Continue your education and earn accreditation with Vectorworks’ monthly webinars. Whether you are a beginner or experienced designer, you can gain new skills, fine-tune workflows, and discover all you can do with Vectorworks. The more you know, the more you can create with Vectorworks.

###### Architecture: Improving Building Delivery with BIM

_Tuesday, April 20 @ 2 PM ET_

 Deliver better buildings faster and for less money with BIM. The biggest advantage of BIM capabilities lies with the owner. Our industry needs to continue to develop our delivery methods through the use of BIM, which provides the ability to serve our clients better by establishing budgets much earlier in the process, reducing risk to the owner and virtually eliminating the “VE Stage” of a project. In this webinar, learn how to use BIM to accelerate schedules by involving sub-consultants earlier into our process and to reduce the cost through the elimination of the constant “round up” that takes place through the current system.

Attendees are eligible for 1 AIA LU and 1 Core Learning Credit via AANB, ALBNL, NSAA, and AIBC.

[![SIGN ME UP](https://no-cache.hubspot.com/cta/default/3018241/46f57ccc-72a7-43ff-8768-0132575ceb29.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/46f57ccc-72a7-43ff-8768-0132575ceb29) 

![Visualized engineering systems in a 3D architectural model.](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210408_April%20Webinars/2104-us-april-webinar-blog-images-bldg.jpg?width=1440&name=2104-us-april-webinar-blog-images-bldg.jpg)

###### Entertainment Webinar: Powering Billie Eilish’s World Tour with GDTF/MVR

_Wednesday, April 21 @ 2 PM ET_

So, you’ve heard of MVR and GDTF, but what exactly can they do for your workflow? Join Tony Caporale, lighting designer at Infinitus Vox, to see how MVR and GDTF helped him create the award-winning lighting design for Billie Eilish’s Where Do We Go World Tour. Discover how using a combination of MVR and GDTF allowed Caporale to create a more unified workflow while keeping his focus on his design, not the tedious task of adapting new fixtures and devices in the lighting industry.

[![SIGN ME UP](https://no-cache.hubspot.com/cta/default/3018241/37d06e7c-bb76-449c-ac55-e3b2086c46a3.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/37d06e7c-bb76-449c-ac55-e3b2086c46a3) 

![Live shot of a suspended walkway at a Billie Eilish concert.](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210408_April%20Webinars/2104-us-april-webinar-blog-images-ent.jpg?width=1440&name=2104-us-april-webinar-blog-images-ent.jpg)

###### Landscape Webinar: Productive Remote Work Through BIM for Landscape

_Thursday, April 22 @ 2 PM ET_

At a time when more site design firms are working remotely, keeping separated team members productive is not only possible, it is more easily managed than ever. Join Eric Gilbey, PLA as he shares how a multi-user environment is a key benefit to working in BIM software. Gilbey will explore how it enables a more holistic approach to project management, and how proper file and team organization enables more seamless incorporation of site project updates.

Attendees are eligible for 1 LA CES PDH and 1 APLD CEU.

[![SIGN ME UP](https://no-cache.hubspot.com/cta/default/3018241/5aa12d8e-0bbb-4057-8e5d-2df4f84b071a.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/5aa12d8e-0bbb-4057-8e5d-2df4f84b071a) 

![A landscape architecture project in design software that involves multiple users in the same file.](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210408_April%20Webinars/2104-us-april-webinar-blog-images-land.jpg?width=1440&name=2104-us-april-webinar-blog-images-land.jpg)

 Topics: [Events](https://blog.vectorworks.net/topic/events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.