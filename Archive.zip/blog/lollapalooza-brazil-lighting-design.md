[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Lollapalooza Brazil’s Rocking Design

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/220718_lalapalooza%20Brazil/Lalapalooza%20Brazil%20Vectorworks_1.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Flollapalooza-brazil-lighting-design)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Lollapalooza%20Brazil’s%20Rocking%20Design&url=https%3A%2F%2Fblog.vectorworks.net%2Flollapalooza-brazil-lighting-design&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Flollapalooza-brazil-lighting-design)

Music festivals such as [Coachella](https://www.coachella.com/), [Primavera Sound](https://www.primaverasound.com/es), and [Tomorrowland](https://www.tomorrowland.com/home/) are beginning to take place all around the world.

These festivals aren’t only a great way to feel community and watch live music. They’re also an opportunity for designers to show off their hard work.

In this post, you’ll read about Erich Bertti and his junior associate, Victor Auricchio, who created the stellar lighting designs for this past year’s [Lollapalooza Brazil music festival](https://www.lollapaloozabr.com/).

## Lighting Design for Lollapalooza 2022

Bertti and Auricchio have worked with some jaw-dropping names in the music scene like Motorhead, Sepultura, Joss Stone, and — most recently — Ghost. Additionally, the Brazilian duo have been involved in [theatrical, corporate, and architectural lighting projects](https://www.instagram.com/erichbertti/?hl=en).

Bertti and co. tackle this variety of projects with a commitment to Vectorworks as their design software. “Vectorworks merges all the needs we have from clients,” said Bertti. The lighting veteran also noted that many of the consultants they work with use other software, so Vectorworks’ ability to work alongside different platforms is crucial.

Bertti began using Vectorworks in 2012, while he was still working for another firm and not yet leading his own independent design team. It was at this firm where Bertti first began working on the lighting designs for Lollapalooza Brazil. Each year, Bertti and Auricchio have created sharp and professional lighting plans.

> [  View this post on Instagram ](https://www.instagram.com/p/CbuqjUbuhm0/?utm%5Fsource=ig%5Fembed&utm%5Fcampaign=loading) 
> 
> [A post shared by Erich Bertti (@erichbertti)](https://www.instagram.com/p/CbuqjUbuhm0/?utm%5Fsource=ig%5Fembed&utm%5Fcampaign=loading)

Bertti and Auricchio’s design boosted the already-sky-high anticipation and drama of the festival’s return, thanks to a complex rigging structure, pyrotechnics, and a geometric lighting design.

![Lalapalooza Brazil Vectorworks_1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220718_lalapalooza%20Brazil/Lalapalooza%20Brazil%20Vectorworks_1.png?width=1440&name=Lalapalooza%20Brazil%20Vectorworks_1.png)The pair’s design process is a collaborative one — with Bertti handling the creative vision, and Auricchio doing the technical drawings and light plots.

Just as Vectorworks is the linchpin of the duo's collaborative process with clients and consultants, it’s also the most important tool internally. “We gather _everything_ in Vectorworks first,” said Bertti.

## Creating “A Pattern of Quality” with the Help of Vectorworks

As impressive as Bertti and Auricchio's work for the festival is, it’s made even more special once Bertti shared that they’re the only third-party team brought in to do lighting design.

The tandem always works on the lighting for “Perry” stage, one of Lollapalooza Brazil’s multiple stages. The reason being is that one year they had lost the gig, but, according to Bertti, Perry, whom the stage is named after, asked someone, “What happened to the show this year?”

Once Perry learned that a different designer had been given the job, he asked that Bertti and Auricchio be put back in charge of the stage’s lighting.

Bertti is proud of this anecdote, as it validates — as he puts it — “a pattern of quality” in their work.

![Lalapalooza Brazil Vectorworks_2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220718_lalapalooza%20Brazil/Lalapalooza%20Brazil%20Vectorworks_2.jpg?width=1440&name=Lalapalooza%20Brazil%20Vectorworks_2.jpg)

But what creates such a pattern?

Certainly, it’s the pair's desire to grow and learn as designers. In fact, when he first entered the live events industry, Bertti would spend nights at the office, taking advantage of the extra time to learn how to design with Vectorworks.

![Lalapalooza Brazil Vectorworks_4](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220718_lalapalooza%20Brazil/Lalapalooza%20Brazil%20Vectorworks_4.jpg?width=1440&name=Lalapalooza%20Brazil%20Vectorworks_4.jpg)

Inspired by Bertti and Auricchio's work? You too can hone your craft at Vectorworks University. Here, you’ll find tech tips and you can work your way towards certifications that prove your skills!

[![BROWSE VECTORWORKS UNIVERSITY](https://no-cache.hubspot.com/cta/default/3018241/80cc3a4d-d8da-4e1e-87d3-d9a3e929e246.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/80cc3a4d-d8da-4e1e-87d3-d9a3e929e246) 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.