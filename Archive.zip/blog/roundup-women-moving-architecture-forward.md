[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Roundup: Women Moving Architecture Forward

 Posted by [Rowena Winkler](https://blog.vectorworks.net/author/rowena-winkler) | 2 min read time 

![3+1-presentation](https://blog.vectorworks.net/hubfs/3+1-presentation.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Froundup-women-moving-architecture-forward)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Roundup:%20Women%20Moving%20Architecture%20Forward&url=https%3A%2F%2Fblog.vectorworks.net%2Froundup-women-moving-architecture-forward&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Froundup-women-moving-architecture-forward)

In honor of [Jeanne Gang](http://studiogang.com/people/jeanne-gang) recently being named on the [TIME 100 list](https://time.com/collection/100-most-influential-people-2019/5567842/jeanne-gang/), we wanted to highlight some more of our favorite women who are crushing it in the architecture industry.

###### Kimberly A. Dwyer at [Dwyer Architectural](https://www.dwyerarch.com/)

As managing partner and founder of the firm, Dwyer strongly advocated to be a part of the New York State Minority and Women Business Development program, leading to its WBE certification. The firm’s designs in the healthcare, medical research, and higher education fields have made a mark in the architecture industry under Dwyer’s leadership.

![Maternity Photo 1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190305_Dwyer%20Architectural/Maternity%20Photo%201.jpg?width=6000&name=Maternity%20Photo%201.jpg)

> _**"Being the new kid on the block, it was one way to get our firm looked at in a different way than our competitors. The certification continues to allow us opportunities including teaming with national firms that has offered us continued growth."**_

**[![Learn More About Dwyer](https://no-cache.hubspot.com/cta/default/3018241/ebdfb559-1258-438d-9b63-3ca3d1d6e7ef.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/ebdfb559-1258-438d-9b63-3ca3d1d6e7ef)** 

###### Lizzie Hinton at [bpr architects](https://bprarchitects.com/)

For over five years, this architect has been leading design projects for bpr, working in a variety of sectors for the firm with an intelligent approach to designing for clients. Structured around an employee ownership model, the UK-based firm shares a percentage of profits with everyone involved in the business, meaning everyone, including Hinton, is a partner. 

![The Ritterman Building](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/180405_bpr%20case%20study/The%20Ritterman%20Building.jpg?width=1500&name=The%20Ritterman%20Building.jpg)

> _**"You can see a building in context, see what it is happening, all its surroundings. Probably in more detail than in back in the day. So, you're not just thinking of the building by itself. At the same time, it must meet strategic needs. Think about the impact of what you are doing."**_

[![Read About bpr's Workflow](https://no-cache.hubspot.com/cta/default/3018241/c98f4190-a8ce-4a8c-bad3-f44813759b34.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/c98f4190-a8ce-4a8c-bad3-f44813759b34) 

###### Karen Lewis at [The M Group Architects + Interior Architects](https://www.mgrouparchitects.com/)

Lewis is a partner and interior designer who is responsible for programming, design development, furniture coordination, construction administration and oversight of construction document production at the firm. As a champion for collaboration and socialization in the workplace, she enjoys meeting the unique challenge of making office spaces functional but adjustable.

> **_"I love my career and I’m passionate about space that hopefully is for the betterment of people when they go to their work environment and I hope to pass that on to the next generation."_** 

 Topics: [BIM (Architecture)](https://blog.vectorworks.net/topic/bim-architecture) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.