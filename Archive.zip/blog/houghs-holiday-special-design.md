[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# JPConnelly Designs NBC's Holidays with the Houghs

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/211203_JPConnelly%20Houghs/10-23-2019_HolidayswithTheHoughs_001.jpeg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fhoughs-holiday-special-design)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=JPConnelly%20Designs%20NBC's%20Holidays%20with%20the%20Houghs&url=https%3A%2F%2Fblog.vectorworks.net%2Fhoughs-holiday-special-design&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fhoughs-holiday-special-design)

As the holiday season approaches, festive specials are a great way to be both merry and bright!

One of NBC’s holiday specials, [_Holidays with the Houghs_](https://www.nbc.com/holidays-with-the-houghs/video/behind-the-scenes-holidays-with-the-houghs/4085501), was designed by the talented James Pearse Connelly. 

###### Emmy Award-winning Production Design

Connelly, founder of [JPConnelly](http://jpconnelly.com/), is known for being one of the premier production designers for a variety of TV genres. Connelly and his team have received a [Primetime Emmy Award](https://www.emmys.com/), a Daytime Emmy Award, and several other nominations.

Founded in 2010, JPConnelly has grown from a two-person operation to a team of 13 full-time employees.

The production design firm has done work on some of television’s most popular shows: _RuPaul’s Celebrity Drag Race, The Voice, The Masked Singer, Top Chef_, and more!

But, it’s their work on NBC’s _Holidays with the Houghs_ that we’ll look at today.

###### Creating a Winter Wonderland 

The project was brought to Connelly after he and his firm were recommended to NBC. “When we kicked off,” he remembered, “it was a synchronous effort. We immediately hit a great concept right off the bat.”

This concept, which was inspired by a vintage postcard Connelly found, was “outdoor frozen winter lake.” The design featured a faux ice dance floor, an atmosphere-creating LED screen, and plenty of space for the program’s talented dancers.

While the design inspiration came quite easily, a major consideration for Connelly and his team was the project’s budget. “It’s not something I like to always make a priority, because it tends to hinder some of the creativity,” said Connelly. “But I’m really quite proud of what we achieved, because the design looked like a million bucks.”

![10-23-2019_HolidayswithTheHoughs_007](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211203_JPConnelly%20Houghs/10-23-2019_HolidayswithTheHoughs_007.jpg?width=1440&name=10-23-2019_HolidayswithTheHoughs_007.jpg)

Another consideration, along with budget, was the stage floor. With over an hour of dance, Connelly and company had to account for the safety and comfort of the dancers.

The floors were also perfectly smooth, without any nails or rivets. This was to protect barefoot dancers, as well as those on roller blades simulating ice skating. The most exciting innovation to the stage floor was the sub floor installed just beneath. A mainstay in all JPConnelly’s dance productions, this system creates bouncing effect for all the dancers to feel and use while performing.

###### Creating Impossible Designs with Vectorworks Spotlight

When speaking to the design of the stage floor, Connelly remarked, “Without Vectorworks, it would be impossible. It’s about the material thickness, stacking it up, understanding elevation, and how that kind of matches up with the rest of the space.”

As the industry-standard for production design, [Vectorworks Spotlight](https://www.vectorworks.net/spotlight) has always been a part of JPConnelly’s design workflow. It’s so engrained into the firms process, in fact, that Connelly said, “It’s sort of like dissecting your best friend in a couple sentences. You know what I mean? It’s a connector between all departments on a level that’s just easy to understand.”

At the start of his design process, Connelly often begins with simply a pencil and a piece of paper — a medium in which he finds it easiest to quickly express himself.

“Just think about the story and the concept,” he said, “and put it down on paper first. Nothing beats the connection when you’re thinking about the story you’re telling.”

After the “napkin sketch” Connelly and his team transform the story into a 3D Vectorworks model. Here, Connelly and his team members ultimately use the software as a tool to communicate their concept.

Designers will use screen shares to collaborate with other designers, but they’ll also use Vectorworks Spotlight to communicate to riggers, lighting designers, and — critically — stakeholders.

When designing the production for _Holidays with the Houghs_, JPConnelly had a “home run” with the stakeholders, said the designer. “Sometimes concepts happen in two, three, four, or five passes, but this one was right out of the gate.”

###### JPConnelly’s Design Freedom

Much like an A-list actor having the privilege to pick and choose their own roles, Connelly — given his reputation — can pick his own design concepts. This freedom is something that Connelly doesn’t take for granted.

![10-23-2019_HolidayswithTheHoughs_001](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211203_JPConnelly%20Houghs/10-23-2019_HolidayswithTheHoughs_001.jpg?width=1440&name=10-23-2019_HolidayswithTheHoughs_001.jpg)

“Sometimes, I don’t even believe how much freedom I get. Just the other day, a client didn’t like a design. And I said to my team, ‘That’s alright. They don’t know what they want. That’s why they come to us.’”

James Pearse Connelly has the freedom to come up with his design concepts because of his track record of excellence in the industry. And, other designers have the same freedom, thanks to Vectorworks Spotlight. Click the button below to read more stories on how Vectorworks can help you _design without limits™._

[![INSPIRE ME!](https://no-cache.hubspot.com/cta/default/3018241/19a71000-31f5-4d9f-bf56-b4d3e3c09009.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/19a71000-31f5-4d9f-bf56-b4d3e3c09009) 

 Topics: [Project Highlight](https://blog.vectorworks.net/topic/project-highlight) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.