[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Vectorworks 2023 Design & BIM Software Released

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 8 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2022%20PVW%20Images/09_2023%20Launch/2208-launch-signature-images-design-suite.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-2023-now-available)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Vectorworks%202023%20Design%20&%20BIM%20Software%20Released&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-2023-now-available&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-2023-now-available)

Vectorworks 2023 is now available for download! Keep reading to see how to get the new version.

At this point, you’ve seen us tease features surrounding [user experience](../../../net/vectorworks/blog/sneak-peek-user-experience-updates-in-vectorworks-2023.html), [BIM](../../../net/vectorworks/blog/bim-updates-in-vectorworks-2023.html), [BIM for landscape](../../../net/vectorworks/blog/sneak-peek-bim-for-landscape-updates-in-vectorworks-2023.html), [entertainment](../../../net/vectorworks/blog/spotlight-and-connectcad-updates-vectorworks-2023.html), and [interoperability](../../../net/vectorworks/blog/collaboration-updates-in-vectorworks-2023.html). You’ve also seen videos of members of the Vectorworks team discussing the major highlights, which you can watch again by navigating to the blogs linked in this paragraph.

The newest version of the design and BIM software brings game-changing upgrades centered around the theme of workflow acceleration. The new features and updates will streamline your process and give you more time to design.

The 2023 release applies to the Vectorworks product suite. English-language editions are available today, September 14, 2022.

[![GET YOUR VECTORWORKS 2023 TRIAL](https://no-cache.hubspot.com/cta/default/3018241/bbc9b28d-7586-46a0-98ed-43dc67ebe42b.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/bbc9b28d-7586-46a0-98ed-43dc67ebe42b) 

Let’s hear from Vectorworks Chief Technology Officer Steve Johnson about what the new version means for you.

> “We understand the importance and value of time and we’re excited to give some of this critical resource back to designers with Vectorworks 2023\. In our continued effort to empower our users to design without limits, our latest release boasts upgrades to essential tools that will lessen the need for manual work. With the freedom to model anything with fewer steps, more automated operations, and more ways to collaborate with others, users will be able to supercharge their workflows and maximize their productivity.”

![SJohnson_DG_1_1100x1100](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/09_2023%20Launch/SJohnson_DG_1_1100x1100.jpg?width=200&name=SJohnson_DG_1_1100x1100.jpg)

And now, the moment you’ve been waiting for: an overview of what’s coming to Vectorworks 2023! You can click a link from the bulleted list below to navigate to sections that interest you.

* [BIM](../../../net/vectorworks/blog/index.html)
* [Interoperability](../../../net/vectorworks/blog/index.html)
* [User experience](../../../net/vectorworks/blog/index.html)
* [BIM for landscape](../../../net/vectorworks/blog/index.html)
* [Entertainment](../../../net/vectorworks/blog/index.html)

#### BIM Features in Vectorworks 2023

Data is vital when it comes to BIM, and Vectorworks 2023 makes it more accessible and easier to manage, allowing you to use data to your advantage for more efficient and precise modeling and documentation.

Powerful data reporting additions will simplify the process of creating detailed reports and quantity takeoffs for building objects, allowing for precise reports for walls, slabs, roofs, and railing/fence objects as well as their defining components. 

![Enhanced-Data-Reporting](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/09_2023%20Launch/Enhanced-Data-Reporting.png?width=500&name=Enhanced-Data-Reporting.png)

The Data Manager’s capabilities have expanded, making it more predictable and easier to use when creating and managing all data types. You can now search, filter, and select multiple data sets, copy and paste information, and apply it to other data sets.

Vectorworks 2023 also offers more control for creating and customizing data tags. You can intuitively find and change data tag object associations, display varying units per instance as needed, and define a scale for use in sheet or design layers.

“Data is a crucial element of BIM or any type of information modeling,” said Rubina Siddiqui, product marketing director at Vectorworks. “Making it more accessible and easier to manage means that designers can take advantage of and use data in a way that doesn’t take their time and focus away from designing.”

[Read about more BIM updates in Vectorworks 2023.](../../../net/vectorworks/blog/bim-updates-in-vectorworks-2023.html)

#### Interoperability Features in Vectorworks 2023

 Vectorworks continues to prioritize collaboration, constantly providing new and effective ways to work with fellow designers and consultants.

Improvements to IFC import capabilities are one of many ways Vectorworks 2023 encourages more productive collaboration. You’ll experience increased performance when importing an IFC file and the ability to import from more applications. New options to filter objects upon import along with criteria-based class and story mapping for alignment with Vectorworks file organization offer greater control.

![IFC-Import-Improvements](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/09_2023%20Launch/IFC-Import-Improvements.png?width=500&name=IFC-Import-Improvements.png)

Vectorworks 2023 also issues a collection of user-friendly import/export improvements for essential exchanges of DWG and DXF files. You can now customize which items and layers are exported in a file through a new, simplified export dialog. At the same time, when importing, it’s easy to select which layers and objects to include.

[Read about more interoperability updates in Vectorworks 2023](../../../net/vectorworks/blog/collaboration-updates-in-vectorworks-2023.html).

#### User Experience Features in Vectorworks 2023

With everyday performance improvements focused on process automation and efficiencies, Vectorworks 2023 does the heavy lifting for you.

You can now streamline documentation workflows with improvements to Section Viewports. Taking advantage of the Vectorworks Graphics Module, these have the new ability to move calculations and processing to the background, allowing for viewports to update up to six times faster while providing the ability to simultaneously work on other tasks.

![non-blocking-section-viewports-final](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/09_2023%20Launch/non-blocking-section-viewports-final.jpg?width=600&name=non-blocking-section-viewports-final.jpg)

Improvements to Cloud Presentations offer more freedom to active subscription and Service Select users to create and customize boards and virtual tours in [Vectorworks Cloud Services](https://www.vectorworks.net/en-US/cloud-services?utm%5Fcampaign=product%5Flaunch&utm%5Fcontent=launch2023-2&utm%5Fmedium=pr&utm%5Fsource=coverage). Virtual tours have added compatibility with various file types such as 3D models, PDFs, images, and more in addition to updates to Vectorworks’ cloud and mobile 3D viewer, providing more robust options to share designs and impress clients.

With this latest release, you’ll also experience Maxon’s Redshift Everywhere initiative, placing Redshift render styles within reach of all customers, regardless of the type of hardware being used, providing even more rendering options for outstanding visualizations.

[Read about more user experience updates in Vectorworks 2023.](../../../net/vectorworks/blog/sneak-peek-user-experience-updates-in-vectorworks-2023.html)

#### BIM for Landscape Features in Vectorworks 2023

With improved visual and organizational capabilities and new tools to save time on grading plans and terrain modeling, Vectorworks continues to pave the way to make adopting BIM into landscape workflows simpler.

You can now also take advantage of Vectorworks’ GIS and georeferencing integrations making file collaboration more straightforward by automatically placing referenced files using GIS settings from a master document. Plus, new GIS Settings and Coordinates allow you to note your preferred method of coordinate entry to incorporate georeferencing data more accurately. 

![gis-referenced-documents](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/09_2023%20Launch/gis-referenced-documents.jpg?width=500&name=gis-referenced-documents.jpg)

Additionally, with Vectorworks Landmark 2023, you can easily specify and model hedgerows, mixed or single species, with the Hedgerow Tool. Seamlessly apply hedges to the site model surface in both 2D and 3D views, quantify by linear unit and simultaneously illustrate them at mature spread and height.

[Read about more BIM for landscape updates in Vectorworks 2023.](../../../net/vectorworks/blog/sneak-peek-bim-for-landscape-updates-in-vectorworks-2023.html)

#### Entertainment Features in Vectorworks 2023

With a focus on continuous improvement to provide entertainment and lighting designers tools they can trust, version 2023 includes critical upgrades to allow for more efficient and successful workflows.

Rigging design and planning is easier than ever in Vectorworks Spotlight 2023\. Improved integration between hoist and bridle objects allows for more consistent and manageable documentation, and two-leg bridle behaviors have been updated for consistency. Also, increased control over the now symbol-based truss cross object will ease a significant portion of your workflows.

![Cable-and-Power-Planning-v2-dark](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/09_2023%20Launch/Cable-and-Power-Planning-v2-dark.jpg?width=600&name=Cable-and-Power-Planning-v2-dark.jpg)

Spotlight users will also find peace of mind with improvements and enhancements in the latest version. Updates to the Shaded Render Mode eliminate the eight-light limit you previously faced, offering more rendering support for textures, gobos, and haze. These features allow you to quickly create and share design concepts and ensure higher quality renderings.

Workflow issues with lighting devices and worksheet functions have also been addressed to deliver simplified drawing capabilities and more precise designs, leaving you more time to focus on the creative process.

[Read about more entertainment updates in Vectorworks 2023.](../../../net/vectorworks/blog/spotlight-and-connectcad-updates-vectorworks-2023.html)

#### Get Your Copy of Vectorworks 2023 Today

We’re thrilled to be sharing this new version of Vectorworks with you. [You can upgrade today by visiting the Customer Portal](http://sso.vectorworks.net/accounts/login), or you can try it yourself with a free trial by clicking the button below.

[![GET YOUR VECTORWORKS 2023 TRIAL](https://no-cache.hubspot.com/cta/default/3018241/bbc9b28d-7586-46a0-98ed-43dc67ebe42b.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/bbc9b28d-7586-46a0-98ed-43dc67ebe42b) 

The release of localized language versions will begin in October and conclude in the first quarter of 2023\. For more information about the availability of Vectorworks 2023 in other markets, [contact your local Vectorworks distributor](https://www.vectorworks.net/international?utm%5Fmedium=pr&utm%5Fsource=coverage&utm%5Fcampaign=product%5Flaunch&utm%5Fcontent=launch2023-2). If you’re a [Vectorworks Service Select](https://www.vectorworks.net/service-select?utm%5Fmedium=pr&utm%5Fsource=coverage&utm%5Fcampaign=product%5Flaunch&utm%5Fcontent=launch2023-2) or [subscription](https://customers.vectorworks.net/subscriptions?utm%5Fmedium=pr&utm%5Fsource=coverage&utm%5Fcampaign=product%5Flaunch&utm%5Fcontent=launch2023-2) customer, you can upgrade to Vectorworks 2023 as soon as the product is released in your local market.

Keep the conversation going on social media by using #Vectorworks2023.

Now it’s time to design — enjoy!

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.