[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Vectorworks BIM and 3D Modeling Help Bring THE Caique Niemeyer Project to Life

 Posted by [Chloe Jefferson](https://blog.vectorworks.net/author/chloe-jefferson) | 2 min read time 

![](https://blog.vectorworks.net/hubfs/Church%20Project_092817/Vectorworks_2018_Signature_Image_550x295.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-bim-and-3d-modeling-help-bring-the-caique-niemeyer-project-to-life)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Vectorworks%20BIM%20and%203D%20Modeling%20Help%20Bring%20THE%20Caique%20Niemeyer%20Project%20to%20Life&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-bim-and-3d-modeling-help-bring-the-caique-niemeyer-project-to-life&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-bim-and-3d-modeling-help-bring-the-caique-niemeyer-project-to-life)

The charismatic temple design featured below is a model of the Santuário Papa João Paulo II, a project by Caique Niemeyer of [Caique Niemeyer Arquitetura & Design](http://www.caiqueniemeyer.com.br/). Caique Niemeyer is the great-grandson of prominent architect Oscar Niemeyer, a pioneer of modernist architecture known for his designs of the buildings of Brasília, Brazil’s capital city. You may have seen their stunning rendering in our news about Vectorworks 2018.

![Vectorworks_2018_Signature_Image_550x295.jpg](https://blog.vectorworks.net/hs-fs/hubfs/Church%20Project_092817/Vectorworks_2018_Signature_Image_550x295.jpg?width=550&height=295&name=Vectorworks_2018_Signature_Image_550x295.jpg)

_Santuário Papa João Paulo II courtesy of Caique Niemeyer Arquitetura & Design_

“This project began with a request asking for a religious temple, and our proposal was so well accepted that it became the Shrine of St. John Paul II,” says Caique Niemeyer. “My experience with \[my great-grandfather\] the architect Oscar Niemeyer in the conception of so many other cathedrals helped me to create this complex.”

This stunning architecture is slated to be built on 12,000 square meters of land in Rio de Janeiro adjacent to Ilha Pura, home to the 2016 Olympic Games Village of Athletes. The 1,961.60-square-meter building will include several visitor-friendly attractions, such as a sanctuary and a museum, as well as an auditorium, shop, cafeteria, and underground parking garage.

Caique Niemeyer and his team are using [Vectorworks](http://www.vectorworks.net/?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=niemeyerchurchproject092817) to create the building’s design and BIM model. “It is critical to emphasize the importance of Vectorworks in the development of this project,” says Caique Niemeyer. “Its practicality and BIM capabilities provided three-dimensional modeling in an easy, fast way, simplifying the preparation of the boards in two dimensions and in coordination with our design partners at Loggia Arquitetura, who are responsible for lighting, engineering, and installations for the project.”

[Learn more](http://www.vectorworks.net/en/2018?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=niemeyerchurchproject092817) about how the latest version of our software can enhance your modeling process and streamline your workflows. 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.