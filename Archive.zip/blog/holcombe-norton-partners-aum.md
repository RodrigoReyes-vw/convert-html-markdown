[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Project Analysis | Site Design at AUM

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2023%20Blog%20Images/6_AUM/blog-1440x800%20%284%29.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fholcombe-norton-partners-aum)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Project%20Analysis%20|%20Site%20Design%20at%20AUM&url=https%3A%2F%2Fblog.vectorworks.net%2Fholcombe-norton-partners-aum&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fholcombe-norton-partners-aum)

Auburn University at Montgomery’s first new building in nearly 30 years, the Student Wellness Center, has been completed. The project included substantial landscape architecture work, performed by Stephen Schrader and Holcombe Norton Partners.

This blog post will explore the landscape architecture design process for this project, which included a massive 40,000 cubic yards of cut/fill.

#### Moving the Earth

The first task was to prepare the building site by filling 40,000 cubic yards to raise the building pad for the wellness building and improve its relationship with the road. This project was seeking LEED credentials, so the firm resolved to use soil from a nearby area on the project site as a sustainable soil management strategy.

40,000 cubic yards of fill material is substantial. Instead of bringing the material from off site, the firm created a usable intramural play field by using the space resulting from the excavation.

![Screenshot 2023-05-25 at 5.13.39 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/6_AUM/Screenshot%202023-05-25%20at%205.13.39%20PM.png?width=662&height=489&name=Screenshot%202023-05-25%20at%205.13.39%20PM.png)

A site modifier creates a 1.25% rise to the south to ensure water sheds northward on this simple modeling exercise.

![Screenshot 2023-05-25 at 5.13.53 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/6_AUM/Screenshot%202023-05-25%20at%205.13.53%20PM.png?width=662&height=489&name=Screenshot%202023-05-25%20at%205.13.53%20PM.png)

After creating the site model, parameters were set for the grading plan to display both existing and proposed contours.

![Screenshot 2023-05-25 at 5.14.15 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/6_AUM/Screenshot%202023-05-25%20at%205.14.15%20PM.png?width=662&height=490&name=Screenshot%202023-05-25%20at%205.14.15%20PM.png)

They had a target of 40,000 cubic yards and through the cut/fill calculations, they were able to realize this goal more informedly, which met the goals of the architects, while also helping facilitate the need for athletic fields contributing to the outdoor recreation goals for the facility.

![Screenshot 2023-05-25 at 5.14.36 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/6_AUM/Screenshot%202023-05-25%20at%205.14.36%20PM.png?width=662&height=494&name=Screenshot%202023-05-25%20at%205.14.36%20PM.png)

The site model can perform slope analysis, so for Schrader, this meant identifying four slope categories. These categories can be easily represented with color fills in the areas where the slope ranges match those chosen in the settings. Green indicates slopes less than 2%, while closer to red means approaching a 2:1 slope. Red shows slopes exceeding 2:1, indicating the need for modifications to stabilize them. This method helps check for steep slopes that could be unstable, at both individual and master planning scales.

![Screenshot 2023-05-25 at 5.14.51 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/6_AUM/Screenshot%202023-05-25%20at%205.14.51%20PM.png?width=662&height=495&name=Screenshot%202023-05-25%20at%205.14.51%20PM.png)

![Screenshot 2023-05-25 at 5.15.06 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/6_AUM/Screenshot%202023-05-25%20at%205.15.06%20PM.png?width=662&height=492&name=Screenshot%202023-05-25%20at%205.15.06%20PM.png)

The images below show the site during excavation up to the construction of the new wellness building.

* ![AUM 1](https://3018241.fs1.hubspotusercontent-na1.net/hub/3018241/hubfs/Blog%20Images/2023%20Blog%20Images/6_AUM/Screenshot%202023-05-25%20at%205.15.20%20PM.png?width=1200&length=1200&name=Screenshot%202023-05-25%20at%205.15.20%20PM.png)
* ![AUM 2](https://3018241.fs1.hubspotusercontent-na1.net/hub/3018241/hubfs/Blog%20Images/2023%20Blog%20Images/6_AUM/Screenshot%202023-05-25%20at%205.15.28%20PM.png?width=1200&length=1200&name=Screenshot%202023-05-25%20at%205.15.28%20PM.png)
* ![AUM 3](https://3018241.fs1.hubspotusercontent-na1.net/hub/3018241/hubfs/Blog%20Images/2023%20Blog%20Images/6_AUM/Screenshot%202023-05-25%20at%205.15.37%20PM.png?width=1200&length=1200&name=Screenshot%202023-05-25%20at%205.15.37%20PM.png)

#### Achieving LEED Accreditation 

Since the overall project sought LEED accreditation, credits available from the site design and implementation were up to Holcombe Norton Partners.One of the most common LEED credits pursued by the firm is the reduction of potable water use from a calculated baseline.

The firm created a worksheet in Vectorworks that draws planting areas, surface areas, and water use values directly from plant objects, landscape areas, and hardscapes and the records appended to other objects. They have a plant template file that has all of their data standardized, from installation sizes to watering needs.

![Screenshot 2023-05-25 at 5.17.02 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/6_AUM/Screenshot%202023-05-25%20at%205.17.02%20PM.png?width=662&height=494&name=Screenshot%202023-05-25%20at%205.17.02%20PM.png)

But where do you get reliable information like this? Often, you can find third-party documentation containing everything you need about native plants. Holcombe Norton Partners takes advantage of Alabama's Cooperative Extension Service, which compiles data on native and introduced plant varieties and their water needs, providing reliable information beyond personal experience.

This method is automatic and scalable, with no change in workflow for others in the office. Team members can simply draw planting plans and open the worksheet to assess progress towards the LEED credit.

![Screenshot 2023-05-25 at 5.17.48 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/6_AUM/Screenshot%202023-05-25%20at%205.17.48%20PM.png?width=662&height=493&name=Screenshot%202023-05-25%20at%205.17.48%20PM.png)

#### Smarter Workflows Enabled by Design Software

The tools in Vectorworks Landmark allowed Holcombe Norton Partners to create a reliable plan for the site while also allowing them to provide detailed documentation for the purposes of achieving LEED credits.

Schrader points out two major aspects of Vectorworks Landmark that serve him and his firm time and time again: worksheets and parametric objects. The combination of the two means your drawing or model acts as the project’s database of information, which can then be used to perform crucial calculations.

“If default objects don’t track the data you need, find out how to attach the information to your objects,” Schrader said. “Parametric objects like parking spaces, hardscapes, and plants save drawing time and tedious counting and calculations.”

Learn more about using Vectorworks to achieve LEED, SITES, BREEAM, SuDS, WSUD, and MWELO objectives in our free webinar:

[![WATCH NOW](https://no-cache.hubspot.com/cta/default/3018241/1bec9b5c-3e2b-4441-ba1d-2266efbcbd3c.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/1bec9b5c-3e2b-4441-ba1d-2266efbcbd3c) 

_\*All images in this post are credited to Holcombe Norton Partners._

 Topics: [Landscapes](https://blog.vectorworks.net/topic/landscapes) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.