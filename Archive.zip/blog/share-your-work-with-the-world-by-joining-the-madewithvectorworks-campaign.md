[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Share Your Work with the World by Joining the #MadeWithVectorworks Campaign

 Posted by [Ishan Dey](https://blog.vectorworks.net/author/ishan-dey) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/200820%20Made%20With%20Vectorworks/Fab%20Lab.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fshare-your-work-with-the-world-by-joining-the-madewithvectorworks-campaign)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Share%20Your%20Work%20with%20the%20World%20by%20Joining%20the%20#MadeWithVectorworks%20Campaign&url=https%3A%2F%2Fblog.vectorworks.net%2Fshare-your-work-with-the-world-by-joining-the-madewithvectorworks-campaign&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fshare-your-work-with-the-world-by-joining-the-madewithvectorworks-campaign)

Architects around the world are helping launch the #MadeWithVectorworks campaign to showcase their best designs. In return, they have the opportunity to raise awareness for their work and their firms. 

Join the campaign for the chance to have your work featured on our social channels and our [MODUS News](https://www.modusnews.com/) website. Read on for inspiration from some of our favorite #MadeWithVectorworks participants. We look forward to hearing from you!

###### Everyday Inspiration 

**moveART**

> [  View this post on Instagram ](https://www.instagram.com/p/B%5FxwhTIJrnx/?utm%5Fsource=ig%5Fembed&utm%5Fcampaign=loading) 
> 
> [Swiss designer & founder of moveART, Norbert Roztocki, made use of our Marionette tool to get his designs manufactured quickly and fast track his business. #MarionetteMonday #Architecture #MadeWithVectorworks](https://www.instagram.com/p/B%5FxwhTIJrnx/?utm%5Fsource=ig%5Fembed&utm%5Fcampaign=loading)
> 
> A post shared by [ Vectorworks](https://www.instagram.com/vectorworks/?utm%5Fsource=ig%5Fembed&utm%5Fcampaign=loading) (@vectorworks) on May 4, 2020 at 12:20pm PDT

The best designs don't just pique your curiosity. They provide an environment that inspires those who inhabit that space. 

In May 2020, we showcased these contemporary park structures designed by Norbert Roztocki, founder of [moveART](http://moveart.swiss/en/vision/). Roztocki showcased his use of the [Marionette](https://www.vectorworks.net/training/marionette?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=081920madewithvectorworks) tool used to algorithmically repeat parts of his design to create uniformity. The time he saved using [Marionette](/what-is-marionette-a-look-at-vectorworks-algorithmic-modeling-tool?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=081920madewithvectorworks) helped keep his designs consistent and produce his designs quickly.

**D.C. Apartment Building**

> [  View this post on Instagram ](https://www.instagram.com/p/B8eyU7QlB9d/?utm%5Fsource=ig%5Fembed&utm%5Fcampaign=loading) 
> 
> [Another segment of #MadeWithVectorworks via @studioupwallarchitects, who uses #Vectorworks exclusively to design, model & refine their projects. Check out their project for a redevelopment site in D.C.](https://www.instagram.com/p/B8eyU7QlB9d/?utm%5Fsource=ig%5Fembed&utm%5Fcampaign=loading)
> 
> A post shared by [ Vectorworks](https://www.instagram.com/vectorworks/?utm%5Fsource=ig%5Fembed&utm%5Fcampaign=loading) (@vectorworks) on Feb 12, 2020 at 12:56pm PST

Designers everywhere aren’t just designing new homes — they’re reimagining entire lifestyles to create functional, inspiring residences. [Studio Upwall Architects](http://www.studioupwall.com/) in Washington, D.C. used [Vectorworks](https://www.vectorworks.net/en-US?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=081920madewithvectorworks) to dream up this stunning apartment complex proposal for a vacant site. Being part of the #MadeWithVectorworks campaign connects you to an innovative, global design community. 

###### **Be Featured on MODUS News**

MODUS News is our publication, dedicated to featuring the most inspiring and intelligent designs by Vectorworks users worldwide. The Latin phrase _modus operandi_ describes the distinct way in which a person works. MODUS News is dedicated to presenting how each architect’s _modus operandi_ leads to unique, exceptional work conceived and designed in Vectorworks software.

**Fab Lab**

> [  View this post on Instagram ](https://www.instagram.com/p/B%5F2w4FdFJAV/?utm%5Fsource=ig%5Fembed&utm%5Fcampaign=loading) 
> 
> [@spaceworkers designed this sleek, minimalist rendering using Vectorworks! Link in bio. ⁠ ⁠ #MadeWithVectorworks #ArchitectureDesign #ContemporaryArchitecture #ContemporaryDesign⁠](https://www.instagram.com/p/B%5F2w4FdFJAV/?utm%5Fsource=ig%5Fembed&utm%5Fcampaign=loading)
> 
> A post shared by [ Vectorworks](https://www.instagram.com/vectorworks/?utm%5Fsource=ig%5Fembed&utm%5Fcampaign=loading) (@vectorworks) on May 6, 2020 at 11:01am PDT

Portuguese firm [Spaceworkers](https://www.spaceworkers.pt/en/) dreamed up The Design Factory and Innovation in Paredes, Portugal. The building facilitates creativity for its community with its open design and uniquely shaped structures, which offer visitors and designers different perspectives. The inclusion of trees and asymmetrical branch-like structures infuses a sense of nature in an otherwise minimalist design. The complex and intricate nature of this project excited us so much that we simply had to include them in [MODUS News](https://www.modusnews.com/europe/fab-lab). 

**Church of Seliger Pater Rupert Mayer**

> [  View this post on Instagram ](https://www.instagram.com/p/CCbWFB%5FHRkC/?utm%5Fsource=ig%5Fembed&utm%5Fcampaign=loading) 
> 
> [Munich-based firm Meck Architekten designs focusing on the human scale, with regards to the urban context & design of interior spaces. See how they pursued their bold vision for the Church of Seliger Pater Rupert Mayer. Link in bio.⁠ ⁠ #Munich #MunichGermany #Germany #ModernArchitecture #ContemporaryArchitecture #Inspo #DesignInspo #Minimalist⁠](https://www.instagram.com/p/CCbWFB%5FHRkC/?utm%5Fsource=ig%5Fembed&utm%5Fcampaign=loading)
> 
> A post shared by [ Vectorworks](https://www.instagram.com/vectorworks/?utm%5Fsource=ig%5Fembed&utm%5Fcampaign=loading) (@vectorworks) on Jul 9, 2020 at 9:01am PDT

Architects are using Vectorworks to put a contemporary spin on long-standing institutions. Munich-based firm [Meck Architekten](https://www.meck-architekten.de/) reimagined the modern church with its design of the Church of Seliger Pater Rupert Mayer. The towering white crown roof’s combination of sharp lines and basket-like texture weaves together the best of contemporary and traditional architecture. The overall design provides a place where churchgoers are able to convene to celebrate their traditions within a modern context. 

###### **What now?** 

Now it’s your turn to be celebrated for your superior work and inspire your fellow designers. Share your designs to be considered for upcoming social media posts and MODUS News articles. MODUS News projects are selected by a committee on an annual basis. 

[![SHARE YOUR PROJECT NOW](https://no-cache.hubspot.com/cta/default/3018241/8603abd1-e3c4-4fe2-86f6-9a5acdedb60e.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/8603abd1-e3c4-4fe2-86f6-9a5acdedb60e) 

 Topics: [BIM (Architecture)](https://blog.vectorworks.net/topic/bim-architecture) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.