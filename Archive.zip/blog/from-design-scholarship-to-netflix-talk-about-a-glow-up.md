[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# From Design Scholarship to Netflix: Talk About a “Glow” Up!

 Posted by [Chloe Jefferson](https://blog.vectorworks.net/author/chloe-jefferson) | 4 min read time 

![blog-featured-image-02](https://blog.vectorworks.net/hubfs/blog-featured-image-02.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Ffrom-design-scholarship-to-netflix-talk-about-a-glow-up)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=From%20Design%20Scholarship%20to%20Netflix:%20Talk%20About%20a%20“Glow”%20Up!&url=https%3A%2F%2Fblog.vectorworks.net%2Ffrom-design-scholarship-to-netflix-talk-about-a-glow-up&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Ffrom-design-scholarship-to-netflix-talk-about-a-glow-up)

To bookend Women’s History Month, we’re spotlighting [Morgan Lindsey Price](/no-more-grey-skies-for-this-successful-scholarship-award-winner), the 2015 [Design Scholarship](https://www.vectorworks.net/scholarship/en/about?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=mlpglow040219) winner. Since then, she’s gone above and beyond to make a name for herself in the entertainment industry, most recently as the set designer and assistant art director for the popular Netflix series, _Glow_.

[Morgan](http://www.morganlindseyprice.com/) began working on _Glow_ after _Are You Sleeping_. Following a text from a friend about the opportunity, she met with the art director who loved her and hired her right away. “I was stoked because I am obsessed with the show, so it’s been very exciting,” she said. 

![MLP+About+Me](https://blog.vectorworks.net/hs-fs/hubfs/190301_Morgan%20Lindsay%20Price%20Glow/MLP+About+Me.jpg?width=493&name=MLP+About+Me.jpg)

_Image courtesy of Morgan Lindsey Price._

Morgan says working on _Glow_ has been life-changing: “The art department is so talented. A lot of people have been here since season one, and they were very welcoming when I joined. It’s like a family. They are such a talented group of people and I feel really lucky and blessed to have stepped into this job.”

With the television industry’s fast-paced nature in mind, Morgan knew she would need a tool that’s fast and efficient, so she turned to [Vectorworks Spotlight](https://www.vectorworks.net/en/spotlight?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=mlpglow040219). “I’m finding that, with a lot of TV shows I’ve worked on, it’s a requirement to use Vectorworks, which has been great,” said Morgan. “It’s easy for us to share files if we need to, and for the art director to quickly look at my work.”

![GLOW S3 - Ep. 303 - Int. Chapel](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190402_MLP%20Glow%20Scholarship/GLOW%20S3%20-%20Ep.%20303%20-%20Int.%20Chapel.jpg?width=5400&name=GLOW%20S3%20-%20Ep.%20303%20-%20Int.%20Chapel.jpg)

_Interior Vegas Chapel Drawing for Glow. Image courtesy of Morgan Lindsey Price._

One of Morgan’s grad school professors taught her how to use Vectorworks. He showed her how to utilize the 3D elements of the program, how to create renderings to better communicate designs with various departments, and then how to integrate the program with other colleagues. “He was the one who showed me [workgroup referencing](http://app-help.vectorworks.net/2019/eng/index.htm#t=VW2019%5FGuide%2FWorkgroup%2FWorkgroups%5Fand%5FReferencing.htm?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=mlpglow040219) and how valuable that could be,” she explained. “I think because it was taught so clearly in grad school, I was able to just run with it and modify my workflow as needed for different shows that I've been on.” 

“I’m finding that, with TV, everything happens so fast. If the muscle memory isn’t there, I’m less likely to incorporate it until I practice it a few times,” she continued.

With that said, Morgan has some advice for those considering Vectorworks to execute entertainment design workflows: 

“My biggest recommendation is to just play with the program in your free time. I don’t know that a lot of people want to do that necessarily, but I feel like that’s been the best way for me to learn. Take the time on a weekend to just figure things out. I mean, I call myself a nerd, but I also am getting to work on an awesome show for Netflix because I have experience with Vectorworks.”

![Int. Chapel Prelim Render Iso](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190402_MLP%20Glow%20Scholarship/Int.%20Chapel%20Prelim%20Render%20Iso.jpg?width=3600&name=Int.%20Chapel%20Prelim%20Render%20Iso.jpg)

_Interior Vegas Chapel for Glow: ISO View. Image courtesy of Morgan Lindsey Price._

When asked about advice for the design scholarship in particular, Morgan encourages you to, “Take chances even when you think it's beyond your grasp. I really didn't think we would win the scholarship, but here I am! I'm incredibly lucky and fortunate to be working with the people I get to work with today. But it took a lot of hard work and reaching out to anyone and everyone I met to just talk about the industry and hear their story. And by doing that, a few people took a chance and hired someone as green as I was and set everything in motion.” 

![Int. Chapel Prelim Render](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190402_MLP%20Glow%20Scholarship/Int.%20Chapel%20Prelim%20Render.jpg?width=3600&name=Int.%20Chapel%20Prelim%20Render.jpg)

_Interior Vegas Chapel for Glow: Camera View. Image courtesy of Morgan Lindsey Price._

Since winning the 2015 Design Scholarship, Morgan’s career has skyrocketed. We encourage you to submit your work to this year’s scholarship. Just imagine if Morgan hadn’t back in 2015.

###### So, what are you waiting for?   
Take the leap. Submit your idea today.

[![Apply Now](https://no-cache.hubspot.com/cta/default/3018241/cd7b6c60-0fb7-4829-b805-4fe40368c76c.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/cd7b6c60-0fb7-4829-b805-4fe40368c76c) 

 Topics: [Vectorworks Design Scholarship](https://blog.vectorworks.net/topic/vectorworks-design-scholarship) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.