[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Using DWG Files in Entertainment Design

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 6 min read time 

![](https://blog.vectorworks.net/hubfs/2300518_ENT%20DWG/blog-1440x800_DWG%20Hero.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fimprove-your-collaborative-process-with-these-dwg-tips)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Using%20DWG%20Files%20in%20Entertainment%20Design&url=https%3A%2F%2Fblog.vectorworks.net%2Fimprove-your-collaborative-process-with-these-dwg-tips&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fimprove-your-collaborative-process-with-these-dwg-tips)

Collaboration between yourself and other designers or teams is ever-present in the entertainment industry. In fact, [in a recent story where industry experts shared their advice for other designers](../../../net/vectorworks/blog/-three-designers-share-the-importance-of-collaboration.html), Beowulf Boritt, a Tony Award-winning designer, described collaboration as "magic."

Understanding how to better import and export files can only improve your ability to create said magic. So, below, you'll find tips for importing, exporting, and referencing DWG files when working with different departments on your next production. 

#### Importing DWG Files of Venues

Your work on a production may likely begin with an engineering team or a venue manager sharing a DWG file of where your production will be taking place. 

This file will be the framework of your project, as importing a DWG file and using it as a reference for your design, in a sense, creates the lines that you get to color within. Once your design is finished, you can then disconnect the referenced DWG file, optimizing the speed of your remaining Vectorworks file. 

![blog-1440x800_DWG Hero 2](https://blog.vectorworks.net/hs-fs/hubfs/2300518_ENT%20DWG/blog-1440x800_DWG%20Hero%202.png?width=1440&height=800&name=blog-1440x800_DWG%20Hero%202.png)

In these early stages of your process, clear communication with your collaborators is key. We recommend you clearly explain what you need in the sent file and have your collaborators share these items' locations.

You see, other design software — unlike Vectorworks — doesn't organize its files into classes _and l_ayers, so if not communicated properly, you could waste valuable time digging through an imported DWG file. 

[This difference, in fact, is one of the several advantages of Vectorworks over other design software, like AutoCAD.](../../../net/vectorworks/blog/top-4-features-autocad-doesnt-have-but-vectorworks-does.html) 

---

#### Curious to learn more about DWG files?   

Click the button below to download the free eBook:

[![GUIDE: DWG FILE FORMAT COLLABORATION IN VECTORWORKS](https://no-cache.hubspot.com/cta/default/3018241/d9e79962-d75f-43ac-b990-f027bbc8357c.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/d9e79962-d75f-43ac-b990-f027bbc8357c) 

---

[There are a couple ways in which you can import your venue's DWG file into Vectorworks](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/DXFDWG/DXF%5FDWG%5Fand%5FDWF%5Ffile%5Fimport.htm?rhsearch=DWG&rhhlterm=dwg). Import Single DXF/DWG and Import DXF/DWG or DWF both import external files into your internal file. The only difference between the two commands is the number of file references that’re brought in or associated.

![DWG Import](https://blog.vectorworks.net/hs-fs/hubfs/2300518_ENT%20DWG/DWG%20Import.png?width=1440&height=1131&name=DWG%20Import.png)

Additionally, Vectorworks displays an alert if any external reference files are missing upon import, ensuring that no vital information goes missing without you noticing.

#### Exporting DWG Files from Vectorworks 

In some cases, your collaborators may want to receive a DWG file of your design once it's completed. This may be to review aesthetic choices you've made or simply check that the production can safely take place on the specific stage, showroom floor, etc. 

When exporting DWG files with collaborators, confirm your collaborator's desired file structure, as well as what precisely they'll be checking. Just as you might not need all the components of an original DWG file, they may not need to receive certain elements of your design file.

Some members of an engineering team, for example, may only care about what trusses or fixtures you're hanging from the venue's roof — to ensure that the roof can hold such weight. Other teams may want to know if there are any high-traffic, dense areas on trade show floors or multi-level centers that will have high foot traffic.

![YouTube Data Driven 1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230413_ENT%20YouTube%20Repurpose%20Data-Driven/YouTube%20Data%20Driven%201.png?width=1440&height=815&name=YouTube%20Data%20Driven%201.png)

Also, confirm with your collaborators if they want a 2D or 3D file sent to them.

A beautiful 3D model is great for creating informative, visually stunning designs, but sending it to an engineering team that only needs information regarding safety and logistics may prove to be unnecessary and time-consuming.

It's also important to remember that, once exported, Vectorworks classes become layers, and optionally, our layers become separate files so that you do not have to spend extra time confirming the location of certain information with your collaborators, such as decorative architecture or HVAC specifications.

You can export single DWG files from Vectorworks Spotlight, or you can export several files as a batch. 

To export your file(s), select **File > Export > Export DXF/DWG**. Next, you just need to select your desired export options in the export dialog. 

#### Repeatable DWG Processes to Save Time

When importing and exporting DWG files, there are multiple considerations you can make to save time on future projects.

For starters, you can turn your imported venues into a symbol, making it easy to reuse again and again.

![Advanced DWG Import Export](https://blog.vectorworks.net/hs-fs/hubfs/2300518_ENT%20DWG/Advanced%20DWG%20Import%20Export.png?width=1440&height=1012&name=Advanced%20DWG%20Import%20Export.png)

There are also advanced settings for imports and exports that you can save as presets. This way, your import/export process is sped up when working with different clients, vendors, and venues.

#### Further Improve Your Collaborative Processes

Better collaboration doesn't start and end with DWG files, either. Vectorworks Spotlight offers a suite of features and capabilities that you can use to leverage your ability to work with others. 

To dive even further into improved collaboration processes in the entertainment industry, click the link below and watch a free webinar:

["HOW 3D CAN ACHIEVE FLEXIBILITY IN ALL AREAS OF PRODUCTION"](https://university.vectorworks.net/course/view.php?id=175)

The webinar, hosted by lighting designer Mark Doubleday, covers how Vectorworks Spotlight can be used to transform 2D drawings into detailed 3D models that can assist with all levels of your production.

Doubleday uses several real-world examples to show how Vectorworks can help troubleshoot potential points of friction in the process, as well as how it can enhance collaboration. 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.