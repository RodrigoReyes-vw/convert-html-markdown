[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# The 5 Best Twinmotion Features for Architects

 Posted by [Guest Author](https://blog.vectorworks.net/author/guest-author) | 7 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/220406_Twinmotion%20Guest%20Blog/twinmotion-direct-link.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fbest-twinmotion-features-with-vectorworks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=The%205%20Best%20Twinmotion%20Features%20for%20Architects&url=https%3A%2F%2Fblog.vectorworks.net%2Fbest-twinmotion-features-with-vectorworks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fbest-twinmotion-features-with-vectorworks)

_Belinda Ercan is the Twinmotion Product Marketing Manager at_ [_Epic Games_](https://store.epicgames.com/)_, a Vectorworks partner. In this blog, she describes the five best features for architects in the Twinmotion real-time rendering engine._

. . .

_Singin’ In The Rain_ — I love this 1952 film by Stanely Donen. I rewatched it recently and realized that one scene in particular lends itself perfectly to describing what Epic Games’ Twinmotion stands for.

This classic musical explores the challenges facing a film studio as it awkwardly adapts to a revolutionary thing called “a talking picture” (films with synchronized sound). As the studio nears the end of their conversion of their current production over to sound, they're still missing one key scene. Then the film's star, Don Lockwood (Gene Kelley), does what we all do in our jobs today: he delivers The Pitch.

We all know The Pitch: “Here's my bright idea; let me tell you about it and take you through it,” Lockwood says.

In the film's logic, Lockwood is _verbally_ describing the scene to the studio head when something magical happens: the camera optically dollies into the scene he describes, a New York noir genre piece, with music (something we take for granted today) and… in color!

![Belinda Ercan Headshot-1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220406_Twinmotion%20Guest%20Blog/Belinda%20Ercan%20Headshot-1.png?width=330&name=Belinda%20Ercan%20Headshot-1.png)_Belinda Ercan_

What accompanies The Pitch is one of the finest scenes of musical history, a glorious technicolor explosion contrasting with their own black-and-white production. After 13 minutes of magic and fanfare, Don asks the head of the studio, “So, what do you think?” to which he answers with the punchline, “I don’t know, I just can’t picture it.”

This is one of the greatest cinematic puns I know. The switch in technology from silent black-and-white film to full audio technicolor is similar to the switch in _storytelling_ we at Epic Games are pushing, allowing clients to fully experience and explore their visions. Epic’s Twinmotion is our tool for creating these rich interactive stories, transposing storytelling so that there is no disconnect between description and visualization, perception and experience. And all without having to outsource the work to a specialist or dive into hours of learning the tech.

Below are some of my favorite Twinmotion tools and features that architects and designers can use to take their story anywhere they want it to go in a fun and simple way.

## 1\. The Path Tracer

I believe creative tools should always help you feel more creative. That means they should never block your flow ⁠— but instead be a place where you can follow your instincts and instantly see your ideas come to life.

New to Twinmotion 2022, the Path Tracer is a DXR-accelerated, physically accurate progressive rendering mode that can make this happen. With it, you can output stunning final-pixel images and panoramas comparable to final renders with global illumination, physically correct refraction, and anti-aliasing in minutes.

Together with Twinmotion’s icon and slider-based interface (which has a learning curve of only about an hour for many architects), the Path Tracer will make it easier than ever to create prototypes or iterate through ideas, all while previewing a final result that looks insanely close to your finished building.

## 2\. Collaboration with Twinmotion Cloud

Also new to Twinmotion is the [Twinmotion Cloud](https://www.twinmotion.com/news/3d-architectural-design-reviews-in-the-time-it-takes-to-make-a-coffee), which allows architectural designers to showcase their latest designs by simply sharing a link, much like the [Vectorworks Cloud](https://www.vectorworks.net/cloud-services). Clients can then view and walk through your project at any time, regardless of how powerful their computers are.

For you, that means there’s no need to prepare for client meetings by producing walkthrough animations or producing screenshots and render; you can just build 3D architectural design reviews in the time it takes to make a cup of coffee.

And for clients, that means they can see the latest idea or design you for a project without needing to download anything, learn new software, or have a powerful workstation. All they need is a browser and everything can be seen in the cloud.

## ![twinmotion-direct-link](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220406_Twinmotion%20Guest%20Blog/twinmotion-direct-link.jpg?width=1440&name=twinmotion-direct-link.jpg)3.The One-Click Sync Plugins

Whether you’re a big studio that requires interoperability between all your team’s favorite software or a small firm that needs a solution that can easily fit into pre-existing pipelines, Twinmotion and [Vectorworks 2022](https://www.vectorworks.net/2022)offer a built-in,[one-click sync plugin](https://www.twinmotion.com/plugins) which is a perfect way to avoid wasting time retraining or building fixes for your workflows.

With the plugins, you can easily bring in data from Vectorworks. From there, materials can be selected and vegetation and people easily added to a scene, which then keeps all changes in sync with the Twinmotion model in real-time as the user designs, edits, and refines.

[\-> Your Guide to Rendering with Twinmotion](../../../net/vectorworks/blog/your-guide-to-rendering-with-twinmotion.html)

## 4\. The Quixel Asset Library

The one-click sync plugins will help you connect Twinmotion to other creator tools, but what if you want to add trees, people, or buildings to your Twinmotion scenes, all without leaving the interface?

For that, Twinmotion acquired Quixel Megascan library, one of the largest libraries of 3D scans in the world. The library — which is regularly updated with new content — includes interactive Smart Assets that help trees grow, doors open, and foliage move, without any extra effort from you. It’s the perfect way to quickly bring an idea to life, with details that shift perceptions and convey new innovations in ways everyone will understand.

## 5\. The Twinmotion to Unreal Engine Bridge

Then there’s the Twinmotion Importer to Unreal Engine. It comes in handy when Twinmotion isn’t enough and you want a more powerful (and more complex) tool to further refine your Twinmotion project. This enables architects to tap into the power of our Unreal Engine so that architectural firms can use the same tools that power everything from _Fortnite_ to Hollywood features like _The Mandalorian_.

That means you can refine your Twinmotion project by turning it into an XR experience, immersive simulation, sales configurator and much more, all using the exact same Twinmotion files. The sky’s the limit!

Vectorworks doesn't just connect to Twinmotion, but it also supports the Datasmith file in such a way that you can take your Vectorworks model anywhere in the Epic Games ecosystem.

Most visualization tools are effectively closed boxes which don’t allow the project data to grow beyond the limits of the tool. That not only limits functionality, but creativity as a whole. And that’s where we, Twinmotion, are building bridges.

. . .

_To learn more about what you can do with Vectorworks and Twinmotion, click the button below and watch a free webinar!_

[![EXPERIENCE THE DATASMITH DIRECT LINK IN SP3 FOR VECTORWORKS 2022](https://no-cache.hubspot.com/cta/default/3018241/7bcbbb59-bff0-4051-bb1b-f31fa82d9fc5.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/7bcbbb59-bff0-4051-bb1b-f31fa82d9fc5) 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.