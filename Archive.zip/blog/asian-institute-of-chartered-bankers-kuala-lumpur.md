[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Project Profile: Asian Institute of Chartered Bankers by GDP Architects

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/211015_ARCH%20Signature%20Project/21_AICB%20Building_A1-S03-01.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fasian-institute-of-chartered-bankers-kuala-lumpur)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Project%20Profile:%20Asian%20Institute%20of%20Chartered%20Bankers%20by%20GDP%20Architects&url=https%3A%2F%2Fblog.vectorworks.net%2Fasian-institute-of-chartered-bankers-kuala-lumpur&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fasian-institute-of-chartered-bankers-kuala-lumpur)

With the release of [Vectorworks 2022](http://vectorworks.net/2022), we’re celebrating a few projects that exemplify what designing with Vectorworks is all about — _design without limits™_ . One of those projects is the Asian Institute of Chartered Bankers (AICB), designed by GDP Architects with the [BIM platform Vectorworks Architect](http://vectorworks.net/architect).

![21_AICB Building_A1-S03-07](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211015_ARCH%20Signature%20Project/21_AICB%20Building_A1-S03-07.jpg?width=540&name=21_AICB%20Building_A1-S03-07.jpg)

The AICB building in Kuala Lumpur presents a façade that’s nothing short of captivating. Its overlapping panels are based on _songket_ fabric weaving, a pattern that belongs to Malaysia.

The _songket_\-inspired pattern links commerce and culture tastefully and unabashedly, a nod to the idea that commercial buildings must respect the regions where they’re built. It would’ve been easy to design any old pattern for the façade, but GDP Architects not only understand the distinct footprint left behind by such a substantial building — they embrace it.

The pattern can be seen throughout the façade, so much so that the firm labels the diamonds an overall motif for the project. The images below show a layered _songket_ pattern that’s presented much differently than on the aluminum-paneled auditorium.

![21_AICB Building_A1-S03-04](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211015_ARCH%20Signature%20Project/21_AICB%20Building_A1-S03-04.jpg?width=1400&name=21_AICB%20Building_A1-S03-04.jpg)

![21_AICB Building_A1-S03-06](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211015_ARCH%20Signature%20Project/21_AICB%20Building_A1-S03-06.jpg?width=657&name=21_AICB%20Building_A1-S03-06.jpg)

The aluminum diamonds serve both form and function. In tropical Kuala Lumpur, they redirect rainfall off the building to preserve it from natural wear as well as invite natural light into the building.

#### A Closer Look at the AICB Building

Here are the facts:

* It’s built on a 3.16-acre site.
* The gross area is 514,359 sq. ft.
* The net area is 325,621 sq. ft.
* The office stands 12 stories high.
* The training center stands 6 stories high.

###### Selecting Materials

The architects focused on the building’s presence in the Kuala Lumpur skyline. The 12-story tower is made of glass and aluminum, offering both elegance and durability. Other material selections include sandstone in the training podium and solid aluminum panels in the auditorium. The architects selected warmer-toned materials for street level to appeal to passersby.

![21_AICB Building_A1-S03-01](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211015_ARCH%20Signature%20Project/21_AICB%20Building_A1-S03-01.jpg?width=773&name=21_AICB%20Building_A1-S03-01.jpg)

###### Addressing Site Constraints

The architects had to design around the fact that the site faces KTM trainlines and a major car traffic artery, which introduce noise disturbances to the scheme. The building form is slightly inclined to reduce sound from these sources, and pocket gardens and vertical greens line the building to further absorb noise.

###### 1 Building, 11 Agencies

The building is home to 11 different agencies, which was a vital design consideration for the architects. There needed to be areas that encourage collaboration as well as rooms for each agency to operate independently. This explains the inclusion of several “breakout rooms” — pictured below — which take a stylistic approach to sequestered spaces.

![21_AICB Building_A1-S03-08](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211015_ARCH%20Signature%20Project/21_AICB%20Building_A1-S03-08.jpg?width=447&name=21_AICB%20Building_A1-S03-08.jpg)

#### Design Without Limits™ with Vectorworks

As the project we’ve selected to showcase what Vectorworks is all about, the AICB building leaves no question in your mind that it’s the product of a very sophisticated design process.

The project team consisted of 19 people — six project managers, three associates, six architects, two interior designers, and two focused on 3D and organization. That’s a lot of people to coordinate for one project.

![21_AICB Building_A1-S03-10](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211015_ARCH%20Signature%20Project/21_AICB%20Building_A1-S03-10.jpg?width=1400&name=21_AICB%20Building_A1-S03-10.jpg)

According to GDP Architects CEO Kamil Merican, roughly 90% of the office uses Vectorworks. The software helps GDP from early concept phases all the way to implementation. They incorporate Grasshopper and Rhino into their workflow as well for specific design needs; this geometry is then carried over into the Vectorworks design hub.

“The tools of Vectorworks are simpler and easier to handle, and in terms of graphics, it’s much better than other BIM softwares,” Merican said.

GDP worked with several consultants including C&S, M&E, and landscape architects. Most consultants used AutoCAD. Merican reports that the file exchange process was painless — it simply involved importing or exporting DWG files to and from Vectorworks.

_All images in this article are courtesy of GDP Architects SDN BHD and photographer Adaptus Design Systems SDN BHD._

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.