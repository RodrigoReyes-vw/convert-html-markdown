[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Adlib’s Switch to Vectorworks Spotlight

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2023%20Blog%20Images/231220_ENT%20MTM%20ADLIB/blog-1440x800_Adlib%20VW%202.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fa-game-changing-switch-to-vectorworks-spotlight)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Adlib’s%20Switch%20to%20Vectorworks%20Spotlight&url=https%3A%2F%2Fblog.vectorworks.net%2Fa-game-changing-switch-to-vectorworks-spotlight&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fa-game-changing-switch-to-vectorworks-spotlight)

“Because of the way Vectorworks works, it's so much easier for anyone to just open a new file and start building a show to our CAD standards,” said Simon Pettitt, Technical Designer for [Adlib](https://www.adlib.co.uk/). 

Such ease was not always the case for the UK-based event technology company. Until the recent switch, Adlib used a combination of other CAD platforms for their rental design needs. 

Now, Pettitt and co. have started making the switch to Vectorworks Spotlight for planning festivals, concerts, and arena shows across the UK and Europe. 

The impetus to change software was an obvious one, said Pettitt: “It was clear that the feeling in the office, given the standard and detail of what could be created, was saying, ‘We have to move to Vectorworks.’” 

Keep reading to discover the newfound freedom Adlib is experiencing with the help of Vectorworks Spotlight. 

#### The Ease of Data-Rich Drawing 

Pettitt has already helped Adlib’s Project Management team make a complete transition to Vectorworks, helping Adlib create template files and object libraries. The rental company has two different Spotlight template files: one for Event use and one for Installation design. These templates follow a detailed layer structure and include preset sheets that Pettitt and his team can easily customize. 

![blog-1440x800_Adlib VW 3](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/231220_ENT%20MTM%20ADLIB/blog-1440x800_Adlib%20VW%203.png?width=1440&height=800&name=blog-1440x800_Adlib%20VW%203.png)

With intuitive data features in Vectorworks Spotlight, Pettitt was able to easily include data visualization, data tags, and data mappings, giving Adlib quick access to a wealth of resources by simply opening a template. 

[RELATED | “GETTING STARTED WITH TEMPLATE FILES”](../../../net/vectorworks/blog/a-template-file-crash-course-vectorworks.html) 

“We maintain a library of our trusses, fixtures, and hoists”, Pettitt stressed. “Lots of them are derived from the stock fixtures in the libraries, but Adlib has a particular format and a particular color code requirement.” ![blog-1440x800_Adlib VW 1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/231220_ENT%20MTM%20ADLIB/blog-1440x800_Adlib%20VW%201.png?width=1440&height=800&name=blog-1440x800_Adlib%20VW%201.png)

Pettitt has implemented data visualization to his trusses in the library, so any designer can pick a truss and define itspurpose to dynamically change within a rigging plot. 

#### Winning Projects & Greater Collaboration 

The creation of Adlib’s data-focused Vectorworks drawings is centered around one thing and one thing only: delivering the best events possible to their clients. “The main focus of all this is the project managers who are actually running our entertainment projects, and they're the ones who’ve really felt the benefit of Vectorworks. Their ability to generate and work on a unified model of a show was near impossible before” said Pettitt. 

![project-sharing-plus-ent (1)](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/090723_ENT%20Geoff%20Franklin%20HOW/project-sharing-plus-ent%20(1).png?width=1440&height=810&name=project-sharing-plus-ent%20(1).png)

Vectorworks Spotlight has a range of features to streamline the process. Gone are the days when rigging and lighting were being drawn in separate files with multiple versions of each file. Now, drawing can take place in a centralized location, with Adlib even taking advantage of [Vectorworks **Project Sharing**](../../../net/vectorworks/blog/an-overview-of-project-sharing-in-vectorworks-software.html). 

“It’s a large pool of people that take a project from start to finish, so ease of collaboration is obviously quite a big thing for us,” Pettitt added. 

For example, Adlib had a project manager who was on a job in Italy, but they needed to modify a screen design for an upcoming stadium show that was being deployed in two weeks' time. The manager was able to log into Vectorworks in Italy, make the change to the show plans, submit it, and the rest of the Adlib team in the UK office could see the edits straightaway. There was no need to worry about duplicating files or any work getting lost. 

“\[Vectorworks Spotlight\] just gives you a data management strategy that allows you to collaborate and better deliver projects. No other program can do that,” said Pettitt. 

#### Try Vectorworks for Free Today! 

If you’re also looking to make a switch to Vectorworks for all your entertainment design, planning, and management needs, click the button below to start a free trial: 

[![DOWNLOAD OUR FREE TRIAL](https://no-cache.hubspot.com/cta/default/3018241/390a27f0-579c-46cd-b561-f1be2603b72c.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/390a27f0-579c-46cd-b561-f1be2603b72c) 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.