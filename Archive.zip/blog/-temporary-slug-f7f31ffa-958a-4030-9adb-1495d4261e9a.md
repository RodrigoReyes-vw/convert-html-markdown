[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Your Blog Post Title Here...

 Posted by 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2F-temporary-slug-f7f31ffa-958a-4030-9adb-1495d4261e9a)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Your%20Blog%20Post%20Title%20Here...&url=https%3A%2F%2Fblog.vectorworks.net%2F-temporary-slug-f7f31ffa-958a-4030-9adb-1495d4261e9a&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2F-temporary-slug-f7f31ffa-958a-4030-9adb-1495d4261e9a)

Once you’ve made good progress adopting BIM in your firm, you should be ready to use your BIM models for coordination during the design and construction process.

But with so many variables to consider, how do you know where to begin with coordinating models?

This is where a BIM Execution Plan is incredibly useful. In this blog post, you’ll find out more about BIM Execution Plans, including who’s responsible for creating them and where to get started should you need to create one for your team or help facilitate its creation with the project owner.

## WHAT IS A BIM EXECUTION PLAN?

A BIM Execution Plan is a document written before work begins on a BIM project. The document provides details on roles, timelines, and responsibilities for all parties involved. It also covers what software, hardware, and IT infrastructure are required, plus defines who’s responsible for information management.

Essentially a coordination roadmap, the BIM Execution Plan helps ensure that all stakeholders agree how the BIM process will be carried out.

The term “BIM Execution Plan,” abbreviated “BEP,” is also known as a BIM Project Execution Plan, or BIM PxP.

* [Related: Your Guide to BIM Acronym Definitions](../../../net/vectorworks/blog/bim-acronym-definition.html)

## WHO IS RESPONSIBLE FOR CREATING A BIM EXECUTION PLAN?

Sometimes, owners and construction managers who are experienced with BIM will provide the BIM Execution Plan to the project team. If this is the case, you as an architect must review the provided plan and make sure you’re able to deliver on it. If the plan specifically requires RVT files and you’re using Vectorworks Architect, for example, you’d want to clear this up with the owner or manager and assure them that Vectorworks files can facilitate the process too through IFC or by exporting to RVT. The PIRs — project information requirements — determined by owners and construction managers are often linked to your contractual obligations, so it’s important to be on the same page.

It's also possible that an owner or construction manager wants to execute the project through BIM but doesn’t have the necessary experience to develop a BEP. If this is the case, you can use your experience and resources provided in this blog to create the BEP yourself.

## WHERE DO YOU START WHEN CREATING A BIM EXECUTION PLAN?

If you’ve had success creating a BIM Execution Plan in the past, you can use that document as a template or starting point. If not, you can download this PDF that has standard BIM PxP requirements laid out in a template.

From there, follow this list to get started laying out the bulk of the plan.

* Agree on the file format and version that will be used
* Establish a project reference point
* Use the architectural model as the baseline to dictate the MEP and structural model orientation
* Establish the LOD of the model and agree on what to model as well as when
* Establish a clear schedule for models updates and information exchange
* Establish a clear schedule for coordination meetings

Afterwards, make sure to perform a mockup file exchange to verify the success of the intended workflow.

If you have questions regarding the specifics of each of these points, be sure to consult our full guide to developing BIM Execution Plans.

Establishing a BIM Execution Plan before getting started on a BIM project makes workflows more efficient and successful as well as less prone to error. With deliverables and timelines clearly established for involved parties, the BEP functions as a project blueprint, making it an essential document for your BIM projects.

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.