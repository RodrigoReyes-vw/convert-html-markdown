[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Women in Architecture: A Conversation with 3+1 architects

 Posted by [Cozette Conrad](https://blog.vectorworks.net/author/cozette-conrad) | 6 min read time 

![3+1-architects-2](https://blog.vectorworks.net/hubfs/Blog%20Images/190904_3+1%20Women%20in%20Architecture/3+1-architects-2.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fwomen-in-architecture-a-conversation-with-31-architects)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Women%20in%20Architecture:%20A%20Conversation%20with%203+1%20architects&url=https%3A%2F%2Fblog.vectorworks.net%2Fwomen-in-architecture-a-conversation-with-31-architects&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fwomen-in-architecture-a-conversation-with-31-architects)

Women across the globe move architecture forward every day. We spoke with Estonian architects Hanna-Liisa Mõtus and Karin Harkmaa about their recent projects, their design approach, and their experiences working in a male-dominated field.

_A conversation with Hanna-Liisa M_ _õtus and Karin Harkmaa of 3+1 architects._

Mõtus and Harkmaa design at [3+1 architects](http://www.threeplusone.ee/), a 12-person firm staffed with graduates of the [Estonian Academy of Arts](https://www.artun.ee/en/home/). Former teachers and students are now firm partners. And even though they don’t teach it at the Academy, 3+1 has used [Vectorworks Architect](https://www.vectorworks.net/en/architect?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=womeninarch090419) for 15 years.

“The first year, we’re not allowed to use computers,” Harkmaa said. “We had to make all the projects by hand.” Perhaps it’s this method of learning — or simply an innate skill for empathizing with clients — that gives Harkmaa and Mõtus their unique perspective on architecture. 

When approaching a new project, they think first of the human element, conceptualizing the space as a whole and how it will support the everyday lives of the people inside. “We have to research the people who are going to use the space and understand what they want and need and kind of translate that into architecture,” said Mõtus.

The architects relied heavily on this approach with the [Tallinn School of Music and Ballet](https://www.hm.ee/en/news/tallinn-school-music-and-ballet-will-be-new-name-state-school-fine-arts), a winning design of [Atelier Thomas Pucher](http://www.thomaspucher.com/) that 3+1 collaborated on in sketch design and took over from preliminary design. The new campus will merge three existing schools. Harkmaa and Mõtus visited each one to get to know the students and instructors, instilling their needs into every detail of the design.

_![3+1Presentationresized-78](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/1909043+1%20Women%20in%20Architecture/3+1Presentationresized-78.jpg?width=601&name=3+1Presentationresized-78.jpg)_ _Rendering of the new campus for Tallinn School of Music and Ballet. Image courtesy of 3+1 architects._

In Estonia, children who want to learn ballet have to move to the capital, Tallinn. The school houses children as young as 10 years old in a dormitory unit, which 3+1 designed with comfort in mind. “It’s more colorful and homely, because they spend long days in school,” explained Mõtus, adding that the environment needs to feel supportive without parents around. 

“The design concept was that it's a little oasis in the middle of the city. The building itself creates a forest in the middle, so there's a place for quiet,” she continued. “You can go inside and the building kind of protects you, and you can just relax and enjoy the peace.”

And then there’s the concert hall: a grand auditorium, beautiful if slightly intimidating to young performers. “It’s supposed to be the dream that you aspire to,” said Mõtus.

![3+1_Presentation_resized-196](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190904_3+1%20Women%20in%20Architecture/3+1_Presentation_resized-196.jpg?width=601&name=3+1_Presentation_resized-196.jpg)_Rendering of the concert hall at Tallinn School of Music and Ballet. Image courtesy of 3+1 architects._

As many large projects do, the Tallinn School of Music and Ballet involved a careful balance of outside-the-box creativity while staying within the confines of strict building standards. Estonia has specific BIM requirements for public buildings, and 3+1 was prepared to meet them.

The firm uses BIM in all their projects. Beyond helping them meet public mandates, BIM enhances their ability to collaborate with project partners. “All of the information is in 3D, and we just communicate through the IFC and BIM models,” explained Mõtus. And communication was key when designing the school, as 3+1 was working as local partners to an architecture firm based in Austria, almost 1,000 miles from Estonia.

“The project is so big and complicated that, for us, you couldn't control it without BIM,” said Mõtus.

![3+1_Presentation_resized-168](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190904_3+1%20Women%20in%20Architecture/3+1_Presentation_resized-168.jpg?width=601&name=3+1_Presentation_resized-168.jpg)_3D model of the Tallinn School of Music and Ballet. Image courtesy of 3+1 architects._

BIM lets you envision your design in an intricate, realistic virtual space — but for 3+1, nothing beats experiencing the finished product. “When you're inside this space — where you have been like a thousand times in your model — and then it's real,” said Harkmaa, “You have created something. And that's the reward.”

Perhaps even more rewarding is succeeding as an underdog. Architecture is a [male-dominated field](https://www.nytimes.com/2018/12/15/opinion/sunday/women-architects.html) — and while 3+1 values talent and ambition regardless of gender, not every collaborator or client feels the same.

Because of their gender, Harkmaa and Mõtus feel there are moments when they need to work even harder to be trusted or taken seriously. “We often feel not fully accepted as professionals until we have proven our competence,” they agreed. “These obstacles might shake you sometimes, but will make you stronger. You just need to be — or look — confident while staying true to yourself.”

Harkmaa and Mõtus, along with their colleagues at 3+1, believe great designs come from passion, personal experience, and devotion. “After all, it depends on the person. No matter which gender you are, the ideas make your architecture,” said Mõtus.

“You have to be persistent,” she continued. “You can't give up. If something is really important to you, you just have to try to explain it and fight for it. Like your everyday life.”

###### Interested in more stories about women crushing it in architecture? Read our latest roundup.

[![Read More](https://no-cache.hubspot.com/cta/default/3018241/48beedf3-2973-453b-b0a8-ff3b335cdd74.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/48beedf3-2973-453b-b0a8-ff3b335cdd74) 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.