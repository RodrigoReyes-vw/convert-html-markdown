[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# December Webinars: The Story of BIM, AV Workflows, & BIM For Landscape

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 2 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/211208_December%20Webinar/December%20BLDG%20Webinar%20Image.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinars-december-2021)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=December%20Webinars:%20The%20Story%20of%20BIM,%20AV%20Workflows,%20&%20BIM%20For%20Landscape&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinars-december-2021&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinars-december-2021)

Maintain accreditation and earn continuing education credits with Vectorworks’ monthly webinars. Whether you are a beginner or experienced designer, you can gain new skills, fine-tune workflows, and discover all you can do with Vectorworks.

###### BIM Has Always Been Here 

_Tuesday, December 14 | 2 pm EST_

Building Information Modeling (BIM) is often mistaken as a relatively new workflow, but it’s been around far longer than many of us know. BIM — at its most basic level — is a combination of geometry and data, which designers have been using for millennia.   
  
This webinar explores the history of BIM, examines the tools influencing current BIM workflows, and offers a glimpse into future technologies for designers.

This course is approved for one AIA LU, CORE AIBC, AAA, OAA, ALBNL, AANB, and NSAA. 

![December BLDG Webinar Image](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211208_December%20Webinar/December%20BLDG%20Webinar%20Image.png?width=1440&name=December%20BLDG%20Webinar%20Image.png)

###### [![SIGN ME UP!](https://no-cache.hubspot.com/cta/default/3018241/a57a289e-1952-4ff6-89ff-989593fd5e52.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/a57a289e-1952-4ff6-89ff-989593fd5e52) 

###### A Complete AV Design Workflow 

_Wednesday, December 15 | 2 pm EST_

Is your design workflow in need of a lift? Join Tom White, industry specialist and training consultant at Vectorworks, for a webinar that will discuss common challenges in entertainment design. White will show you his innovative solutions to these problems, walking you through a complete AV design workflow — from modeled elements in Vectorworks to schematics in ConnectCAD.

![December ENT Webinar Image](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211208_December%20Webinar/December%20ENT%20Webinar%20Image.png?width=1440&name=December%20ENT%20Webinar%20Image.png) 

###### [![SIGN ME UP!](https://no-cache.hubspot.com/cta/default/3018241/49a9e9ea-9d0e-49dc-b2c1-5a29ca37e79f.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/49a9e9ea-9d0e-49dc-b2c1-5a29ca37e79f) 

###### When It Has To Be BIM

_Thursday, December 16 | 2 pm EST_

Landscape architecture is evolving, and BIM is becoming more important than ever. Join Todd McCurdy, FASLA to explore an example project in which workflows using BIM software were used throughout the design process. McCurdy will show the benefits of BIM on a new restaurant site, in a pedestrian zone, where planting, steps, ramps, grading, and drainage are all part of the landscape architect's scope. Like most multidisciplinary design team projects, Todd will share how crucial IFC exchanges are when each participant is using a different BIM solution, and how easily these files can be shared among team members to guide design direction with project stakeholders.

 This course is approved for  one LA CES PDH and one APLD CEU. 

![December Webinar LND Image](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211208_December%20Webinar/December%20Webinar%20LND%20Image.jpg?width=1440&name=December%20Webinar%20LND%20Image.jpg) 

[![SIGN ME UP!](https://no-cache.hubspot.com/cta/default/3018241/9e59c619-e0c1-483b-bdcb-9a23e5bc8cb9.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/9e59c619-e0c1-483b-bdcb-9a23e5bc8cb9) 

If you’re wanting more great webinars, [you can watch all of our webinars on demand](https://university.vectorworks.net/). In [November](../../../net/vectorworks/blog/vectorworks-webinars-november-2021.html), we discussed game show lighting, Twinmotion, and dynamic design-build efficiency.

 Topics: [Project Highlight](https://blog.vectorworks.net/topic/project-highlight), [Tech Tips and Workflows](https://blog.vectorworks.net/topic/tech-tips-and-workflows), [BIM (Landscape)](https://blog.vectorworks.net/topic/bim-landscape) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.