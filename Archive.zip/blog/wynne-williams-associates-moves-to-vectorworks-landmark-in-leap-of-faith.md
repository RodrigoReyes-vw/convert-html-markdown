[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Wynne-Williams Associates Moves to Vectorworks Landmark in Leap of Faith

 Posted by [Guest Author](https://blog.vectorworks.net/author/guest-author) | 7 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/200728_Matt%20Bird%20/blog-images-resize-july-28.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fwynne-williams-associates-moves-to-vectorworks-landmark-in-leap-of-faith)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Wynne-Williams%20Associates%20Moves%20to%20Vectorworks%20Landmark%20in%20Leap%20of%20Faith&url=https%3A%2F%2Fblog.vectorworks.net%2Fwynne-williams-associates-moves-to-vectorworks-landmark-in-leap-of-faith&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fwynne-williams-associates-moves-to-vectorworks-landmark-in-leap-of-faith)

_This article was originally published on_ [_Land8’s website_](https://land8.com/british-firm-wynn-williams-associates-takes-leap-of-faith/) _and is written_ _by Cheryl Corson, RLA, ASLA, CPSI._

As Matt Bird, senior landscape architect and BIM manager at Wynne-Williams Associates describes it, “the firm took on a multi-school project in 2014, our first large BIM project and doing it in SketchUp was very painful.” Bird described the use of multiple software products on that project and the great potential for error. So in November 2015 at a BIM conference, he shopped around for an alternative.

![Manor Street project ](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/200728_Matt%20Bird%20/Manor%20Street%20project%20.png?width=600&name=Manor%20Street%20project%20.png)_Image of the Manor Street project, modeled in Vectorworks Landmark. Courtesy of Wynne-Williams Associates._

In the UK, BIM is required for firms working on government contracts. Wynne-Williams Associates, a firm northeast of London, does about 80% of its work in the educational sector. After comparing several options, Bird and his colleagues opted for [Vectorworks Landmark](https://www.vectorworks.net/en-US/landmark?utm%5Fcampaign=blog&utm%5Fcontent=072820landmattbird&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext) design and BIM software. Initially, longtime British instructor and [Vectorworks](https://www.vectorworks.net/en-US?utm%5Fcampaign=blog&utm%5Fcontent=072820landmattbird&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext) Sales Enablement Director Tamsin Slatter helped the firm with training. “The issue is having time to integrate more of our processes into Vectorworks,” says Bird. “We’re busy, and moving to Vectorworks was very much a leap of faith.”

After only two years, the team has made a gradual transition to Landmark to the point where new projects are now begun solely in the software. “One project we started completely in Landmark is at an urban site in Braintree called Manor Street. It is nice and complex and has a lot of steep slopes. We’re still learning site modeling, and we’re trying to incorporate it as much as possible.” Bird goes on to describe how the biggest win for them was to have the modeling and plant data in one package. “It meant that we were able to mitigate and now eliminate using multiple software such as Revit or SketchUp.”

![Elevation and detail ](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/200728_Matt%20Bird%20/Elevation%20and%20detail%20.png?width=600&name=Elevation%20and%20detail%20.png)_Elevation and detail sheet for the Manor Street project. Courtesy of Wynne-Williams Associates._

Bird is responsible for training office staff, and it is important to him that various people develop different skills with the software so that no one person holds all the institutional knowledge. He finds that the firm’s weekly design meetings result in changes being made more quickly and easily than before. He also finds that the IFC file transfer format is more stable in Vectorworks than using the Revit import function.

Some things that the firm has not yet utilized in Vectorworks but plans to in the future include GIS, [Marionette](https://www.vectorworks.net/training/marionette?utm%5Fcampaign=blog&utm%5Fcontent=072820landmattbird&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext), the Camera Match tool, and integrate with [Bluebeam](https://www.bluebeam.com/), a sister brand to Vectorworks and also part of the [Nemetschek Group](https://www.nemetschek.com/). The firm is also doing their tree surveys in a different software for the time being and looking to utilize the Import Tree Survey file feature recently added to Landmark. However, Bird is a big fan of the Vectorworks Landmark improvements to hardscape modeling, especially since hardscape layers play such an important role in BIM compliance. And the firm has integrated [Vectorworks’ real-time rendering application partner plug-in Lumion](../../../net/vectorworks/blog/lumion-renderings-with-vectorworks.html) with success.

![Vectorworks model](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/200728_Matt%20Bird%20/Vectorworks%20model.png?width=600&name=Vectorworks%20model.png)_Vectorworks model, visualized in Lumion. Courtesy of Wynne-Williams Associates._

Regarding BIM, explains Bird, “the government here has established a universal (class) naming system, so our workflow didn’t change too much when we moved to Vectorworks. Depending on the stage or LOD required, we do spend extra time for modeling, front loading objects, which makes our process easier at later stages. More often than not, we look to make sure any hardscape slabs were constructed with as much information as possible.” Landscape architects at Wynne-Williams Associates collect BIM objects from various sources including Vectorworks libraries.

A key role that Vectorworks has played in the firm’s work is with community input into public design projects. “With Vectorworks we can quickly produce images to show community members, which is quite helpful. It’s an extra tool in our arsenal.”

Another feature that Bird appreciates about the software is that while they have issues with multiple versions saving in Revit, they don’t have the same worry with Vectorworks. “The architects use Revit,” says Bird, “which does not allow you to save in earlier versions, and we have long discussions at staff meetings about which version of Revit to use. This isn’t an issue with Vectorworks.”

Bird won a free trip to the 2020 [Vectorworks Design Summit](https://www.vectorworks.net/design-summit?utm%5Fcampaign=blog&utm%5Fcontent=072820landmattbird&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext) in San Diego by participating in a Vectorworks social media contest. The [Design Summit was unfortunately cancelled due to COVID-19](/how-vectorworks-is-helping-customers-during-covid-19?utm%5Fcampaign=blog&utm%5Fcontent=072820landmattbird&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext). Therefore, this interview was conducted by video conference. When asked how the pandemic had affected the firm’s business, Bird, speaking from his kitchen at home, said, “it hasn’t been as big as we thought it would be. Construction slowed for a couple of weeks, and then it picked back up again. We had some staff furloughs but hope to bring those folks back on soon. At first, we all went to the office to collect what we needed to work from home. And like most companies, we are now doing a lot with video-conferencing.”

Additionally, Wynne-Williams Associates uses Vectorworks’ [Project Sharing](https://www.vectorworks.net/products/features/project-sharing?utm%5Fcampaign=blog&utm%5Fcontent=072820landmattbird&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext) often for their larger projects and given the current situation, they’re trialing [Vectorworks Cloud Services](https://www.vectorworks.net/cloud-services?utm%5Fcampaign=blog&utm%5Fcontent=072820landmattbird&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext) to host the project file rather than having it on their office server.

Wynne-Williams Associates award-winning projects are beautifully [featured on their website](https://w-wa.co.uk/), including schools, playgrounds, recreation spaces, and open space projects. 

#### About the Author

![Cheryl Corson headshot](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/200728_Matt%20Bird%20/Cheryl%20Corson%20headshot.png?width=281&height=283&name=Cheryl%20Corson%20headshot.png)

Corson is a self-employed landscape architect and Vectorworks Landmark user based in the Mid-Atlantic region. She has used Vectorworks since 2009\. Corson has also helped prepare over 1,000 landscape architects for the LARE through her online learning platform, [Corson Learning](https://corsonlearning.com/). She is also the author of the Sustainable Landscape Maintenance Manual for the Chesapeake Bay Watershed, and leads the Mid-Atlantic Vectorworks Landmark User Group. Contact her at [cheryl@cherylcorson.com.](../../../net/vectorworks/blog/index.html)

_Image: Kat Forder Photography._

 Topics: [Landscapes](https://blog.vectorworks.net/topic/landscapes) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.