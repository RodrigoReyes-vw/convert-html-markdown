[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Tech Tips with Sooner Rae Creative, Designers for Big Names in Music

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 10 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/221117_Sooner%20Rae%20Creative/blog-1440x800_Sooner%20Rae%20Creative.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fadvice-for-you-and-your-vectorworks-spotlight-workflow)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Tech%20Tips%20with%20Sooner%20Rae%20Creative,%20Designers%20for%20Big%20Names%20in%20Music&url=https%3A%2F%2Fblog.vectorworks.net%2Fadvice-for-you-and-your-vectorworks-spotlight-workflow&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fadvice-for-you-and-your-vectorworks-spotlight-workflow)

Are you ever curious how designers and drafters are using [Vectorworks Spotlight](https://www.vectorworks.net/spotlight)? Or if they’re sitting on some advice that may work wonders for you and your workflow?

Well, if you have, this is the blog for you. The talented members and collaborators of Sooner Rae Creative have some helpful opinions on Vectorworks, design, and combatting the demands of chaotic and fast-paced live events industry.

But first, a little background on the trio and their impressive resume of projects.

## Getting to Know Sooner Rae Creative 

A lighting designer with 20-plus years of experience, Sooner Routhier has worked with the likes of Rihanna, Jay-Z, and Coldplay. And, as if working with such talented artists isn’t a reward enough, Routhier has won the Live Design Achievement Award, a prize which honors the work of young designers. 

In 2019, Routhier started [Sooner Rae Creative](https://soonerrae.com/). And, in 2021 she was joined by her design assistant, Allison Ciccarelli. 

Routhier doesn’t create their stunning designs all on their own, however. She works closely with Matt Geasey and Bryan Seigel — whom make up [Clear All Visuals](https://www.facebook.com/clearallvisuals/) — to create drafts in Vectorworks Spotlight. Geasey is a Vectorworks beta-tester and drafter with 15 years of experience in the live events industry. Seigel is a newer collaborator of Routhier and Geasey’s, having previously worked in lighting production in Austin, Texas and as a trainer at Vectorworks.

![P!ATD_TPA-43](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221117_Sooner%20Rae%20Creative/P!ATD_TPA-43.jpg?width=1440&height=960&name=P!ATD_TPA-43.jpg)

_Panic! At The Disco_

After Routhier has an initial meeting with the clients, she jumps right into Vectorworks and starts to sketch out designs with basic 3D modeling tools and gets her ideas together. “It's really just about all the raw tools and orbiting around a model to be able to see if things are lining up properly,” she says, even humbly joking, “I can draw circles and squares.” 

Routhier then shares her concepts with Geasey and Seigel who flesh out the Vectorworks files with all the 3D modeling and documentation needed for every show to be a success. 

## Vectorworks Advice from Entertainment Design Professionals

Like countless other design professionals around the world, Routhier, Geasey, and Seigel use Vectorworks to create breathtaking, effective designs in a timely manner. Below are just a few of the features that help them do it:

### Using Schematic Views in Vectorworks Spotlight

“Right now, we’re also very big into [schematic views](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/LightingDesign2/Concept%5FSchematic%5Fviews.htm?rhsearch=schematic%20views&rhhlterm=schematic%20views%20view),” Seigel said.

The team use the “Create Schematic View” command to quickly create easy-to-read 2D views for paperwork from an already-existing 3D model. The feature helps them meet their goal of documenting and presenting ideas as quickly as possible. 

Funny enough, Seigel became familiar with the benefits of schematic views during his time working internally for Vectorworks. 

“I made the videos for the feature when it first came out,” he remembers. “Then, I started with Matt \[Geasey\] and saw that he was doing things a different way. I was like, ‘No, there’s this whole other feature that’s perfect for this thing you’re trying to do.’”

[To create schematic views in Spotlight](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/LightingDesign2/Creating%5Fschematic%5Fviews.htm?rhsearch=schematic%20views&rhhlterm=schematic%20views%20view):

1. Select a rigging object
2. Select the Create Schematic View command in the Spotlight > Visualization menu
3. Select the layer and view once the Create Schematic View dialog box opens
4. To create a schematic view of a connected rigging system, select “Create a schematic view of the rigging system.” Otherwise, proceed to step 4
5. Click on the drawing to place the schematic view

For a single rigging object, the rigging object is placed at your click point. For _multiple_ rigging objects, the first rigging object in the stacking order is placed at your click point. Click to place each rigging object individually. For a connected rigging system, the rigging object that was selected to create the schematic view is placed at your click point with the system objects connected to it.

### Templates to Repeat Processes

To save time and meet the incredible demands of the live events industry, the trio relies heavily on [creating templates so that their processes are repeatable and efficient](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Setup/Concept%5FTemplates.htm?rhhlterm=templates%20template&rhsearch=template). 

“If you find yourself doing something more than once, take a moment or two and add it to a template,” said Seigel. “There’s no other feature that saves you more time and gives you more consistency in what you’re producing.”

 To create a template: 

1. Take your file with all desired elements and select the “Save as Template” command
2. Enter the name of the template and save it in your desired folder
3. Save the template
4. To use the template, select “File > New” to open the “Create Document” dialog box. Select “Use document template,” and then select the new template from the list

### Data Tags, Worksheets, and Data Visualization to Save Time

In a similar vein of their template use, Routhier, Geasey, and Seigel use data management features in Spotlight — [data tags](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Annotation2/Adding%5Fdata%5Ftags%5Fand%5Flabels.htm?rhsearch=data%20tags&rhhlterm=data%20tags%20tag%20tagging%20tagged), [worksheets](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Worksheets/Creating%5Fworksheets.htm?rhsearch=worksheet&rhhlterm=worksheets%20worksheet), and [data visualization](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Views/Creating%5Fa%5Fnew%20data%5Fvisualization.htm?rhsearch=data%20visualization&rhhlterm=data%20visualization%20visualizing%20visualizations%20visually) — to get time back in their design process.

By creating data-rich files, the team makes their lives easier when interacting with technical directors and other event professionals. “We do our best to mitigate as many phone calls as we can,” said Geasey. The little extra work of adding data to their drawings actually saves them time, since anything anyone would wonder — or have to call about — is embedded into the drawing.

In fact, Routhier had an experience that validated the team’s efforts. She woke up to an email from a vendor with whom they hadn’t worked with in a while. The vendor, according to Routhier, said, “I really like what you’re doing. Very clean, precise, and intuitive. Nicely done.”

### Shaded Renderings for Drawings and Presentations

Once the model is fully built out, Routhier and co. create [shaded renders.](https://university.vectorworks.net/course/view.php?id=2228)

Shaded Render Mode, which received an update with Vectorworks 2023, supports more light objects, glow textures, and more, meaning you’ll get a better understanding of your project while designing and ensuring a better quality render output. 

When you’re in a shaded render view, objects may overlap, obscuring your view of objects lower in the stacking order. And, since Shaded mode is a working mode, it lets Routhier “revolve around the model and make sure everything is looking proper and in its right place.” 

Additionally, the renderings are now a staple in the proposal package that the team provides their clients.

## Other Advice from Entertainment Design Professionals

The trio’s advice isn’t limited to only Vectorworks, either. They also have some other great tips for you!

![Evanescence2021-26](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221117_Sooner%20Rae%20Creative/Evanescence2021-26.jpg?width=1440&height=961&name=Evanescence2021-26.jpg)

Evanescene

### Keep it Simple When You Need To

“Keep it as simple as you need to understand a drawing for yourself and explain it to others,” Geasey said. 

It can be tempting to start making incredibly complex drawings and diagrams as soon as you start out. But, as Geasey points out, there’s a chance that it can all get away from you pretty quick.

“If you try to do everything at once, you’re just going to clutter your file all up and it’s going to be a real dumpster fire.”

Instead, Geasey advises that you add one new feature or design element to each project. This way, you can gradually scale your design process and figure out what works best for you. 

### Ask Questions and Never Stop Learning

“Don’t be afraid to ask questions when you’re stuck on something,” said Routhier. “I ask these guys \[Geasey and Seigel\] questions all the time!”

It’s a refreshingly humble answer from someone who’s worked with some of the biggest names in music; but, it also explains why Routhier is as successful as she is. She's always willing to learn more.

![Evanescence2021-49](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221117_Sooner%20Rae%20Creative/Evanescence2021-49.jpg?width=1440&height=960&name=Evanescence2021-49.jpg)

She continued, actually echoing Geasey’s advice, explaining that the more she and her team learn, the simpler their processes and workflow becomes. 

The founder of Sooner Rae Creative ends with a metaphor that all design professionals — no matter your level of expertise — can benefit from:

> “When you’re watching a cooking show and a high-end chef is putting together a beautiful plate of food, you always hear them talking about ‘touches.’ How many touches does it take to make a dish? If you’re looking at 50 touches for a plate of food, your customer is going to be hungry. 
> 
> But, if you can get the same dish out the door in three touches, then you’re going to have a happy, full customer.
> 
> It’s the same thing with creating lighting designs in Vectorworks — fewer touches.”

## Still Wanting More Tech Tips and Tutorials? We Got You Covered

If the advice from Routhier, Geasey, and Seigel has left you wanting more Vectorworks tips and tutorials, click the button below to visit Vectorworks University. 

[![BROWSE VECTORWORKS UNIVERSITY](https://no-cache.hubspot.com/cta/default/3018241/80cc3a4d-d8da-4e1e-87d3-d9a3e929e246.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/80cc3a4d-d8da-4e1e-87d3-d9a3e929e246) 

_All images courtesy of Sooner Rae Creative and Todd Moffses._

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.