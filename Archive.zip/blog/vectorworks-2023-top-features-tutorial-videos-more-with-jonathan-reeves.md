[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# The Vectorworks 2023 Features This Architect Loves

 Posted by [Guest Author](https://blog.vectorworks.net/author/guest-author) | 7 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/221103_Jonathan%20Reeves%20Guest%20Blog_Launch%202023/blog-1440x800_Jonathan%20Reeves.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-2023-top-features-tutorial-videos-more-with-jonathan-reeves)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=The%20Vectorworks%202023%20Features%20This%20Architect%20Loves&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-2023-top-features-tutorial-videos-more-with-jonathan-reeves&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-2023-top-features-tutorial-videos-more-with-jonathan-reeves)

_This story is written by Jonathan Reeves BA (Hons) M, Arch Dip. Arch RIBA_, _of_ [_Jonathan Reeves Architects_](https://www.jonathanreevesarchitects.uk/) _and_ [_Jonathan Reeves CAD_](https://www.youtube.com/channel/UC56qp6QeXSAayDOOHu3BcCA?view%5Fas=subscriber)_._ 

....

As autumn approaches and the summer fades behind us, the changing seasons remind us of the changes in our lives. Sometimes, it feels that the pace of technological change is hard to keep up with and make the most of in a way that can benefit us.

![jr architecture jonathan reeves](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221103_Jonathan%20Reeves%20Guest%20Blog_Launch%202023/jr%20architecture%20jonathan%20reeves.jpg?width=1440&height=964&name=jr%20architecture%20jonathan%20reeves.jpg)

One common theme I see in life is the search for more time to do all we need to accomplish in a day. This year’s release of Vectorworks 2023 focuses on exactly that with the goals of “Supercharging Your Workflow” and “giving you time back.”

There are many new features and enhancements in this year’s Vectorworks release that aim to speed up and automate tasks for designers that will make you more productive, creative, and ultimately give you more time to design.

###### My Favourite Vectorworks 2023 Features

Welcome Home

One of my favourite new features you will notice right away is the [new Vectorworks Home ](../../../net/vectorworks/blog/home-screen-innovation.html)[Screen](../../../net/vectorworks/blog/home-screen-innovation.html). This brings together a well-presented visual experience that allows you to easily access your recent files, find out what’s new, and learn about the [Cloud Services](https://www.vectorworks.net/cloud-services) as well as manage your account. It’s convenient having this Home Screen when you start up Vectorworks and a great way to develop the skills of the community by showing them more of the amazing things Vectorworks can offer them.

Interactive Openings

My next top feature has to be the amazing new Direct Modeling of Doors and Windows. This was afeature I imagined and suggested to Vectorworks a few years back (I am sure along with many others, but I like to think that a little of this idea might have been influenced by me!). Being able to place and edit openings directly in 2D or 3D makes designing much more intuitive, and very fast indeed, saving huge amounts of time. I love the new enhancementsto bi-folding doors and windows, that are now totally flexible with no limits in what you can do.

Powerful Wall Improvements

These improvements to windows and doors have also been combined with efficient consolidations for wall tool creation and editing, and the new wall closure options are fantastic! It’s now possible to create a wide range of different splayed and rounded reveals to your walls that display detail both in top/plan and 3D, freeing up creativity and saving time asyou can easily build this into your wall styles.

What a Legend

Of all the new features, the most dramatic must be the totally new automated Graphic Legend tool. This can be used to create schedules of doors, windows or almost anything in the project with amazing flexibility and speed. I think it’s a very powerful tool that changes the way Vectorworks is used and encourages users to dig deeper into more intelligent workflows as it saves so much time and effort, it can’t be ignored.

Giving You the Edge

3D modelling in Vectorworks has always been excellent, and I love the history-based modelling that lets you go back and edit the geometry that you have created at almost any time. Now the new Offset Edge tool takes direct 3D editing way further with new modes for planar and now non-planar objects. This revolutionises your 3D modelling workflows and willmake users feel more comfortable with learning freeform modelling.

The Rendering Revolution

Having fast built-in rendering while you design has always been strong in Vectorworks, but now Vectorworks features environmental lighting and object reflections directly in shaded views. When you combine this to the new unlimitednumbers of lights and effects like lit fog, it’s possible to give your clients a really nice real-time experience by walking around your designs. This way, you can just go into [Twinmotion](../../../net/vectorworks/blog/your-guide-to-rendering-with-twinmotion.html), [Enscape](../../../net/vectorworks/blog/simple-tips-for-using-enscape-and-vectorworks.html), or [Lumion](../../../net/vectorworks/blog/lumion-renderings-with-vectorworks.html) if you want to take things even further.

Updated Redshift rendering has also now been made available to everyone regardless of their GPU hardware as it uses the CPU when required.

Background to the Future

Designers love sections, and now huge improvements in the VGM (Vectorworks Graphics Module) mean that sectionviewports render up to 6 times faster with 80% less memory, in the background. This means that now nearly all the rendering processes are non-blocking while you carry on working which could significantly reduce your stress and couldmean you will drink less coffee or tea!

My Background

As a Vectorworks user my experience now goes way back when I first started with MiniCAD 4 (the precursor to Vectorworks) back in the early 90’s, while I was studying for a Masters in Architecture and Computing at SheffieldUniversity. From my first experience of CAD drafting and 3D modelling on my first Apple Mac, I was hooked, and this combination of Computing and Architecture became the focus and the passion of my career ever since!

Over the years we have witnessed huge changes in both computer hardware and software capabilities, with theexponential growth in speed and capability that has revolutionised the architectural design process.

Now it is common to design directly on the computer from first principles and for me that is why I have always loved Vectorworks with its simple but powerful user interface, and amazing 2D graphics combined with powerful 3D modelling and rendering tools. Add in the extremely powerful BIM (Building Information Modelling) capabilities and interoperability with a wide range of other software such as Revit, SketchUp, Enscape and Twinmotion, and Vectorworks offers a true “all-in-one” with no limits.

As well as using Vectorworks in my own architectural practice for the last 20 years, I have also been an active professional trainer. I find this inspiring as I have worked with some of the best designers and practices in the business over the years, providing bespoke CAD/3D and BIM training to individuals and practices. Since the pandemic, all of thishas been done using Zoom, which means I can now teach students all over the world.

Over the last few years, I have also been developing my YouTube channel, [Jonathan Reeves CAD](https://www.youtube.com/channel/UC56qp6QeXSAayDOOHu3BcCA?view%5Fas=subscriber). I focus mainly on Vectorworks and real-time rendering software like Twinmotion and Enscape as 3D architectural modelling and visualisation has always been my true passion, and I love sharing this with my followers. The channel now has over 12,600 subscribers and 280 videos, and I aim to keep growing this.

_For more of Reeves’ insights, click the button below to watch the free webinar:_

_[![REVOLUTIONIZE YOUR RENDERING WITH VECTORWORKS AND TWINMOTION](https://no-cache.hubspot.com/cta/default/3018241/e0991bee-9a25-4f4e-9873-20ea2c533ed1.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/e0991bee-9a25-4f4e-9873-20ea2c533ed1)_ 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.