[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Skakki Studio's Captivating Workflow Transformation

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 3 min read time 

![webinar-image-ent-sept](https://blog.vectorworks.net/hubfs/Blog%20Images/190919_Skakki/webinar-image-ent-sept.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-to-make-better-renderings-with-half-the-software)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Skakki%20Studio's%20Captivating%20Workflow%20Transformation&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-to-make-better-renderings-with-half-the-software&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fhow-to-make-better-renderings-with-half-the-software)

Wouldn’t it be nice to design, previsualize, document, and coordinate events without all the back-and-forth between software?

In the events industry, we know how quickly you need to work to meet deadlines. It gets tricky when you have to spend time importing and exporting files from different software. The transition between programs invariably affects project efficiency.

[Skakki Studio](https://skakki.com/), an event design and visualization studio in Italy, found a solution in [Vectorworks](https://www.vectorworks.net/en-US?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=entsept). Before switching, they would work with up to 8 different pieces of software to develop stunning renderings like the one below, which was created with their newfound Vectorworks workflow.

![webinar-image-ent-sept](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190919_Skakki/webinar-image-ent-sept.jpg?width=1440&name=webinar-image-ent-sept.jpg)

_Rendering courtesy of Enzo Appetecchia and Skakki Studio._

But their rendering workflow was long and tedious. Their business goal is to provide the same visual standards found in architecture at a fraction of the cost, according to firm director Enzo Appetecchia.

Enzo hosted a webinar with us — if you’re looking for direction on how to create beautiful renderings, you won’t want to miss it!

[![Watch: Switching to Vectorworks for Efficient Workflows](https://no-cache.hubspot.com/cta/default/3018241/670078fc-34ce-4aec-aad6-8c078657b53a.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/670078fc-34ce-4aec-aad6-8c078657b53a) 

Read on for a look into Skakki Studio’s transformed workflow, a before-and-after story with a striking result.

## Before Vectorworks

Skakki Studio used SketchUp for basic venue and set modeling, then integrated Layout with SketchUp for documentation, presentation, and scaled drawings. They used 3DS Max or Blender for more complex scenes, Wysiwyg for lighting and truss design and previz, AutoCAD for drawing 2D plots and editing clients’ files, VRay as a rendering engine, and Photoshop for image touch-ups.

If you think about it, that’s a _ton_ of time wasted transitioning files between software. “We used to spend valuable hours importing and exporting models and cleaning up geometries in order for the design to be consistent,” Enzo said. "No external rendering engine can be integrated into Wysiwyg, so our only choice was to re-export the models to other software." He found that 3D elements would often have inaccurate or oversimplified geometries when exported.

Skakki chose VRay for rendering but said it struggled with more complex scenes. Rendering frame-by-frame animations would sometimes take their computers days, Enzo said.

All in all, Skakki went through a lot of work to produce renderings. Why not make the entire process more simplistic without sacrificing quality?

## After Vectorworks

The resulting workflow is a compelling one for event designers. 

Skakki Studio now uses one software for all their 3D modeling needs — from modeling to documentation, scaled drawings, lighting design, and rigging. They do it all in Vectorworks, greatly reducing the number of programs needed to prepare a model for rendering.

“It’s nothing short of revolutionary,” Enzo said.

They’ve reduced the overall number of software programs from seven or eight down to just three. That’s a lot of time saved on clerical tasks. That’s a lot of time they can now use designing.

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.