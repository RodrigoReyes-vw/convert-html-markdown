[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Simple Tricks for More Efficient Entertainment Design

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/221026_Ben%20Instep%20Siyan/Siyan_BBC_blog-1440x800.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2F3-vectorworks-tips-that-will-help-you-work-faster)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Simple%20Tricks%20for%20More%20Efficient%20Entertainment%20Design&url=https%3A%2F%2Fblog.vectorworks.net%2F3-vectorworks-tips-that-will-help-you-work-faster&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2F3-vectorworks-tips-that-will-help-you-work-faster)

There’s nothing quite like being a designer or technician in the entertainment industry. The excitement, the creativity, the energy — that’s why you love it, and that’s why we love it as well.

But let’s face it, it’s also one of the most demanding jobs out there, so anything that can save you time and make your day easier is _more than welcome!_

In this post, we’ll share simple tricks that – in addition to a strong cup of coffee —will make your working process more efficient. You’ll be able to focus more on the parts of your work that you love!

## Personalize Your Workspace 

When tailoring your design space in Vectorworks Spotlight, the [**Workspace Editor**](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Start/Palettes%5Fand%5Ftool%5Fsets.htm?rhsearch=workspace%20editor&rhhlterm=workspace%20workspaces%20editor) is a great place to start. But if you’re looking for even greater levels of personalization to speed up your workflow, we recommend checking out the **[Smart Options Display](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Start/Smart%5FOptions%5FDisplay.htm?rhsearch=smart%20options%20display&rhhlterm=smart%20options%20option%20display)**. 

Using this display keeps your frequently used tools, tool sets, tool modes, and more right next to your cursor while you’re working in your drawing. You’ll no longer need to move your mouse around to locate your Lighting Device tool, rigging tools, or whatever you find yourself using most often. Instead, your focus can stay on your design itself.

![Vectorworks Spotlight Tips 2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230127_ENT%20Tech%20Tips%20Work%20Faster/Vectorworks%20Spotlight%20Tips%202.png?width=500&height=427&name=Vectorworks%20Spotlight%20Tips%202.png)

The Smart Options Display can be found in the Vectorworks Preferences dialog box. Once opened, select the triggers that help you work faster, and specify which of the available smart options will help you maximize efficiency.

Another way you can make your workspace more custom is by **creating templated files where** your preferred classes, design layers, sheet layers, and saved views with specific view modes are already predefined.

Creating classes and layers at the start of each project can be time-consuming and tedious. So, once you’ve built out your classes, layers, and views the way you like, select File > Save As Template. You don’t even need to have geometry in your document to save it as a templated file.

**Create Custom Symbols with Plug-in Objects**

Now, let’s take a few seconds to discuss how plug-in objects can save you several minutes each time you open a file.

Plug-in objects are dynamic objects from tools like your Lighting Device tool, Pipe and Drape tool, and more! Plug-in objects have all the power of standard symbols, with the added advantage of being customizable. Unlike symbols, plug-in objects can be placed onto the drawing and remain modifiable. They’re very useful if you’re drawing many different variations of the same object.

![image (5)](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230127_ENT%20Tech%20Tips%20Work%20Faster/image%20(5).png?width=310&height=491&name=image%20(5).png)

Plug-in objects are geared specifically towards lighting design workflows and the logical ways in which you work. By using these objects, you don’t have to draw new pieces of content from project to project; you can simply drop them into your file and begin adding necessary data.

_And then, if you want to take your time-saving hacks one step further,_ you can save all of your plug-in objects as a grouped symbol. Saving grouped symbols as almost a templated set is a great time-saver when you’re working on different projects in the same venue or if you’re repeating the same foundational design concept. You can simply 

To save multiple plug-in objects as a grouped symbol:

1. Select the objects you want to be a part of your group
2. Modify > Create Symbol
3. Name the grouped symbol
4. Assign specific classes
5. Select Convert to Group
6. Drop it into your file

Grouping these objects means you can edit all the plug-in objects in the symbol without having to edit the symbol definition. If there are smaller edits you need to make to to specific plug-in objects once the symbol is in your new file, you can ungroup the symbol and begin making any necessary changes.

## Explore and Refresh

![Siyan_BBC_blog-1440x800](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221026_Ben%20Instep%20Siyan/Siyan_BBC_blog-1440x800.png?width=1440&height=800&name=Siyan_BBC_blog-1440x800.png)

_Image courtesy of Ben Inskip and Siyan._

Vectorworks is always updating tools and commands, so it’s a good idea to go back and relearn them from time to time — you could be missing out on a way to save time.

But how do you explore new features that will refresh your workflow?

Three Vectorworks resources, [Vectorworks University](https://university.vectorworks.net/), [the Vectorworks 2023 Online Help](https://app-help.vectorworks.net/2023/eng/index.htm), and our blogare great places to start!

Vectorworks University offers a suite of free webinars, while the Online Help provides detailed tips on specific tools and support for getting started in Vectorworks. Click the button below to visit the Vectorworks Online Help and learn more about Vectorworks’ features:

[![HOW CAN WE HELP?](https://no-cache.hubspot.com/cta/default/3018241/0cf81699-5087-441b-bdfb-60caaab0d1e0.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/0cf81699-5087-441b-bdfb-60caaab0d1e0) 

Lastly, our blog gives you fresh posts on a weekly basis about all things Vectorworks. Looking for similar tech tips like the ones you’ve read today? Check out these posts:

[READ | “Tech Tips with Sooner Rae Creative, Designers for Big Names in Music”](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html)

[READ | “These 6 Features Will Save You Time in Lighting Design”](../../../net/vectorworks/blog/6-game-changing-spotlight-features-for-lighting-designers.html)

[READ | “10 Features that Work Wonders for Scenic Designers”](../../../net/vectorworks/blog/10-scenic-design-features-you-need-to-be-using.html)

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.