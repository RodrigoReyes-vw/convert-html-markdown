[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Better Together: Introducing the Global Vectorworks Partner Network

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/210426_Partner%20Network/5447-2104-vectorworks-partner-network-social-media-and-blog-posts.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fintroducing-the-global-vectorworks-partner-network)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Better%20Together:%20Introducing%20the%20Global%20Vectorworks%20Partner%20Network&url=https%3A%2F%2Fblog.vectorworks.net%2Fintroducing-the-global-vectorworks-partner-network&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fintroducing-the-global-vectorworks-partner-network)

As a company, Vectorworks serves a global userbase of over 650,000\. The software is used all around the world, and so wouldn’t it be best for us to also partner with companies from all around the world?

You bet!

We’ve recently announced the [Vectorworks Partner Network](https://www.vectorworks.net/community/partner-network), a means to connect with innovators in our industries and incorporate stunning software and hardware integrations to the Vectorworks product line. The logic is that when we combine our resources, we form a diverse ecosystem that can improve product offerings and simultaneously share them with wider audiences. In essence, we’re better together.

![5447-2104-vectorworks-partner-network-social-media-and-blog-posts](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210426_Partner%20Network/5447-2104-vectorworks-partner-network-social-media-and-blog-posts.jpg?width=1440&name=5447-2104-vectorworks-partner-network-social-media-and-blog-posts.jpg)

For the Vectorworks user, this means exciting things: [Service Pack 3 for Vectorworks 2021](../../../net/vectorworks/blog/service-pack-3-now-available-for-vectorworks-2021.html) already introduced some game-changing capabilities, like the ability to export the Datasmith format, the native file format for Epic Games and the Unreal Engine, and a direct two-way connection with Solibri Office. As the Partner Network grows, users can expect to see future built-in, add-on, and/or plug-in options for Vectorworks software.

Here’s what Vectorworks CEO Dr. Biplab Sarkar says of the Partner Network:

> _“Our network of global partners are innovators and collaborators that empower designers to transform the world with great design. Together with our partner community, we’ll pioneer and deliver innovative solutions, address customer pain points, and maximize user workflow efficiencies. Our promise for all stakeholders in our partner network is that collectively, we’re better together; and customers are better off with our partnerships.”_

The Partner Network builds off decades of successful partnerships with companies such as Bluebeam, dRofus, Maxon, Solibri, Enscape, Lumion, MA Lighting International, NBS Chorus, ROBE lighting, and Siemens. 

## Partnership Categories

Technology partners help optimize Vectorworks software — we’re looking for advanced built-in capabilities and third-party solutions to bolster our software and showcase yours.

Content partners offer manufacturer-specific libraries of CAD/BIM symbols, material textures, images, and/or associated data that represent manufacturers’ products. 

Hardware partners are quality-tested and validated manufacturers who meet performance requirements and standards for users worldwide. 

## Partnership Tiers

Partners are divided into three distinct categories — silver, gold, and platinum. Each tier receives different benefits, though there are some constants like a listing on our directory and access to a private partner group on our forum.

![tier-table](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210426_Partner%20Network/tier-table.png?width=1440&name=tier-table.png)

Check out the partner page if you’re interested in partnering with us or to browse the partner directory.

[![Learn More](https://no-cache.hubspot.com/cta/default/3018241/e2cd487c-3f15-4f1e-bd65-199dca3d3f37.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/e2cd487c-3f15-4f1e-bd65-199dca3d3f37) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.