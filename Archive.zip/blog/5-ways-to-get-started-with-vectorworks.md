[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# 5 Ways to Get Started with Vectorworks

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 6 min read time 

![Vectorworks---Jason-Dixson-Photography-181105-141539-9456](https://blog.vectorworks.net/hubfs/Vectorworks---Jason-Dixson-Photography-181105-141539-9456.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2F5-ways-to-get-started-with-vectorworks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=5%20Ways%20to%20Get%20Started%20with%20Vectorworks&url=https%3A%2F%2Fblog.vectorworks.net%2F5-ways-to-get-started-with-vectorworks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2F5-ways-to-get-started-with-vectorworks)

Vectorworks software is beginner-friendly. At first, it felt out of my league. I didn't know where to begin. But hesitancy subsided as I realized how learning the basics is just downright feasible.

Hi, I’m Alex, a copywriter for Vectorworks. Recently, I completed our [Core Concepts course](https://www.vectorworks.net/training/core-concepts?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=link&utm%5Fcontent=5ways050719), which was designed for beginners like myself to form a foundation for more proficient usage.

It's worth noting that I am not a designer. Taking this course was my first interaction with any sort of design software. I went in blind — the blank sheet in Vectorworks was foreign to me.

As I went through the course, I took notes on what I thought would be useful to a bona fide beginner. Below you’ll find 5 of my takeaways.

Keep in mind that these tips come from me_,_ not the course itinerary. This is all me here, relaying what I learned and what excited me in Core Concepts training.

###### ****1\. Custom key binds are smart time savers**

Instead of scrolling to each tool with your mouse, commit [key shortcuts](http://app-help.vectorworks.net/2019/eng/VWKeyboardShortcuts.pdf?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=link&utm%5Fcontent=5ways050719) to muscle memory.

For example, the selection tool is mapped to “x” on your keyboard. You’ll save yourself a fraction of a second each time you press “x” instead of scrolling. Throughout an entire career, this adds up.

_![selection tool](https://blog.vectorworks.net/hs-fs/hubfs/0407195Ways2GetStarted/selection%20tool.jpg?width=1368&name=selection%20tool.jpg)_

_Tools usage in Vectorworks. The selection tool overshadows others._ 

My biggest takeaway from the training is that you can take this _even further_. If I were a consistent Vectorworks user, I’d use a gaming mouse with extra buttons. I’d map the selection tool to where my thumb rests, then I’d feel really smart about how much time I’m saving.

###### **2\. Don’t ignore classes and layers**

Classes are organizational categories. So, for a building design, you might have a class for walls, a class for roofing, a class for interior design, and so on. To work on the interior, you can mark the roof and walls invisible, which means you can easily navigate complex, information-rich designs. Limiting the visible geometry also lets your machine run smoother since it doesn’t have to render extraneous objects.

For layers, imagine you’re drawing a two-story building and you’ve finished the first floor, but you’re having trouble properly placing objects on the second floor.

You can organize all of that floor’s geometry into a layer, then set the layer to appear precisely above the first story at a specified elevation. This way, you aren’t struggling for precision in the 3D drawing space.

Classes and layers are pretty straightforward and mastering them will make your designs much easier to interpret.

###### **3\. Use input boxes**

On a related note, you’ll notice a dialogue box whenever you place geometry. Instead of drawing free-hand, consider using this box to type in your desired dimensions. To do this, all you have to do is press the TAB key. It means you can draw more accurately and produce designs _to scale._ This was super helpful in my documentation process.

###### **4\. Take advantage of documentation**

On that note, proper documentation is _huge_ in design. Fortunately, Vectorworks has integrated all steps of documentation and presentation into its software.

![Colonnade](https://blog.vectorworks.net/hs-fs/hubfs/040719_5Ways2GetStarted/Colonnade.jpg?width=5350&name=Colonnade.jpg)  

_Viewport for the colonnade designed in the Core Concepts class._

I should admit that I tend to treat documentation as an afterthought. Before taking this course, I didn’t think beyond design itself to consider what follows.

Now, the bigger picture is clear to me.

Definitely familiarize yourself with using sheets and viewports to present your designs. That’s part of what makes Vectorworks so powerful: you can mobilize your project from start to finish, from sketch to complete BIM presentation. Use this to your advantage, especially preset templates, which cut down document set-up time.

###### **5\. Have fun and experiment**

Vectorworks software affords you the freedom to design whatever you want.

When I took the course, I went off-track and started designing something similar to the Taj Mahal. The result wasn’t _quite_ up-to-par, but I did make somewhat of a barbaric nod to the famous structure.

Fine. So it was only a box with a rounded roof surface. But still, it gave me insight into how easy it is to pick up the basics.

Learn. Create. _Experiment._ That’s how you’ll make Vectorworks yours. The design space is your _tabula rosa_, a blank slate for your ideas to flourish. You’ll never know what you’re capable of unless you approach the software with an almost child-like mysticism. Let your ideas run wild.

In the words of my trainer, Bryan Seigel: “At the end of the day, Core Concepts provides a surface-level roadmap of Vectorworks and experience with common interactions. The software is ridiculously flexible. The best designs and workflows I’ve seen are from users who committed themselves to creating something they thought was cool and locking themselves in a room until they achieved their vision in Vectorworks.”

Take it from me: if a copywriter with little design background can do it, so can you.

###### **Master the basics. Take the course now.**    
**[![CHECK OUT OUR TRAINING OPTIONS](https://no-cache.hubspot.com/cta/default/3018241/2af1cf31-1aef-4284-9afd-fc9c0ab33d26.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/2af1cf31-1aef-4284-9afd-fc9c0ab33d26)** 

###### About the author

**![AAltieri_891x1100](https://blog.vectorworks.net/hs-fs/hubfs/040719_5Ways2GetStarted/AAltieri_891x1100.jpg?width=300&name=AAltieri_891x1100.jpg)** 

Alex Altieri is an associate copywriter for Vectorworks, Inc. He has degrees in digital/print journalism and philosophy from the Pennsylvania State University. Although he's not a designer by trade, Alex remains inspired by the ways in which Vectorworks software helps incite creativity. 

 Topics: [Tech Tips and Workflows](https://blog.vectorworks.net/topic/tech-tips-and-workflows) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.