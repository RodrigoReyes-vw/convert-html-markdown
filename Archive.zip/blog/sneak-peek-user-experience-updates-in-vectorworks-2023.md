[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# User Experience Updates in Vectorworks 2023

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2022%20PVW%20Images/08_UX/blog-1440x800%20%281%29%20copy%203.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fsneak-peek-user-experience-updates-in-vectorworks-2023)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=User%20Experience%20Updates%20in%20Vectorworks%202023&url=https%3A%2F%2Fblog.vectorworks.net%2Fsneak-peek-user-experience-updates-in-vectorworks-2023&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fsneak-peek-user-experience-updates-in-vectorworks-2023)

It’s time to start looking ahead to Vectorworks 2023!

The next version of Vectorworks design software brings practical features centered around the theme of workflow acceleration, with several features and improvements developed to streamline your process so you can work faster with the same or improved quality.

As we look ahead to the release, you’ll see a series of blogs here on Planet Vectorworks that tease new features. This one will go into user experience updates, which you may have seen a video about on our social media.

> Coming soon to [#Vectorworks2023](https://twitter.com/hashtag/Vectorworks2023?src=hash&ref%5Fsrc=twsrc%5Etfw): User experience improvements that will speed up your processes and leave you more time to design. <https://t.co/G1C9oJqPtZ> [#Architecture](https://twitter.com/hashtag/Architecture?src=hash&ref%5Fsrc=twsrc%5Etfw) [#LandscapeArchitecture](https://twitter.com/hashtag/LandscapeArchitecture?src=hash&ref%5Fsrc=twsrc%5Etfw) [#LightingDesign](https://twitter.com/hashtag/LightingDesign?src=hash&ref%5Fsrc=twsrc%5Etfw) [#InteriorDesign](https://twitter.com/hashtag/InteriorDesign?src=hash&ref%5Fsrc=twsrc%5Etfw)
> 
> — Vectorworks (@Vectorworks) [August 16, 2022](https://twitter.com/Vectorworks/status/1559544009487515649?ref%5Fsrc=twsrc%5Etfw) 

Be sure to watch as director of product development Hughes Tsafak discusses exciting updates coming to Vectorworks 2023, including major performance gains to the section viewports workflow.

## Up to 80% Less Memory When Processing Section Viewports

“Calculating and processing for viewports will be moved to the background and will be taking advantage of the Vectorworks Graphics Module,” Tsafak explained.

![Screen Shot 2022-08-17 at 9.43.27 AM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/08_UX/Screen%20Shot%202022-08-17%20at%209.43.27%20AM.png?width=700&name=Screen%20Shot%202022-08-17%20at%209.43.27%20AM.png)

This makes processing section viewports require 80% less memory, a change that lets you generate section viewports up to six times faster. This update is bound to speed up your documentation process and create an overall pleasant experience when processing section viewports.

Excited yet? Read on to see what other user experience updates are coming to Vectorworks 2023.

## Huge Improvements to the Cloud & Mobile 3D Viewers

 The ways you view models on the go are getting drastic quality upgrades in Vectorworks 2023\. The update areas are visualization, navigation, and export improvements.

First, in the Cloud and mobile viewers, there will be support for light objects from the Vectorworks model, including the Heliodon and an understanding of directional north. This gives you the opportunity to collaborate with clients or remote team members on sun and shade studies and better understand things like heat gain due to window placements.

There are also several visual quality improvements. Better material representation with reflections, ambient occlusion, and draw edges give you the ability to create more accurate presentations of your work.

Improvements to the navigation interface round out the upgrades to Cloud and mobile 3D viewers. All in all, you’ll be able to present your design vision much better to clients on mobile, in a browser, or in [AR](../../../net/vectorworks/blog/how-to-transition-from-2d-vr-visualization.html).

## Cloud Presentation Improvements

Virtual tours have received added compatibility with various file types such as 3D models, videos, images, and PDFs. A new ability to create text and hyperlink-based pins has also been added. This creates a more flexible, immersive experience for designer and client when reviewing ideas.

## Shared Network Workflow Efficiencies

For teams who use Project Sharing on the Vectorworks Cloud, 2023 introduces the ability to sync shared resources, projects, and files over the local network rather than relying on internet upload and download speeds, making collaborating on the Vectorworks Cloud smoother and more efficient. Accessing downloaded files across the team will be much more streamlined; no more struggling with bandwidth challenges to access files.

## Improved Resource Libraries Organization

The Resource Library carries all your textures, text styles, symbols, and other content, making it essential to the design process. With organization updates in Vectorworks 2023, you’ll be able to find what you’re looking for with ease. Content library folders have been consolidated and reorganized with a more intuitive and industry-specific naming convention; less hierarchy in folder structure makes finding what you’re looking for much more intuitive.

## There’s So Much More!

There’s so much to be excited about in the new version of Vectorworks. We’ll be teasing more features as release approaches. Be sure you’re subscribed to the Planet Vectorworks blog to be notified.

[![SUBSCRIBE FOR VECTORWORKS 2023 UPDATES](https://no-cache.hubspot.com/cta/default/3018241/7fac1a1e-9f0d-494d-8e87-ff9537016edb.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/7fac1a1e-9f0d-494d-8e87-ff9537016edb) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.