[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Still Time to Apply ⏰ | Vectorworks Design Scholarship

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/221207_Scholarship%20Winners%20Blog/blog-1440x800_Scholarship%20Winner%201.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fstill-time-apply-vectorworks-design-scholarship)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Still%20Time%20to%20Apply%20⏰%20|%20Vectorworks%20Design%20Scholarship&url=https%3A%2F%2Fblog.vectorworks.net%2Fstill-time-apply-vectorworks-design-scholarship&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fstill-time-apply-vectorworks-design-scholarship)

_Image courtesy of the 2022 Richard Diehl Award winner, Michelle Wanitzek_.

Whether you’re enjoying your summer break by a pool, up to your knees in coursework, or planning the next chapter of your academic career, one thing is certain . . .

You can still apply for the Vectorworks Design Scholarship!

The scholarship is open to any undergraduate or graduate student pursuing a degree related to architecture, interior design, landscape architecture, landscape design, or entertainment design. 

Participants who submit qualified entries have the chance to be selected as a regional winner, with the potential to win up to $3,000 USD, depending on their location. But that's not all - regional winners also compete for the coveted Richard Diehl Award, which comes with a grand prize of $7,000 USD. In total, you could walk away with a cool $10,000 USD.

Take a (short) break between hanging out at the pool or catching up with family and friends to apply today! Just click the button below to get started:

[![SUBMIT YOUR DESIGNS](https://no-cache.hubspot.com/cta/default/3018241/92f9dd96-ad20-416b-9f70-94a85fc50ba4.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/92f9dd96-ad20-416b-9f70-94a85fc50ba4) 

_\*_ _Please note that submission dates, deadlines, and prize amounts vary slightly based on the country and/or region where you live._

_![arch-gif](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2303272023%20Scholarship%20Announcement%20Blog/arch-gif.gif?width=700&height=991&name=arch-gif.gif)_

#### Gain Recognition from Some of the Best Designers in the World!

A monetary reward isn’t all that you can get from the Vectorworks Design Scholarship. [You also have a special opportunity to show off your designs to an impressive crop of designers and professors](https://www.vectorworks.net/scholarship/judges).

This year’s scholarship judges include:

[**Blair Barnette**](https://britishfilmdesigners.com/) — chairperson, British Film Designers Guild

[**Eric Berg**](https://www.pc-ld.com/) — principal, Pacific Coast Land Design, Inc.

[**Vanessa Brady**](https://www.sbid.org/) — founder and CEO, The Society of British & International Interior Design

[**David Chadwick**](https://www.caduser.com/) — editor and chief writer, _CAD User_ and_Construction Computing Magazine_

[**Steven Chavez**](https://www.nationalamla.org/) — landscape architect and founder, SCLA and NAMLA

[**Colin Davis**](https://www.studiopartington.co.uk/) — director, Studio Partington

[**Jonathan Emery**](https://dsa-ed.co.uk/) — landscape architect, DSA Environment & Design Ltd.

[**David Farley**](https://www.davidfarleydesign.net/) — set and costume designer, David Farley Design

[**Victoria Farrow**](https://www.linkedin.com/in/victoria-farrow-4848338) — associate professor & BA Architecture course director, Birmingham City University

[**Curt Henry**](https://www.dwyerarch.com/) — senior architectural designer, Dwyer Architectural 

[**Stephen Jones**](https://www.csus.edu/) — professor, Theatrical Design, California State University – Sacramento

[**Len Levine**](https://www.iclsociety.com) — lighting designer and International Cinema Lighting Society (ICLS) member

[**Will Metcalf**](https://swtdesign.com/) — designer, SWT Design

[**Anne Militello**](https://vortexlighting.com/), head of the Master of Fine Arts Lighting and Design Program, California Institute of the Arts

[**Cristina Murphy**](http://www.xcoop.org/) — professor and co-founder of XCOOP

[**Caitlin Saunders**](https://www.starbucks.com/) — senior project designer, Starbucks

[**Ashley Scheidel**](https://www.ashleyscheideldesign.com/) — founder and creative director, Ashley Scheidel Design Studio

[**Edward Turner**](https://www.pegasusgroup.co.uk/) — senior director, Pegasus Group

[**Eric Winter**](https://alchemyarch.com/) — architect, Alchemy Architects

"This is such a great opportunity. You can submit a project that you’ve been working on for your degree, so it’s not even any extra work. Why wouldn’t you!?" said David Farley.

At Vectorworks, we, like Farley, are excited to see what you submit. And if you’re not a student but know someone who should apply, please share this blog with them!

[![APPLY FOR THE SCHOLARSHIP](https://no-cache.hubspot.com/cta/default/3018241/3a50b93c-6c4e-45f5-b9fd-8d7eaf689a2b.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/3a50b93c-6c4e-45f5-b9fd-8d7eaf689a2b) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.