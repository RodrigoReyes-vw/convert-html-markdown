[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# How to Make a Colossal Comeback at Competitions: Student Edition

 Posted by [Rowena Winkler](https://blog.vectorworks.net/author/rowena-winkler) | 6 min read time 

![NCLC email](https://blog.vectorworks.net/hubfs/NCLC%20email.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fnclc-student-winner)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=How%20to%20Make%20a%20Colossal%20Comeback%20at%20Competitions:%20Student%20Edition&url=https%3A%2F%2Fblog.vectorworks.net%2Fnclc-student-winner&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fnclc-student-winner)

Every year Vectorworks sponsors the 3D Exterior Landscape Design event at the National Association of Landscape Professionals (NALP) National Collegiate Landscape Competition (NCLC). [NCLC is a three-day event](https://www.landscapeprofessionals.org/collegiate-landscape-competition) where hundreds of students gather to exhibit their skills in landscape and horticulture.

![NCLC Students](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/043018_NCLC%20Student%20Winner/NCLC%20Students.jpg?width=476&height=357&name=NCLC%20Students.jpg)

_Students competing at NCLC. Image courtesy of Eric Gilbey._

Eric Gilbey, product marketing manager of landscape at Vectorworks, has been attending the event since he was a student and now represents the company at the competition.

“Having experienced NCLC when I was in college and just beginning to learn what the industry had in store is reason enough to give back to today’s students,” said Gilbey. “The one thing that hasn’t changed over the years is that students are eager to jump into the industry, and it is great for us to be there to welcome them.”

One of those students is Tyler Gilson, a four-year Horticulture student from Michigan State University (MSU) with a degree concentration in Landscape Design, Construction, and Management. Being involved with plants and landscaping since childhood (his uncle owns a small garden center in Ohio), it was easy for Gilson to select his major. What wasn’t as easy, however, was getting selected by MSU to represent the university at NCLC in the fall 2015 semester — and learning Vectorworks within a short period of time to feel prepared for the competition.

“I immediately downloaded the student version of [Vectorworks Landmark ](http://www.vectorworks.net/landmark?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=nclcwinner050118)and began practicing a little bit here and there,” said Gilson. “As the competition approached, I spent my spring break watching [Getting Started Guides](http://www.vectorworks.net/training/2018/getting-started-guides?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=nclcwinner050118) and practicing.”

Unfortunately for Gilson, that NCLC competition did not go as smoothly as he would have liked.

“My mind completely froze,” he said. “I forgot how to create [3D viewports](http://app-help.vectorworks.net/2018/eng/index.htm#t=VW2018%5FGuide%2FViewports1%2FCreating%5FSection%5FViewports.htm?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=nclcwinner050118), and overall I was very inexperienced with the software.”

Disappointed in his results, Gilson vowed the 2017 competition would be different.

“I continued practicing with Vectorworks throughout the summer and fall of 2016 and I even used it during my study abroad to Northern Ireland,” said Gilson. “We had one big design that we had to do for the whole semester, a church. So, my roommate downloaded Vectorworks and I taught him how to use it; we both did our designs of the church in Vectorworks and displayed it for class.”

_![Ireland Church2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/043018NCLC%20Student%20Winner/Ireland%20Church2.png?width=2212&height=1470&name=Ireland%20Church2.png)_

_Vectorworks file of church design project. Image courtesy of Tyler Gilson._

With more experience under his belt, Gilson felt fully prepared to compete a second time.

“I probably spent well over 200 hours on the software, so I was ready to rock,” said Gilson. “With all the practice on the software and having watched the Getting Started Guides at least ten times, I ended up finishing my design in an hour and a half. I was able to create a pergola, a seat wall, two patios, mass plantings, and large shade trees and still have twenty extra minutes at the end of the competition.”

![NCLC email](https://blog.vectorworks.net/hs-fs/hubfs/NCLC%20email.png?width=439&height=316&name=NCLC%20email.png)

_Gilson with Eric Gilbey and Tony Kostreski at NCLC 2018\. Image courtesy of Tyler Gilson._

Gilson took first place and won a professional license of Vectorworks Landmark. “As soon as I installed my new version of the software, I started practicing and reaching out to different companies and friends about doing freelance design,” said Gilson. “With the professional license I was able to continue doing what I love all summer while making a decent living on the side.”

Gilson’s freelance work was great practice. He was invited to compete at the 2018 NCLC this March and won again, extending his professional license for another year. His efforts eventually led to employment: upon graduation he will be working in Ann Arbor, Michigan for a company called [Canopy Landscapes](http://www.canopylandscapes.com/). According to Gilson, none of this would have been possible without the help of Vectorworks.

“It's sounds kind of corny to say it, but Vectorworks — the whole program and everything to do with the competition — has changed my life quite a bit,” said Gilson. “It’s opened up a lot of doors for me, given me a bit of a name for myself and in the industry and what I’m doing with design.”

Tony Kostreski, product marketing specialist of landscape at Vectorworks and a former competitor at NCLC, joined Gilbey in representing Vectorworks at the competition. “Witnessing the energy, dedication, and teamwork as a competitor in the 2013 National Collegiate Landscape Competition was such a valuable experience, and it was even more rewarding to return as a sponsor,” said Kostreski. “It was an honor to pass the baton to Tyler since it helped me build such a strong foundation for my career. I’m excited that he can keep the spirit at NCLC alive.”

His mentors who supported him along the way are just as proud.

“Tyler Gilson is an amazing young man. He is dedicated to learning everything he can about Horticulture to become a successful leader in the landscape industry,” said Marcus Duck, one of Gilson’s coaches and an instructor in MSU’s Department of Horticulture. “Tyler logged a tremendous number of hours practicing various design techniques with Vectorworks. He has even used the software to design the landscape display for our Student Horticulture Association’s 30th annual Spring Show and Plant Sale.”

“For me, nothing has been more a more effective tool than Vectorworks Landmark,” said Gilson. “I can’t say enough about the software or the team behind it, and I’m excited to use it professionally and to continue being a champion for the software that has changed my life.”

##### **Interested in a free educational license of Vectorworks?**

**[![Click Here](https://no-cache.hubspot.com/cta/default/3018241/28fe3ce3-a25e-4200-a1ce-54e10e4dff79.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/28fe3ce3-a25e-4200-a1ce-54e10e4dff79)** 

 Topics: [BIM (Landscape)](https://blog.vectorworks.net/topic/bim-landscape) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.