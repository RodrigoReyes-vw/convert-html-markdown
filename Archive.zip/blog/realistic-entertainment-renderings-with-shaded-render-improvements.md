[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Continued Improvement to Real-Time Rendering

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/231116_ENT%20Shaded%20Render%20Camera/Arena-Hero%20Image.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Frealistic-entertainment-renderings-with-shaded-render-improvements)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Continued%20Improvement%20to%20Real-Time%20Rendering&url=https%3A%2F%2Fblog.vectorworks.net%2Frealistic-entertainment-renderings-with-shaded-render-improvements&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Frealistic-entertainment-renderings-with-shaded-render-improvements)

With improvements to the **Shaded** rendering mode in Vectorworks Spotlight, you can create higher levels of realism in earlier stages of your design process.

This post will explore these improvements, specifically the three new tabs found in the **Shaded Options** dialog: **General**, **Camera**, and **Quality**. Through a combination of these tabs (plus the removal of an eight-light shadow limit), you can create realistic renders in real time directly within your model.

#### 3 Tabs to Control Your Shaded Renders

###### General

The General tab includes controls for the visibility of textures, colors, shadows, and edges, while the anti-aliasing option controls the pixelation of your visualization.

You’ll also find all of the lighting options in the General tab, such as environmental lighting, reflections, and object reflections. These options give you an efficient, direct way to access your lighting and background options.

![screenshot_2023-11-17_at_10.35.22___am_720](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/231116_ENT%20Shaded%20Render%20Camera/screenshot_2023-11-17_at_10.35.22___am_720.png?width=400&height=534&name=screenshot_2023-11-17_at_10.35.22___am_720.png)

###### Camera

With the Camera tab, you can choose to add various camera effects to your rendering, enhancing your Shaded views.

![shaded 2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/231116_ENT%20Shaded%20Render%20Camera/shaded%202.png?width=400&height=534&name=shaded%202.png)

These effects work just like a traditional camera, but if you don’t have any previous photography experience, here’s a quick rundown:

**Depth of Field** changes the focal point of what you are looking at. For example, when you are working on your computer, and the screen is clear, but your peripheral vision is not, that is an example of Depth of Field.

Changing the aperture (**F-Stop**) changes how sensitive the Depth of Field is. If you have a high F-Stop, you'll have the whole image in focus. A lower F-Stop will be more sensitive to the Depth of Field. Changing the F-Stop also changes how open the lens of the camera is. High F-Stop will lead to a darker image.

**ISO** is light sensitivity. The lower the ISO, the less "noise" will be in the image, but the image will be darker. You can have a very high ISO speed, like 3200, but the image will become less crisp.

**Shutter Speed** is how long the "film" is exposed for. A faster shutter speed will be great for capturing a race car, but it makes for a darker image. A long shutter speed will make a lighter image, but it will be blurry if something in the image is moving.

These settings go hand-in-hand to help you create the precise views and representations of your designs you want.

Check out how you can manipulate the different settings together below:

  
![Arena-Far DOF](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/231116_ENT%20Shaded%20Render%20Camera/Arena-Far%20DOF.jpg?width=1440&height=842&name=Arena-Far%20DOF.jpg)![Arena-Near DOF](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/231116_ENT%20Shaded%20Render%20Camera/Arena-Near%20DOF.jpg?width=1440&height=842&name=Arena-Near%20DOF.jpg)

_![Arena-High FStop](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/231116ENT%20Shaded%20Render%20Camera/Arena-High%20FStop.jpg?width=1440&height=842&name=Arena-High%20FStop.jpg)_ 

Bloom can also be a helpful tool in your Shaded render toolkit, adding a glowing halo effect to lights you’ve placed in your set, stage, or live event design.

###### Quality

The third and final tab of your Shaded render dialog is Quality, which helps you control the detail and shadows of your rendering.

![screenshot_2023-11-17_at_10.34.40___am_720](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/231116_ENT%20Shaded%20Render%20Camera/screenshot_2023-11-17_at_10.34.40___am_720.png?width=400&height=534&name=screenshot_2023-11-17_at_10.34.40___am_720.png)

In addition to the greater control and customization the General, Camera, and Quality tabs offer, you can use different backgrounds in your renderings. As mentioned before, this rendering freedom that’s available directly in your production’s model can save you time and increase your productivity.

#### Better Renderings = Bigger Impact

To discover the full potential of Vectorworks Spotlight's rendering capabilities and truly impress your clients with impactful presentations, click the button below:

[![EVENT RENDERINGS WITH A BIGGER IMPACT](https://no-cache.hubspot.com/cta/default/3018241/2029a96f-f592-49cf-bb02-4be17d58a47b.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/2029a96f-f592-49cf-bb02-4be17d58a47b) 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.