[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Capture the Beauty of Nature with Name-Brand Colors in Vectorworks

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/230125_2023%20Color%20of%20the%20Year/Sherwin%20Williams-Redend%20Point.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fdiscover-the-wonder-of-nature-with-name-brand-colors-in-vectorworks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Capture%20the%20Beauty%20of%20Nature%20with%20Name-Brand%20Colors%20in%20Vectorworks&url=https%3A%2F%2Fblog.vectorworks.net%2Fdiscover-the-wonder-of-nature-with-name-brand-colors-in-vectorworks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fdiscover-the-wonder-of-nature-with-name-brand-colors-in-vectorworks)

You design spaces to make an impact.

And whether you’re trying to [promote wellness](../../../net/vectorworks/blog/how-wellness-has-become-key-in-post-pandemic-workspaces.html) or [create an inspirational workplace](https://www.vectorworks.net/customer-showcase/boosting-design-confidence-with-the-flexibility-of-bim), the right combination of layout, materiality, and color is essential. This blog will focus on the third of that essential trio and how you can use a custom color palette in Vectorworks to harness the beauty of nature and create impactful spaces.

## Name-Brand Paint Manufacturer’s Nature-Inspired Colors 

Whether you're going for a rustic, bohemian, or minimalist look, natural hues can seamlessly blend with any design scheme, adding depth and texture to your interiors. And this was likely something some of the biggest paint manufacturers were thinking of when they released their 2023 Color of the Year selections.

![Behr-Blank Canvas](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230125_2023%20Color%20of%20the%20Year/Behr-Blank%20Canvas.png?width=1440&height=711&name=Behr-Blank%20Canvas.png)

Some manufacturers like [Behr](https://www.behr.com/consumer/inspiration/2023-coty/?gclid=Cj0KCQiAq5meBhCyARIsAJrtdr652O1FDNmoYtKJnQi153jPc6Oz0I2uZ536VP8q%5FOj2-v3Z4u0ymnQaAqh6EALw%5FwcB&gclsrc=aw.ds), [Dulux Trade](https://www.duluxtradepaintexpert.co.uk/en/content/dulux-colour-of-the-year-2023), and [Sherwin Williams](https://www.sherwin-williams.com/en-us/color-of-the-year-2023?gclid=Cj0KCQiAq5meBhCyARIsAJrtdr6JCDQtsQejN7Is%5FqgNsfEej-LLMJq8mYBKBPE4o2Y%5Fsz2KbZOLfLEaAhDUEALw%5FwcB) selected neutral earth tones. Sherwin Williams, [a Vectorworks partner](https://www.vectorworks.net/community/partner-network/find-partner), picked Redend Point as their 2023 Color of the Year in an effort to “embrace a spirit of connection with the world around.”

![Glidden-Vining Ivy](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230125_2023%20Color%20of%20the%20Year/Glidden-Vining%20Ivy.png?width=1440&height=708&name=Glidden-Vining%20Ivy.png)

But not all the selections are neutral browns and earth tones. There are rich, calming colors like [Glidden’s](https://www.glidden.com/trends) Vining Ivy and [Krylon’s](https://www.businesswire.com/news/home/20221013005159/en/Krylon%C2%AE-Announces-2023-Color-of-the-Year-Spanish-Moss) Spanish Moss, for example. 

[Valspar](https://www.valspar.com/colors/colors-of-the-year) and [Pantone’s](https://www.pantone.com/color-of-the-year/2023) colors, on the other hand, are more vibrant and reminiscent of what you might find in a flowery garden or meadow.

On their website, Pantone said that Viva Magenta “is a shade rooted in nature descending from the red family and expressive of a new signal of strength. Viva Magenta is brave and fearless, and a pulsating color whose exuberance promotes a joyous and optimistic celebration, writing a new narrative.”

![Pantone-Viva Magenta](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230125_2023%20Color%20of%20the%20Year/Pantone-Viva%20Magenta.png?width=1440&height=711&name=Pantone-Viva%20Magenta.png)

## How to Download the Custom Color Palette in Vectorworks

The hues mentioned above, in addition to a few others from the industry’s leading manufacturers, are available in a custom Vectorworks color palette.

The full list of name-brand colors available is as follows:

* Behr — Blank Canvas
* Better Homes & Gardens — Canyon Ridge
* Dulux Trade — Wild Wonder
* Dunn-Edwards — Terra Rosa
* Dutch Boy — Rustic Greige
* Glidden — Vining Ivy
* Krylon — Spanish Moss
* Pantone — Viva Magenta
* Sherwin Williams — Redend Point
* Valspar — Gentle Violet

![blog-1440x800_COTY2023](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230125_2023%20Color%20of%20the%20Year/blog-1440x800_COTY2023.png?width=1440&height=800&name=blog-1440x800_COTY2023.png)

To download all the different color options so they’re available at your fingers in Vectorworks, click the button below:

[![DOWNLOAD THE COLOR PALETTE](https://no-cache.hubspot.com/cta/default/3018241/b4e743df-2ee5-424e-b3da-092ef816ee17.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/b4e743df-2ee5-424e-b3da-092ef816ee17) 

Once downloaded, you’ll need to simply place the .xml file into the application folder.

**For Mac customers to locate the palette:** Finder> Applications> Vectorworks 2023> Libraries> Default> Color Palettes 

**For Windows customers to locate the palette:**C:\\ Program Files\\ Vectorworks 2023\\ Libraries\\ Default\\ Color Palettes

![Screenshot 2023-01-24 at 15.08.54](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230125_2023%20Color%20of%20the%20Year/Screenshot%202023-01-24%20at%2015.08.54.png?width=1440&height=827&name=Screenshot%202023-01-24%20at%2015.08.54.png)

After the file has been placed, restart Vectorworks.

Then, in the Attributes palette, go to the color selection pop-over. In the "Active Document" pull-down menu, you'll find the Color of the Year palette under the "Other Palettes" option. 

![Screenshot 2023-01-24 at 16.25.27](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230125_2023%20Color%20of%20the%20Year/Screenshot%202023-01-24%20at%2016.25.27.png?width=330&height=397&name=Screenshot%202023-01-24%20at%2016.25.27.png)

From there, the only thing left to do is what you do best — design. Share your designs on social media, tag us, and use #MadeWithVectorworks for a chance to be featured on our social platforms.

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.