[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# March Webinars | Now Available On Demand

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/240312_March%20Webinars/blog-1440x800_March%20Webinar%20BLDG.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinar-march-2024)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=March%20Webinars%20|%20Now%20Available%20On%20Demand&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinar-march-2024&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinar-march-2024)

Explore the latest Vectorworks webinars, offering insights into enhancing site analysis with 3D models, navigating the learning curve in Vectorworks Architect, and delving into the world of ConnectCAD.

#### RACK & PANEL PLANNING WITH CONNECTCAD 

_Aired March 6_

Layout rooms and rack planning updates in Vectorworks 2024 open new planning and design possibilities for your A/V workflows.

This webinar, hosted by Jesse Cogdell, European entertainment product specialist, explores how your new workflow will function and how you can leverage the latest features in ConnectCAD in Vectorworks 2024.

[WATCH THE ENTERTAINMENT WEBINAR](https://university.vectorworks.net/course/view.php?id=3083).

![3d-rack-workflow](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/231211_December%20Webinars/3d-rack-workflow.png?width=1440&height=810&name=3d-rack-workflow.png)

#### The Data Difference: 3D for Landscape Analysis

_Aired March 21 | Approved for one APLD CEU and LA CES CEU_

Though 3D-modeled landscapes are becoming more common in design workflows, many still hesitate to involve valuable techniques in all areas of their design workflow.  
  
A key benefit to incorporating 3D and BIM in your landscape design, beyond selling, is analysis. In this session, you'll learn how to leverage the power of solar, terrain, building, and landscape feature modeling to better analyze site conditions, advise clients, and validate design choices.  
  
By integrating 3D with 2D design workflows, there's less disruption in getting to a sellable, better-performing solution for your clients.

[WATCH THE LANDSCAPE WEBINAR](https://university.vectorworks.net/course/view.php?id=3258).

![blog-1440x800_March Webinar LAND](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/240312_March%20Webinars/blog-1440x800_March%20Webinar%20LAND.png?width=1440&height=800&name=blog-1440x800_March%20Webinar%20LAND.png)

#### Leveling the Learning Curve

_Aired March 26_

Thinking about the possibility of changing software may feel daunting, but you can take on the learning curve and succeed. And when you do, there are many tangible benefits you will gain.

Watch Neil Barman, Vectorworks Architect product specialist, Architect AIBC, as he discusses techniques for learning a new software and approaching Vectorworks. He demonstrates foundational strategies to help you get started in Vectorworks, provides tips for working smarter, not harder, and equips you with support resources to improve your skills once you move to Vectorworks.

[WATCH THE ARCHITECTURE WEBINAR](https://university.vectorworks.net/course/view.php?id=3262).

![blog-1440x800_March Webinar BLDG](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/240312_March%20Webinars/blog-1440x800_March%20Webinar%20BLDG.png?width=1440&height=800&name=blog-1440x800_March%20Webinar%20BLDG.png)

#### The Power of ConnectCAD’s Panel Builder 

_Aired March 27_ 

Panel diagrams are the backbone of seamless installations for system integrators and audiovisual installers; with [ConnectCAD's Panel Builder workflow](../../../net/vectorworks/blog/whats-new-with-connectcad-in-vectorworks-2024.html), you can streamline the creation of panel diagrams, enabling precise documentation of cable connections and equipment layouts. This workflow ensures accuracy during installation and facilitates efficient troubleshooting and maintenance post-deployment. 

From large-scale AV installations to intricate system integrations, ConnectCAD's Panel Builder workflow elevates the efficiency and precision of panel diagram creation —enhancing the overall success of your projects.

[WATCH THE ENTERTAINMENT WEBINAR](https://university.vectorworks.net/course/view.php?id=3266).

![blog-1440x800_March Webinar ENT](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/240312_March%20Webinars/blog-1440x800_March%20Webinar%20ENT.png?width=1440&height=800&name=blog-1440x800_March%20Webinar%20ENT.png)

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.