[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Mobile Scanning Makes Its Mark on Vectorworks

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2024%20Blog/2_Mobile%20Capture/Object%20Capture-Multi%20view.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-to-scan-real-world-objects-into-vectorworks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Mobile%20Scanning%20Makes%20Its%20Mark%20on%20Vectorworks&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-to-scan-real-world-objects-into-vectorworks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fhow-to-scan-real-world-objects-into-vectorworks)

As you know, taking site inventory is a vital step to take in a site design project. Having a digital record of existing conditions gives you a helpful basis from which to design.

In this article, we’ll look at how you can use your mobile device to aid this process. Keep reading to discover a convenient and practical way to take site inventory and to find a webinar presentation on this technology by our product experts.

#### Photogrammetry and Point-Cloud Scanning Defined

First, let’s make sure we’re on the same page with what these two terms mean.

**Photogrammetry** – A method using photographs to create 3D models of objects or spaces. It works by using multiple photographs from different angles to produce an accurate model of the subject.

**Point-Cloud Scanning** – A method that produces 3D digital representations of real-world locations. They’re collections of thousands or even millions of individual points, each with X, Y, and Z coordinates. Point clouds are produced by LIDAR, or Light Detection and Ranging.

#### The Nomad App | How to Scan Real-World Objects into Your Files

[Nomad](https://cloud.vectorworks.net/products/) is Vectorworks’ mobile application that you can download for iOS and Android devices.

With Nomad-enabled mobile devices, photogrammetry can be used to capture objects that you can physically walk around. This is because you need several photos from several angles for it to work properly. Objects like boulders, tree trunks, plants, sculptures, furniture, building facades, and even people are great candidates for this kind of scanning.

![Scanned Objects 01](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2024%20Blog/2_Mobile%20Capture/Scanned%20Objects%2001.png?width=3136&height=1806&name=Scanned%20Objects%2001.png)

If your mobile device is equipped with a LIDAR scanner — which most smartphones and tablets are nowadays — then point-cloud scanning can be used for smaller sites that you can walk around in 10-20 minutes that can’t be accessed by a drone.

#### Why Not Use a Drone Instead?

More and more, drones are being used to quickly scan a site’s existing conditions and generate point-cloud representations. These files can be faithfully imported into any of the Vectorworks Design Suite products, which is an effective way to get started on your design file. But there are limitations to drone use, such as:

* No-fly zones
* Areas with too much tree canopy
* Poor weather
* The cost of drones and restrictions on drone operation

So, if you’re unable to use a drone, mobile scanning is an excellent alternative. With both options at your disposal, you won’t have to worry about being able to generate site representations.

#### Importing into Vectorworks

After you’ve finished capturing site conditions with your mobile device, the Nomad app produces an OBJ and USDZ file, both of which can imported into Vectorworks. When you import either file, you’ll see a 3D mesh. Enabling multiview then lets you see the object from different perspectives.

![Object Capture-Multi view](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2024%20Blog/2_Mobile%20Capture/Object%20Capture-Multi%20view.png?width=4064&height=2334&name=Object%20Capture-Multi%20view.png)

For point-cloud scanning, the Nomad app will produce a PTS file that can be imported directly into Vectorworks at scale. This point-cloud representation can then be traced over, so you have a base of existing conditions to work from for your site design.

![Residence-Point Cloud](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2024%20Blog/2_Mobile%20Capture/Residence-Point%20Cloud.png?width=4064&height=2334&name=Residence-Point%20Cloud.png)

The 3D points from the point-cloud scan can also be used to generate a site model. Stake Objects can be easily placed throughout the Point Cloud by snapping to specific points, allowing you to take advantage of the **Create Site Model from Source Data** command. This can’t replace the complete accuracy of a regular survey, but it does give you a fantastic starting point for your conceptual design process.

![Residence-Site Model](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2024%20Blog/2_Mobile%20Capture/Residence-Site%20Model.png?width=4064&height=2334&name=Residence-Site%20Model.png)

#### See How It Works Step by Step!

You’re in luck — you can watch a full presentation for free on how to use the Nomad app for photogrammetry and point-cloud scanning. Just click the button below and you’ll be directed to the presentation on Vectorworks University.

[![WATCH NOW](https://no-cache.hubspot.com/cta/default/3018241/fbb76806-72c0-4769-bbe5-d4c156e4f316.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/fbb76806-72c0-4769-bbe5-d4c156e4f316) 

 Topics: [Landscapes](https://blog.vectorworks.net/topic/landscapes) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.