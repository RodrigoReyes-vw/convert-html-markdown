[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Collaboration and Automated Design in Vectorworks Spotlight

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/231019_ENT%20MTM%20Stefan%20Bahrway/blog-1440x800-7.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fgame-changing-vectorworks-features-for-this-ex-autocad-designer)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Collaboration%20and%20Automated%20Design%20in%20Vectorworks%20Spotlight&url=https%3A%2F%2Fblog.vectorworks.net%2Fgame-changing-vectorworks-features-for-this-ex-autocad-designer&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fgame-changing-vectorworks-features-for-this-ex-autocad-designer)

Wondering how switching to [Vectorworks Spotlight](https://www.vectorworks.net/spotlight) would benefit you?

For Stefan Bahrawy of [Spectre, a Norwegian production and event design firm,](https://spectre.no/) the switch to Vectorworks Spotlight from AutoCAD was all about improved collaboration and automated design tools. Keep on reading to learn more.

![PXL_20231026_055748954.PORTRAIT](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/231019_ENT%20MTM%20Stefan%20Bahrway/PXL_20231026_055748954.PORTRAIT.jpg?width=400&height=531&name=PXL_20231026_055748954.PORTRAIT.jpg)

#### Why Bahrawy and Spectre Switched to Vectorworks Spotlight

###### Improved Design Collaboration

Bahrawy, a rigging designer, used AutoCAD for seven years while working independently and for other companies. Then, in 2022, Bahrawy switched to Vectorworks Spotlight along with the other designers of Spectre. One of the key reasons for this switch was better collaboration. “It’s essential for all of us to be able to work on the same file with Project Sharing,” Bahrawy said.

With Project Sharing, Vectorworks’ multi-user environment, the Spectre team can all collaborate on the same project, no matter where they are in the world. Useful features in Project Sharing include the following:

* Layers Tab — This allows you to see which layers are available, which layers are checked out by others (shown in gray text), and which layers you have checked out yourself (shown in blue text). The project administrator can designate layers as master layers within this tab.
* Objects Tab – This allows you to see all checked-out individual objects. You can see the owner, object type, layer, class, and object ID for each object.
* History Tab — This contains a compilation of all change history to the Project File so you can track the multitude of changes that occur in a multiuser environment.
* Users Tab — This lets you see a list of the entire project team. The tab will show usernames, full names, permission levels, and associated colors. The project administrator can edits permission levels from this tab.

![project-sharing-plus-ent (1)](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/090723_ENT%20Geoff%20Franklin%20HOW/project-sharing-plus-ent%20(1).png?width=1440&height=810&name=project-sharing-plus-ent%20(1).png)

Bahrawy shared that he and his colleagues recently started to dig deeper into Project Sharing and how it can help them with multiple projects and larger projects alike, such as their work on the regional [Eurovision Song Contest](https://eurovision.tv/) production.

“We have started to see that we are working at a quicker pace,” the designer said, still witnessing the powerful changes Vectorworks can provide his team with.

###### Automated Design Features in Braceworks

In addition to Project Sharing, Bahrawy has taken advantage of other features of Vectorworks Spotlight, specifically the automated tools and symbols in [Braceworks, Vectorworks’ add-on rigging analysis module](../../../net/vectorworks/blog/brace-yourself-3-tips-on-starting-in-braceworks.html).

![braceworks-product-shot](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/231019_ENT%20MTM%20Stefan%20Bahrway/braceworks-product-shot.jpg?width=1440&height=1189&name=braceworks-product-shot.jpg)

As a rigging designer, Bahrawy recognized the importance of a streamlined and accurate design process: “Instead of having to model every truss in AutoCAD myself, there’s a library in Vectorworks which is easily accessible so I can draw trusses and different objects in an automated fashion.”

These automated features help the Spectre team work on larger projects — like the aforementioned Eurovision Song Contest — with more efficiency. As Bahrawy noted, for a smaller project, he could simply put a cable or a truss down at the end of the show, but with a bigger project, there’s much more to consider.

Bahrawy and the Spectre team can now trust the work they’re doing with the help Braceworks and its automated calculations and symbols.

#### Switch to Vectorworks Spotlight Today

To switch to Vectorworks for all your entertainment and live event design needs, click the button below:

[![DOWNLOAD VECTORWORKS SPOTLIGHT](https://no-cache.hubspot.com/cta/default/3018241/b1b315da-7fb2-485a-920b-ce8b62f4fddf.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/b1b315da-7fb2-485a-920b-ce8b62f4fddf) 

_\*Design in featured image courtesy of:_

_Creative Director/Production Designer - Jesse Lee Stout_  
_Production Designer - Sooner Routhier_  
_Lighting Programing - Sooner Routhier, Joe Lott, Aaron Luke_  
_Associate Lighting Design and Touring Lighting Director - Aaron Luke_  
_Photography - Todd Moffses_

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.