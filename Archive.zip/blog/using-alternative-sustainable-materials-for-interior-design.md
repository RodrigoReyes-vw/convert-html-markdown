[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Material Focus | Mycelium for Interiors

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/240116_INT%20Mycelium/Kitchen%20render%20-%20large%202.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fusing-alternative-sustainable-materials-for-interior-design)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Material%20Focus%20|%20Mycelium%20for%20Interiors&url=https%3A%2F%2Fblog.vectorworks.net%2Fusing-alternative-sustainable-materials-for-interior-design&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fusing-alternative-sustainable-materials-for-interior-design)

Trying new materials and finishes can be a joy, especially if they’re helping meet your project’s sustainability needs.

In this post, we’ll look at how Mycelium and 3D printing can open the door to new design possibilities.

#### What’s Mycelium?

Created from a thin root-like fungus, Myceliumcan be molded into any shape you desire, whether it be brick, insulation, or more custom elements like lamps or sculptures.

There are countless advantages to using Mycelium for your projects. It’s bio-degradable, lightweight, and in most applications, carbon-negative.

Mycelium is also naturally fire-resistant, making it a great addition to non-load-bearing surfaces in kitchens. And if you’re using Mycelium in a kitchen design, Mycelium can be water-resistant with the right finish.

For more on designing kitchens, [check out our blog on the power of the **Parametric Cabinet** tool in Vectorworks 2024](../../../net/vectorworks/blog/endless-combinations-new-parametric-cabinet-tool.html).

#### Experimenting with Mycelium & Design Technology

Design firms and manufacturers around the world have already started experimenting with Mycelium.

[bioMatters](https://www.biomatters.org/), a research and design studio based in New York City and London, for example, is crafting tiles out of Mycelium and algae using 3D printing. Per [_designboom_](https://www.designboom.com/design/biomatters-sustainable-tiling-system-3d-printing-mycelium-algae-myco-alga-11-06-2023/)_,_ the MYCO-ALGA are made using “computational algorithms, \[and\] the panels are digitally designed and then 3D printed, grown, and enriched with bio pigments to infuse natural hues.”

Using algorithms-aided design techniques ([which can be taken advantage of in Vectorworks via the **Marionette** feature](../../../net/vectorworks/blog/what-is-marionette-a-look-at-vectorworks-algorithmic-modeling-tool.html)), you too can generate random patterns and representations of your sustainable materials, just like bioMatters’ sprawling, organic MYCO-ALGA tiles.

Think of algorithmic modeling like a recipe where the algorithm is the recipe itself. It takes the ingredients (the inputs), mixes them together based on the instructions (the manipulation), and gives you a final dish (the outputs). So, in a way, algorithmic modeling is like building a program recipe.

![Marionette](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/160122_Graphical%20Scripting%20in%20Marionette/Marionette.png?width=700&height=347&name=Marionette.png)

Marionette and algorithms-aided design aren’t the only ways you can experiment with sustainable design like bioMatters. Vectorworks can also assist with 3D printing.

You can take your 3D model from Vectorworks [using any number of modeling techniques](https://university.vectorworks.net/course/index.php?mycourses=0&tagfilter%5Bcategory%5D=38&tagfilter%5Btype%5D=0&tagfilter%5Bdifficulty%5D=0&categorysort=default&mycourses=0&search=). Or, you can import 3D objects from elsewhere. Vectorworks can import .stl and .obj files, and once you’ve modeled your object, you can translate the file into a format your printer can decode. 

For more on how to 3D print from a Vectorworks file, click the button below:

[![3D PRINTING WITH VECTORWORKS](https://no-cache.hubspot.com/cta/default/3018241/c9fd70d6-8f0b-4cd2-8725-aac1a25a7593.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/c9fd70d6-8f0b-4cd2-8725-aac1a25a7593) 

Design technology or even specifying the use of Mycelium in your designs boils down to one fundamental, exciting idea: exploration.

Design — and sustainability, for that matter — can be a fun journey of working with new technologies and materials to generate innovative solutions that improve the quality of the design and the impact it can have on the environment. Ultimately, by going on that journey and exploring the boundaries of sustainable design, you’re one step closer to designing without limits.

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.