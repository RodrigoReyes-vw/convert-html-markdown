[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# RENDER'S GAME: VECTORWORKS PARTNERS WITH AIAS FOR DESIGN COMPETITION

 Posted by [Troy McConnell](https://blog.vectorworks.net/author/troy-mcconnell) | 2 min read time 

![aias_competition](https://blog.vectorworks.net/hubfs/aias_competition.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Frenders-game-vectorworks-partners-with-aias-for-annual-design-competition)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=RENDER'S%20GAME:%20VECTORWORKS%20PARTNERS%20WITH%20AIAS%20FOR%20DESIGN%20COMPETITION&url=https%3A%2F%2Fblog.vectorworks.net%2Frenders-game-vectorworks-partners-with-aias-for-annual-design-competition&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Frenders-game-vectorworks-partners-with-aias-for-annual-design-competition)

For the second year, we are celebrating the next generation of designers through our partnership with the [American Institute of Architecture Students (AIAS)](http://www.aias.org/). Together, we are sponsoring the second annual AIAS [In Studio Render/Sketch Competition](http://www.aias.org/competitions/studio-render-sketch-competition/).

![aias_competition](https://blog.vectorworks.net/hs-fs/hubfs/aias_competition.jpg?width=720&name=aias_competition.jpg)  

AIAS is asking its members to share their sketches and renderings to showcase their work and inspire those looking to grow their skill sets.

"AIAS members like to live on the edge of design, technology, and innovation,” said Nick Serfass, executive director of the AIAS. “As the next generation of architects, the AIAS is excited to partner with Vectorworks, a next-generation technology company. Vectorworks' products and technology can help propel AIAS members to the forefront of the design and architecture professions."

The deadline for AIAS members to enter the competition is December 14\. Participants should share their sketches and/or renderings on their public Instagram and tag AIAS (@aiasorg) and Vectorworks (@vectorworks), and use the hashtags #AIASInStudio and #InStudioRender.

Every Wednesday throughout the competition, AIAS National Officers will select their top five submissions and feature them in the AIAS InStudio Highlights on Instagram.

At the end of the competition, the jury will select three winners from posted submissions. The first-place winner will receive a cash prize of $300, with second- and third-place winners taking home $200 and $100, respectively. For inspiration, take a look at last year’s winning entries [here](http://www.aias.org/wp-content/uploads/2018/01/InStudio-Render-Sketch-Comp%5FWinners.pdf).

![Picture1](https://blog.vectorworks.net/hs-fs/hubfs/Picture1.png?width=324&name=Picture1.png) 

_First place winner from last year's competition, Jenny Nguyen. Taichung Opera House_

![Picture2](https://blog.vectorworks.net/hs-fs/hubfs/Picture2.png?width=201&name=Picture2.png) 

_Second place winner from last year's competition, Mark Davis. Hammond-Harwood House._

Submissions must be uploaded to Instagram by 11:59 p.m. on Friday, December 14, 2018, and winners will be announced at the [2018 AIAS Forum event](http://www.aias.org/events/forum-2018/) in Seattle.

**Want to learn more about how we help support students?**

[![Visit Our Education Page](https://no-cache.hubspot.com/cta/default/3018241/79c43e04-9902-4d63-a569-91b45deafa02.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/79c43e04-9902-4d63-a569-91b45deafa02) 

 Topics: [Academic](https://blog.vectorworks.net/topic/academic) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.