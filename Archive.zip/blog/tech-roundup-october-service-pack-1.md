[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Tech Roundup: October, Service Pack 1

 Posted by [Chloe Jefferson](https://blog.vectorworks.net/author/chloe-jefferson) | 2 min read time 

![Screen Shot 2017-10-10 at 5.22.52 PM.png](https://blog.vectorworks.net/hubfs/Screen%20Shot%202017-10-10%20at%205.22.52%20PM.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Ftech-roundup-october-service-pack-1)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Tech%20Roundup:%20October,%20Service%20Pack%201&url=https%3A%2F%2Fblog.vectorworks.net%2Ftech-roundup-october-service-pack-1&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Ftech-roundup-october-service-pack-1)

This year’s launch came with several new and superior features, but at Vectorworks we are always looking to improve. Our staff worked hard to address issues presented to us by you, the users, and made the necessary changes in the Vectorworks 2018 Service Pack 1, available now for download. These downloads will update all English-language Vectorworks 2018 products (Designer, Architect, Landmark, Spotlight, and Fundamentals) to version SP1.

The Service Pack includes fixes and improvements in the following areas:

* Improved Title Block Border objects, including the ability to top align issues and revisions; title blocks created in previous versions of Vectorworks now open properly in version 2018
* Added the Reset Braceworks IDs command to ensure Braceworks object IDs are unique
* Improved the site model to retain and edit source data after site model creation
* Increased screen/graphical redraw reliability and response time in various use cases
* Corrected a number of memory leaks occurring during file conversions and imports
* Increased multiple drawing view stability in relation to Renderworks
* Improved compatibility with macOS 10.13 (High Sierra)

The full list of release notes can be found [here](http://www.vectorworks.net/downloads/notes/2018SP1%5FNotes?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=techroundup1017). This wish list came directly from users who filed their concerns. We made sure to make each of these issues a priority, ensuring that our users are provided with the most updated version of the software. 

To make this transition as seamless as possible, we’ve included step-by-step download instructions for you. Be sure to read the download instructions carefully prior to installation.

[![Download Now](https://no-cache.hubspot.com/cta/default/3018241/6668b6a4-5209-4b7e-8e45-262d3f08ba7a.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/6668b6a4-5209-4b7e-8e45-262d3f08ba7a) 

![Screen Shot 2017-10-10 at 5.22.52 PM.png](https://blog.vectorworks.net/hs-fs/hubfs/Screen%20Shot%202017-10-10%20at%205.22.52%20PM.png?width=550&name=Screen%20Shot%202017-10-10%20at%205.22.52%20PM.png "Screen Shot 2017-10-10 at 5.22.52 PM.png")_Rendered panorama_ 

Haven’t downloaded Vectorworks 2018 yet? This version of our software delivers a robust suite of capabilities that will enhance your modeling process, simplify your workflows, and help you create one-of-a-kind experiences.

For example, you’ll be able to provide your clients with a 360-degree interactive view of your model in the Renderworks feature set with new [rendered panoramas](http://www.vectorworks.net/training/2018/getting-started-guides/rendering-in-vectorworks/rendering-panoramas?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=techroundup1017). Put your clients in the middle of your vision, no matter how big the model is.

You can access the full list of new features [here](http://www.vectorworks.net/en/2018?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=techroundup1017).

Customers outside the U.S. should [contact their local distributor](http://www.vectorworks.net/international?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=techroundup1017) for pricing and availability.

 Topics: [Tech Tips and Workflows](https://blog.vectorworks.net/topic/tech-tips-and-workflows), [BIM (Landscape)](https://blog.vectorworks.net/topic/bim-landscape), [Production & Lighting Design](https://blog.vectorworks.net/topic/production-lighting-design) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.