[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# New Possibilities with Vectorworks Nomad & Apple PDFKit

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/230629_Nomad%20Apple%20PDFKit/blog-1440x800_NOMAD%20Hero-2.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fusing-apple-tech-to-streamline-mobile-pdf-workflows)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=New%20Possibilities%20with%20Vectorworks%20Nomad%20&%20Apple%20PDFKit&url=https%3A%2F%2Fblog.vectorworks.net%2Fusing-apple-tech-to-streamline-mobile-pdf-workflows&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fusing-apple-tech-to-streamline-mobile-pdf-workflows)

That’s right. [The Vectorworks Nomad app](https://apps.apple.com/app/vectorworks-nomad/id506706850) has new functionalities that improve your ability to view files generated from your Vectorworks files — wherever you may be.

Let’s dive right into the update and what it means for your mobile design workflows.

---

#### Wait … What’s the Nomad App?

If you’re not yet familiar with the Nomad mobile app, let’s first use this section to provide some useful background information.

The mobile app allows you to browse and annotate PDFs, panoramas, and more generated from your Vectorworks files. Additionally, you can share these views in Nomad with your collaborators and colleagues. 

Changes you make to Vectorworks files are automatically synchronized to your private cloud library, allowing you to browse and share your latest designs from any web-enabled device.

![Nomad Illustration](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230629_Nomad%20Apple%20PDFKit/Nomad%20Illustration.png?width=332&height=184&name=Nomad%20Illustration.png)

Nomad is part of [Vectorworks Cloud Services](https://www.vectorworks.net/cloud-services) and is available to anyone registering for a free account. [Vectorworks Service Select](https://www.vectorworks.net/service-select) members and subscribers also have access to Nomad, with the advantage of more cloud storage as well. 

[To get started with Vectorworks Cloud Services, click here](https://sso.vectorworks.net/accounts/login/?next=https%3A%2F%2Fcloud.vectorworks.net%2Fportal%2Ffiles%2Fhome%2F).

Nomad functionalities include:

* Viewing and navigating 3D models of Vectorworks files in the cloud library.
* Viewing 3D models of Vectorworks files in a real-world setting using augmented reality (AR) technology (requires an AR-compatible device).
* Using AR technology and your mobile device’s camera to measure objects in the real world.
* Viewing rendered panoramic images or animation movies of Vectorworks files.
* Creating 3D models from photos.
* Marking up PDF files with Text, Freehand, Oval, Rectangle, and Line tools and save the marked-up files to the cloud library.

Now that you’re up to speed, continue reading to find out what’s new with Nomad for iOS.

---

#### What’s New with the Vectorworks Nomad App?

With the iOS update, Nomad is now based on Apple’s PDFKit technology and no longer the open-sourced PDF technology of years past, improving your ability to get the most out of Nomad. 

"Transitioning our iOS PDF view and markup functionality to use native PDFKit allows for a streamlined and improved experience when viewing PDF files, adding markups, and using Apple Pencil,” said Lyuben Hadzhipopov, Vectorworks’ cloud and mobile manager.

The advantages mentioned by Hadzhipopov as well as other exciting ones you'll find with the use of Apple's PDFKit, are listed below:

➕ Handle and process larger PDFs inside the Nomad application.

➕ Support of multiple [Apple Pencil](https://www.apple.com/apple-pencil/?afid=p238%7CsraIMFAgF-dc%5Fmtid%5F1870765e38482%5Fpcrid%5F648918799862%5Fpgrid%5F76054337646%5Fpntwk%5Fg%5Fpchan%5F%5Fpexid%5F%5F&cid=aos-us-kwgo-btb-applepencil--slid---product-) features.

➕ Create markups and annotations directly within your PDF..

➕ Maintain file and image quality through markup processes.

#### Improving Your Design Experience with Cutting-Edge Apple Tech

This update to Nomad is essentially an “under-the-hood” improvement, and it lays the groundwork for [even more improvements coming soon](https://www.vectorworks.net/public-roadmap), such as the ability to use all the Apple Pencil gestures when viewing and working on your designs. 

![VCS](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230629_Nomad%20Apple%20PDFKit/VCS.jpg?width=936&height=614&name=VCS.jpg)_Design courtesy of 3+1 Architect._

The adoption of Apple tech like PDFKit and Apple Pencil demonstrates our commitment to using cutting-edge technology to help you design without limits.

[Vectorworks is, in fact, the first major BIM authoring tool to run natively on Apple Silicon](../../../net/vectorworks/blog/5-things-the-new-macos-big-sur-optimized-with-m1-brings-to-vectorworks.html). Plus, the Vectorworks Graphics Module (VGM) makes full use of Apple’s Metal API. Together, these updates increase the speed at which you can design by two to four times.

“There’s nothing that serves design like great performance,” said Steve Johnson, Vectorworks chief technology officer. “We’re excited to see these technology advances serve our design customers.” 

![Apple Tech](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230629_Nomad%20Apple%20PDFKit/Apple%20Tech.png?width=1440&height=739&name=Apple%20Tech.png)

To learn more about some of our other innovative upgrades to Vectorworks, [click here and read our article on the USD file format](../../../net/vectorworks/blog/new-possibilities-for-digital-content-exchange-with-usd-format.html).

#### Download the Nomad App Today!

If you’re not already using the Nomad app, you can click the button below and download it for your Apple devices:

[![DOWNLOAD THE NOMAD APP](https://no-cache.hubspot.com/cta/default/3018241/2604b215-b517-4340-89eb-3b2a2e82ee0f.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/2604b215-b517-4340-89eb-3b2a2e82ee0f) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.