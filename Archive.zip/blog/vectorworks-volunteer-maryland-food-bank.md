[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Serving Our Community at Maryland Food Bank

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/210722_MFB_Volunteer/maryland-food-bank-group-sq.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-volunteer-maryland-food-bank)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Serving%20Our%20Community%20at%20Maryland%20Food%20Bank&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-volunteer-maryland-food-bank&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-volunteer-maryland-food-bank)

At Vectorworks, we strive to broaden our perspectives by collaborating and interacting with people whose experiences are different from our own. To promote inclusion — [one of our four core values](https://www.vectorworks.net/en-US/company/values) — we encourage our team to gain new perspectives through volunteering. We proudly offer our team members time off specifically for serving their communities, wherever that may be.

![maryland-food-bank-group-sq](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210722_MFB_Volunteer/maryland-food-bank-group-sq.jpg?width=1080&name=maryland-food-bank-group-sq.jpg)

With members of the Vectorworks family having such an opportunity, they are given the important chance to put themselves second. Lee Draminski, Vectorworks partnership specialist, said, “Creating a culture of ‘giving back’ is something Vectorworks perpetuates by providing VTO (Volunteer Time Off) for its employees to spend up to 24 hours of paid time annually to volunteer.”

Draminski continued, “It’s fun to organize co-worker groups to volunteer as a team, because there is strength in numbers; and, our collective efforts can be more impactful. This couples a team-building opportunity with the ability to give back to our own communities, while supporting causes and organizations we are passionate about.”

One of our favorite volunteering destinations is the amazing Maryland Food Bank.

From their [three different locations](https://mdfoodbank.org/about/locations/), MFB distributes over 40 million meals a year to food-insecure Marylanders. Additionally, [per their website](https://mdfoodbank.org/), the food bank works with a network of statewide partners “to create pathways out of hunger.”

![employee-packing-box-sq](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210722_MFB_Volunteer/employee-packing-box-sq.jpg?width=1080&name=employee-packing-box-sq.jpg)

Over our several visits to the non-profit, we’ve been grateful for the opportunity to help in the warehouse, whether packing boxes of food off a conveyor belt or gathering food for an emergency site.

Members of our Vectorworks family have found their time at MFB to be incredibly valuable, including Marketing Programs Director Alice Lowy: “Food is such a vital component of wellbeing, and so many events and holidays revolve around food. The Maryland Food Bank’s mission feels like a great way to give back to our local MD community, where our headquarters are located.”

As is the case with many community-conscious organizations, the COVID-19 pandemic has forced the non-profit sector to adapt their approaches to service. MFB proudly [says on its site](https://mdfoodbank.org/news/mfbs-evolution-for-marylands-recovery/) that they’re “not the same food bank that operated prior to the pandemic.”

With the loss of loved ones and jobs alike, the pandemic has only increased the challenges felt by so many of the members in MD and worldwide. Our Alice Lowy said, “I personally feel and felt very privileged during the pandemic, so I was looking for ways to get involved and give back to those who were really struggling.” Now, more than ever, it is important to support organizations like MFB.

![vectorworks-employee-packing-food-box-sq](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210722_MFB_Volunteer/vectorworks-employee-packing-food-box-sq.jpg?width=1080&name=vectorworks-employee-packing-food-box-sq.jpg)

If you, too, are interested in volunteering at Maryland Food Bank, [click here](https://mdfoodbank.org/ways-to-give/volunteer/)! Or, if you are moved by the non-profit’s story and mission (but don’t live in the Maryland area), [donate here](https://mdfoodbank.org/donate/)!

 Topics: [News](https://blog.vectorworks.net/topic/news) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.