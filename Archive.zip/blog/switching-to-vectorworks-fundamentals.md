[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# How to Switch to Vectorworks Fundamentals

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2203013_Fundamentals%203D%20Modeling/5127-2009-launch-product-page-updates-fund-med-1440x725_opti.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fswitching-to-vectorworks-fundamentals)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=How%20to%20Switch%20to%20Vectorworks%20Fundamentals&url=https%3A%2F%2Fblog.vectorworks.net%2Fswitching-to-vectorworks-fundamentals&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fswitching-to-vectorworks-fundamentals)

[Vectorworks Fundamentals](https://www.vectorworks.net/fundamentals) gives you the freedom to imagine, design, and document all your design ideas. 

Despite your limitless design possibilities, a transition to Vectorworks Fundamentals is easier than you might think. In fact, you can switch in five, easy steps. 

Read on to learn more.

## What’s Vectorworks Fundamentals?

Before we dive into switching to Vectorworks Fundamentals, let’s review what the software is and what it can be used for. 

Simply put, Fundamentals is a powerful design software that allows you to create general drawings, 3D models, and document all in one software. The product is perfect for professions like product designers who need a robust modeling tool that's centered around flexible, yet accurate, free-form modeling and drawing.

[READ: “Geiger Furniture | Masters of Vectorworks Fundamentals"](https://www.vectorworks.net/en-US/customer-showcase/geiger-furniture-masters-of-vectorworks-fundamentals)

Now, let’s review the five steps towards getting started with Vectorworks Fundamentals.

### Step 1 | Get Started with a Free Trial

Taking Vectorworks for a trial run is like test driving a car before you buy it. The difference with a software trial is that you have the time to freely explore the program in-depth.

Getting started with a Vectorworks trial is free, easy, and gives you the chance to do some research before committing to a license. Use this time to get a feel for Fundamentals’ [user interface](../../../net/vectorworks/blog/palettes-workspaces-and-ui-in-vectorworks.html), as well as its precision drawing, modeling, rendering, and documentation capabilities.

[Click here](https://www.vectorworks.net/products?hsCtaTracking=a8896ded-3c2b-43d9-af99-d6c429ed26e6%7C0e4fec67-4da7-4f4d-a86e-deed7d07a749&showModal=trial-form) to begin your free trial.

### Step 2 | Take Advantage of Free Learning Resources

As you explore Vectorworks during your trial period, take the time to check out some free learning resources on [Vectorworks University](http://university.vectorworks.net/) (our learning management system), the [Planet Vectorworks blog](../../../net/vectorworks/blog/index.html), or our [monthly webinars series](https://www.vectorworks.net/events).

We offer you a mix of general and industry-specific content. So, depending on your industry, you can filter content so it’s best tailored to you and your work.

![5127-2009-launch-product-page-updates-fund-med-1440x725_opti](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2203013_Fundamentals%203D%20Modeling/5127-2009-launch-product-page-updates-fund-med-1440x725_opti.jpg?width=1440&name=5127-2009-launch-product-page-updates-fund-med-1440x725_opti.jpg)

### Step 3 | Purchase Your Preferred License

After your trial, you can choose between a monthly or a yearly subscription.

#### **Option 1: Monthly Subscription**

A monthly subscription allows you to pay for only what you need when you need it.

#### **Option 2: Yearly Subscription**

This option means you can maintain access to Vectorworks year-round at a discount compared to paying monthly.

[Click here](https://customers.vectorworks.net/subscriptions?hsCtaTracking=e0b5f0f1-9a74-4c17-bcff-9be28dad887e%7C3392836a-5dc0-4cb2-bd83-3d2cf5ab1a62) to choose the subscription option that’s best for you!

### Step 4 | Training Opportunities

There’s a variety of ways to get help with Vectorworks!

First, check out the [Community Forum](http://forum.vectorworks.net/) to engage with like-minded designers and Vectorworks staff. Even if you don’t feel like posting yourself, you might find that your question has been answered already.

[Vectorworks University](http://university.vectorworks.net/) is a great place to familiarize yourself with operations and workflows.

If you’re looking for more specific training, the customer success team at Vectorworks is filled with product specialists who are experts at using Vectorworks software. You can take classes online, schedule sessions for your entire firm, or even work one-on-one with a member of the training team.

### Step 5 | Take on a Pilot Project

As you familiarize yourself with using Vectorworks, try using the software on a pilot project. A pilot project is a real project with real stakes.

Here are some recommendations for choosing a pilot project:

1. One with a non-compressed timeline.
2. One with a more straightforward design solution.
3. One that's representative of the kind of work you normally do.

For more information on switching to Vectorworks, click the button below and watch a free webinar.

[![GETTING STARTED WITH VECTORWORKS](https://no-cache.hubspot.com/cta/default/3018241/7473b852-5b07-4840-b2ff-0a3929019b71.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/7473b852-5b07-4840-b2ff-0a3929019b71) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.