[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Crowd Simulation with crowd:it & Vectorworks

 Posted by [Guest Author](https://blog.vectorworks.net/author/guest-author) | 8 min read time 

![](https://blog.vectorworks.net/hubfs/Screenshot%202023-11-22%20at%2011.51.43%20AM.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fexplore-the-crowdit-plugin-in-vectorworks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Crowd%20Simulation%20with%20crowd:it%20&%20Vectorworks&url=https%3A%2F%2Fblog.vectorworks.net%2Fexplore-the-crowdit-plugin-in-vectorworks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fexplore-the-crowdit-plugin-in-vectorworks)

_This post is written by Sophia Simon, head of operations and business development at [accu:rate](https://www.accu-rate.de/en/)._ 

_. . ._ 

#### WHY CROWD SIMULATION?

Crowd simulation is a powerful tool that allows designers, planners, and emergency responders to understand and predict crowds' behavior and make informed decisions that can improve safety, efficiency, and comfort in various situations.

The technology behind it makes it possible to simulate the behavior of crowds in various situations, such as pedestrian movement in public spaces, evacuation of buildings during emergencies, or crowd behavior during events.

Simulation software simulates many people's movements and assigns individual characteristics, behaviors, and preferences to them. These characteristics and the geometry in which the scenario is supposed to happen must be modeled and assigned upfront. Usually, during the simulation process, different scenarios will be tested and compared to each other. Therefore, floorplans have to be prepared for the simulation. This extra task can be time-consuming, so the different software must be compatible.

[That's why we've developed a plugin for Vectorworks](https://www.accu-rate.de/en/en-crowdit-x-vectorworks/) to help our mutual customers get faster results with less media disruption.

#### HOW DOES IT WORK?

The basis for good simulation results is correct geometry, modeled in a design program and prepared for simulation. 

We've developed a plugin that allows you to define simulation objects in Vectorworks, which is easily done by creating a "crowd:it" class or via the Menu bar.

In the next step, the geometry can be exported and processed in crowd:it. If there are changes to the geometry, make your edits in Vectorworks, and the plan can be replaced in crowd:it. All previous work is preserved.

#### ADVANTAGES OF THE PROGRAMS COMBINED

When used together, Vectorworks and crowd:it offer a range of advantages, including:

**Accurate Modeling:** Vectorworks provides an accurate and detailed modeling environment that allows designers to create realistic models of buildings and environments. By combining Vectorworks with crowd:it, designers can add realistic crowds to their models, allowing them to visualize and analyze how people will move and interact within the space.

**Improved Design Decisions:** By simulating pedestrian movement using crowd:it, event planners or designers can identify potential bottlenecks or other issues with the design before construction begins. This enables designers to make informed design decisions that can help improve people’s flow within a space, enhance safety, and optimize the use of available space.

**Enhanced** **Safety:** By using crowd:it to simulate pedestrian movement, designers can identify potential safety hazards and take steps to mitigate them before construction begins. This can help to ensure that buildings and public spaces are safe and accessible for everyone.

**Cost** **Savings:** By identifying potential design issues and safety hazards early on in the design process, designers can avoid costly redesigns or changes during the construction phase. This can help to save time and money, improving the overall efficiency of the design process.

The combination of Vectorworks and crowd:it offers designers a powerful toolset for creating accurate and realistic models of buildings and environments, simulating pedestrian movement, and optimizing the use of available space.This can help to improve safety, save time and money, and enhance the overall quality of the design. 

The higher the compatibility between the design program and the simulation program, the faster adjustments and variants can be tested.

#### EXAMPLE: HOW TO OPTIMIZE ROUTES IN A CINEMA

But what exactly can you offer your customers with crowd simulation? And what’s the workflow like? 

Here’s an example from one of our customers, Oliver Klaus, the founder of Vonclaussen Company. Klaus is an expert on health, safety, and management of events. Vectorworks has been his favorite design program for many years. When we developed the crowd:it plugin for Vectorworks, he was one of our beta testers and is an ambassador for crowd simulation. In one of his simulation projects, he was commissioned to check the planned conversion of a cinema for safety and optimization potential.

The challenges in cinemas are the same as in theaters or concert halls: many people want to do the same things quickly and have similar routes through a building. They arrive at the same time, then want to buy drinks and snacks or go to the restroom, and after the movie, they want to leave immediately. 

When planning a movie theater, you must consider this early on. If the visitors don't feel comfortable or have to wait too long in line, they may not come back.

To modernize an existing structure, you must work with what is there. Especially when the geometry is complicated, proofing functionality with a simulation makes sense. To update a movie theater, the auditoriums are rearranged, and two smaller auditoriums are added to offer afternoon shows.

This increases the number of visitors present and the number of screenings per day. But it also affects the circulation through the building, as people leaving the theater may interfere with those arriving for evening shows. Because of the different paths of arriving patrons as well as limited space in front of the box office and concession stands, the question is how to arrange the exits from the new theaters to balance the use of the aisles and avoid cross traffic in front of the stands, where patrons were queuing.

To let visitors leave the theater halls, two options were examined with the help of a simulation.

The first video shows people exiting through the center aisle and using the path above thestairs to go downstairs or to the restrooms. It appears that the exit is fine, and there’s no congestion.

In the second option, people are crossing the queuing area, but they're still not blocking each other.

This can also be confirmed by showing the traces, the path of each agent. With this tool, every path of every single person is drawn so that the main routes are visible.

These visualizations show that both options work. However, in the first, the traces show that the main aisle is very busy. So, let's take a closer look.

We can analyze specific areas in the simulation and evaluate them for various measures such as velocity, density, or time spent in that area.

![traces-1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/231122_Crowdit%20Guest%20Blog/traces-1.png?width=756&height=376&name=traces-1.png)

![traces-2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/231122_Crowdit%20Guest%20Blog/traces-2.png?width=767&height=409&name=traces-2.png)

And as shown in the graphic below, measures like density or velocity can be analyzed through an evaluation polygon. Within this polygon, the velocity can be tracked, as shown in the diagram. With a distribution between 1.61 and 0.46 m/s as average values for velocity, the simulation can show that there’s no congestion in the aisle, and the patrons can walk to the exits without any slowdown or obstruction.

![crowd 4](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/231122_Crowdit%20Guest%20Blog/crowd%204.png?width=600&height=400&name=crowd%204.png)

Based on the simulated results, Klaus concluded that both options can be used, but the first was better since the paths are clearer and there’s less counterflow. It would make sense to keep the second option as well, in case there’s an overlap of exits and arrivals in the big halls.

Per Oliver Klaus: “In these projects you must go back and forth with the customer to define the final geometry. Using the crowd:it plugin in Vectorworks is a big help, because you can make the changes in Vectorworks and simply load the plan back into crowd:it. So, the workflow is iterative and accompanies one throughout the customer project. Changes can be inserted quickly, and I can provide my customers with results to their questions at any time.”

#### Exclusive crowd:it Offer for Vectorworks Customers 

In an exclusive offer for Vectorworks customers, accu:rate is offering free access to crowd:it until May 31, 2024\. Click the button below to learn how you can redeem the offer:

[![VISIT THE CUSTOMER PORTAL](https://no-cache.hubspot.com/cta/default/3018241/371165f2-9f22-44bc-b312-8f080ca203db.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/371165f2-9f22-44bc-b312-8f080ca203db) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.