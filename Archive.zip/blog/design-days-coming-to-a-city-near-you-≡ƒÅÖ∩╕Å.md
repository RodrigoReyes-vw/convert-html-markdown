[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# What You Need to Know About Vectorworks Design Day

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2023%20Blog%20Images/08_Design%20Day%20Announcement/blog-featured-1440x800.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fdesign-days-coming-to-a-city-near-you-%F0%9F%8F%99%EF%B8%8F)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=What%20You%20Need%20to%20Know%20About%20Vectorworks%20Design%20Day&url=https%3A%2F%2Fblog.vectorworks.net%2Fdesign-days-coming-to-a-city-near-you-%F0%9F%8F%99%EF%B8%8F&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fdesign-days-coming-to-a-city-near-you-%F0%9F%8F%99%EF%B8%8F)

This worldwide series of events is tailor-made for architects, interior designers, landscape professionals and site designers, and entertainment design professionals. Join industry leaders and design enthusiasts for inspiring stories, presentations, and networking opportunities, plus get excited for Vectorworks senior leadership's exploration of what’s new in Vectorworks 2024.

Scroll through this blog post to find an event in a city near you and get ready to connect and learn with the Vectorworks community!

#### What Can You Look Forward to at Vectorworks Design Day?

* Get ready to be wowed by the latest version of Vectorworks software, Vectorworks 2024, released in September 2023.
* Gain valuable insights from real-world case studies presented by fellow professionals who are successfully using Vectorworks software in their own practices.
* Connect and network with like-minded designers and the Vectorworks team, forging new relationships and collaboration opportunities.
* Have your technical questions answered by Vectorworks experts at our Tech Desk.
* Uncover the future of Vectorworks with an exclusive presentation by senior leadership, where they'll dive into plans from our [Roadmap](https://www.vectorworks.net/public-roadmap).

#### Design Day UK 

**Date**: October 3, 2023

**Industries**: Architecture, interiors, & landscapes

[![SAVE MY SPOT](https://no-cache.hubspot.com/cta/default/3018241/8e05545a-69a2-4558-aca2-6efc64d49efe.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/8e05545a-69a2-4558-aca2-6efc64d49efe) 

#### Design Day Los Angeles

**Date**: October 17, 2023

**Industries**: Entertainment

[![SAVE MY SPOT](https://no-cache.hubspot.com/cta/default/3018241/22158040-ff6a-47bb-98a1-5f25904fd31c.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/22158040-ff6a-47bb-98a1-5f25904fd31c) 

#### Design Day Vancouver

**Date**: October 25, 2023

**Industries**: Architecture, interiors, & landscapes

[![SAVE MY SPOT](https://no-cache.hubspot.com/cta/default/3018241/be5009d7-55c5-4813-a5e4-ee161e7fdc58.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/be5009d7-55c5-4813-a5e4-ee161e7fdc58) 

#### Design Day New York City

**Date**: November 1, 2023

**Industries**: Architecture, interiors, & landscapes

[![SAVE MY SPOT](https://no-cache.hubspot.com/cta/default/3018241/1fa00d8c-295d-45eb-9f19-71a0095ee55c.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/1fa00d8c-295d-45eb-9f19-71a0095ee55c) 

#### Design Day Brooklyn 

Date: November 2, 2023

Industries: Entertainment

[![SAVE MY SPOT](https://no-cache.hubspot.com/cta/default/3018241/381db2eb-1913-4b3e-a6b8-f2f83ecfb465.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/381db2eb-1913-4b3e-a6b8-f2f83ecfb465) 

#### Design Day Sydney 

**Date**: March 19, 2024

**Industries**: Architecture, interiors, & landscapes

[![SAVE MY SPOT](https://no-cache.hubspot.com/cta/default/3018241/bdeac6d2-d87f-4474-b020-0756f6c66264.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/bdeac6d2-d87f-4474-b020-0756f6c66264) 

#### Relive the Action | Looking Back to Design Day 2022

Wondering what kinds of presentations you can expect at [Design Day 2023](https://designday.vectorworks.net/)? Take a look back at the 2022 events in the UK and Canada. Many talented designers discussed how they’re using Vectorworks to achieve beautiful and bespoke design solutions.

###### Design Day UK 2022

Iain Lyon and Lisa McRavey, landscape architects at RaeburnFarquharBowen, used Vectorworks Landmark and Esri ArcGIS mapping software to explore potential improvements along the 134-mile John Muir Way. Their findings were presented in an interactive story map, offering a dynamic and accessible experience for public consultation.

Niall Williams, director of ND Landscape Architects and host of the Vectorworks-sponsored People, Place & Nature podcast, teamed up with Water Offsets CEO Tapiwa Gavaza to discuss the increasing problems of water scarcity in some areas of the UK, particularly in the South East. 

Studio Partington used Vectorworks' Embodied Carbon Calculator tool — Bronze Stevie Awards winner for the 20th annual International Business Awards — for their proposals to replace the facade of Crescent House. This technology helped balance the preservation of history with the reduction of operational carbon. The project showcases how Vectorworks' native carbon and energy calculation tools empowers you to seamlessly integrate these processes into everyday design workflows.

[Starbucks' interior design team](https://university.vectorworks.net/course/view.php?id=2388) highlighted the flexibility of Vectorworks in improving their workflow. By using Vectorworks and implementing BIM principles, standardized file templates, and centralized 3D resource libraries, the team was able to streamline their design process from 11 weeks to just four weeks.

###### Design Day Canada 2022 Recap

Charles Britton and Jordi Ashworth of McFarland Marceau Architects discussed their firm's recent transition to a BIM workflow. They discussed major breakthroughs in their transition, which involved file setup, automation, tools, coordination, and change management. They briefly discussed how training with Vectorworks team supported their transition, and presented their pilot project, Gitxsan West Secondary School.

Scott Irvine and Kayla Poch of PWL Parntership Landscape Architects, Inc. reflected on the lessons they learned as they integrated BIM in their design process. They presented their project, TriCity Central - North Site, and shared their site modeling process for the project. They also shared the challenges they faced in their first BIM project, and the solutions they found.

Robert Sondergaard of Electric Aura Projects presented his design process for the 2021 Grey Cup Halftime show from conception to game day. He discussed how Vectorworks was essential in the design process and was used to create detailed working drawings while also being able to produce renderings to communicate with stakeholders.

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.