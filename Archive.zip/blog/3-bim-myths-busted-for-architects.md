[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# 3 BIM Myths Architects Must Understand

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/210622_BIM%20Myths/5.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2F3-bim-myths-busted-for-architects)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=3%20BIM%20Myths%20Architects%20Must%20Understand&url=https%3A%2F%2Fblog.vectorworks.net%2F3-bim-myths-busted-for-architects&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2F3-bim-myths-busted-for-architects)

As the AEC industry continues discussing [building information modeling (BIM)](https://www.vectorworks.net/architect/bim), it’s become clear that [some firms aren’t quite ready to fully embrace the workflows](https://www.aia.org/resources/6151-firm-survey-report).

Here are a few reasons a firm might decide to shy from BIM:

1. BIM is too complex for their firms and implementing the workflows requires too much time, money, or other resources.
2. BIM impedes creativity with its focus on data.
3. BIM is a software instead of a process, or that there is one standard proprietary “BIM software” that everyone needs to use.

We sat down with the product marketing team for [Vectorworks Architect](https://www.vectorworks.net/en-US/architect) to talk about these myths, where they come from, and what the truth is.

## Myth: BIM is too complex for many architecture firms

This one’s common, and it’s a logical jump — because BIM can involve tons of data, firms sometimes feel like they don’t have the necessary resources. Unfamiliarity can play another role here — the process is different, so some natural hesitancy makes sense. 

But just because a BIM process is unfamiliar doesn’t mean smaller firms are out of contention. BIM comes in many shapes and sizes — small, large, open, closed, etc. There’s no one way to incorporate BIM into a project or practice; it all depends on the needs of the firm and the project.

Vectorworks' Rob Hollis, AIA expands on the subject:

There’s nothing saying BIM needs to be complex. BIM is just a method to coordinate data, and architects already had record of this data anyway — think materials, quantities, sizes, and other measurements — so now it’s just a matter of making sure the information is coordinated across drawings, models, and worksheets such that it’s sharable with clients and consultants.

Firms are encouraged to evaluate what they’re looking for out of BIM, then start small and add on over time. BIM is not all or nothing — it can be whatever a firm needs it to be.

## Myth: BIM hinders creativity and impedes artistry

This myth points to the very nature of BIM. Because it deals so heavily with data, it’s easy to assume that it’s an inherently less artistic process. If the claim were true, it would make sense that firms shy from BIM.

But BIM doesn’t impede artistry, because it’s an addition to an existing process, not a replacement.

Sarah Barrett, Assoc. AIA explains further:

Nothing about BIM takes away from the work firms already do. It just adds to it, organizes it, even hastens it. So, if anything, BIM can make designers _more_ creative by delegating time-consuming tasks like documentation to automation, allowing more billable hours to be devoted to design work.

Another related claim is that BIM also negatively affects the aesthetics of documentation, which is crucial as the legal agreement between project owner and architect. Many architects develop a signature document style via line weights, attributes, images, and rendered views, and believe incorporating BIM methodology will remove the artistry that makes their documents individualistic.

With a software like Vectorworks, visuals are essential and can be incorporated into BIM documentation with the same ease as with a non-BIM process. BIM helps make the documents more robust and coordinated, but doesn’t take away from any visual attributes designers might include with documents.

## Myth: BIM is a specific software solution

With the ways we all talk about it, it makes sense to think that BIM is a specific software solution. We even call Vectorworks Architect “BIM software.”

But here BIM is descriptive, telling what the software _can do_, not what the software _is_. Semantically, Vectorworks is a BIM authoring tool.

BIM is a process, not a one-size-fits-all answer; it looks to frontload collaboration between all project stakeholders, such as owners, planners, designers, builders, architects, interior designers, landscapers, engineers, and more. As Meindert Leenders of ILD Architects puts it, BIM is a means to an end, but never the end in itself — even though other design packages seem to suggest that.

See what Luc Lefebvre, OAQ, LEED AP thinks about this myth:

We’d encounter some challenges if BIM were a software in itself. For one, it would need to account for the needs of dozens of different disciplines in the AEC industry with specialized tools. As of now, no one tool exists in the industry that offers such specialized capabilities for all aspects of a multi-disciplinary process.

Two, it would defeat the entire purpose of BIM. BIM widens the range of available software options, not condenses it. Cross-functional collaboration is the name of the game here. Requiring the use of one software, then, would be counterintuitive.

The key to succeeding in this endeavor is to have non-proprietary [open BIM](http://vectorworks.net/openbim) standards, allowing communication across the entire ecosystem of software options — and Vectorworks is proud to be at the forefront of these initiatives.

[![Explore successful BIM projects designed in Vectorworks](https://no-cache.hubspot.com/cta/default/3018241/3864c8bf-5008-48a8-81a1-9d18ac8d9bbe.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/3864c8bf-5008-48a8-81a1-9d18ac8d9bbe) 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.