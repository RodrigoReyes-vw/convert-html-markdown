[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Collaborating & Planning on a James Cameron-Inspired Exhibit

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/230315_ENT%20Joe%20Golden%20Collaboration%20Tips/Joe%20Golden%20CHALLENGER%20Collab%20Blog5-1.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-collaboration-tips-from-an-industry-pro)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Collaborating%20&%20Planning%20on%20a%20James%20Cameron-Inspired%20Exhibit&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-collaboration-tips-from-an-industry-pro&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-collaboration-tips-from-an-industry-pro)

James Cameron’s _Titanic_ came out in 1997, and it became an instant sensation. It was the first film to pass the one-billion-dollar mark in worldwide box office earnings [(per Cosmopolitan,)](https://www.cosmopolitan.com/entertainment/movies/a13819282/titanic-box-office-records-oscars/) and has remained deeply entrenched part of the zeitgeist ever since.

A year before Cameron’s film was released, Joe Golden began using Vectorworks’ design environment and workflows. Since then, the software, much like _Titanic_’s influence on pop culture, has remained a deeply entrenched part of the designer’s workflow. 

Cameron and Golden’s creative journeys intersected in 2022 when Golden, now a special projects manager for [Gallagher Staging](https://www.gallagherstaging.com/), was approached to help design an exhibit showcasing Cameron’s DEEPSEA CHALLENGER submersible and science platform for the [Natural History Museum of LA County](https://nhm.org).

This post will explore — or “dive into,” if you will — Golden’s DEEPSEA CHALLENGER project and how he used Vectorworks to collaborate with the National History Museum of LA County, as well as lighting and video vendors.

## The Natural History Museum’s DEEPSEA CHALLENGER Exhibit 

### The Project

[Per the announcement on the Natural History Museum’s site](https://nhm.org/pressure), the exhibit celebrates Cameron’s 2012 solo dive to the deepest point on earth, the Challenger Deep in the Mariana Trench.

Cameron’s diving vessel serves as the exhibit’s focal point, positioned in front of a monstrous video wall. The surrounding lights, trusses, and panels all then work in concert to create an immersive experience for anyone who steps foot in the exhibit.

![Joe Golden CHALLENGER Collab Blog2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230315_ENT%20Joe%20Golden%20Collaboration%20Tips/Joe%20Golden%20CHALLENGER%20Collab%20Blog2.jpg?width=1440&height=648&name=Joe%20Golden%20CHALLENGER%20Collab%20Blog2.jpg)

Golden was picked to help create the exhibit by David Pullido, the National History Museum of LA County’s exhibit designer. “Our solution worked the best for them,” said Golden, who noted that his team’s modular structure worked “much better than a tent.”

### Challenges

As is the case with just about any design project, the path from Golden taking on the project to its completion wasn’t a straight line. In fact, Golden notes that the layout of the exhibit kept changing, and the load-in got moved up by a whole 10 days — requiring Golden to be incredibly flexible.

Golden had to work with a lighting vendor and video vendor in addition to Pullido. So, communication with all the necessary parties became incredibly important. In fact, Golden’s main advice for other designers when collaborating on large-scale projects is to “back up your files and keep communication open.”

![blog-1440x800_Joe Golden Challenger 3D](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230315_ENT%20Joe%20Golden%20Collaboration%20Tips/blog-1440x800_Joe%20Golden%20Challenger%203D.png?width=1440&height=800&name=blog-1440x800_Joe%20Golden%20Challenger%203D.png)

Given these challenges — the need to quickly edit and document designs, plus the ability to communicate with all the project’s different collaborators — Golden’s mastery of Vectorworks was pivotal to the project’s success.

## Collaboration and Communication with Vectorworks Spotlight

There’s one Vectorworks capability Golden mentions frequently: [referencing design layer viewports](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Viewports1/Creating%5Fa%5Freferenced%5Fdesign%5Flayer%5Fviewport.htm?rhsearch=design%20layer%20viewport%20referencing&rhhlterm=design%20designated%20layer%20layers%20viewport%20viewports%20referenced%20referencing).

Referencing allows you to use information — including design layers, classes, and resources — from other Vectorworks files in your current file. The default method in [Vectorworks Spotlight](https://www.vectorworks.net/spotlight) is to create a design layer viewport and then reference the desired item. This method is useful because the referenced layers, classes, and resources stored and managed within each referenced viewport — giving you more control over your collaborative process. 

In Golden’s case, he used viewport referencing alongside the vendor and museum so that they could each work in their own files and not disrupt one another — promoting smoother collaboration. 

According to Golden, the project’s video vendor was also not using Vectorworks, so the software’s ability to import a wide range of files — IFC, RVT, DXF/DWG, and DWF, to name a few — was invaluable. 

[RELATED | “SIMPLE TRICKS FOR MORE EFFICIENT ENTERTAINMENT DESIGN”](../../../net/vectorworks/blog/3-vectorworks-tips-that-will-help-you-work-faster.html)

![Joe Golden CHALLENGER Collab Blog4](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230315_ENT%20Joe%20Golden%20Collaboration%20Tips/Joe%20Golden%20CHALLENGER%20Collab%20Blog4.jpg?width=1440&height=648&name=Joe%20Golden%20CHALLENGER%20Collab%20Blog4.jpg)

## Don’t Stop Exploring! Check Out Live Coffee Breaks

Looking for more workflow-improving insights? Continue your journey with [Vectorworks Coffee Breaks](../../../net/vectorworks/blog/online-vectorworks-learning-sessions-coffee-breaks.html). The live versions of these short, casual online sessions are now available to all Vectorworks customers!

With live Coffee Breaks, you have the opportunity to learn about different Vectorworks topics. You'll also be able to interact with Vectorworks trainers and ask questions throughout the sessions. Coffee Breaks are 100% online, so you can add to your skills without leaving your desk.

Click the button below to view all upcoming Coffee Breaks:

[![VIEW UPCOMING COFFEE BREAKS](https://no-cache.hubspot.com/cta/default/3018241/16abfd79-ceea-4842-91a6-ef49876d6b00.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/16abfd79-ceea-4842-91a6-ef49876d6b00) 

_All images courtesy of Joe Golden and Gallagher Staging._ 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.