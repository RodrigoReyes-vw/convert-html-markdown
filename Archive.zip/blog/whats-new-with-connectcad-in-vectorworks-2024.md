[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Simple, Painless Connections with ConnectCAD in Vectorworks 2024

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/240122_ENT%20ConnectCAD%202023/Screenshot%202024-01-22%20at%201.10.33%20PM.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fwhats-new-with-connectcad-in-vectorworks-2024)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Simple,%20Painless%20Connections%20with%20ConnectCAD%20in%20Vectorworks%202024&url=https%3A%2F%2Fblog.vectorworks.net%2Fwhats-new-with-connectcad-in-vectorworks-2024&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fwhats-new-with-connectcad-in-vectorworks-2024)

[Vectorworks 2024 features limit-defying updates](https://www.vectorworks.net/en-US/2024) across all of Vectorworks’ design products so you can witness the benefits of a superior workflow. 

In this post, you'll learn what's new with [ConnectCAD](https://www.vectorworks.net/en-US/connectcad) in Vectorworks 2024 and how its streamlined and detailed tools can help you hand over documentation to clients and system contractors. 

#### 3D Rack Workflow 

With a new 3D Rack Workflow in Vectorworks 2024, you can easily place equipment into a rack and adjust and move around while maintaining its connection to its schematic device. 

The **Equipment Rack 3D** tool helps you represent a standalone, 3D view of a rack, console rack, or enclosure for a concept drawing or a model view of the design. 

You can automatically populate your 3D racks with equipment based on your schematic design using the **Create Equipment** command or manually add new equipment using the Equipment item tool. When using the command, be sure that the devices on their schematic layer have the correct location information, including Room, Rack, RackU, and — if a modular device — Slot. If you don’t fill in a schematic device’s RackU parameter, the equipment will generate on top of the Rack.

The **Equipment Rack 3D** tool also allows for a broader range of customization of AV plan's racks, whether it be fourpost, two post, console, or enclosure, and its physical attributes. There are also display items that you can turn on and off, such as doors, power, weight, and a Rack Ruler. This will allow you to recreate and save your most often-used racks for later use. 

With new 3D capabilities, your equipment items can be mounted on the front or rear of a rack. To do so, simply change the **Mounting** dropdown in the **Object Info Palette (OIP)** from **Front** to **Rear**.

![Rack Tray](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/240122_ENT%20ConnectCAD%202023/Rack%20Tray.png?width=1440&height=1090&name=Rack%20Tray.png)

The **Rack Frame Tool** in Vectorworks 2024 can also help document modular equipment items like distribution amplifiers and SSD Drives in your 3D plan, along with the ability to change the naming on the Slots from the **Edits Slots** dialog in the **OIP**. And, if you need a different way to visualize your modular equipment, you can use the tool to change your rack frames to trays. To do this, simply select **Tray** under the **Type** dropdown. 

#### Panel Visualization 

Panel visualizations in the revamped ConnectCAD allow for better visual representations of the many varied connections that may be a part of your equipment racks. 

You can now create custom panel layouts with **Panel Styles,** the **Panel Builder** and the **Panel Connector** tool, all of which are located in the **ConnectCAD Layout** toolset. 

These layouts will help you visualize and label standard or custom connector panels with to-scale, detailed views. 

The **Panel Builder** can be accessed in the **OIP** after placing a connector from the **Panel Connector** tool. The **Panel Builder** dialog screen allows you to insert multiple sets of connectors, as well creating a graphical panel representation from default geometry. You can either select a number of default connectors in the **Resource Selector** or use your own created connectors.

![Panel Builder](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/240122_ENT%20ConnectCAD%202023/Panel%20Builder.png?width=1440&height=810&name=Panel%20Builder.png)

Once the panel is generated, the panel can be edited to add custom graphics and linked text. Then, you can create the associated schematic devices by pressing the **Create Schematic Devices** button in the **OIP** and selecting the **Schematic Layer** as the destination.

You can also easily create custom symbols by duplicating a default connector and adjusting the 2D geometry and attached information. 

If your workflow requires you to create a schematic view first, you can use the **Create Panel View** command. Once you have placed your appropriate jackfield and connector panel devices around your Schematic, you’ll then make them into one panel with the **Combine Panels** command from the **ConnectCAD Drawing** menu. 

Give that panel of connections a unique device name. This way, you’ll be able to spread multiple connection points across your view that are still associated with a specific panel. Then, use the **Create Panel View** command to populate a visual representation of those connections.

#### Rack Elevations & Worksheets 

Finally, with the **Create Rack Elevation** command and **Rack Equipment Worksheets**, you can easily pull documentation of the needed equipment for built racks and send them off to contractors or equipment purchasers. 

The **Create Rack Elevation** command allows you to generate 2D elevations of your 3D equipment racks. After selecting the command (**ConnectCAD \> Layout > Create Rack Elevation**), a dialog will open in which you can choose your desired sheet layer, naming convention, and whether you want a front and/or rear viewport. 

![Rack Elevation and Worksheet](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/240122_ENT%20ConnectCAD%202023/Rack%20Elevation%20and%20Worksheet.png?width=1440&height=810&name=Rack%20Elevation%20and%20Worksheet.png)

Moreover, the **Make Rack Equipment Worksheet** tool in the **Layout** toolset will create worksheets of your populated equipment inside each rack. The dialog gives you the option of reordering and turning on/off various columns associated with the rack. 

#### Learn More About ConnectCAD

For more on the topics covered in this blog post, click the button below:

[![FREE CONNECTCAD WEBINAR](https://no-cache.hubspot.com/cta/default/3018241/1fd54a3b-2944-4032-8020-9f26c4a34132.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/1fd54a3b-2944-4032-8020-9f26c4a34132) 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.