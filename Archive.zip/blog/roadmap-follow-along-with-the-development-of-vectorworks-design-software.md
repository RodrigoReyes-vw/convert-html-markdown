[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# ROADMAP: Follow Along with the Development of Vectorworks Design Software

 Posted by [Jeremy Powell](https://blog.vectorworks.net/author/jeremy-powell) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/5245-2011-us-blog-public-roadmap-for-vectorworks-feature-image.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Froadmap-follow-along-with-the-development-of-vectorworks-design-software)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=ROADMAP:%20Follow%20Along%20with%20the%20Development%20of%20Vectorworks%20Design%20Software&url=https%3A%2F%2Fblog.vectorworks.net%2Froadmap-follow-along-with-the-development-of-vectorworks-design-software&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Froadmap-follow-along-with-the-development-of-vectorworks-design-software)

I’m [Jeremy](https://www.linkedin.com/in/jerpowell/), VP of marketing here at Vectorworks, and I’m happy to share with you a look into the strategies and functionality on our current development roadmap for Vectorworks products.

If you had the opportunity to join us for our virtual [Vectorworks Design Day](https://www.vectorworks.net/design-day?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=113020publicroadmap) this past October, we hope you heard the opening presentation from our CEO, Dr. Biplab Sarkar, about the mission of Vectorworks, Inc. and the meaning behind the statement we made with the launch of the [Vectorworks 2021 product line](http://vectorworks.net/2021?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=113020publicroadmap) — Simplicity to Design the Complex. 

Sarkar explained that this phrase takes the mission and vision of Vectorworks and succinctly expresses our promise to you — to be a brand and company that’s inspired by design. Our purpose —our commitment — is to lessen the inherent complexities of designing buildings, landscapes, and performances.

How does Vectorworks do this? We focus our investments on creating products centered on the design phases. We invest in building best-in-class technologies where they don’t exist; and when they do exist, we integrate them into our software solutions and build intuitive interfaces on top of it. We do this to create software that is simple to learn and simple to use.

What we create for you should never dictate your design, rather it should make your process of designing simpler — the simplicity to design the complex.

In 2021, we will move to a dedicated webpage for sharing our roadmap so that you can have a clearer understanding about the areas of development we are investing in that will constantly improve your experiences with our products for years to come. For now, here's a snapshot of what's in store for Vectorworks' development. 

## Development Roadmap

![5245-2011-us-blog-public-roadmap-for-vectorworks-updates-sp3](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201130%20Development%20Roadmap/5245-2011-us-blog-public-roadmap-for-vectorworks-updates-sp3.jpg?width=2430&name=5245-2011-us-blog-public-roadmap-for-vectorworks-updates-sp3.jpg) 

As you read through, we felt it was also important to pull back the curtain and share more about our strategies for future areas of development.

## Development Strategies

### For Everyone

We believe your focus should be on your designs, not your design software.

Our long-term commitment is to enhance and simplify the user interface and experience in Vectorworks products. The main areas of development in our core Vectorworks technologies and interfaces are in the themes of Quality and Performance, UI/UX, and Graphics Modernization. These areas will continue to drive us towards making your experiences in Vectorworks products faster and more intuitive, while also providing the stability and accuracy you require.

### For Collaborators

One of the great strengths about Vectorworks is the variety of supported file formats. We take pride in being a design hub, and we have no plans on stopping our investments in this area. Our goal is to continue to invest in optimizing the most used file formats, supporting value-added partner products, and ensuring that project teams and BIM collaboration remains unrivaled.

### For Architects and Interiors

We made several great advancements in recent releases, and we have a clear focus on continued support for a growing demand on 3D and BIM workflows. We are also undertaking the re-engineering and modernization of core architectural objects to support the creation of accurate BIM models and the documentation of modern construction methods and materials.

### For Landscape Architects, Designers, and Planners

With purpose-built tools for landscape design, [Vectorworks Landmark](http://vectorworks.net/landmark?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=113020publicroadmap) is providing ways to simplify the complex learning curve of adopting BIM in the landscape industry, and is quickly becoming the [BIM platform of choice for landscape architecture.](http://vectorworks.net/start/bim-for-landscape?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=113020publicroadmap) As we move forward, we are investing in developments that focus on making it simpler to produce landscape BIM models, support the demand to create sustainable sites, and creating tight integrations between landscape BIM and GIS workflows.

**For Entertainment Design and Production Professionals**

Our commitment to users in the [entertainment industry](http://vectorworks.net/spotlight?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=113020publicroadmap) is to invest first and foremost in re-engineering for better file performance. We will make tools more responsive. We will consolidate features where multiple options cause confusion. We will create consistency in behaviors between the various tools and commands in our entertainment products, and we will add functionality that simplifies your workflows. You will see evidence of this investment in the many great performance enhancements and bug fixes in version 2021\. And you will continue to see this in releases moving forward.

We hope this has given you some insight into what lies ahead for Vectorworks development. This is of course a snapshot at this moment in time and not an exhaustive list of all features in development or research. As with any roadmap, things can and do change as time passes. We look forward to continuing to share our plans with you, and to hearing your feedback with regularity. 

Vectorworks design software wouldn’t be what it is today without valuable feedback from our users. Join conversations about the roadmap by visiting the community forum.

[![JOIN THE CONVERSATION](https://no-cache.hubspot.com/cta/default/3018241/9f926f6a-f289-40d2-b989-758ab667bbda.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/9f926f6a-f289-40d2-b989-758ab667bbda) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.