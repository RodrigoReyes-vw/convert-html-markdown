[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# What’s the Video Camera Object in Vectorworks Spotlight?

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 6 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/230504_Video%20Camera/blog-1440x800_Video%20Camera%20Object%202.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fpicture-this-the-video-camera-object-in-vectorworks-spotlight)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=What’s%20the%20Video%20Camera%20Object%20in%20Vectorworks%20Spotlight?&url=https%3A%2F%2Fblog.vectorworks.net%2Fpicture-this-the-video-camera-object-in-vectorworks-spotlight&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fpicture-this-the-video-camera-object-in-vectorworks-spotlight)

Are you an entertainment designer working closely alongside directors, directors of photography, or camera operators? If so, you’re going to want to check out this blog post. 

Continue reading to learn about the Video Camera object in Vectorworks Spotlight and how it can help you and your collaborators understand how your designs will be photographed, filmed, or livestreamed.

#### What’s the Video Camera Object?

The Video Camera object in Vectorworks is a useful tool when planning any event, episode, or day of shooting. As the name suggests, the tool is a way for you to plan for real-world camera placement, helping ensure that you’re prepared for a shoot. 

By using the Video Camera object, you’re able to see how lighting, scenic elements, and the overall structure of your design will be shot, all through a simulated viewfinder. [If planning and designing for a music festival](../../../net/vectorworks/blog/lollapalooza-brazil-lighting-design.html), for example, you can use the Video Camera object to see if the talent will be in the frame and unobstructed by any elements in the line of site. 

The camera is customizable via your Object Info palette (OIP). You can define the camera by a lens, camera body, stand type, and more so that it matches the real-life camera being used. And, as settings change, the active view of the camera updates automatically. 

![2023.04-camera -blog 2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230504_Video%20Camera/2023.04-camera%20-blog%202.png?width=247&height=800&name=2023.04-camera%20-blog%202.png)

Also located in the OIP are your camera effects. These effects include depth of field, exposure, bloom, vignette, and chromatic aberration.

#### How to Use the Video Camera Object

So now that you’re aware of _what_ the Video Camera object is, an important question remains: _how_ do you use it?

The Video Camera is located in both the Event Design and Visualization tool sets. Once selected, you have two choices. You can use existing resources by clicking **Lens**, **Body,** and/or **Stand** from the Resource Selector. Or you’re able to create a custom video camera via the **Preference** dialog.

Like other custom objects in Vectorworks, your custom camera object can be saved to a library so you can quickly use it from project to project.

![2023.04-camera -blog 20](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230504_Video%20Camera/2023.04-camera%20-blog%2020.png?width=1440&height=1058&name=2023.04-camera%20-blog%2020.png)

To place the object, click where in the file you’d like to place the camera and then, once again, determine where the camera is looking. Click on the camera to see the viewfinder view. The view is shown through a blue rectangle as shown below: 

![2023.04-camera -blog 3](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230504_Video%20Camera/2023.04-camera%20-blog%203.png?width=1440&height=827&name=2023.04-camera%20-blog%203.png)

You’re able to manipulate the camera after it’s activated just as a camera operator would with a regular camera; select aim, pan, tilt, and rotate from the OIP. Set as many Video Camera objects in your file as your production is going to use. This way, you’re planning for every necessary angle. 

#### Using the Video Camera Object for Viewports and Sheet Layers

Another helpful way to use the Video Camera object is to create viewports to bring to a presentation or preproduction meeting. 

To link a Renderworks camera or video camera to a sheet layer viewport, start by selecting your desired camera. 

Once you’ve selected **Create Viewport from Camera** **, the** dialog opens. Here, you can decide whether to create a viewport that’s: 

● Linked to the camera. The existing video camera is moved from the design layer to the viewport and can be edited or deleted from there.

● Linked to a copy of the camera. The original video camera stays on the design layer, and the copy is placed on the viewport. Edits to the copy affect the viewport, but edits to the original camera on the design layer do not.

● Not linked to the camera. The viewport cannot be updated by editing a video camera object. 

Your viewport is created in whatever sheet layer you specify, with its view, projection, and perspective distance set to that of the camera. 

If you choose to link the camera to the viewport, the linked camera becomes part of the viewport. It can be edited (or deleted), changing the viewport’s view parameters by editing the camera through the viewport, giving you all the control you need.

#### Leveraging the Video Camera and Heliodon Objects

When working with shaded 3D models and realistic renderings in Vectorworks, the Video Camera object can help you, a director, or DOP see how light on a set or stage will affect a shot. 

This can be light coming from your detailed lighting devices, simpler spotlight objects, or solar animations via the [Heliodon object](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/SolarStudies/Solar%5Fstudies.htm). 

The object, located in your visualization tool set, demonstrates the location of sunlight and shadows cast on the model as the sun’s position changes for any day of the year and any location on Earth. You can enter accurate region/city information for the simulations. 

And with the film industry especially, the control of shadows is just as vital as the use of light. So, the Helidon object in your models, paired with the Video Camera, can show how the time of day in which you’ll be shooting can adjust the shadows on a performer’s face.

![2023.04-camera -blog 4](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230504_Video%20Camera/2023.04-camera%20-blog%204.png?width=1440&height=813&name=2023.04-camera%20-blog%204.png)

To learn more about specific features like the Video Camera object and the Heliodon object, visit the Vectorworks Online Help:

[![HOW CAN WE HELP?](https://no-cache.hubspot.com/cta/default/3018241/0cf81699-5087-441b-bdfb-60caaab0d1e0.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/0cf81699-5087-441b-bdfb-60caaab0d1e0) 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.