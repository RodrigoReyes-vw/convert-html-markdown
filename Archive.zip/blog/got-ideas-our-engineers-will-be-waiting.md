[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Got Ideas? Our Engineers Will Be Waiting

 Posted by [Chloe Jefferson](https://blog.vectorworks.net/author/chloe-jefferson) | 2 min read time 

![DS_Ask_Engineer_Blog_Email_Weekly_Bottom_Image](https://blog.vectorworks.net/hubfs/DS_Ask_Engineer_Blog_Email_Weekly_Bottom_Image.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fgot-ideas-our-engineers-will-be-waiting)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Got%20Ideas?%20Our%20Engineers%20Will%20Be%20Waiting&url=https%3A%2F%2Fblog.vectorworks.net%2Fgot-ideas-our-engineers-will-be-waiting&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fgot-ideas-our-engineers-will-be-waiting)

While the [2018 Vectorworks Design Summit](http://www.vectorworks.net/design-summit?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=asktheengineers071818) is the ultimate training experience for you, we also want to give you the chance to train us! Your feedback is important to us, so stop by one of our many Ask the Engineers stations to pitch your ideas. We will listen.

“We’re all about innovation, but we can’t do it alone,” said Darick DeHart, VP of product management. “With our users’ ideas, we are able to stay ahead of the latest trends and cutting-edge technologies in the industries we serve.”

Here are some topics to get you started: 

**Mobile**

Tell us how you can best view your Vectorworks models in Augmented Reality within the Nomad mobile app.

![Mobile Station](https://blog.vectorworks.net/hs-fs/hubfs/Mobile%20Station.jpg?width=4000&name=Mobile%20Station.jpg)

_Alex Nicol, mobile team manager at Vectorworks, gives a demonstration at the 2017 Design Summit._

**Cloud**

Discuss how to improve Photos to 3D model, a feature that converts reality captured from photos into a point cloud and mesh.

**User Interface**

Give feedback on how we can save you time and clicks to make Vectorworks easier to use.

**Tools & Release** 

Let us know how the intelligent, integrated updater can improve your user experience.

**User Interaction** 

Comment on how we can improve the power of the VGM to increase the efficiency and performance of sheet layer navigation graphics.

**Research** 

Share ideas for improvements in areas such as clip cube in viewports, point cloud improvements, mesh face deletion, and web view.

![Research Station](https://blog.vectorworks.net/hs-fs/hubfs/Research%20Station.jpg?width=4000&name=Research%20Station.jpg)

_Justin Hutchison, research manager at Vectorworks, gives a demonstration at the 2017 Design Summit._

We will also have stations for each industry product (Architect, Landmark, Spotlight), and many more…

Still haven’t registered yet? Hurry, because the lowest rate of $499 (with a buy one, get one free offer) **ends July 31!**

**[![Learn More](https://no-cache.hubspot.com/cta/default/3018241/314813ec-2ed0-4467-b0fe-98f53e25276c.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/314813ec-2ed0-4467-b0fe-98f53e25276c)** 

 Topics: [Vectorworks Design Summit](https://blog.vectorworks.net/topic/vectorworks-design-summit) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.