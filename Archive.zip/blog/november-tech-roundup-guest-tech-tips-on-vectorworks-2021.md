[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# November Tech Roundup: Guest Tech Tips on Vectorworks 2021

 Posted by [Kamica Price](https://blog.vectorworks.net/author/kamica-price) | 2 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/201119_Tech%20Roundup%20/November%20Tech%20Roundup%20Blog%20Image.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fnovember-tech-roundup-guest-tech-tips-on-vectorworks-2021)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=November%20Tech%20Roundup:%20Guest%20Tech%20Tips%20on%20Vectorworks%202021&url=https%3A%2F%2Fblog.vectorworks.net%2Fnovember-tech-roundup-guest-tech-tips-on-vectorworks-2021&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fnovember-tech-roundup-guest-tech-tips-on-vectorworks-2021)

For this month’s roundup, we’re bringing you tips from a well-respected Vectorworks reseller and trainer — Jonathan Reeves of [Jonathan Reeves CAD](https://jonathanreeves-cad.co.uk/). Read on for tech tips in [#Vectorworks2021](https://www.vectorworks.net/2021?utm%5Fcampaign=blog&utm%5Fcontent=111920techroundup&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext).

## Grid Line Tool

In this video, explore the new Grid Line Tool now available in #Vectorworks2021\. Gridlines are a simple yet powerful feature that will revolutionize your BIM, 2D, and 3D modeling workflows.

## Sliding and Pocket Doors

This video dives into some of the BIM features of #Vectorworks 2021\. Sliding and Pocket Doors include an array of new settings that offer flexibility to design large contemporary openings for your clients. Check out the new options and learn how to make the most of these new improvements for your future projects.

## Enhancing Your Workspace

Improve your workspace and keyboard shortcuts to get the most from #Vectorworks2021 — or any version of Vectorworks. Learn how to specifically tailor the tools, commands, and shortcuts to your own requirements for increased productivity.

## Smart Markers

#Vectorworks2021 now gives you the option to create your own drawing marker from scratch and define unique graphics. The new Smart Markers will streamline your project documentation process offering your files superior coordination between models, data, and sheet layers.

Exceptional design demands exceptional tools and platforms built to deliver absolute creative expression and maximum efficiency. At Vectorworks, we believe your design software should offer the freedom to follow your imagination wherever it may lead. See for yourself with a free 30-day trial of Vectorworks. [Click here](https://www.vectorworks.net/trial/form) for more information.

If you're still in school or a recent graduate and are looking for that all-in-one solution, check out Vectorworks' academic programs and see how you can get free or discounted software. [Click here](https://www.vectorworks.net/en-US/education) for more information.

Make the most of your software experience with [Vectorworks University](https://university.vectorworks.net/). Take classes online, sign up for one of our webinars, or schedule a training session. Beginners and experienced designers alike will gain new skills, fine-tune workflows and dive into all you can do with Vectorworks. 

 Topics: [Product Launch](https://blog.vectorworks.net/topic/product-launch), [BIM (Architecture)](https://blog.vectorworks.net/topic/bim-architecture), [Tech Tips and Workflows](https://blog.vectorworks.net/topic/tech-tips-and-workflows) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.