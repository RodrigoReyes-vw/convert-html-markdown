[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# 9 Facts About James Bond Movie Sets and Their Creation

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 2 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/220215_Skyfall%20Repurpose/M-0548_%5BB23_SU_CR_08105%5D.tif) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-vectorworks-was-used-to-design-the-sets-of-skyfall)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=9%20Facts%20About%20James%20Bond%20Movie%20Sets%20and%20Their%20Creation&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-vectorworks-was-used-to-design-the-sets-of-skyfall&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fhow-vectorworks-was-used-to-design-the-sets-of-skyfall)

As conversations circulate online about who will take over Daniel Craig's role as James Bond, it's a good time to return to one of our favorite stories: the design work on _Skyfall,_ the 2012 installation of the Bond franchise. And it just so happens that 11/8/22 is the 10th anniversary of _Skyfall_'s release!

In this post, we’ll be sharing a few details about [EON Production](https://www.eon.co.uk/)’s designs and workflows, as well as some interesting facts about the film itself. But to read to full case study on how Vectorworks was used to create the sets of _Skyfall,_ click the link below.

[READ: “Using Vectorworks for Bond Sets”](https://www.vectorworks.net/en-US/customer-showcase/vectorworks-software-for-bond-sets)

![M-0548_[B23_SU_CR_08105]](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220215_Skyfall%20Repurpose/M-0548_%5BB23_SU_CR_08105%5D.jpeg?width=1440&name=M-0548_%5BB23_SU_CR_08105%5D.jpeg)

## 5 Ways EON Productions Used Vectorworks for the Set Design of _Skyfall_

1. [Vectorworks Design Suite](https://www.vectorworks.net/design-suite) was used to efficiently model multiple sets and adhere to strict deadlines.
2. 3D models were completed in mere days to communicate designs to construction teams.
3. The Scale Objects command was used for resizing and one-off adjustments to designs.
4. The Text tool and Import command were used along with drawing, scaling, and hatching when designing the set for Skyfall’s iconic motorcycle chase in Istanbul.
5. Blast layout schematics were designed in Vectorworks and easily shared with the production team for Skyfall’s dramatic finale.

![EON_Bond_Shanghai](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220215_Skyfall%20Repurpose/EON_Bond_Shanghai.jpeg?width=1440&name=EON_Bond_Shanghai.jpeg)

## 4 Facts About the Production of _Skyfall_

1. The production of _Skyfall_ lasted five months.
2. For the motorcycle chase at the Grand Bazaar in Istanbul, the production team worked closely with the Historical Buildings Commission of Istanbul, as well as the Mayor and Council of Istanbul.
3. The Shanghai set pieces were built on the historic Pinewood Studios, just outside of London.
4. Skyfall Lodge, Bond’s childhood home and the site of the film’s climax, was created in the public heathland of Hankley Common in the UK.

## Inspire Your Next Vectorworks Design

Learning how talented designers create exceptional projects is a great way to get inspired. For more stories like this, as well as tips for improving your Vectorworks workflow, click the button below.

[![SUBSCRIBE TO PLANET VECTORWORKS](https://no-cache.hubspot.com/cta/default/3018241/8a5d9ee2-9088-47b9-9883-9f473a72fd34.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/8a5d9ee2-9088-47b9-9883-9f473a72fd34) _Images ©SKYFALL 2012 Danjaq, LLC, United Artists Corporation, Columbia Pictures Industries, Inc, EON Productions. All rights reserved._

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.