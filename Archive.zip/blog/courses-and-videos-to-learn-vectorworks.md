[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Vectorworks Tutorial Series | Beginning in Vectorworks

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/220721_Beginner_Tutorial%20Series/VW%20Basics.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fcourses-and-videos-to-learn-vectorworks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Vectorworks%20Tutorial%20Series%20|%20Beginning%20in%20Vectorworks&url=https%3A%2F%2Fblog.vectorworks.net%2Fcourses-and-videos-to-learn-vectorworks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fcourses-and-videos-to-learn-vectorworks)

Are you new to Vectorworks and its robust design features?

Well, there are several great resources at your disposal! There’s our blog, _[Planet Vectorworks](../../../net/vectorworks/blog/index.html)_, which features industry updates, tech tips, and all things Vectorworks.

[READ: Breaking Down the Vectorworks UI for Beginners](../../../net/vectorworks/blog/palettes-workspaces-and-ui-in-vectorworks.html)

You also have access to [Vectorworks University](https://university.vectorworks.net/). Here, you’ll find videos and courses that can expand your skills, perfect your workflows, and optimize your software for your creative process.

In this tutorial series, you’ll find three pieces of content that will put you well on your way to becoming a master of Vectorworks. The content will cover the following topics:

* User interface, mouse interaction, and document organization in Vectorworks
* 2D and 3D modeling in Vectorworks
* Vectorworks at its most minimalistic for focused design

Read on to begin your Vectorworks journey.

###### User Interface, Mouse Interaction, and Document Organization in Vectorworks

The course below, titled “The Basics,” is a great place to start once you’ve downloaded Vectorworks.

This guide will walk you through the overall user interface, mouse interaction, and document organization. It will also introduce you to the basic use of tools and commands in the software. You’ll become familiar with many of the basic conventions used in all Vectorworks products. 

Click the link below, and let the learning begin!

![VW Basics](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220721_Beginner_Tutorial%20Series/VW%20Basics.png?width=1440&name=VW%20Basics.png)

[Watch: The Basics](https://university.vectorworks.net/course/view.php?id=58)

###### 2D and 3D Modeling in Vectorworks

In this course, you’ll be introduced to core modeling concepts in Vectorworks. Starting with key 2D drafting techniques, you’ll learn how to create and manipulate 2D forms. Then, you’ll witness the power of Vectorworks’ hybrid drawing environment by exploring fundamental 3D modeling workflows.

Click the link below to check out the course. 

![VW Free-form Modeling](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220721_Beginner_Tutorial%20Series/VW%20Free-form%20Modeling.png?width=1440&name=VW%20Free-form%20Modeling.png)

[Watch: Free-form Modeling](https://university.vectorworks.net/course/view.php?id=64)

###### Vectorworks at Its Most Minimalistic for Focused Design

The architects at [GASA](https://www.archdaily.com/search/projects/categories/schools/country/norway/offices/gasa-architects), one of Norway's leading firms for sustainable architecture, believe it’s important to stay focused on the core of their profession: designing inspiring and well-functioning environments for everyday life. 

Find out how the team at GASA creates robust concepts by simplifying the organization and management of their Vectorworks files.

![VW Minimalistic](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220721_Beginner_Tutorial%20Series/VW%20Minimalistic.png?width=1440&name=VW%20Minimalistic.png)

[Watch: Vectorworks at its Most Minimalistic](https://university.vectorworks.net/course/view.php?id=52)

###### Get Certified!

Find tutorials and classes, like the ones in this blog, at Vectorworks University and work your way towards certifications that prove your skills!

[![BROWSE VECTORWORKS UNIVERSITY](https://no-cache.hubspot.com/cta/default/3018241/80cc3a4d-d8da-4e1e-87d3-d9a3e929e246.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/80cc3a4d-d8da-4e1e-87d3-d9a3e929e246) 

 Topics: [Tech Tips and Workflows](https://blog.vectorworks.net/topic/tech-tips-and-workflows) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.