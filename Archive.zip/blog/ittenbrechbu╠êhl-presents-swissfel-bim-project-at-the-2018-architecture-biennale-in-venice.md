[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# ITTENBRECHBÜHL PRESENTS BIM PROJECT AT 2018 ARCHITECTURE BIENNALE

 Posted by [Lisa Lance](https://blog.vectorworks.net/author/lisalance) | 2 min read time 

![news_©ittenBrechbuehl-01](https://blog.vectorworks.net/hubfs/Blog%20Images/180726_IttenBrechbuhl+Biennale/news_%C2%A9ittenBrechbuehl-01.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fittenbrechb%C3%BChl-presents-swissfel-bim-project-at-the-2018-architecture-biennale-in-venice)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=ITTENBRECHBÜHL%20PRESENTS%20BIM%20PROJECT%20AT%202018%20ARCHITECTURE%20BIENNALE&url=https%3A%2F%2Fblog.vectorworks.net%2Fittenbrechb%C3%BChl-presents-swissfel-bim-project-at-the-2018-architecture-biennale-in-venice&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fittenbrechb%C3%BChl-presents-swissfel-bim-project-at-the-2018-architecture-biennale-in-venice)

Architecture and general planning practice [IttenBrechbühl](https://www.ittenbrechbuehl.ch/en) exhibited a spatial installation with images of the [SwissFEL](https://www.psi.ch/swissfel/), Switzerland’s X-ray free-electron laser, at the renowned Architecture Biennale in Venice.

![news_©ittenBrechbuehl-01](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/180726_IttenBrechbuhl+Biennale/news_%C2%A9ittenBrechbuehl-01.jpg?width=600&name=news_%C2%A9ittenBrechbuehl-01.jpg)

_The installation can be seen in the Palazzo Mora of the European Cultural Foundation._ 
_Image © IttenBrechbühl_.

**Created with the Latest BIM Planning Methods**

A Vectorworks user for many years, the Swiss architecture firm used a BIM workflow to plan the Paul Scherrer Institute (PSI), the large-scale research facility of the SwissFEL building.

Unveiled on May 24, [the installation by IttenBrechbühl](https://www.ittenbrechbuehl.ch/node/5900) demonstrates the firm’s use of BIM planning for the design of the building, which houses one of the world's four free-electron X-ray lasers. The installation shows backlit images of the institute in a black cube — the building’s architecture is the ultimate in precision. The photographs show the 750-meter-long SwissFEL building in its scientific sobriety and its manifold complexity.

![PSI Swiss FEL Einbau Roentgenlaser 3©René Rötheli Baden](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/180726_IttenBrechbuhl+Biennale/PSI%20Swiss%20FEL%20Einbau%20Roentgenlaser%203%C2%A9Rene%CC%81%20Ro%CC%88theli%20Baden.jpg?width=600&name=PSI%20Swiss%20FEL%20Einbau%20Roentgenlaser%203%C2%A9Rene%CC%81%20Ro%CC%88theli%20Baden.jpg)

_The Swiss Free Electron Laser (FEL) is in an absolutely controlled, technically highly precise space._ 
_Image © René Rötheli Baden._

Visitors can view the exhibit in the Palazzo Mora of the European Cultural Foundation until November 25, 2018\. [Click here](https://vimeo.com/272544775) to see a behind-the-scenes video of the installation.

Exceptional design demands exceptional tools and platforms built to deliver absolute creative expression and maximum efficiency. At Vectorworks, we believe your design software should offer the freedom to follow your imagination wherever it may lead. See for yourself with a free 30-day trial of Vectorworks. [Click here](https://www.vectorworks.net/trial/form) for more information.

If you're still in school or a recent graduate and are looking for that all-in-one solution, check out Vectorworks' academic programs and see how you can get free or discounted software. [Click here](https://www.vectorworks.net/en-US/education) for more information.

Make the most of your software experience with [Vectorworks University](https://university.vectorworks.net/). Take classes online, sign up for one of our webinars, or schedule a training session. Beginners and experienced designers alike will gain new skills, fine-tune workflows and dive into all you can do with Vectorworks. 

 Topics: [BIM (Architecture)](https://blog.vectorworks.net/topic/bim-architecture) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.