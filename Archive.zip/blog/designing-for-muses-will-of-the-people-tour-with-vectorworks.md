[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# A Post-Apocalyptic Masterpiece | Muse’s “Will Of The People” Tour

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 6 min read time 

![](https://blog.vectorworks.net/hubfs/240123_ENT%20Sooner%20Muse/Vectorworks_Muse-2.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fdesigning-for-muses-will-of-the-people-tour-with-vectorworks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=A%20Post-Apocalyptic%20Masterpiece%20|%20Muse’s%20“Will%20Of%20The%20People”%20Tour&url=https%3A%2F%2Fblog.vectorworks.net%2Fdesigning-for-muses-will-of-the-people-tour-with-vectorworks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fdesigning-for-muses-will-of-the-people-tour-with-vectorworks)

_Image courtesy of:_

_Production design by Jesse Lee Stout and Sooner Rae_

_Photography courtesy of Todd Moffses_

Regardless of discipline, the relationship between designer and client is a special one. When that client is another artist, the relationship deepens. Conversations about aesthetics and practical considerations get put on the back burner, and — suddenly — you’re not just designing; you’re telling a story.

To bring the story of their “Will Of The People” tour to life, world-renowned rock band Muse sought the help of Jesse Lee Stout, Sooner Routhier, Matt Geasey, and Bryan Seigel.

#### Bringing “Will Of The People” to the Masses

Stout, who’s been creating under the name [Metaform](https://metaform.studio/) since he was 19 years old and has collaborated with the likes of the Red Hot Chili Peppers, Beck, and Phish, worked with Muse before, giving him a clear understanding of the group’s creative dynamic and needs to put on stellar live shows.

The Metaform designer was in talks with the band about their newest tour throughout the recording process of the _Will Of The People_ album. He talked with them about themes in their music, culture, politics, and more to get a clear understanding of where the band was coming from when making their new music.

“The band and I really wanted to go a very different direction from their previous tour, to give this campaign its own identity. The band and I developed a post-apocalyptic near-future world as a metaphor for our ‘new normal.’ In the past couple years, a pandemic wreaked havoc, an insurrection stormed the \[US\] Capitol, anonymous activist hackers attacked governments and corporations, and people began tearing down monuments across the globe. We all quickly grew accustomed to wearing masks and proposed a story of a group of vigilantes resetting the world,” said Stout.

![Vectorworks_Muse-1](https://blog.vectorworks.net/hs-fs/hubfs/240123_ENT%20Sooner%20Muse/Vectorworks_Muse-1.jpg?width=1440&height=960&name=Vectorworks_Muse-1.jpg)

_Image courtesy of:_

_Production design by Jesse Lee Stout and Sooner Rae_

_Photography courtesy of Todd Moffses_

In the middle of the album cycle, Stout brought in award-winning designer Sooner Routhier to help create the lighting and production design. Routhier created a rig that, according to her, “Feels like the skeletal nature of a post-apocalyptic, near-future world.” 

The rig design consisted of grids of lights that put the band in a deconstructed building, creating an industrial look and further building on the album’s narrative of chaos, disorder, and the promise of reconstruction. 

The lighting and scenic elements ideated by Stout, Routhier, and the band became the visual identity for the Fall 2022 tour and carried through the 2023 arena tour.

![Vectorworks_Muse-6](https://blog.vectorworks.net/hs-fs/hubfs/240123_ENT%20Sooner%20Muse/Vectorworks_Muse-6.jpg?width=1440&height=720&name=Vectorworks_Muse-6.jpg)

_Image courtesy of:_

_Production design by Jesse Lee Stout and Sooner Rae_

_Photography courtesy of Todd Moffses_

A world tour these days wouldn’t be complete without an Instagram-able moment, either. 

A giant head of the album’s protagonist, Will, looks over the performers, boasting a mirror mask and hood. “There’s something really intimidating about looking at someone and seeing your own reflection looking back at you. I immediately knew I wanted to bounce light off of these mirrors as an identity for the show,” said Stout.

To an audience member watching the show, the mirror mask shows them that they can be Will and — more importantly — the change they want to see in the world.

#### Storytelling With the Help of Vectorworks

Once a clear vision for the tour was established, the team began drafting and planning in their design tool of choice, Vectorworks Spotlight.

“Once I’ve completed my research, gathered references, and started to put things in a deck for artist or event approval, I begin to experiment with actual shapes in a three-dimensional environment with Vectorworks,” said Routhier.

![Vectorworks_Muse-4](https://blog.vectorworks.net/hs-fs/hubfs/240123_ENT%20Sooner%20Muse/Vectorworks_Muse-4.jpg?width=1440&height=961&name=Vectorworks_Muse-4.jpg)

_Image courtesy of:_

_Production design by Jesse Lee Stout and Sooner Rae_

_Photography courtesy of Todd Moffses_

Geasy and Seigel, frequent collaborators of Routhier’s, helped draw out the conceptual elements of the project. According to Seigel, the biggest advantage of Vectorworks is the ability to simulate how well design conceptions function in a fully built-out virtual rig. “Once the model is built, we can plug in any design concept and immediately evaluate if it will work or determine what needs to change,” he said.

![Vectorworks_Muse-5](https://blog.vectorworks.net/hs-fs/hubfs/240123_ENT%20Sooner%20Muse/Vectorworks_Muse-5.jpg?width=1440&height=960&name=Vectorworks_Muse-5.jpg)

_Image courtesy of:_

_Production design by Jesse Lee Stout and Sooner Rae_

_Photography courtesy of Todd Moffses_

The drafts team relied heavily on Vectorworks Spotlight’s Subdivision modeling and Schematic Views to create scenic elements like the giant Will head, other inflatable characters, and even video content walls that help push the story of the show forward through a series of vignettes.

“For all the inflatables, we found that bringing in a low-poly mesh and converting it to a subdivision is a great way to have complex objects look great without hurting the performance,” said Seigel. “For the eight sets of lighting ladders, schematic views were an excellent way to ensure that the design revisions were always synced up with our paperwork. We took advantage of the ability to customize the 2D front components of our lighting devices and enjoyed that we could use our existing label legends in the schematic views.”

With data-rich, purpose-built tools, the entire team of Stout, Routhier, Geasy, and Seigel were able to focus on what they wanted to do most: tell a story.

[![RELATED | TECH TIPS WITH SOONER RAE CREATIVE](https://no-cache.hubspot.com/cta/default/3018241/22ff255a-65dc-4cd7-8e62-be572aa007d6.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/22ff255a-65dc-4cd7-8e62-be572aa007d6) 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.