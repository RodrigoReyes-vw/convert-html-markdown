[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# October Webinars: Small-Scale BIM, 3D Models, & Efficient Design-Build

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/221020_October%20Webinar%20Blog/blog-1440x800_BLDG%20October%20Webinar.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinars-for-october-2022)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=October%20Webinars:%20Small-Scale%20BIM,%203D%20Models,%20&%20Efficient%20Design-Build&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinars-for-october-2022&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinars-for-october-2022)

Maintain accreditation and earn continuing education credits with Vectorworks’ monthly webinars. Whether you’re a beginner or experienced designer, you can gain new skills, fine-tune workflows, and discover all you can do with Vectorworks.

## Sustainable Resources for Small-Scale BIM

_Aired October 18_

BIM has primarily been considered for large project documentation efficiency, while smaller projects and their design processes are often neglected. This session’s goal is to show architects and allied design professionals how the inherently data-rich nature of BIM can serve smaller and design-oriented projects. BIM can refine your building design process and help you use materials more sustainably.   
  
Through a series of technical vignettes, participants will see BIM in a new light: far more than an improved documentation and sharing environment reserved for large projects, BIM can improve both the efficiency of the design process and the efficiency of the design itself.

This course is also approved for one AIA LU. 

![blog-1440x800_BLDG October Webinar](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221020_October%20Webinar%20Blog/blog-1440x800_BLDG%20October%20Webinar.png?width=1440&height=800&name=blog-1440x800_BLDG%20October%20Webinar.png)

[Click here to watch the webinar on demand.](https://university.vectorworks.net/course/view.php?id=2347)

## 3D Models and Renderings for Live Events

_Aired October 19_

Are you new to 3D modeling in Vectorworks or just looking to keep your skills sharp? 

Either way, this is the presentation for you! Join our session to learn how to create 3D models that will perfectly complement your presentation. You’ll learn tons of tips for 3D modeling in Vectorworks, like how textures can reduce the complexity of models, details on conceptual and free-form designs, and rendering tricks to help you present your models.

![blog-1440x800_ENT October Webinar](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221020_October%20Webinar%20Blog/blog-1440x800_ENT%20October%20Webinar.png?width=1440&height=800&name=blog-1440x800_ENT%20October%20Webinar.png)

[Click here to watch the webinar on demand.](https://university.vectorworks.net/course/view.php?id=2366)

## Maximizing Landscape Design-Build Efficiency with Technology

_Aired October 27_

During the Great Recession, landscape architect and owner of a mid-size design-build company, Joe Hanauer decided to “tech up.” His goal then was to be a one-person design-build office. Now, with labor markets tight, using technology to create efficiencies for installation crews is increasingly important. With hardware including a tablet, computer, GPS Surveyor, altimeter level and camera, combined with software for note taking, estimating, and designing this session will reveal how they are all essential to creating an efficient workflow from first call to last shovel.

This session will also show how this “almost-paper-free” technology workflow can be used to run a one-person office and scaled to work with larger firms as well.

This course is also approved for one LA CES PDH and one APLD CEU.

![blog-1440x800_LAND October Webinar](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221020_October%20Webinar%20Blog/blog-1440x800_LAND%20October%20Webinar.png?width=1440&height=800&name=blog-1440x800_LAND%20October%20Webinar.png)

[Click here to watch the webinar on demand.](https://university.vectorworks.net/course/view.php?id=1939)

## Vectorworks 2023 is Here!

If you didn’t know already, [Vectorworks 2023](../../../net/vectorworks/blog/vectorworks-2023-now-available.html) is here! New features and updates to the Vectorworks suite of products will let you spend more time doing what you love most, designing. Click the button below to learn more.

[![SEE ALL OF WHAT'S NEW IN VECTORWORKS 2023](https://no-cache.hubspot.com/cta/default/3018241/b4d9d5d3-d537-4a8f-a198-916548b6a371.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/b4d9d5d3-d537-4a8f-a198-916548b6a371) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.