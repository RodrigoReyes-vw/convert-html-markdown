[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# March Tech Roundup: Videos for Vectorworks 2020 Service Pack 3

 Posted by [Kamica Price](https://blog.vectorworks.net/author/kamica-price) | 2 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/200318_SP3/4770-2003-sp3-blog-and-pr-image-1920x1080%20copy.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fmarch-tech-roundup-videos-for-vectorworks-2020-service-pack-3)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=March%20Tech%20Roundup:%20Videos%20for%20Vectorworks%202020%20Service%20Pack%203&url=https%3A%2F%2Fblog.vectorworks.net%2Fmarch-tech-roundup-videos-for-vectorworks-2020-service-pack-3&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fmarch-tech-roundup-videos-for-vectorworks-2020-service-pack-3)

The latest [Vectorworks 2020](https://www.vectorworks.net/en-US/2020?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=032620techroundup) Service Pack 3 release introduced performance improvements and new connections to partner applications. Here’s a first-hand look at some of the key updates — the Enscape free beta, GDTF/MVR improvements, and NBS Chorus integration.

![4770-2003-sp3-blog-and-pr-image-1920x1080 copy](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/200318_SP3/4770-2003-sp3-blog-and-pr-image-1920x1080%20copy.jpg?width=470&name=4770-2003-sp3-blog-and-pr-image-1920x1080%20copy.jpg)

## Enscape for Vectorworks: Free Beta

Another real-time rendering connection is available through [Enscape](https://enscape3d.com/works-with/vectorworks/). Windows users can take advantage of a free beta to quickly produce high-quality, compelling live-linked renderings while continuing to work in their Vectorworks model.

The Enscape: Free Beta is being offered to Vectorworks users now through October 2020.

## Service Pack 3: MVR & GDTF Updates

SP3 brought a fully connected workflow between [Vectorworks Spotlight](https://www.vectorworks.net/en-US/spotlight?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=032620techroundup), [Vision](https://www.vectorworks.net/en-US/vision?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=032620techroundup), and consoles that support these open file formats.

With improved GDTF data workflows in SP3, GDTF files can now be directly imported into Spotlight, applied to any Vectorworks lighting device, and be managed directly from the Resource Manager. These lighting devices can then be sent to any previz software or console that supports GDTF, including Vision, which will now recognize GDTF files when using the MVR Import.

## Enhance Your BIM Workflow with NBS Chorus Integration

The [NBS Chorus](https://www.thenbs.com/) integration allows you to manage, modify, and verify BIM specifications. Users can open a web palette in Vectorworks, letting them work concurrently with their model and NBS Chorus.

Any data modified in NBS Chorus through the web palette will update in the data record of the Vectorworks model, ensuring accurate and up-to-date specification information that is accessible at all times from the model.

NBS Chorus requires an active [Vectorworks Service Select](https://serviceselect.vectorworks.net/login%5Fform?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=032620techroundup) membership to use this function.

Check out the other quality and performance improvements of SP3.

[![Learn More](https://no-cache.hubspot.com/cta/default/3018241/0b039272-7daf-48ab-a1bd-a2b2a95593fe.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/0b039272-7daf-48ab-a1bd-a2b2a95593fe) 

 Topics: [Product Launch](https://blog.vectorworks.net/topic/product-launch), [BIM (Architecture)](https://blog.vectorworks.net/topic/bim-architecture), [Partner Products](https://blog.vectorworks.net/topic/partner-products) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.