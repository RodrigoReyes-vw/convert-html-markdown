[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Happy New Year and Happy New Roundup!

 Posted by [Chloe Jefferson](https://blog.vectorworks.net/author/chloe-jefferson) | 2 min read time 

![Screen Shot 2018-01-17 at 5.07.46 PM](https://blog.vectorworks.net/hubfs/Screen%20Shot%202018-01-17%20at%205.07.46%20PM.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fjanuary-tech-roundup)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Happy%20New%20Year%20and%20Happy%20New%20Roundup!&url=https%3A%2F%2Fblog.vectorworks.net%2Fjanuary-tech-roundup&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fjanuary-tech-roundup)

Already struggling to keep your design resolutions? We’re here to keep you on track with this month’s technical roundup, a compilation of insightful tips and tricks, helpful webinars, and software updates. 

**Let There Be Light! With the Halo Background Effect**

Eager to enhance the realistic quality of your renderings? In the video below, Vectorworks User Experience Manager Jim Wilson shows you how to seamlessly create backlit or halo-effect lighting in minutes.

  
**Get Your Computer Up to Spec with CINEBENCH**

Quickly learn how to install and use CINEBENCH, a utility for MAXON that allows you to evaluate your computer’s performance capabilities.

  
**Brace Yourself for Another Round of Helpful Webinars**

There’s a lot to discover about the [Braceworks](http://vectorworks.net/Braceworks?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=techroundup0118) add-on for [Vectorworks Spotlight](http://vectorworks.net/spotlight?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=techroundup0118) and [Designer,](http://vectorworks.net/designer?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=techroundup0118) our entertainment rigging analysis module that provides design, production, and rigging professionals with an easy way to gauge the performance of temporary structures under loads**.**

This one-of-a-kind module ensures safety and compliance with engineering codes and standards, creating a completely integrated modeling, analysis, and documentation process in one interface.

Want to learn more about Braceworks? Sign up for one of our upcoming demo webinars.

The first of five webinars will be on Thursday, January 25 at 1:00 p.m.

[![SIGN UP NOW](https://no-cache.hubspot.com/cta/default/3018241/e2275f8b-277b-4b43-8af8-1817682bccb4.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/e2275f8b-277b-4b43-8af8-1817682bccb4) 

**One of the Most Exciting Trends of 2018 Has Arrived: [Augmented Reality](https://www.rd.com/culture/technology-trends-2018/)**

Augmented reality (AR), which superimposes a computer-generated image on a real-world view, is now available for consumer mobile devices, making immersive and compelling viewing available to everyone. And in response to the fast-moving development of this technology, tech companies are creating new workflows. As a prime example of this, we have added AR capabilities to our free Vectorworks Nomad mobile app, specifically a new viewing mode that is available on iOS devices that support Apple’s ARKit technology.

[![READ THE RELEASE](https://no-cache.hubspot.com/cta/default/3018241/c7c4cf40-73e1-4eab-8a9e-22efc0c14920.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/c7c4cf40-73e1-4eab-8a9e-22efc0c14920) 

 Topics: [Tech Tips and Workflows](https://blog.vectorworks.net/topic/tech-tips-and-workflows), [Production & Lighting Design](https://blog.vectorworks.net/topic/production-lighting-design) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.