[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# April Webinars | Now Available On Demand

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 2 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/240404_April%20Webinars/blog-1440x800_April%20LAND.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinars-april-2024)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=April%20Webinars%20|%20Now%20Available%20On%20Demand&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinars-april-2024&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinars-april-2024)

April showers bring May flowers, and April webinars bring new opportunities to sharpen your skills and earn industry-related accreditations.

These new, on-demand webinars cover topics including designing to achieve net-zero carbon, landscape site analysis, and collaborative design on film and television sets.

Learn more about the webinars below.

#### Designing to Achieve Net-Zero Carbon

_Aired April 16 | Approved for One AIA LU/HSW_

The reality of the climate crisis forces architects to implement sustainable design practices. In this webinar, the Arkin Tilt Architect team will discuss how emerging methods can help reduce a project’s carbon footprint while enabling you to design captivating structures your clients love.

Discover the tools you need to gain confidence in educating your clients and stakeholders and to help you make informed decisions while designing.

[WATCH THE ARCHITECTURE WEBINAR.](https://university.vectorworks.net/course/view.php?id=3372)

![blog-1440x800_April BLDG](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/240404_April%20Webinars/blog-1440x800_April%20BLDG.png?width=1440&height=800&name=blog-1440x800_April%20BLDG.png)

#### Data Management for Streamlined Site Analysis

_Aired April 24 | Approved for One APLD and LA CES CEU_

Discover the power of digital tools for optimizing site analysis in your projects.

In this webinar, you'll learn advanced data import techniques and innovative approaches to working with both 2D and 3D topographical surveys. Plus, you’ll discover how to develop sustainable landscape designs by leveraging site model data to assess slope, elevation, surface water flow, and site context using georeferencing and satellite imagery.

With these insights and more, you can confidently handle early-stage design decisions.

[WATCH THE LANDSCAPE WEBINAR.](https://university.vectorworks.net/course/view.php?id=3415)

![blog-1440x800_April LAND](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/240404_April%20Webinars/blog-1440x800_April%20LAND.png?width=1440&height=800&name=blog-1440x800_April%20LAND.png)

#### Keys to Production & Set Design Collaboration

_Aired April 24_

With the number of departments working on film and television sets, efficient collaboration is crucial.

Watch experienced designers Dawn Snyder and AE Chadwick for a detailed look at the collaborative workflow between production and set design.

In the first part of the webinar, Snyder will discuss how production designers gather research and create a "look" for a project before sharing their vision with set designers. Then, Chadwick will show how he uses that information to make working drawings, leveraging the power of Vectorworks’ layers and classes and his own library of custom PIOs to communicate the production designer's vision to the rest of the team.

[WATCH THE ENTERTAINMENT WEBINAR.](https://university.vectorworks.net/course/view.php?id=3416)

![blog-1440x800_April ENT](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/240404_April%20Webinars/blog-1440x800_April%20ENT.png?width=1440&height=800&name=blog-1440x800_April%20ENT.png)

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.