[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# May Webinars: Social Media Marketing, Irrigation, & AV Workflows

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 2 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/220517_May%20Webinar/May%20Webinar%20BLDG.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinars-for-may-2022)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=May%20Webinars:%20Social%20Media%20Marketing,%20Irrigation,%20&%20AV%20Workflows&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinars-for-may-2022&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinars-for-may-2022)

Maintain accreditation and earn continuing education credits with Vectorworks’ monthly webinars. Whether you are a beginner or experienced designer, you can gain new skills, fine-tune workflows, and discover all you can do with Vectorworks.

###### Win More Work Through Social Media Marketing 

_Aired May 17_

Social media marketing is taking over as one of the key drivers in building relationships, driving traffic, increasing brand awareness, and giving an inside look at what your business is all about. 

The AEC industry is no exception for potential clients using social media for discovery. In this webinar, Joselyn Wojtalewicz, Vectorworks’ content marketing manager, will guide you through best practices on using different social media platforms, examples of successful firms using social media marketing, and how you can grow your audience.

This course is approved for one AIA LU, AIBC, and AAA.

![May Webinar BLDG](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220517_May%20Webinar/May%20Webinar%20BLDG.jpg?width=1440&name=May%20Webinar%20BLDG.jpg)

[Click here to watch the webinar on demand.](https://university.vectorworks.net/course/view.php?id=2117)

###### Powerful Tools for Irrigation Design

_Aired on May 19_

Irrigation design for efficiency, analysis, and quantity takeoffs are standard requirements in today’s world of landscape design.

The powerful tools within Vectorworks Landmark allow you to place outlets while seeing product-specified performance. Connect piping in your design that will calculate friction loss and hydraulic pressure, while automatically sizing the lateral and mainline piping. And, you can place drip tubing while generating true GPH required per zone.

Once designed, you can analyze, document, and calculate the irrigation network, creating a robust, water-efficient irrigation design.

![May Webinar LND](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220517_May%20Webinar/May%20Webinar%20LND.jpg?width=1440&name=May%20Webinar%20LND.jpg)

[Click here to watch the webinar on demand.](https://university.vectorworks.net/course/view.php?id=2118)

###### Modeling to Schematics: Full AV Design Workflow

_Aired on May 25_

Retool your AV workflow with Tom White, industry specialist and training consultant at Vectorworks. The webinar will discuss common challenges with AV design and innovative ways to overcome them. White will take you through a complete AV design workflow — from modeled elements in Vectorworks to schematics in ConnectCAD.

![May Webinar ENT_AV](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220517_May%20Webinar/May%20Webinar%20ENT_AV.jpg?width=1440&name=May%20Webinar%20ENT_AV.jpg)

[Click here to watch the webinar on demand.](https://university.vectorworks.net/course/view.php?id=1948)

If you want more great webinars, [you can watch all of our webinars on demand](https://university.vectorworks.net/). In [April](../../../net/vectorworks/blog/vectorworks-webinars-for-april-2022.html), we hosted webinars about interior and landscape 3D design, as well as switching to Vectorworks.

To browse the upcoming webinar schedule, click the button below.

[![VIEW UPCOMING VECTORWORKS EVENTS](https://no-cache.hubspot.com/cta/default/3018241/29b8a4d2-f157-4806-a2f0-c66df7afecf7.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/29b8a4d2-f157-4806-a2f0-c66df7afecf7) 

 Topics: [Tech Tips and Workflows](https://blog.vectorworks.net/topic/tech-tips-and-workflows) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.