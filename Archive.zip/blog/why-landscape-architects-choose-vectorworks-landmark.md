[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Why Landscape Architects Choose Vectorworks Landmark

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 7 min read time 

![](https://land8.com/wp-content/uploads/2020/10/200902_Glenaire-S-Courtyard-Aerial.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fwhy-landscape-architects-choose-vectorworks-landmark)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Why%20Landscape%20Architects%20Choose%20Vectorworks%20Landmark&url=https%3A%2F%2Fblog.vectorworks.net%2Fwhy-landscape-architects-choose-vectorworks-landmark&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fwhy-landscape-architects-choose-vectorworks-landmark)

_This Q&A was initially [published on Land8](https://land8.com/why-landscape-architects-choose-vectorworks-landmark/)._

In landscape architecture, many of the available software options seem to specialize in individual areas, requiring an investment in add-ons to enable more holistic workflows. This comes as a sticking point for many landscape architecture firms whose work spans beyond 2D drawings and plans. [Vectorworks Landmark](https://www.vectorworks.net/landmark) is known for being an all-in-one solution, which means landscape architects can work without having to invest in additional software. In this article, you’ll hear from two landscape architects who’ve switched to Vectorworks Landmark and are now benefiting from more streamlined workflows.

The first firm is [SiteWorks](http://www.siteworkscm.com/), who are based in New York City and provide a variety of landscape architecture services, including project scheduling/budgeting and construction implementation.

Next is [Surface 678](https://surface678.com/), who have received three awards from the North Carolina ASLA in 2020\. Surface 678 works on projects in the academic, cultural, civic, corporate, healthcare, senior living, and recreation markets, and have been using Vectorworks since 2019.

Let’s see why each firm made the switch.

###### **Can you share some workflow pain points you and your firm experienced before Vectorworks Landmark?**

_Jordan Guerrero, ASLA, AEP, ASLA NY Board Member, Landscape Designer at SiteWorks_ 
We do a lot of cost estimates and takeoffs in our projects, and our previous software wasn’t able to do the kind of digital terrain modeling and cut/fill analysis that we felt was necessary for our documentation needs. Working across multiple platforms to accomplish these things was a definite pain point for us.

_Phillip Tripp, PLA, Senior Landscape Architect at Surface 678_ 
We used to work in AutoCAD for black-lined construction drawings and basic color-toned conceptual plans. Over time, as architects and civil engineers started using Revit and Civil 3D, there were layers of complexity and special requests for files in formats best suited for AutoCAD. It never felt as inclusive and coordinated with Revit and Civil 3D as we had hoped.

→[Related: Why Landscape Architecture Firms Are Dumping 2D CAD](https://landezine.com/why-landscape-architecture-firms-are-dumping-2d-cad/)

![Glenaire Retirement Community in Cary, North Carolina. Courtesy of Surface 678.](https://land8.com/wp-content/uploads/2020/10/200902_Glenaire-Overall-Illustrative.jpg) 

_Glenaire Retirement Community in Cary, North Carolina. Courtesy of Surface 678._

###### **Why did you decide on Vectorworks Landmark?**

_Jordan Guerrero (SiteWorks) —_ Vectorworks Landmark is very finely tuned to the needs of landscape architects in terms of tools and features. We were also really drawn to having an all-in-one solution, one that enables BIM workflows, too, because other countries are already requiring it and now it’s coming to us.

→ [Related: Why BIM Is Taking Over Landscape Architecture](../../../net/vectorworks/blog/why-bim-is-taking-over-landscape-architecture.html)

_Phillip Tripp (Surface 678) —_ The lightbulb moment was realizing Vectorworks designed Landmark specifically for landscape architects, with native tools and features that are integral to our process. In contrast, with AutoCAD, we’d have to invest in separate add-on applications for each license in the office.

###### **What’s the biggest difference you experience in your everyday workflows?**

_Jordan Guerrero (SiteWorks) —_ The biggest thing for us is being able to do digital terrain modeling for cut/fill analysis. Our ultimate goal is to lead our practice with technology, and the landscape-focused features in Vectorworks Landmark allow us to do that.

_Phillip Tripp (Surface 678) —_ There are three big changes I’d call out. The first is replacing AutoCAD files with references to allow multiple people to work simultaneously with a single Vectorworks Project Sharing file.

The second is capitalizing on the dual system of organizing data — classes and layers — to exponentially increase our ability to develop conceptual options quickly in a clear and manageable way, from simple diagrams to full construction alternates; all while simultaneously keeping presentation quality graphics current without ever leaving Vectorworks. Additionally, our more complex projects are using Vectorworks site modeling and freeform modeling features in conjunction with Twinmotion to produce highly detailed flythrough videos for clients, without the need to use SketchUp or Rhino.

![Glenaire Retirement Community in Cary, North Carolina. Courtesy of Surface 678.](https://land8.com/wp-content/uploads/2020/10/200902_Glenaire-S-Courtyard-Aerial.jpg) 

_Glenaire Retirement Community in Cary, North Carolina. Courtesy of Surface 678._

The third is the use of Vectorworks’ resource library to actively manage our plant library and detail library, which improves our ability to provide quality assurance standards across all projects — a Vectorworks benefit that will continue to improve as we expand our office standards.

###### **In what ways does Vectorworks Landmark help you perform your job responsibilities to the highest level?**

_Jordan Guerrero (SiteWorks) —_ When we look at a site model, we’re really focusing on the real-world implications of how everything interacts. That’s why digital terrain modeling and cut/fill analysis are so important to us. They allow us to better understand the site, its elevations, and what those elevations mean when it comes to design services.

_Phillip Tripp (Surface 678) —_ Exceeding client expectations requires success in multiple ways; but in general, it’s high quality graphics and options in a timely manner which Vectorworks has proven more than capable, including expanding our services from high end perspectives to complete models, which clients have used for marketing in every case.

###### **Have there been any challenges since switching? If so, how have you addressed them?**

_Jordan Guerrero (SiteWorks) —_ We have to be very open about our software choice when working with other firms. It’s been important to talk it out at the beginning and determine proper file types. It’s just about assuring firms that our using Vectorworks isn’t going to change their workflow. Although there are many file types to collaborate with, the translation of information isn’t always seamless. We find that it sometimes requires testing with clients to find an agreeable file type to work with.

_Phillip Tripp (Surface 678) —_ An anticipated growing pain is that new hires are typically unfamiliar with Vectorworks and require in-office training during orientation and continued assistance through office mentors for the first couple months.

We work around this with Project Sharing. All production staff on a project can see the efforts of their peers and can identify when new hires would benefit from reminders on techniques or office standards. We’re optimistic that universities will expand their software options within the landscape architecture program and offer access or training courses in Vectorworks, as this skill set would be highly valued.

[![Get Help on the Vectorworks Forum](https://no-cache.hubspot.com/cta/default/3018241/8b49f5ab-4cc5-477b-ae53-b1164d53f325.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/8b49f5ab-4cc5-477b-ae53-b1164d53f325) 

 Topics: [BIM (Landscape)](https://blog.vectorworks.net/topic/bim-landscape) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.