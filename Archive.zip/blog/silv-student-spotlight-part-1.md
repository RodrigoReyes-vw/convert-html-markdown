[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# SILV Student Spotlight: Part 1

 Posted by [Chloe Jefferson](https://blog.vectorworks.net/author/chloe-jefferson) | 4 min read time 

![SILV_Blog_Email_Weekly_Bottom_Image](https://blog.vectorworks.net/hubfs/SILV_Blog_Email_Weekly_Bottom_Image.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fsilv-student-spotlight-part-1)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=SILV%20Student%20Spotlight:%20Part%201&url=https%3A%2F%2Fblog.vectorworks.net%2Fsilv-student-spotlight-part-1&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fsilv-student-spotlight-part-1)

Recently, Frank Brault, our product marketing manager for entertainment, spent two weeks helping young professionals learn the ins-and-outs of [Vectorworks](https://www.vectorworks.net/?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=silvpart1082318) and [Vision](https://www.vectorworks.net/en/vision?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=silvpart1082318) at the annual [Stagecraft Institute of Las Vegas](https://stagecraftinstitute.com/) event (SILV).

“Working with the SILV program is rewarding because the students are enthusiastic and appreciative,” said Frank. “Jane Childs, the director of SILV, has dedicated the entire program to her late husband, Don Childs, whose life and teaching provide daily inspiration to the activities. I am grateful and excited each year that I am invited to participate with the Stagecraft Institute of Las Vegas.”

In a three part series, we had the opportunity to interview three of the participants and gain insight to their experiences. The first is Tales Ribeiro, a 29-year-old lighting technician.

Born and raised in Brazil, Ribeiro left the country to learn English at the age of 20, and found himself falling in love with the entertainment industry. A self-described “big dreamer,” he most recently worked as a lighting technician/programmer/designer for Princess Cruises.

“Tales is the kind of student that teachers love to have in the class,” said Frank. “He is enthusiastic, positive, friendly, and inquisitive. He helped lift the excitement in our Vectorworks classes. It is always rewarding to teach, but Tales made it more fun for me and the other students as well.”

![Tales Pre-Vis](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/180823_SILV%20Blog%20Part%201/Tales%20Pre-Vis.jpg?width=2093&name=Tales%20Pre-Vis.jpg)

_Ribeiro presenting a project using Vectorworks previsualization software_

Here are some of his thoughts on SILV and Vectorworks.

**What drew you to pursue theater design as a career?**

Theater has the incredible power to change people’s moods by taking them somewhere else. I feel like through this career, I will be able to touch people’s souls and share the journey that I have created in my head with them.

**What drew you to apply to SILV?**

The chance to take classes from incredible professionals and teachers and alongside passionate students. When the two groups are combined in the same room, the results are fantastic.

**What did you find helpful?**

Having teachers who are part of what we are trying to achieve, who know exactly how the product works, and who extend their arms to any questions and/or doubts we may have in the future.

**How was your experience learning about Vectorworks and Vision?**

Honestly, I had never touched Vectorworks before. Having Frank Brault walk with us through the process was like riding a bicycle. Now when I see a Vectoworks project, I automatically start to think of the process to get the final result.

Vision is a very powerful tool for us programmers. Understanding the environment was a great tool for me. Plus, the way Vision interacts with Vectorworks and with the consoles is the perfect marriage. 

**What are your plans moving forward?** 

I just attended a job fair, and incredible opportunities have shown up. Now it’s my time to sit down and figure out which one of them will allow me to continue what I’ve started at SILV. 

**What features of Vectorworks and/or Vision do you think will be the most beneficial to you?** 

The communication of these platforms. Vectorworks and Vision are efficient and cooperative to transfer, connect, and interact with consoles. And Spotlight just makes the entertainment industry more welcome to the 3D world.

**Anything else you would like to add?**

Just thank you, Vectorworks, for being not only a software, but also a company that shows passion for what you do. It was great having your professionals here to share and listen.

![IMG_2443](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/180823_SILV%20Blog%20Part%201/IMG_2443.jpg?width=4032&name=IMG_2443.jpg)

_Frank lecturing during SILV_

Keep an eye out for our next SILV interview, with 22-year-old lighting programmer and technician Andy Shores.

 Topics: [Production & Lighting Design](https://blog.vectorworks.net/topic/production-lighting-design) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.