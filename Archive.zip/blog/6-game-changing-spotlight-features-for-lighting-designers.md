[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# These 6 Features Will Save You Time in Lighting Design

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 6 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/221020_Tools%20for%20Lighting%20Designers/blog-1440x800_multiview_vectorworks.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2F6-game-changing-spotlight-features-for-lighting-designers)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=These%206%20Features%20Will%20Save%20You%20Time%20in%20Lighting%20Design&url=https%3A%2F%2Fblog.vectorworks.net%2F6-game-changing-spotlight-features-for-lighting-designers&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2F6-game-changing-spotlight-features-for-lighting-designers)

As a lighting designer, you’re often required to work at break-neck speed, having to create drawings and plots for events at what feels like a drop of a hat.

That’s why, in this post, you’ll find six features in Vectorworks Spotlight that will improve your efficiency when creating lighting designs for live events. 

Lighting Design Features That Will Save You Time:

1. [Duplicate Spotlight Objects](../../../net/vectorworks/blog/index.html)
2. [“Find and Modify” Command](../../../net/vectorworks/blog/index.html)
3. [Shaded Rendering](../../../net/vectorworks/blog/index.html)
4. [2D Components for Symbols](../../../net/vectorworks/blog/index.html)
5. [Focus Tool](../../../net/vectorworks/blog/index.html)
6. [Multiview Feature](../../../net/vectorworks/blog/index.html)

## 1\. Duplicate Spotlight Objects

The Duplicate commands in Vectorworks Spotlight are essential for lighting designers. They allow you to create duplicate objects quickly and easily, place them along paths, or create backups of your objects.

Duplicated objects will retain all the properties of the original object, making it easy to create multiple lights with identical properties. For example, if you need to lay out uplights on a drape line or wall, you can add one fixture, focus it, and then use any duplicate commands to place more.

There are three Spotlight features related to duplicated objects that will save you time on your next design project: the Duplicate Along Path, Duplicate Array, and Move by Points tool.

Duplicate Along Path

[The Duplicate Along Path command](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Objects%5Fedit1/Duplicating%20objects%5Falong%5Fa%5Fpath.htm?rhsearch=duplicate%20along%20path&rhhlterm=duplicating%20duplicate%20duplicates%20duplicated%20along%20path) creates and places several copies of your lighting objects along an existing path. If your 2D object and 3D paths are selected, the 2D object is projected onto the path.

![image_duplicate along path](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221020_Tools%20for%20Lighting%20Designers/image_duplicate%20along%20path.png?width=405&height=405&name=image_duplicate%20along%20path.png)

To duplicate lighting objects along your path, select the object or objects to duplicate, and select the path object, which you can draw with the Line tool. Once the Duplicate Along Path dialog box opens, you’ll be able to choose from the following options:

* Select a path object
* Duplicate Placement
* Number of Duplicates
* Fixed Distance
* Start Offset
* Curve Length
* Center object on path
* Target to path
* Keep original orientation
* Preview

Duplicate Array

[The Duplicate Array command](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Objects%5Fedit1/Duplicate%5Farray.htm?rhsearch=duplicate%20array&rhhlterm=duplicate%20duplicating%20duplication%20duplicates%20duplicated%20array%20arrayed%20arrays) controls how many copies of selected objects are made and how these copies are arrayed — or placed — in the drawing.

To create a duplicate array, select the lighting object that you want to copy, and select the command. Then, once the Duplicate Array dialog box opens, select your desired duplication array shape.

You can create linear, rectangular, and circular arrays of your lighting objects.

![Duplicate Array 2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221020_Tools%20for%20Lighting%20Designers/Duplicate%20Array%202.png?width=1440&height=648&name=Duplicate%20Array%202.png)

Move by Points Tool

Selected objects can be moved, duplicated, and distributed along a specified distance by clicking with the [Move by Points tool](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Objects%5Fedit1/Moving%5Fobjects%5Fby%5Fclicking%5Fwith%5Fthe%5FMove%5Fby%5FPoints%5Ftool.htm?rhhlterm=moving%20move%20moved%20moves%20points%20point&rhsearch=move%20by%20points) active.

![image_move by points](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221020_Tools%20for%20Lighting%20Designers/image_move%20by%20points.png?width=2788&height=348&name=image_move%20by%20points.png)

## 2\. Find and Modify Command

You can quickly and easily search lighting devices and accessories with custom search criteria by using the [Find and Modify command](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/LightingDesign1/Find%20and%5Fmodify.htm?rhsearch=find%20and%20modify&rhhlterm=find%20modify).

Once you find your device or accessory, you can also use this command to perform actions upon them. This will save you time and let you move on to your next design task.

![image_find and modify](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221020_Tools%20for%20Lighting%20Designers/image_find%20and%20modify.png?width=352&height=430&name=image_find%20and%20modify.png)

## 3\. Shaded Render Mode

One of the most exciting new features in [Vectorworks 2023](https://www.vectorworks.net2023/) is [the new shaded rendering options](https://university.vectorworks.net/course/view.php?id=2228). With the removal of the eight-light limit and more rendering support for lights and textures, you’ll be able to better create and share views of your design concepts.

![image_shaded render](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221020_Tools%20for%20Lighting%20Designers/image_shaded%20render.png?width=1440&height=663&name=image_shaded%20render.png)

Since the shaded render mode is built into Renderworks, you don’t need expensive hardware to produce a quality rendering in a short amount of time. You and your consultants won’t have to wait for a final render to understand your scene!

[\-> RELATED: ENTERTAINMENT UPDATES IN VECTORWORKS 2023](../../../net/vectorworks/blog/spotlight-and-connectcad-updates-vectorworks-2023.html)  

## 4\. 2D Components for Symbols

If you’re creating 3D models of your lighting designs, you can reduce your 2D workload by using [2D components for symbols](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Symbols/Workflow%5F%20Using%5F2D%5Fcomponents%5Fof%5Fsymbols%5Fand%5Fplug-in%5Fobjects%5Fin.htm?rhhlterm=2d%20components%20component&rhsearch=2d%20components). With the feature, you’re in complete control of the detail level your symbols and plug-in objects display. Your 3D light objects, for example, also come with a 2D representation that makes generating plots and other paperwork painless.

![image_edit 2D components](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221020_Tools%20for%20Lighting%20Designers/image_edit%202D%20components.png?width=1440&height=871&name=image_edit%202D%20components.png)

Simply right-click to edit the detail and display of any 2D/3D hybrid object so it draws exactly as you want in plan, elevation, and section views.

Learn more about 2D components for symbols by watching the video below:

## 5\. Focus Point tool

[The Focus Point tool](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/LightingDesign2/Focusing%5Flighting%5Fdevices.htm?rhsearch=focus%20tool&rhhlterm=focus%20tool) in Vectorworks Spotlight determines where your lights are pointing, so it’s a necessary step in creating light beam representations. The focus point tool also lets you create practical and artistic looks that are familiar to programmers. 

![image_focus point](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221020_Tools%20for%20Lighting%20Designers/image_focus%20point.png?width=1440&height=1128&name=image_focus%20point.png)

You can efficiently create focus points that you can assign to multiple lighting devices, saving you from the time-consuming burden of assigning focus points to each individual fixture.

Lastly, it’s important to remember that — in 3D views — lighting devices rotate automatically to aim at the focus point. For the same behavior in 2D views, select “Automatically rotate 2D to focus point” within [your Spotlight preferences](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Setup/Spotlight%5Fpreferences%5FLighting%5FDevices%5FParameters%5Fpane.htm#h).

## 6\. Multiview Panes

One of the most underrated features across the suite of Vectorworks products is [your ability to work in multiple views simultaneously](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Views/Changing%5Fthe%5Fmultiple%5Fview%5Fpane%5Flayout.htm?rhhlterm=pane%20panes&rhsearch=multiview%20pane). With this feature, you can split your laptop or monitor screen into multiple views.

So, for example, you can create four panes to review how your lights are creating shadows and interacting with all the elements of your design. Or, you use this feature when presenting your design to clients is by simply having two panes, one for your light plot and one with a shaded render. This way, clients and/or venue owners can see your full vision quickly and easily!

Any edits made in one pane are instantly made to your other panes and your model as a whole. 

![blog-1440x800_multiview_vectorworks](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221020_Tools%20for%20Lighting%20Designers/blog-1440x800_multiview_vectorworks.png?width=1440&height=800&name=blog-1440x800_multiview_vectorworks.png)

For further tips on how you can supercharge your workflow, be sure to click the button below and check out Vectorworks University. Here, you’ll find videos, webinars, and tutorials that will help you save time and create limitless designs.

[![BROWSE VECTORWORKS UNIVERSITY](https://no-cache.hubspot.com/cta/default/3018241/80cc3a4d-d8da-4e1e-87d3-d9a3e929e246.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/80cc3a4d-d8da-4e1e-87d3-d9a3e929e246) 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.