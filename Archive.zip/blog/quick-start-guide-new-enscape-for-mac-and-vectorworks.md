[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Getting Started with New Enscape for Mac and Vectorworks

 Posted by [Guest Author](https://blog.vectorworks.net/author/guest-author) | 9 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/231013_Enscape%20for%20Mac/Enscape%20Hero%20Image.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fquick-start-guide-new-enscape-for-mac-and-vectorworks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Getting%20Started%20with%20New%20Enscape%20for%20Mac%20and%20Vectorworks&url=https%3A%2F%2Fblog.vectorworks.net%2Fquick-start-guide-new-enscape-for-mac-and-vectorworks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fquick-start-guide-new-enscape-for-mac-and-vectorworks)

_This blog is written by Gemma Da Silva, who is responsible for the Enscape Blog and is the content marketing lead at Chaos. For useful rendering tips, check out their_ [_video tutorials_](https://www.youtube.com/c/Enscape3D)_, the Enscape_ [_Knowledge Base_](https://enscape3d.com/community/knowledge-base-vectorworks/) _for step-by-step how-to articles, and the_ [_Community Forum_](https://forum.enscape3d.com/) _to connect with fellow Enscape and Vectorworks users._

_. . ._

Enscape for Vectorworks is now available on macOS, providing you with another way to view your projects as high-quality visualizations.

Here, we take a look at how to get started and explore some of the key features that make visualizing projects easy and enjoyable with [Enscape for Mac](https://enscape3d.com/enscape-for-mac/?utm%5Fsource=Vectoworks&utm%5Fmedium=intro-to-Enscape-for-mac). 

#### HOW TO OPEN ENSCAPE IN VECTORWORKS FOR MAC

Enscape is a real-time rendering plugin that’s activated directly within Vectorworks. This means that after installation, you won’t find it among your other applications as it’s not a standalone piece of software. 

To enable Enscape when opening Vectorworks the first time after installing the plugin, start Vectorworks with any model of your choice or even an empty scene. Go to **Tools > Third-Party > Enscape > Add Enscape** to your workspace.

Now you should see the Enscape icon in your **Tool Sets** palette. Selecting it will open the **Enscape Tool Set**, containing various icons to access and control further parts of the plugin, but for now we want to start the render window first.

To start Enscape with any given project open, click the Enscape icon towards the top of the toolbar in Vectorworks. If you’re not in a 3D view, you might see a message asking you to select a 3D view to start Enscape. In that case, just select “Normal Perspective” in the **Viewport** settings to get going.

**![](https://lh5.googleusercontent.com/C7VoPkeP8XBPb-VlWbvgh4RLAg9N3hiTpfd1-0XK3i4T3HystrY_3_-VKnwTh4D1s_u7j0lDv5rBTPAwy8owZwQ5eGYYzDNjbS2elX-TUVdU2o34xA4RQjDgFsMR9muLksaKDTMFVg40mqrotP1IeI4)**

_After selecting the Enscape logo in Tool Sets, clicking the Enscape icon at the top of the tool bar will start Enscape._

#### Navigating in enscape

After starting Enscape, a separate window opens to show an accurate representation of your design. To move around and explore your project, you can either use the WASD or the arrow keys.   

* **Forwards**: Press W or the up arrow key
* **Backwards**: Press S or the down arrow key
* **Left**: Press A or the left arrow key
* **Right**: Press D or the right arrow key
* **Look around**: Left click, move the mouse while holding the left mouse button

To access the help menu which displays all of these controls and many more, click the question mark icon in the top right corner of the **Enscape** window. 

**![Enscape Help Menu](https://blog.vectorworks.net/hs-fs/hubfs/Enscape%20Help%20Menu.jpg?width=300&height=1029&name=Enscape%20Help%20Menu.jpg)**

#### Synchronized and saved views

As Enscape is a plugin that’s integrated directly into Vectorworks, it’s always possible to visualize your rendered project in real time. 

With the help of two features, **Synchronized Views** and **Saved Views**, you can quickly view your project as you design and prepare presentations.

By enabling **Synchronize Views**, as you navigate Vectorworks, Enscape will follow and show you the same view. This is ideal for quickly seeing how changes to the model will look and affect a project in reality.

**![A screenshot of a computer**
**Description automatically generated](https://blog.vectorworks.net/hs-fs/hubfs/undefined-3.jpeg?width=1440&height=900&name=undefined-3.jpeg)**

_The Snychronized Views icon._

With any **Saved Views** that you have set up in Vectorworks, these can also be visualized immediately in Enscape, which is particularly handy for when you need to present your ideas. 

In the Enscape window, click the button with the binocular icon in the toolbar at the top. This opens up **Enscape View Management**. Clicking any of these views will move the Enscape camera to the correct position and even update the time of day and visibility settings based on what has been set for that particular saved view. This helps to significantly speed up the amount of time it takes to prepare a presentation.  

#### 3D MODELS IN THE ENSCAPE ASSET LIBRARY

Below the **Enscape Renderer Tool Sets** button, you can find the **Asset Library**.

This button opens a window that gives you access to thousands of optimized, high-quality 3D models that you can place in your scene to quickly add detail for a lifelike presentation. 

To place assets, select one, left-click it twice, and then left-click twice in your Vectorworks scene where you’d like to place it. For easy navigation in the Enscape library, use the search function, categories, or tags to narrow down your search. 

Enscape Assets will be represented in your Vectorworks scene with a low-detail placeholder but will show up in high detail in the Enscape window. Furthermore, using the placeholders in your Vectorworks scene, you can move Enscape assets, rotate them, or hide the design layer they’re stored on.

![Enscape Asset Library Icon copy](https://blog.vectorworks.net/hs-fs/hubfs/Enscape%20Asset%20Library%20Icon%20copy.jpg?width=1440&height=901&name=Enscape%20Asset%20Library%20Icon%20copy.jpg)

_The Enscape Asset Library._

#### THE ENSCAPE MATERIAL EDITOR

Below the **Asset Library** button in the **Enscape Tool Set** is where you can find the **Enscape Material Editor**. This is one of the most important parts of the user interface.

This is where you can edit and enhance your existing Vectorworks materials (or textures, as they are referred to in Vectorworks) for improved realism.

If you want to create a new texture and apply it to a part of your design, you still do that in Vectorworks. Having the **Enscape Material Editor** open, you will find a list of all of the textures in Vectorworks. They will appear as materials in the **Enscape Material Editor**, and changing anything about them in one tool will also change it in the other.

![A computer screen shot of a room
Description automatically generated](https://blog.vectorworks.net/hs-fs/hubfs/undefined-Oct-13-2023-05-03-49-6478-PM.jpeg?width=1440&height=900&name=undefined-Oct-13-2023-05-03-49-6478-PM.jpeg)

_The Enscape Material Editor icon._

###### Editing Materials

When editing materials in Enscape, you can change the base attributes like color, roughness or reflections, metallic value, or transparency. However, it gets particularly interesting when you involve image files, called textures, to control some of these attributes. 

You can use the existing color textures you already have in Vectorworks. There are also plenty of online resources where you can download high-quality [free 3D textures](https://blog.enscape3d.com/free-rendering-textures?utm%5Fsource=Vectorworks&utm%5Fmedium=mac-post), such as ambientcg.com. 

Download a material (we recommend downloading it in 2K resolution). Once downloaded, open the folder you've received and save the image files on your Mac. Go back to the **Enscape Material Editor** to import the files.

#### EXPORTING ENSCAPE VISUALIZATIONS 

Currently in Enscape for Mac, it’s possible to export and share your scene as a still image rendering, a 360-degree panorama, or a web standalone file.

###### Still Image Renders

Before exporting a still image, you may first want to change the resolution. Go to **Visual Settings** (found in the top right corner of the Enscape window). The **Output** tab is where you can change the resolution and the image file format.

You may also wish to change the time of day (shift + right mouse button), and enable **Safe Frame**, so you can see exactly which parts of your scene will be rendered. When ready, click the Screenshot button which is located on the **Enscape toolbar** at the top left of the rendering window. Your image will be created in just a few seconds.

**![A room with a large window**
**Description automatically generated](https://blog.vectorworks.net/hs-fs/hubfs/undefined-Oct-13-2023-05-06-17-5446-PM.jpeg?width=1440&height=900&name=undefined-Oct-13-2023-05-06-17-5446-PM.jpeg)**

_Click the Screenshot button to render an image in seconds._

###### 360-Degree Panoramas

If you wish to export a panorama, select the **Mono Panorama** button, and Enscape will create a 360-degree panorama from your current position.

Once created, the panorama can be found in the **Upload Management** area in the **Enscape Tool Set** in Vectorworks. From here you can save the panorama as an image file, but you can also share it via the Vectorworks or Enscape clouds. 

This provides you with a shareable web browser link and a QR code, both of which provide immediate access to the panorama.

**![A room with a large window**
**Description automatically generated](https://blog.vectorworks.net/hs-fs/hubfs/undefined-Oct-13-2023-05-07-19-3867-PM.jpeg?width=1440&height=902&name=undefined-Oct-13-2023-05-07-19-3867-PM.jpeg)**

_Click the 360 button to render a panorama._

###### Web Standalone

By clicking the **Web Standalone** export button in the Enscape rendering window, you can export your entire project to the web. This allows anyone the ability to navigate and explore your project, even if they don’t have Enscape or your design software installed.

Once exported, you can find the standalone file in the Upload Management window, in the **Web Standalones** tab.

![A room with a large window
Description automatically generated](https://blog.vectorworks.net/hs-fs/hubfs/undefined-Oct-13-2023-05-08-04-1378-PM.jpeg?width=1440&height=900&name=undefined-Oct-13-2023-05-08-04-1378-PM.jpeg)

_Click the Web button to export a web-based version of your rendered project._

#### GET STARTED WITH ENSCAPE FOR MAC AND VECTORWORKS

If you’re new to Enscape, download a [free trial](https://enscape3d.com/enscape-for-mac/?utm%5Fsource=Vectorworks&utm%5Fmedium=intro-to-Enscape-for-mac) to see how it can help accelerate and improve various aspects of your design workflow. 

Existing customers can download the new Enscape for Mac for Vectorworks [here](https://enscape3d.com/download/?utm%5Fsource=Vectorworks&utm%5Fmedium=intro-to-Enscape-for-mac).

_\*All images courtesy of Enscape._

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.