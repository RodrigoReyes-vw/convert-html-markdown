[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# The Future Is Here: This Smart Street Actually Responds to the Needs of People

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 6 min read time 

![vw_blog_mcgregor-coxall](https://blog.vectorworks.net/hubfs/vw_blog_mcgregor-coxall.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fthe-future-is-here-this-smart-street-actually-responds-to-the-needs-of-people)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=The%20Future%20Is%20Here:%20This%20Smart%20Street%20Actually%20Responds%20to%20the%20Needs%20of%20People&url=https%3A%2F%2Fblog.vectorworks.net%2Fthe-future-is-here-this-smart-street-actually-responds-to-the-needs-of-people&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fthe-future-is-here-this-smart-street-actually-responds-to-the-needs-of-people)

Some Vectorworks users have been with us since their company’s beginnings. [McGregor Coxall](https://mcgregorcoxall.com) is a design firm with offices in the U.K., Australia, and China that’s committed to developing sustainable city designs — they’ve been transforming city landscapes into more friendly, cosmopolitan spaces since 1998\. And they’ve been using Vectorworks the entire time.

For the [Smart Design for a Smart Future](https://mcgregorcoxall.com/news-detail/282) project, McGregor Coxall was tasked with somehow modernizing landscapes to meet the needs of an evolving citizenry. Michael Cowdy, a Director and Urbanism Leader with McGregor Coxall, discussed how the City of London has two modes: it’s either a commuter central or a ghost town. This is particularly true of western Cheapside near St. Paul’s Cathedral, a heavy tourist destination.

During the day, people move in and out of the city in droves; outside of work hours, though, it’s easy to notice a dwindling population. The population can increase up to 5,000 percent during peak times each day, which takes a huge toll on the city’s infrastructure, according to Cowdy.

“So, the question we posed is: how can we rethink the street infrastructure and make it more responsive to the changing demands of a day, focused around the needs of people?” Cowdy said.

Technology is a core piece to the McGregor Coxall puzzle, and to ensure every detail was in its proper place, the London cityscape was designed with what Cowdy described as an “intelligent street system.” They call it “Smart Carpet,” and it’s a way to rethink the street of tomorrow with modular furniture, LED paving, kinetic energy generation, interlock-able furniture and more. The result is an interactive and engaging environment that can be easily redesigned for the needs of the public. In their proposal, McGregor Coxall noted that the furniture can be “endlessly configured for events, dining, meeting spaces, work hubs and play spaces.”

![mcgregorcoxall1](https://blog.vectorworks.net/hs-fs/hubfs/McGregor%20Coxall/mcgregorcoxall1.jpg?width=530&name=mcgregorcoxall1.jpg)_LED paving and kinetic energy redistribution combine to make for a street that can alter itself._ 
_Image courtesy of McGregor Coxall._

Furthermore, the Smart Carpet design implements sensory recognition analysis to collect traffic and pedestrian data in real time. Almost eerily, the city itself would know when pedestrian traffic peaks and when the roads are used more for commuters.

“We created a 21st century street that was able to change from a commuter road at, let’s say, 7:00 a.m., to a sports recreational space at lunch time, into a social interactive place in the evening, and then a cultural activation place at night,” Cowdy said. “It was trying to shift smart cities from being a technology-driven perspective to a more engaging, people-focused algorithm that uses technology as a tool to inform better decision making. That’s how we framed it all.”

![mcgregorcoxall2](https://blog.vectorworks.net/hs-fs/hubfs/McGregor%20Coxall/mcgregorcoxall2.jpg?width=530&name=mcgregorcoxall2.jpg)_Modular furniture can be rearranged according to needs of the public. Image courtesy of McGregor Coxall._

Vectorworks is critical to the McGregor Coxall design process. One of the advantages offered by Vectorworks, according to Cowdy, is the ability to convert their work into 3D models early on in the design process. “We always want to translate our work very quickly into 3D so we can actually visibly see the perspective, the dimensions, the composition of the actual site we’re working on,” he said. “Especially with landscape architecture, Vectorworks has been a very important tool for us. The sketch design — which essentially would be like your concept drawing — is all done in Vectorworks. When you move to the next stage, the layers and classes are instantly transformed into the design documentation and illustrative style that’s needed.”

Additionally, there's a feature in Vectorworks that allows the user to attach price tags to materials. From very early on, this helped the team predict what it would cost to implement their project. It's features like this that drew the firm to Vectorworks — along with material costs, having one program that works from schematic design all the way to construction eliminated the need to work back-and-forth with other softwares, increasing their overall efficiency. 

Through workshops in London, constant emails and Skype calls, the McGregor Coxall team maintained a smoothly operated project despite being spread over four offices and three continents. “I think it’s a no-brainer that Vectorworks is clearly improving the speed and flow of the practice,” Cowdy said. “It’s been the backbone of the business for 20 years, so we’re happy. We’re now using Vectorworks across the four studios — it’s integrated now, so that’s been important as a process.” He noted that McGregor Coxall applied Vectorworks to each new studio from the start.

Of course, as Vectorworks evolves over time, the designers at McGregor Coxall evolve with it. Since there’s a new version of Vectorworks every year, McGregor Coxall found a hearty challenge in keeping everyone on the same page. “Vectorworks is progressing,” Cowdy said, “and we’re growing a business which has transformed from when I joined. There were 14 of us. Now, there are 52 of us.”

That’s why they invested in employing a Vectorworks specialist for a six-week training course. “We need to get better at using it to make sure we’re maximizing its capability,” Cowdy said. “It’s just making sure that the team operates and moves the same speed as Vectorworks to get the best out of it.”

In light of the challenge, McGregor Coxall’s Smart Carpet design presents a futuristic counter to the population shift London experiences on a daily basis. The smart and engaging design creates a street that learns from itself — it’s no wonder they called it “smart.”  
[![Check Out Vectorworks Landmark](https://no-cache.hubspot.com/cta/default/3018241/434295b6-9748-436a-8adf-d667cfd590b1.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/434295b6-9748-436a-8adf-d667cfd590b1) 

 Topics: [Landscapes](https://blog.vectorworks.net/topic/landscapes) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.