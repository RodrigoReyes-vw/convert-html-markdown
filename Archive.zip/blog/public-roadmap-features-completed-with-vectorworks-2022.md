[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Public Roadmap Features Completed with Vectorworks 2022

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/2022_Launch/2108-vss-whats-new-seminar-hs-lp-mobile-750x428.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fpublic-roadmap-features-completed-with-vectorworks-2022)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Public%20Roadmap%20Features%20Completed%20with%20Vectorworks%202022&url=https%3A%2F%2Fblog.vectorworks.net%2Fpublic-roadmap-features-completed-with-vectorworks-2022&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fpublic-roadmap-features-completed-with-vectorworks-2022)

Ahead of the [2021 virtual Design Summit](../../../net/vectorworks/blog/all-about-the-2021-vectorworks-design-summit.html), we’re excited to share an update on our development roadmap!

We first shared the [roadmap](https://www.vectorworks.net/public-roadmap) almost a year ago. The intention was transparency into our development priorities as well as creating a new way to engage with the Vectorworks community on what matters most to them in future developments.

It’s exciting to take a step back and see how much has been accomplished in such a short time.

Vectorworks 2022 checked some significant boxes. These include support for Apple silicon processors, a direct link to [Twinmotion](http://unrealengine.com/twinmotion), a graphics modernization initiative, and much more!

Largely, new features and improvements center around the new tagline, Design Without Limits™. It’s all about enabling design freedom and encouraging creative ideas rather than getting in their way.

The rest of this blog will explore some of the flagship developments in version 2022\. For a list of improvements and new features, check out the public roadmap:

[![What's new in 2022?](https://no-cache.hubspot.com/cta/default/3018241/b784a025-0578-42fa-af72-0c4c4c8b4425.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/b784a025-0578-42fa-af72-0c4c4c8b4425) 

## Next-Gen Tech

Focused development in core technologies and interfaces makes the software faster and more intuitive while providing the stability and accuracy required for maximum efficiency.

Vectorworks is the first major BIM application to run natively on Apple silicon processors. Testing of Vectorworks 2022 has shown speed increases of two to four times.

Other improvements in next-gen tech include:

* Full use of Metal on Mac and DirectX on Windows in the Vectorworks Graphics Module.
* A new Redshift render mode powered by [Redshift by Maxon](http://maxon.net/redshift).
* A new direct link to [Twinmotion](http://unrealengine.com/twinmotion).
* A redesign of the attribute and snapping palettes and new per-face texture mapping, which support an intuitive process for creating and visualizing designs.

## 3D & BIM Workflows

Vectorworks 2022 offers improvements to 3D and BIM workflows for greater precision, control, and accuracy of visual models and their corresponding data.

* Updates to the worksheet database and Data Manager provide a consistent interface, better visual cues, a new search mode, and an improved formula bar with a new set of functions to help make generating targeted reports, schedules, and material take offs easy.
* Improvements to the stair tool for direct editing and modifying help simplify the process of [designing complex objects](../../../net/vectorworks/blog/the-best-3d-modeling-for-interior-architecture.html).
* Re-engineering and modernization of core architectural objects like wall components and data reporting support the creation of accurate BIM models.

![2022-signature-image--arch-original](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210915_Launch/2022-signature-image--arch-original.jpg?width=1440&name=2022-signature-image--arch-original.jpg)

Asian Institute of Chartered Bankers | Courtesy of [GDP Architects](https://www.gdparchitects.com/) and photographer Adaptus Design Systems SDN BHD 

## Interoperability

Vectorworks takes pride in being a design hub and continues to invest in optimizing the most-used file formats, supporting value-added partner products, and ensuring that project teams and BIM collaboration remain unrivaled.

* Version 2022 includes improvements to the DWG file import to support Civil3D, as well as DWG and GIS georeferencing.
* IFC import/export capabilities are enhanced for improved quantity takeoffs and GIS workflows.

## Landscape & GIS

As the [BIM platform of choice for landscape architecture](../../../net/vectorworks/blog/why-bim-is-taking-over-landscape-architecture.html), Vectorworks Landmark 2022 delivers more options for accurate modeling reflective of real-life design considerations.

* Improvements to the site model make it easier to define and report on soil layers.
* Updates to the Plant tool, hardscape objects, and integrations with Esri make it easier to produce landscape BIM models that leverage GIS workflows while meeting the demand to create sustainable sites.

![2022-signature-image-land-original](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210915_Launch/2022-signature-image-land-original.png?width=1440&name=2022-signature-image-land-original.png)

Vancouver Convention Center Expansion | Courtesy of [PWP Landscape Architects Inc.](http://www.pwpla.com/)

## Entertainment

Our commitment to users in the entertainment industry is to invest first and foremost in re-engineering to better file performance and to provide highly responsive tools.

* Versions 2022 of Vectorworks Spotlight, Braceworks, ConnectCAD, and Vision have greater consistency between tools as well as functionality focused on simplifying processes like cable and power planning.
* This latest release also delivers many usability enhancements such as better controls on the camera tool, a position name field for truss, and context menus for shifting data.
* Improved placement and direct editing of objects in Schematic Views makes day-to-day documentation in Vectorworks Spotlight faster and more intuitive.

![2022-signature-image-ent-original](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210915_Launch/2022-signature-image-ent-original.jpg?width=1440&name=2022-signature-image-ent-original.jpg)

One Third Beijing | Courtesy of [Live Legends](https://www.livelegends.com/) 

Learn more about how you can get started with Vectorworks 2022 [here](http://vectorworks.net/2022).

Now that version 2022 is out the door, we’re looking ahead and adding more to the roadmap. We’ll update it regularly throughout the year, so check it out often and share your feedback in the comment section within each feature.

[![Show me the development roadmap](https://no-cache.hubspot.com/cta/default/3018241/1f23f5c6-80f8-4c57-8407-5fe18939dca6.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/1f23f5c6-80f8-4c57-8407-5fe18939dca6) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.