[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Learn About River Island’s Use of AI in Retail Stores

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/230829_INT%20River%20Island/20230505_DrawCreative_RiverStudio_TraffordCentre_485.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fsee-how-river-island-are-designing-retail-spaces-for-the-future)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Learn%20About%20River%20Island’s%20Use%20of%20AI%20in%20Retail%20Stores&url=https%3A%2F%2Fblog.vectorworks.net%2Fsee-how-river-island-are-designing-retail-spaces-for-the-future&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fsee-how-river-island-are-designing-retail-spaces-for-the-future)

Online shopping is at an all-time high, so how do you offer your customers the convenience they’ve come to expect in a retail space?

The answer is balance.

The folks at [River Island, a storied fashion brand that offers elevated looks for men, women, and children, in addition to a wide variety of beauty products](https://www.riverisland.com/), are working hard to achieve such balance.

#### Innovative Technologies, Improved Customer Experience

River Island’s first shop location was on the historic Kings Road in London; but now, River Island serves up trending clothing items across over 250 locations in the UK.

In addition to trending fashions, River Island has its hand in trending technologies.

River Island’s solution to creating exciting in-person shopping experiences comes in the form of new River Studios concept stores.

One of the most interesting aspects of the new stores, [according to a blog from the brand](https://www.riverisland.com/editorial/welcome-to-river-island), are smart fitting rooms and in-store self checkout. With carefully placed touch screens, customers can get different styles or assistance from in-store stylists. Then, once a shopper has found what they want, they can check out easier than ever before.

![River Island Changing Room](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230829_INT%20River%20Island/River%20Island%20Changing%20Room.png?width=1440&height=1207&name=River%20Island%20Changing%20Room.png)

Additionally, there’s the exciting innovation of “Chloe,” an AI styling system that’s currently available in limited stores. With Chloe, clothing found in River Studios will feature washable tags that will register through the mounted touch screens throughout the retail space and changing rooms, helping shoppers find more of what they love.

Simply put, the Chloe AI system creates a faster way for customers to find the exact pieces of clothing they’re looking for.

This technology, blended with the advantages of in-person shopping — being able to try on clothes, seeing fabrics in person, and participating in a curated space — will create a new feel for the brand’s retail locations.

Creating the Retail Spaces of the Future with Vectorworks Architect

Technology-focused storefronts for the River Island brand will be designed by an in-house design team using [Vectorworks Architect](https://www.vectorworks.net/architect). The team, and designer Hannah Boulter, have long leaned on Vectorworks Architect to aid in their design work for River Island, mainly using 2D drawings to plan out new stores and renovations to existing stores, in addition to adding the Chole system and changing room touch screens.

![Screen Shot 2023-08-29 at 3.27.23 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230829_INT%20River%20Island/Screen%20Shot%202023-08-29%20at%203.27.23%20PM.png?width=1440&height=1021&name=Screen%20Shot%202023-08-29%20at%203.27.23%20PM.png)

But as the company pushes to improve its retail offerings, she’s also looking to improve how she uses the software. To do so, Boulter sought the assistance of Vectorworks Senior Industry Specialist — Interiors, Kesoon Chance, to help the brand learn how to use Vectorworks' data-centric features for a more automated design process.

With features like [custom record formats](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Database/Record%20format%5Fdatabase%5Fconnection.htm?rhhlterm=custom%20record%20records&rhsearch=custom%20records), [data tags](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Annotation2/Adding%5Fdata%5Ftags%5Fand%5Flabels.htm?rhsearch=data%20tags&rhhlterm=data%20tags%20tag%20tagging%20tagged), and [reports](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/RecordsSchedules/Creating%20reports.htm?rhhlterm=reports%20report&rhsearch=reports), Boulter is learning to streamline how she designs in Vectorworks, just like how River Island is improving the shopping experience for their customers.

“Kesoon and I went over things like our merchandise fixtures around the store,” said Boulter, “and each fixture has a typical number of arms. Before, we’d send the design to our manufacturer, and they’d go around and have to count all the fixtures by hand. There’s so much room for human error.”

![Screen Shot 2023-08-29 at 3.27.49 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230829_INT%20River%20Island/Screen%20Shot%202023-08-29%20at%203.27.49%20PM.png?width=1440&height=1018&name=Screen%20Shot%202023-08-29%20at%203.27.49%20PM.png)

Now, Boulter and her River Island team have a formula that quickly calculates the number of arms for each merchandise fixture and automatically tabulates them into a table to share with manufacturers.

[To learn more about how to use data management features in Vectorworks Architect, click here](../../../net/vectorworks/blog/data-driven-modeling-interiors.html).

_\*Images courtesy of River Island._

#### Learn More About Designing Influential Retail Spaces

Inspired by River Island and want to design your own modern retail spaces?

Look no further than this webinar, “Data-Driven 3D Modeling for Interiors.”

![Tutorial Series_Data_INT](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220922_October%20Tutorial%20Series%20Data%20Driven/Tutorial%20Series_Data_INT.png?width=1440&height=800&name=Tutorial%20Series_Data_INT.png)

In this presentation — inspired by an elegant retail interiors project located in Tokyo by designers Mana & Takashi Kobayashi, IMA Inc. — Luis M. Ruiz, interior associate AIA, discusses how you can increase your efficiency and win more work with an integrated data-driven 3D modeling process.

Your workflow is no longer just about providing 2D drawings and details; great visualizations and smart take-offs can all be a part of your design process. BIM for interiors is a more thoughtful way to design, organize, and face today’s challenges in the industry. 

Click the button below to watch the webinar for free:

[![DATA-DRIVEN RETAIL SPACES WITH VECTORWORKS](https://no-cache.hubspot.com/cta/default/3018241/7341108a-1079-40bb-89f7-5382cae507ea.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/7341108a-1079-40bb-89f7-5382cae507ea) 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.