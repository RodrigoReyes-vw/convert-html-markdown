[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Inside Vectorworks: Gaining Insight from Data Analytics

 Posted by [Chloe Jefferson](https://blog.vectorworks.net/author/chloe-jefferson) | 2 min read time 

![Keyboard_Blog_Email_Weekly_Bottom_Image](https://blog.vectorworks.net/hubfs/Keyboard_Blog_Email_Weekly_Bottom_Image.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Finside-vectorworks-gaining-insight-from-data-analytics)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Inside%20Vectorworks:%20Gaining%20Insight%20from%20Data%20Analytics&url=https%3A%2F%2Fblog.vectorworks.net%2Finside-vectorworks-gaining-insight-from-data-analytics&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Finside-vectorworks-gaining-insight-from-data-analytics)

At [Vectorworks](http://www.vectorworks.net/?utm%5Fcampaign=blog&tum%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=keyboardshortcuts02052018), our engineers use several sources to help develop new features, such as user requests on the community board, distributor recommendations, and competitive analysis. Another beneficial tool they rely on to decide what new features to produce is data analytics.

With data analytics, there are no definite answers. Our data engineers have to look at the data with an open mind in order to find something they didn’t expect to see.

![Screen Shot 2018-01-24 at 1.19.32 PM.png](https://blog.vectorworks.net/hs-fs/hubfs/Screen%20Shot%202018-01-24%20at%201.19.32%20PM.png?width=259&name=Screen%20Shot%202018-01-24%20at%201.19.32%20PM.png "Screen Shot 2018-01-24 at 1.19.32 PM.png")

_Big-Data Engineer Chen Zheng_

One of our big-data engineers is Chen Zheng, who has been working at Vectorworks since 2015\. Her day-to-day responsibilities include helping the other engineers decipher data analytics and user logs, allowing them to make insightful decisions about improvements to the software. Data like this is particularly useful in helping the team create keyboard shortcuts for Vectorworks, because it can provide a snapshot of which commands and tools designers use the most. 

For example, for the recent feature, the engineers wanted to create an easy shortcut so users could quickly toggle between single view and multi-view settings. By analyzing data captured through the software, they discovered which default keys users prefer and tracked how many users favor customized keys. This data helped them choose which keyboard shortcut would benefit users the most.

![Screen Shot 2018-01-24 at 1.17.04 PM.png](https://blog.vectorworks.net/hs-fs/hubfs/Screen%20Shot%202018-01-24%20at%201.17.04%20PM.png?width=525&name=Screen%20Shot%202018-01-24%20at%201.17.04%20PM.png "Screen Shot 2018-01-24 at 1.17.04 PM.png")

_Key usage metrics used to determine the ‘M’ key as the shortcut for multiple drawing views_ 

Zheng says her job is interesting because she makes important assessments that make our systems better and better, and it’s all based on feedback from our users. The metric reports show which tools and keys users choose to utilize the most, allowing her and her team to easily make tweaks and adjustments. “It’s interesting to see how users have different preferences,” Zheng said.

If you have certain preferences or wish list items that you would like to share with our big-data engineers, please share them through the Vectorworks Community Board.

[![Share Your Requests](https://no-cache.hubspot.com/cta/default/3018241/c4f5ebc6-9321-4c8b-be3a-d8e37906dfb0.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/c4f5ebc6-9321-4c8b-be3a-d8e37906dfb0) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.