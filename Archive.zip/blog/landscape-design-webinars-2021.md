[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Site Design Webinars You May Have Missed

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 8 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/210827_September%20Webinar/RISE_Cover_Image.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Flandscape-design-webinars-2021)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Site%20Design%20Webinars%20You%20May%20Have%20Missed&url=https%3A%2F%2Fblog.vectorworks.net%2Flandscape-design-webinars-2021&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Flandscape-design-webinars-2021)

When you look back on the past 12 months, what are you thankful for? What are you proud of? At Vectorworks, we’re proud of the learning opportunities we provided to the [architecture](../../../net/vectorworks/blog/architecture-webinars-2021.html), site, and [entertainment](../../../net/vectorworks/blog/entertainment-design-webinars-2021.html) design industries.

Many of these courses are also approved for continuing education credits, making them a great way to meet any requirements you might have by the end of the year! 

Without further ado, let’s take a look back at 2021’s site design webinars.

###### 3D Modeling for Landscape Analysis

Learn how to leverage the power of solar, terrain, building, and landscape object modeling to better analyze site conditions, advise clients, and validate design choices. In this webinar with Principal and Landscape Designer Danilo Maffei, attendees will explore site modeling, the Heliodon tool, and saved views to create useful and compelling reports and exhibits—both for internal use and presentations to clients.

This course is approved for one LA CES HSW PDH and one APLD CEU.

![blog-images-resize-jan-land-webinar](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210113_JanuaryWebinars/blog-images-resize-jan-land-webinar.jpg?width=1440&name=blog-images-resize-jan-land-webinar.jpg)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/94c54b65-d377-4797-8525-3e11cb612c63.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/94c54b65-d377-4797-8525-3e11cb612c63) 

###### When It Has To Be BIM

Watch Todd McCurdy, FASLA, and explore a project in which BIM software was used throughout the design process. Todd will share how crucial IFC exchanges are when each participant is using a different BIM solution, and how easily these files can be shared among team members to guide design direction with project stakeholders.

This course is approved for one LA CES PDH and one APLD CEU.

![December Webinar LND Image](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211208_December%20Webinar/December%20Webinar%20LND%20Image.jpg?width=1440&name=December%20Webinar%20LND%20Image.jpg)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/a5e52471-9469-4100-98e4-ffa0cfc54dcb.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/a5e52471-9469-4100-98e4-ffa0cfc54dcb) 

###### Strategies for Adopting BIM in Landscape Architecture

Landscape architecture firms considering the move from traditional CAD workflows to BIM face a similar dilemma as they did years ago in transitioning to CAD from hand drawing. This presentation will share strategies for your organization to consider when developing a transition plan for BIM implementation. From assessing your firm’s current use of design and modeling software, to meeting BIM collaboration requirements and identifying where support is most needed, we provide a series of questions to ask yourself as you carry out this assessment and determine how to make office-wide changes for BIM integration.

This course is approved for one LA CES PDH and one APLD CEU. 

![LAND NOW](https://blog.vectorworks.net/hs-fs/hubfs/LAND%20NOW.jpg?width=1440&name=LAND%20NOW.jpg)

[![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/2549c820-9065-4167-ae02-0de3166a2ce9.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/2549c820-9065-4167-ae02-0de3166a2ce9) 

###### Productive Remote Work Through BIM for Landscape

At a time when more site design firms are working remotely, keeping separated team members productive is not only possible, it’s more easily managed than ever before. Eric Gilbey, PLA as will share how a multi-user environment is a key benefit to working in BIM software. Gilbey will explore how it enables a more holistic approach to project management, and how proper file and team organization enables more seamless incorporation of site project updates.

This course is approved for one LA CES PDH and one APLD CEU.

![2104-us-april-webinar-blog-images-land](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210408_April%20Webinars/2104-us-april-webinar-blog-images-land.jpg?width=1440&name=2104-us-april-webinar-blog-images-land.jpg)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/46d896ed-50a4-42b5-8d5a-f19f3e83b18f.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/46d896ed-50a4-42b5-8d5a-f19f3e83b18f) 

###### The World According to BIM

Everyone is talking about BIM – big BIM, small BIM, BIM level 2\. But what should you think of before you start on your BIM journey? By making sure your project is in order, with the right structure and 

knowledge, you can make the transition into the World of BIM a whole lot easier. This webinar is focusing on the resources and structure you will be grateful to have in place when you approach your first BIM Execution Plan – it will show you how and why you should have templates prepared, how to work with libraries of resources, and how to ensure that you use all of Vectorworks’ tools when it comes to placing your project in the real world with help of GIS.

This course is approved for one LA CES PDH and one APLD CEU.

![20-2007-us-webinar-land-september-rise-cover-image-1680x1120](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210609_June%20Webinars/20-2007-us-webinar-land-september-rise-cover-image-1680x1120.jpeg?width=1440&name=20-2007-us-webinar-land-september-rise-cover-image-1680x1120.jpeg)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/6823073d-8e0f-4622-a40f-dc02c9612575.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/6823073d-8e0f-4622-a40f-dc02c9612575) 

###### Collaborative Design Tools for Landscape Architects

A landscape architects’ workflow is more multi-disciplinary now than ever before. Renta Urban Land Design’s Stephen Schrader, PLA, ASLA, GRP, will walk you through a multi-family development project in North Georgia. Learn how to set up drawings, integrate architectural and civil plans, utilize smart objects to capture project data and enhance presentations, make use of worksheets to report project data, and learn best practices for sharing data with the appropriate design teams to maximize efficiencies.

This course is approved for one LA CES PDH and one APLD CEU.

![20-2006-webinar-land-august-copy-design-sm-rise-cover-image](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210707_July%20Webinar/20-2006-webinar-land-august-copy-design-sm-rise-cover-image.jpg?width=1440&name=20-2006-webinar-land-august-copy-design-sm-rise-cover-image.jpg)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/5b85a527-6599-46af-b9bf-b9a1ccb43e44.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/5b85a527-6599-46af-b9bf-b9a1ccb43e44) 

###### Landscape Design Technology for Water Efficient Landscapes 

Designing landscapes with sustainability in mind is no longer a matter of preference but one of meeting jurisdictional requirements. Site designers are increasingly leaning on design software and online resources to make their current design workflows easier, and also to help meet the new obligations in water-efficient site design. By incorporating the water needs of proposed plants, designing hydrozones for irrigation and calculating water budgets, design applications help you to plan for beautiful landscapes that maximize water efficiency.

This course is approved for one LA CES HSW PDH and one APLD CEU.

![blog-1440x800-5](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210729_August%20Webinar/blog-1440x800-5.png?width=1440&name=blog-1440x800-5.png)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/4232d73e-3b0d-4aeb-a7f0-05052c0bbc78.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/4232d73e-3b0d-4aeb-a7f0-05052c0bbc78) 

###### Enhance Collaboration with Georeferencing

No matter who’s involved in your file exchange, it’s crucial to maintain accurate project file position and origin. This is essential for efficient design and documentation workflows — and the integrity of project delivery. This presentation will review best practice workflows using georeferencing within the file organization to integrate other CAD, BIM, and GIS files.

This course is approved for one LA CES PDH and one APLD CEU.

![RISE_Cover_Image](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210827_September%20Webinar/RISE_Cover_Image.jpg?width=1440&name=RISE_Cover_Image.jpg)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/0bb0ef59-2335-4696-a3ee-bbe76ab00c0c.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/0bb0ef59-2335-4696-a3ee-bbe76ab00c0c) 

###### Dynamic Efficiency for Design Build

If you’re designing and building with a team, dynamic collaboration and workflow efficiency are vital to the success of the project. In this webinar, you’ll explore how to achieve dynamic efficiency from concept to field. Using real-world projects and examples from their team on the ground in Colorado, Cheri Stringer of 10x award-winning TLC Gardens Design Build Firm will walk you through integrating graphics, applying detail, and utilizing sheet sets for construction implementation. Together we’ll tackle best practices for creating a project portfolio and analyze strategies for effective team execution with Vectorworks sheet sets, graphics, and 3D model visualizations.

![5453-2104-us-may-land-webinar-dynamic-efficiency-rise-cover-image-1680x1120](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210506_May%20Webinars/5453-2104-us-may-land-webinar-dynamic-efficiency-rise-cover-image-1680x1120.png?width=1440&name=5453-2104-us-may-land-webinar-dynamic-efficiency-rise-cover-image-1680x1120.png)

###### [![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/0add34be-8d59-46b8-bf22-91c13fa27b7c.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/0add34be-8d59-46b8-bf22-91c13fa27b7c) 

###### Maximizing Landscape Design-Build Efficiency with Technology 

During the Great Recession, landscape architect and owner of a mid-size design-build company Joe Hanauer decided to “tech up.” His goal then was to be a one-person design-build office. Now, with labor markets tight, using technology to create efficiencies for installation crews is increasingly important. 

With hardware including a tablet, computer, GPS Surveyor, altimeter level and camera, combined with software for note taking, estimating and designing this session will reveal how they are all essential to creating an efficient workflow from first call to last shovel. This session will also show how this “almost-paper-free” technology workflow can be used to run a one-person office and scaled to work with larger firms, too.

This course is approved for one LA CES and one APLD CEU.

![November Web 3](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211111_November%20Webinars/November%20Web%203.png?width=1440&name=November%20Web%203.png)

[![WATCH ON DEMAND](https://no-cache.hubspot.com/cta/default/3018241/d190ccb5-3d00-47bb-9ba0-105fab4b9ad1.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/d190ccb5-3d00-47bb-9ba0-105fab4b9ad1) 

With 2022 right around the corner, be sure to stay tuned-in to [Vectorworks University](https://university.vectorworks.net/) for a variety of webinars that’ll help you grow as a designer.

 Topics: [Resources](https://blog.vectorworks.net/topic/resources) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.