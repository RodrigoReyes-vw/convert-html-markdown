[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Boost Your Skills with Free Training Opportunities

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 2 min read time 

![](https://blog.vectorworks.net/hubfs/vw-blog-training.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fboost-your-skills-with-free-training-opportunities)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Boost%20Your%20Skills%20with%20Free%20Training%20Opportunities&url=https%3A%2F%2Fblog.vectorworks.net%2Fboost-your-skills-with-free-training-opportunities&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fboost-your-skills-with-free-training-opportunities)

As we await the return to normal work life, there are still plenty of ways to keep your skills sharp. And what better way than free courses?

![vw-blog-training](https://blog.vectorworks.net/hs-fs/hubfs/vw-blog-training.jpg?width=1440&name=vw-blog-training.jpg)

We offer a variety of industry-specific training. They include:

* [Getting Started Seminars](../../../net/vectorworks/blog/index.html)
* [Essentials Seminars](../../../net/vectorworks/blog/index.html)
* [Hidden Treasures Seminars](../../../net/vectorworks/blog/index.html)
* [Workflow Seminars](../../../net/vectorworks/blog/index.html)

This post will cover what’s happening in the month of June, so be sure to save the link to stay up to date on all future offerings.

[![SEE ALL TRAININGS](https://no-cache.hubspot.com/cta/default/3018241/a72fc011-a2e6-4499-bfbd-0e78db2d45b3.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/a72fc011-a2e6-4499-bfbd-0e78db2d45b3) 

## Getting Started Seminars

_All industries - June 16 & 23, 2020_

Our Getting Started seminars are designed for those who are new to [Vectorworks](https://www.vectorworks.net/en-US?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=061520freetraining) software. The presenters will explore important topics like the user interface, common tools and commands, and getting the most out of the hybrid 2D/3D environment.

Attendees will come away feeling more confident about their journey with Vectorworks.

## Essentials Seminars

Essentials courses are for those who have a familiarity with the software but are looking to take it to the next level. 

You’ll learn about common workflows in your industry as well as information needed to be successful in using the software. Topics include importing files, file setup and organization, efficient drawing techniques, and presentation capabilities. 

Here’s the schedule through the end of June. All Essentials sessions occur at 1 p.m. ET.

* Spotlight Essentials - June 16
* Vision Essentials - June 18
* Architect Essentials - June 24
* Braceworks Essentials - June 25
* Landmark Essentials - June 30

## Hidden Treasures Seminars

Hidden Treasures Seminars are all about uncovering hidden gems — those lesser-known capabilities that can substantially improve the way you work. 

This month, we have a Hidden Treasures session happening on the 18th. 

## Workflow Seminars

Workflow seminars take specific Vectorworks capabilities and deconstruct them down to their basics. These sessions are good for those who desire mastery of a particular tool, concept, or workflow. 

Here are the June topics. These brand new sessions are hosted by Vectorworks UK training staff and occur at 8 a.m. ET.

* [Reflected Ceiling Plans](https://www.eventbrite.com/e/vectorworks-essentials-seminar-reflected-ceiling-plans-free-for-a-limited-time-tickets-104564832228) \- June 23
* [Patching Lighting Fixtures](https://www.eventbrite.com/e/vectorworks-essentials-seminar-patching-lighting-fixtures-free-for-a-limited-time-tickets-104565395914) \- June 24

Trainings will be free through the end of June — don’t miss out!

Visit our social media channels (@Vectorworks) to stay up to date with what training we’ll be offering through the rest of the year.

 Topics: [COVID-19](https://blog.vectorworks.net/topic/covid-19) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.