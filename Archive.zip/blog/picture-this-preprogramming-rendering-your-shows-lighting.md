[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# What Can Vision Previz Do for You? 5 Tips for Beginners

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/230328_Tech%20Tips%20for%20Vision/blog-1440x800_Vision-2.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fpicture-this-preprogramming-rendering-your-shows-lighting)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=What%20Can%20Vision%20Previz%20Do%20for%20You?%205%20Tips%20for%20Beginners&url=https%3A%2F%2Fblog.vectorworks.net%2Fpicture-this-preprogramming-rendering-your-shows-lighting&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fpicture-this-preprogramming-rendering-your-shows-lighting)

You have a special eye for creating incredible experiences.

You can share your ideas with clients, builders, consultants, and collaborators using 2D drawings and line plot diagrams. But did you know you can show off the full breadth of your designs with [Vision](https://www.vectorworks.net/vision), the previz and programming option for Vectorworks Spotlight?

To visualize your designs like never before, we recommend these five tips:

1. Use the Software Console feature when working with several conventional fixtures
2. Configure Vision to save time
3. Customize views for a personal fit
4. Manage your media with the Assign Video command and NDI
5. Leverage GDTF/MVR for a streamlined process

#### 1\. Use the Software Console Feature When Working with Several Conventional Fixtures

The greatest advantage to using Vision is the ability to pre-program your show before getting to the show site.

You can interface lighting consoles such as Artnet, sACN, MA-net, and Multi-input inside of the software. Just patch your console, set its output protocol, and then select Vision’s “DMX Provider.”

If there’s an error in the design process or the import of your model, such as light being oriented incorrectly, Vision provides you with a range of tools to update your design quickly and easily.

And, if you have a large number of conventional fixtures in your design, you can use the **Software Console** feature that allows the adjustment of gobo, iris, focus, and shutters, helping you to finetune these instruments in Vision before having to begin on the larger task of moving light devices.

![Software Console Combined](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230328_Tech%20Tips%20for%20Vision/Software%20Console%20Combined.png?width=1440&height=810&name=Software%20Console%20Combined.png)

If the conventional lighting devices are being imported from Vectorworks, some parameters, such as shutters and barn doors, are already set.

#### 2\. Configure Vision to Save Time

If a production schedule is weighing on you, or a show day is fast approaching, you can tailor Vision to fit your needs. For example, the **Performance/Quality** **slider** adapts to your needs and lets you still render under a time crunch.

![Performance Slider](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230328_Tech%20Tips%20for%20Vision/Performance%20Slider.png?width=500&height=557&name=Performance%20Slider.png) 

You can further adjust your Vision preferences with **Basic** **Mode** and **Advanced Mode**. With the former, you can customize simple preferences like resolution quality and even interactive options like the **Display Grid**.

Use **Advanced Mode** to adjust rendering quality, environmental detail, and even haze.

#### 3\. Customize Views for a Personal Fit

How about another tip on customizing Vision to save time 😎?

In addition to configuring the performance of Vision to meet your needs, you can adjust your views. You can turn tool sets on and off, for example, to create space when needed or make sure that your most used tools are only a click away.

You can also enable Multiview inside of Vision. With this, your screen will be split into four different views, letting you simultaneously view your project from different perspectives.

![Multiview 1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230328_Tech%20Tips%20for%20Vision/Multiview%201.png?width=1440&height=827&name=Multiview%201.png)

#### 4\. Manage Your Media with the Assign Video Command and NDI

Outside video and laser content can take your project to the next level.

You can sync this kind of content to your Vision file by setting up any 3D object in [Spotlight](https://www.vectorworks.net/vision) as a media playback screen and using the **Assign Video** command in Vision.

You can allow a live preview output of your programming by using an NDI stream, a royalty-free video over IP transmission.

For example, in Vectorworks you could model a 3D object to resemble your upstage video wall and assign it a video input under the **Spotlight > Visualization** menu.

![Vision Video Source Combined](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230328_Tech%20Tips%20for%20Vision/Vision%20Video%20Source%20Combined.png?width=1440&height=810&name=Vision%20Video%20Source%20Combined.png)

#### 5\. Leverage GDTF/MVR for a Streamlined Process

If your show or event has large amounts of moving scenery, we recommend splitting up your Spotlight design as separate My Virtual Rig (MVR) files. Once in Vision, each MVR file will appear as its own layer. 

And if you have multiple MVR files coming in from lighting distributors, venue managers, or other collaborators, you can merge file types in Vision. These files include mvr, gLTF/glb, vsn, v3s, 3ds, obj, and esc.

[RELATED | Getting Started with GDTF and MVR](../../../net/vectorworks/blog/getting-started-gdtf-mvr.html)

Pairing Vectorworks and Vision gives you the ability to leverage massive amounts of data to previsualize projects. Between the data and the rendering, you and your collaborators will have a complete understanding of the project when arriving at the show site.

To learn more about the industry-uniting file formats and how you can use them in Vision, click the button below:

[![STREAMLINE YOUR PROCESS WITH GDTF AND MVR](https://no-cache.hubspot.com/cta/default/3018241/ca3fd1f8-e12a-40c5-aed4-304ab2e58bc5.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/ca3fd1f8-e12a-40c5-aed4-304ab2e58bc5) 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.