[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Faster Site Design Workflows from Start to Finish

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 8 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2023%20Blog%20Images/10_VW24%20LAND%20Features/Site-Model-Snapshots-v2.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-2024-features-for-the-landscape-industry-%F0%9F%8E%89)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Faster%20Site%20Design%20Workflows%20from%20Start%20to%20Finish&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-2024-features-for-the-landscape-industry-%F0%9F%8E%89&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-2024-features-for-the-landscape-industry-%F0%9F%8E%89)

Let’s continue our exploration of industry-specific functionality in [Vectorworks 2024](../../../net/vectorworks/blog/download-vectorworks-2024-today.html). This time, we’ll examine features and updates for the landscape industries.

#### Landmark Color Palette

Vectorworks Landmark 2024 brings you a dedicated color palette to provide an efficient nature-focused color selection experience. You'll be able to quickly access the colors you need to clearly communicate your design intentions, saving you time and letting you focus on your design.![Landmark-Color-Palette](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/10_VW24%20LAND%20Features/Landmark-Color-Palette.png?width=1920&height=1080&name=Landmark-Color-Palette.png)

#### New Automated Fence Tool

Say hello to the new, automated **Fence** tool! Optimized for simplified and detailed representations, the Fence tool supports integrated posts, gates, and terrain-conforming options like raked or panel/stepped.

![fence-tool](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/10_VW24%20LAND%20Features/fence-tool.png?width=3840&height=2160&name=fence-tool.png)

The Fence tool will save you significant time while designing in 2D and 3D, and also allow for accurate material reporting, reducing the chance for errors in material specifications.

###### Tips & Tricks for the Automated Fence Tool Workflow

If you incorporate fencing in your design projects, then the Fence tool’s automated workflow is developed for you to efficiently design preconfigured and custom fences, in both 2D and 3D, and it’s suited for any industry supported by Vectorworks’ Design Suite products.

One of the first things you’ll note about the Fence tool’s intuitive interface is how similar it is to other smart object tools. The mode bar provides immediate access to available preconfigured fence styles through the resource selector, the familiar polyline placement modes, and the fence tool’s preferences to adjust the tool’s settings.

Let’s review some other important aspects of this feature:

* Fence objects can be placed in either 2D or 3D working environments and be represented dynamically in both.
* These objects are surface-aware, which means they'll automatically follow site model surfaces, or with **Gravity** mode, they can follow surfaces of any 3D object, including hardscapes, landscape areas, slabs, and walls.
* Fence objects automatically facet to the designated post spacing when drawn in a curved path, which is a tremendous time-saving feature.
* Once you have initially placed your fence system, flexibly adjust or customize it using the familiar **Reshape** For example, to accommodate an entry way, you can add, remove, and adjust the position of the posts, to make way for a gate. Then, simply add a gate by selecting the gate mode and choose where the gate should go, making it easy to place as many gates wherever needed.

###### ”General” Tab

* You’ll note the opportunity to change the 2D and 3D levels of detail. This can be very useful in moving from schematic design to design development and construction document phases, or to present your proposed fence design with as much detail as you prefer.
* Another general setting is the overall fence configuration, which can quickly switch to be raked or stepped.

###### “Posts” Settings

* In **Posts** settings, you can accurately adjust your fence installation for each project. For example, if you know the panel span is meant to be shorter than the default, you can quickly change this, as well as modifications to the post height above ground and depth below ground. As you would expect, this automatically changes the overall post length, reducing errors found with the material order once installation begins.
* Specifying the footer for every post is as easy as picking its shape and size.
* When framing fences, rails are critical to its longevity, and since conditions can vary, so should the railing specifications. Fortunately, changing the number of rails, their type, and their profile dimensions is easy in this dialog.

###### “Attributes” Dialog

* The best location to customize fencing materials is through the **Attributes** dialog, within the Fence settings…here you can use class settings for each fence part, or use assigned material settings. If your eventual goal is to report not only the parts, but their materials as well, it will be worth the short time spent assigning these attributes.

#### Site Model Analysis Legends

With the latest improvements for site model analysis, you'll have better control over the graphical output of your site model snapshot with the ability to include a legend to help clients understand color values including elevation and slope.

With a highly customizable color scale, you can reference all the relevant information about your slope ranges and elevation values. Additional settings allow you to display customizable site model data, perfect for reference or comparative analyses. You'll be able to visualize data more easily so you can effectively make and communicate design decisions in a timely manner.

###### Tips & Tricks for Site Model Analysis Legends

Firstly, to access this feature, simply adjust your site model settings to the desired visual output. Then, in the Object Info palette, click “Create a snapshot.”

This will generate a Site Model Snapshot where you can toggle the Legend on and off, adjust its opacity, give it a title, assign the Legend Title and Intervals to classes with customized text styles, and toggle the order of the intervals in the Legend.

For elevation analysis, you can adjust the contour intervals within the **Site Model Settings** to display different ranges of elevation in your legend.

![Site-Model-Snapshots-v2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/10_VW24%20LAND%20Features/Site-Model-Snapshots-v2.png?width=1920&height=1080&name=Site-Model-Snapshots-v2.png)

You can also adjust the minimum and maximum elevation colors within the **Graphic Properties** to create the graphic style you desire and, with the option to display flow arrows, you can gain valuable insight into where water drains on site.

With Slope Analysis, you can adjust the number of slope categories you require, define their slope, and select highly customized colors giving you flexibility in graphical output and slope ranges to help better inform you on the conditions of an existing or proposed site.

Lastly, there is an additional powerful option to Freeze or Unfreeze your Site Model Snapshot. **Freeze** will preserve the visual settings of any modifiers applied to a site model up until the point the Site Model Snapshot is created, allowing you to explore different design options or to visualize different construction phases. **Unfreeze** will automatically keep your Elevation or Slope Analysis and its Legend up to date with the latest modifications applied to your site model.

#### Plant Root Ball & Excavation Zone Improvements

Get better accuracy in your plans with improvements to Plant Root Ball and Excavation Zone settings. You'll see more customization options for both, giving you the ability to set top and bottom diameter dimensions for plant root balls as well as round and rectangular excavation zones. Work smarter within the heavily restricted confines of urban spaces and beyond, and clearly communicate with other project collaborators and installers.

#### Learn More about Vectorworks 2024

This post covers the landscape-specific features in Vectorworks 2024, but there are so many more additions to the software that will work wonders for your workflow. Make sure to look through the whole range of features and see what the new version can do for you.

[![WHAT'S NEW IN 2024?](https://no-cache.hubspot.com/cta/default/3018241/83ace893-bffc-41fa-bbc7-f023baf29681.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/83ace893-bffc-41fa-bbc7-f023baf29681) 

 Topics: [Landscapes](https://blog.vectorworks.net/topic/landscapes) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.