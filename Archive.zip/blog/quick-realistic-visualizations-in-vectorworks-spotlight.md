[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# A Rundown on Shaded Render Mode

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/230615_ENT%20Shaded%20Render/blog-1440x800-5.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fquick-realistic-visualizations-in-vectorworks-spotlight)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=A%20Rundown%20on%20Shaded%20Render%20Mode&url=https%3A%2F%2Fblog.vectorworks.net%2Fquick-realistic-visualizations-in-vectorworks-spotlight&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fquick-realistic-visualizations-in-vectorworks-spotlight)

You're well aware of the quick turnarounds and time-sensitive demands of the entertainment industry. These demands are also why we’ve dedicated several blog posts on time-saving features and practices with [Vectorworks Spotlight](https://www.vectorworks.net/spotlight). 

Below is a small sampler of posts you might find useful:

[READ | “Simple Tricks for More Efficient Entertainment Design”](../../../net/vectorworks/blog/3-vectorworks-tips-that-will-help-you-work-faster.html)

![Siyan_BBC_blog-1440x800](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221026_Ben%20Instep%20Siyan/Siyan_BBC_blog-1440x800.png?width=1440&height=800&name=Siyan_BBC_blog-1440x800.png)

[READ | “These 6 Features Will Save You Time in Lighting Design”](../../../net/vectorworks/blog/6-game-changing-spotlight-features-for-lighting-designers.html)

![blog-1440x800_multiview_vectorworks](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221020_Tools%20for%20Lighting%20Designers/blog-1440x800_multiview_vectorworks.png?width=1440&height=800&name=blog-1440x800_multiview_vectorworks.png)

[READ | “Beyond Design — Manage Shows and Events with Vectorworks Spotlight”](../../../net/vectorworks/blog/not-just-for-design-production-management-with-spotlight.html)

![blog-1440x800_production management](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230330_Production%20Management%20with%20Spotlight/blog-1440x800_production%20management.png?width=1440&height=800&name=blog-1440x800_production%20management.png)

[READ | “What You Need to know About Efficiency & Safety with Braceworks”](../../../net/vectorworks/blog/brace-yourself-3-tips-on-starting-in-braceworks.html)

![blog-1440x800_Braceworks Featured Image](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/23_ENT%20Braceworks%20for%20Beginners/blog-1440x800_Braceworks%20Featured%20Image.png?width=1440&height=800&name=blog-1440x800_Braceworks%20Featured%20Image.png)

In this post, you’ll learn about another Vectorworks improvement: the updates to the Shaded render mode, [introduced in Vectorworks 2023](../../../net/vectorworks/blog/2023-service-pack-5.html).

The updates to the Shaded Render mode offer you the chance to create realistic visualizations of your projects without having to wait for more intensive renderings.

#### What’s Shaded Render Mode in Vectorworks Spotlight?

Shaded render mode is one of the visualization options in your Render Mode dropdown menu. The mode creates quality, detailed renderings with colors, shading, and textures. 

And with the release of Vectorworks 2023, the Shaded render mode in Vectorworks now supports glow textures, lit fog, gobos, texture bump, environmental effects, and reflections.

The updates to the Shaded Render mode also allow unlimited lights in your scene, removing the previous eight-light limit. So, your 3D model will match what your production actually requires in terms of lighting.

Check out this video to learn a little more about the feature and — more importantly — see it in action:

#### Advantages of Shaded Rendering for Live Events, Productions, and More

The biggest advantage of Shaded rendering in Vectorworks, as we already mentioned, is that you can use it to quickly make life-like visuals of your projects. With the speed of the feature and the ease of making edits in real-time, it’s a great way for you and other stakeholders to understand what a production will look like in-person.

You’ll be able to create designs in an environment that better represents the materials you’re using for set pieces, stage elements, etc. If you’re using glass or fiberglass on a stage, for example, Shaded render mode lets you simulate the reflectivity of the material. This way, you can see how the surface may interact with lights or other components of your design.

With environmental effects, lit fog, and gobo shading, too, you can take the 3D models of your productions to the next level.

The advantages speak for themselves, really. Take a look at some of the images below and see what Shaded renderings can do for you:

![Screen Shot 2023-06-15 at 11.31.41 AM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230615_ENT%20Shaded%20Render/Screen%20Shot%202023-06-15%20at%2011.31.41%20AM.png?width=1440&height=791&name=Screen%20Shot%202023-06-15%20at%2011.31.41%20AM.png)

![Screen Shot 2023-06-15 at 11.31.56 AM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230615_ENT%20Shaded%20Render/Screen%20Shot%202023-06-15%20at%2011.31.56%20AM.png?width=1440&height=774&name=Screen%20Shot%202023-06-15%20at%2011.31.56%20AM.png)

![Screen Shot 2023-06-15 at 11.32.34 AM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230615_ENT%20Shaded%20Render/Screen%20Shot%202023-06-15%20at%2011.32.34%20AM.png?width=1440&height=791&name=Screen%20Shot%202023-06-15%20at%2011.32.34%20AM.png)

#### Find Out What New Features are Coming Soon!

As we mentioned above, the updates to Shaded Render mode were implemented with the release of Vectorworks 2023\. To see what other features are coming to future versions of Vectorworks, click the button below and view our Public Roadmap. 

The Roadmap is a way for the Vectorworks community to follow along with our engineering team, plus have the ability to offer feedback and, recently, [**submit feature requests**](https://www.vectorworks.net/public-roadmap). 

“Every business has to have long-term strategies, and in order to execute those strategies, you need a roadmap. Plain and simple. We’ve been in business for over 35 years — and how do we stay in business? Because we listen to our customers. And the Public Roadmap is an excellent vehicle for that,” said Vectorworks CEO Dr. Biplab Sarkar.

Click the button below to see what’s on the way:

[![VIEW PUBLIC ROADMAP](https://no-cache.hubspot.com/cta/default/3018241/d8f4298e-ec94-4439-b84e-1b5457402354.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/d8f4298e-ec94-4439-b84e-1b5457402354) 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.