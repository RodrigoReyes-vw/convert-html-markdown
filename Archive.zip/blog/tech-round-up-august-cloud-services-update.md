[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# TECH ROUNDUP: SEPTEMBER 2017, CLOUD SERVICES UPDATE

 Posted by [Chloe Jefferson](https://blog.vectorworks.net/author/chloe-jefferson) | 2 min read time 

![DropBox_photo1.png](https://blog.vectorworks.net/hubfs/September%20Tech%20Roundup/DropBox_photo1.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Ftech-round-up-august-cloud-services-update)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=TECH%20ROUNDUP:%20SEPTEMBER%202017,%20CLOUD%20SERVICES%20UPDATE&url=https%3A%2F%2Fblog.vectorworks.net%2Ftech-round-up-august-cloud-services-update&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Ftech-round-up-august-cloud-services-update)

The Vectorworks Cloud Services web portal was created in 2011, and its user interface and functions have never been significantly updated, until now. You asked, we listened, and now the Cloud Services web portal is better than ever. These upgrades can be enjoyed through the use of [Vectorworks 2018](http://www.vectorworks.net/en/2018?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=techroundup0917), which launched last week. The main webpage and all its dialog boxes are re-implemented to address functional deficits, improve user experience, and add new features. 

Now not only is Vectorworks Cloud Services integrated with Dropbox, but with Google Drive as well. If you use Google Drive as your primary storage, you can take advantage of Vectorworks applications and services without changing your regular workflow.

![DropBox_photo1.png](https://blog.vectorworks.net/hs-fs/hubfs/September%20Tech%20Roundup/DropBox_photo1.png?width=541&height=349&name=DropBox_photo1.png)

_Vectorworks Cloud Services now has integration with Dropbox and Google Drive._

Some other features being integrated into this web portal renovation include a responsive layout that automatically resizes for your different devices, drag and drop uploads, and uploads of multiple files. You’ll also enjoy better file organization, an easier-to-use sharing interface, and improved 3D models of your files on the cloud, using the same 3D web view functionality available in Vectorworks.

We’re also excited to announce the rendered panorama feature, available in Vectorworks 2018, which allows you to provide clients with a 360-degree interactive view of your model. If you’re a [Vectorworks Service Select](https://serviceselect.vectorworks.net/login%5Fform?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=techroundup0917) member, you can generate rendered panoramas on the cloud instead of tying up your local computer.

![RenderedPanorama_photo2.png](https://blog.vectorworks.net/hs-fs/hubfs/September%20Tech%20Roundup/RenderedPanorama_photo2.png?width=541&height=442&name=RenderedPanorama_photo2.png)

_A glimpse of the new rendered panorama feature._ 

Ready to take your design workflow to the next level? [Sign up for Vectorworks Cloud Services](https://cloud.vectorworks.net/accounts/login/?next=/portal/files/home/?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=techroundup0917) and start enhancing the way you collaborate within the cloud.

 Topics: [Tech Tips and Workflows](https://blog.vectorworks.net/topic/tech-tips-and-workflows) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.