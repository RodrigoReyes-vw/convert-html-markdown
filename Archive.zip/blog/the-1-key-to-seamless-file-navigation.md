[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# How to Use Saved Views to Your Advantage

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2023%20Blog%20Images/2_BLDG%20Tips/01_Complex%203D%20View-Gallery%202.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fthe-1-key-to-seamless-file-navigation)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=How%20to%20Use%20Saved%20Views%20to%20Your%20Advantage&url=https%3A%2F%2Fblog.vectorworks.net%2Fthe-1-key-to-seamless-file-navigation&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fthe-1-key-to-seamless-file-navigation)

If you’re looking for a guaranteed way to be more efficient with Vectorworks, this is the blog for you.

By using saved views to your advantage, you’re bound to drastically decrease the amount of time you spend navigating your file. Let’s see how to use them.

## **WHAT IS A SAVED VIEW?**

A saved view is like a camera that is set up to show your drawing from a certain orientation, with a specific set of viewing parameters, including which class and design layers are active, the visibilities of classes and the design layers, the current zoom and pan, render mode, data visualizations, and the page location.

Saved views can be created, edited, duplicated, and deleted from the Organization dialog box and the Navigation palette.

## **HOW TO BEST USE SAVED VIEWS**

The first step to effectively using saved views is to consider the areas of your model or drawing that require a lot of clicking around and changing class and layer visibility to see relevant information. For many architects, switching between 2D and 3D can be one of those times, especially when you have a long list of classes or layers to sift through.

![01_Complex 2D View-Gallery](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/2_BLDG%20Tips/01_Complex%202D%20View-Gallery.png?width=1408&height=750&name=01_Complex%202D%20View-Gallery.png)

### **![01_Complex 3D View-Gallery 2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/2_BLDG%20Tips/01_Complex%203D%20View-Gallery%202.png?width=1405&height=750&name=01_Complex%203D%20View-Gallery%202.png)**

### **VIEWS FOR DRAWING, MODELING, & EDITING**

Here you’ll see a few ways to create views for any part of your process.

### **SETTING UP VIEWS BEFORE YOU START DESIGNING**

Saved views can add value to your workflow at the very start of a project.

Try setting up a saved view for things like diagramming, analysis, early site planning for building coverage, setbacks, and massing models. That way, as you work through these items, you can quickly show what you need to see on screen.

![02_Diagramming View-02](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/2_BLDG%20Tips/02_Diagramming%20View-02.png?width=1407&height=750&name=02_Diagramming%20View-02.png)

![02_Diagramming View-03](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/2_BLDG%20Tips/02_Diagramming%20View-03.png?width=1268&height=750&name=02_Diagramming%20View-03.png)

Setting up these views now and saving them to a template file is an exponential time saver.

### **CLIP CUBE** 

First, if you’re unfamiliar with Clip Cube, [here’s your introduction](../../../net/vectorworks/blog/could-this-be-the-coolest-vectorworks-feature.html). It’s an incredibly useful feature for a variety of reasons, including creating saved views.

You can use the Clip Cube to verify:

* If stairs meet slabs
* If stairs have proper head clearance
* If millwork objects in kitchens or other areas are properly stacked

And that’s only naming a few examples.

![03_Stair & Clip Cube-03](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/2_BLDG%20Tips/03_Stair%20%26%20Clip%20Cube-03.png?width=1405&height=750&name=03_Stair%20%26%20Clip%20Cube-03.png)

The process is simple, too.

1. Turn on the appropriate classes and layers
2. Set the Clip Cube boundary
3. Create a new saved view and make sure you check “Restore View Orientation,” “Zoom and Pan,” and “Page Location.”

### **CLASS/LAYER VISIBILITIES**

Detail drawings are usually drawn at a different scale than floor plans, even in design layers. Because of the various scales of design layers, using saved views is a great way to isolate details from everything else so you can get a clear view of elements drawn at that specific scale.

Additionally, if design options are controlled by classes or layers, saved views can be used to quickly navigate between the proposals. Here, a saved view is used to quickly switch between walnut and white oak millwork.

![04_Class Layer Visibilities-Walnut Millwork](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/2_BLDG%20Tips/04_Class%20Layer%20Visibilities-Walnut%20Millwork.png?width=1406&height=750&name=04_Class%20Layer%20Visibilities-Walnut%20Millwork.png)

### **![04_Class Layer Visibilities-White Oak Millwork](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/2_BLDG%20Tips/04_Class%20Layer%20Visibilities-White%20Oak%20Millwork.png?width=1407&height=750&name=04_Class%20Layer%20Visibilities-White%20Oak%20Millwork.png)**

### **“ALL ON” 3D VIEW**

Top/plan views for working on floor plans usually requires you to hide all layers for floors above and below the one you’re working on. But for viewing the model in 3D, it’s useful to have all design layers visible for an overall view of the project so you can easily see what the big picture is looking like.

### **RENDERING AND PRESENTATION VIEWS**

It’s also useful to create saved views for rendering and presenting your work.

### **RENDERING**

Plan your saved views for cameras, heliodon objects, lights, furniture, plants, etc. is an easy way to stay organized when [placing cameras](../../../net/vectorworks/blog/using-the-renderworks-camera-for-interiors-visualization.html) for generating renderings. You can do this for overall exterior renderings or for smaller portions of the project such as interior space or details.

Additionally, you can save rendering styles to your saved views. If you know that saved view X is always going to be in Shaded, you can set that up ahead of time and save yourself some work later.

![01_Complex 3D View-Gallery](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/2_BLDG%20Tips/01_Complex%203D%20View-Gallery.png?width=1405&height=750&name=01_Complex%203D%20View-Gallery.png)

### **PRESENTATIONS**

Saved views are incredibly useful for showing what you’ve been working on to a client, colleague, or supervisor.

Here, you’re basically creating a PowerPoint presentation within Vectorworks. Your saved views are the slides. The views allow you to easily move through parts of the project, such as between rooms or stories.

## **MORE INFORMATION ON SAVED VIEWS**

For more information regarding using saved views, visit the Vectorworks 2023 Online Help.

[![LEARN MORE](https://no-cache.hubspot.com/cta/default/3018241/c35ac88a-83ca-4b5d-9f81-0346c647fef9.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/c35ac88a-83ca-4b5d-9f81-0346c647fef9) 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.