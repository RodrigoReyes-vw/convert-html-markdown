[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Vectorworks User Provides a Clean Path to the Future

 Posted by [Chloe Jefferson](https://blog.vectorworks.net/author/chloe-jefferson) | 2 min read time 

![Lick ext SCP_1948 edit.jpg](https://blog.vectorworks.net/hubfs/Lick%20ext%20SCP_1948%20edit.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-user-provides-a-clean-path-to-the-future-)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Vectorworks%20User%20Provides%20a%20Clean%20Path%20to%20the%20Future&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-user-provides-a-clean-path-to-the-future-&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-user-provides-a-clean-path-to-the-future-)

At [Vectorworks](http://www.vectorworks.net/?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=zeronetenergy012518), we value the use of sustainable design. That’s why we’re proud to share that San Francisco-based Vectorworks user [Hamilton + Aitken Architects](http://haarchs.com/) is a participant in the [7x7x7 Design Energy Water](http://www.7x7x7designenergywater.com/) initiative. Through this program, the firm demonstrates ways existing school campuses can transition to Zero Net Energy (ZNE) — a clean path to the future.

ZNE means that the total amount of energy used by a building on an annual basis is equal to or less than the renewable energy generated on site.

![Lick ext SCP_1948 edit.jpg](https://blog.vectorworks.net/hs-fs/hubfs/Lick%20ext%20SCP_1948%20edit.jpg?width=550&name=Lick%20ext%20SCP_1948%20edit.jpg "Lick ext SCP_1948 edit.jpg")_The James Lick Middle School, modernized by Hamilton + Aitken Architects. Originally built in 1930, the school is an example of how even older buildings can have a path to zero net energy. Image courtesy of Hamilton + Aitken Architects._

The purpose of the 7x7x7 program is to encourage school districts throughout California to develop long-range master plans to reduce energy and water consumption, while improving the quality of educational spaces.

“The 7x7x7 Design Energy Water case study required a great deal of technical analysis and calculations,” says Hamilton + Aitken Architects Principal Chad Hamilton. “Using Vectorworks, we were able to generate data on volume and area that we could feed into worksheets to estimate energy and water usage, available rainwater and greywater for recycling, feasibility of using on-site photovoltaics, and many other required calculations. 

![Lick int lobby._SCP0532.jpg](https://blog.vectorworks.net/hs-fs/hubfs/Lick%20int%20lobby._SCP0532.jpg?width=550&name=Lick%20int%20lobby._SCP0532.jpg "Lick int lobby._SCP0532.jpg")_An inside view of t_ _he James Lick Middle School. Image courtesy of Hamilton + Aitken Architects._

As a result of this initiative, the [San Francisco Unified School District](http://www.sfusd.edu/) voted on September 26, 2017, to pass a resolution in support of carbon neutral schools. They plan to transition all district campuses to ZNE by 2040.

Here are some of the many benefits of moving existing schools towards ZNE:

* Maximize daylight and air quality while curtailing harmful pollutants to keep students and teachers healthier
* Reduce energy use to a minimum to improve efficiency
* Optimize cost and decrease maintenance burdens as much as possible, which also reduces operating cost
* Encourage pride and commitment among families and the neighborhood, while preserving the beauty of the past by maintaining and modernizing beautiful school buildings

You can read more about the Hamilton + Aitken Architects case study and find other resource materials [here](http://www.7x7x7designenergywater.com/). 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.