[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# SILV Trains Next Generation of Entertainment Professionals

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 2 min read time 

![stagecraft-institute](https://blog.vectorworks.net/hubfs/stagecraft-institute.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fsilv-trains-next-generation-of-entertainment-professionals)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=SILV%20Trains%20Next%20Generation%20of%20Entertainment%20Professionals&url=https%3A%2F%2Fblog.vectorworks.net%2Fsilv-trains-next-generation-of-entertainment-professionals&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fsilv-trains-next-generation-of-entertainment-professionals)

[The Stagecraft Institute of Las Vegas (SILV)](https://stagecraftinstitute.com/) equips young professionals with the technology and experience needed to succeed in entertainment production.

SILV is an intensive 8-week training program where industry experts contribute their time and resources, their goal to foster another generation of great live entertainment.

Frank Brault, our entertainment product marketing manager, was one of those industry experts. He spent two weeks in Las Vegas this summer teaching [Vectorworks Spotlight](https://www.vectorworks.net/en/spotlight?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=SILV070919) and [Vision](https://www.vectorworks.net/en/vision?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=SILV070919) and said the workload is intense.

SILV fits a college semester’s worth of work into an 8-week program, capped off by a final project where students coordinate an entire production. “You kind of have to put your life on hold,” said Alyssa Glenn, a freelance electrician and SILV student.

For Glenn, SILV’s 6:45 a.m. classes reinforced her love for the classroom. “It’s very fast-paced and chaotic, but you learn a lot in a short period of time,” she said.

![blonde-guy (1)](https://blog.vectorworks.net/hs-fs/hubfs/190709_SILV/blonde-guy%20(1).jpg?width=1440&name=blonde-guy%20(1).jpg)

“I feel like I’ve been doing class for two years when I’ve only been here for two weeks,” said Vinnie Zampieri, a SILV student who works as a stage manager in Brazil.

Believe it or not, before being introduced to drafting software, Zampieri used Microsoft Paint for lighting projects. Needless to say, he found quite the workflow upgrade in professional-grade programs like Spotlight and Vision.

"I’ve never heard of Vectorworks. It makes me feel like I can do any kind of job,” Zampieri said. Vectorworks helps him to perform quickly the drawings he has to do every day. “I can’t handle AutoCAD. I think Vectorworks is much easier.”

For both, SILV meant hands-on experience working alongside professionals who believe in the future of entertainment production.

###### Get your hands-on experience.

[![TRAIN WITH VECTORWORKS](https://no-cache.hubspot.com/cta/default/3018241/a1c1f897-8c3f-4eb3-9c9b-b007886fe32c.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/a1c1f897-8c3f-4eb3-9c9b-b007886fe32c) 

 Topics: [Production & Lighting Design](https://blog.vectorworks.net/topic/production-lighting-design) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.