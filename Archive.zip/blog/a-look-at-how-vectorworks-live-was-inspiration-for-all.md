[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# A Look at How Vectorworks Live was Inspiration for All

 Posted by [Rowena Winkler](https://blog.vectorworks.net/author/rowena-winkler) | 3 min read time 

![First-Shipping_Japan](https://blog.vectorworks.net/hubfs/First-Shipping_Japan.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fa-look-at-how-vectorworks-live-was-inspiration-for-all)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=A%20Look%20at%20How%20Vectorworks%20Live%20was%20Inspiration%20for%20All&url=https%3A%2F%2Fblog.vectorworks.net%2Fa-look-at-how-vectorworks-live-was-inspiration-for-all&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fa-look-at-how-vectorworks-live-was-inspiration-for-all)

On November 30, 2018, our Japanese distributor [A&A Co., LTD.](http://www.aanda.co.jp/) hosted the [Vectorworks Live event](https://www.youtube.com/watch?v=JrRZPxZtStM) to reveal Vectorworks 2019 to the Japanese market. More than 300 attendees gathered at the Shinagawa Grand Hall in Tokyo alongside representatives from Vectorworks headquarters to witness how the latest features can enhance Japanese designs.

![Hall](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190117_JapanEvent/Hall.jpg?width=4752&name=Hall.jpg)

_Vectorworks Live event at Shinagawa Grand Hall. Photo courtesy of Takeshi Nohara._ 

“It was a thrill and a privilege to be a part of Vectorworks Live in Tokyo—a wonderful event in an incredible city,” said Vectorworks VP of Product Development Steve Johnson. “It is extra special to celebrate in Japan with our customers and our long-standing partners at A&A.”

“This was a great opportunity for us to meet our customers in Japan and see first-hand the projects they are working on,” said Vectorworks VP of Product Management Darick DeHart.

Among the many presentations about the latest 2019 features in [Vectorworks Architect](https://www.vectorworks.net/en/architect?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=japanevent011719), [Landmark](https://www.vectorworks.net/en/landmark?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=japanevent011719), [Spotlight](https://www.vectorworks.net/en/spotlight?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=japanevent011719), and [Fundamentals](https://www.vectorworks.net/en/fundamentals?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=japanevent011719), Vectorworks CEO Dr. Biplab Sarkar talked about the current status of Vectorworks, with Johnson and DeHart sharing their plans for core technologies and the design series in future releases. Vectorworks Senior Architect Product Specialist Luis Ruiz concluded the day by discussing the benefits of 3D modeling and renderings to the Japanese audience.

![Panorama](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190117_JapanEvent/Panorama.jpg?width=4752&name=Panorama.jpg)

_Ruiz demonstrating Vectorworks rendered panoramas. Photo courtesy of Takeshi Nohara._ 

“We chose to show how an interior commercial project can be created by applying different modeling techniques,” said Ruiz. “We focused on the importance of lighting sources, materials, and the different types of output options for creating professional renderings, presentation boards, and the advantages of integrating new features, such as 3D rendered panoramas and cloud technology to their daily workflows.”

Based on comments from the audience, Ruiz’s presentation inspired many attendees and got them excited to try Vectorworks 2019.

![VWX Store-Front Desk](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190117_JapanEvent/VWX%20Store-Front%20Desk.jpg?width=5292&name=VWX%20Store-Front%20Desk.jpg)

_The Vectorworks storefront desk. Image courtesy of Vectorworks, Inc._ 

“I thoroughly enjoyed being able to meet directly with our customers and see the wonderful designs they do with Vectorworks,” said Johnson. “It was inspiring and informative—the perfect opportunity to listen carefully and to learn how we can serve our customers even better.”

“It was a great honor to meet such talented designers like Hiroshi Haraguchi-san and Toshiya Izumi-san,” said Ruiz. “During the event, we could feel the enthusiasm for the new Vectorworks 2019 release. It was also great to be there to show existing users and prospects all the possibilities and benefits that they can achieve doing 3D with Vectorworks.”

![First Shipping_Japan](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190117_JapanEvent/First%20Shipping_Japan.jpg?width=4752&name=First%20Shipping_Japan.jpg)

_First shipping of Vectorworks 2019\. Photo courtesy of Takeshi Nohara using fish-eye lens._

Dr. Sarkar reflected on the event with similar thoughts.

“Attending the A&A launch event every year is very special for us as we get to describe the design trends and discuss innovative ideas in front of a wide cross-section of Japanese users,” said Sarkar. “Being one of the most popular CAD/BIM programs in Japan, it is our responsibility to present the future of Vectorworks as a company and as a product.”

## Want to know how Vectorworks 2019 can enhance your projects?

**[![Learn More](https://no-cache.hubspot.com/cta/default/3018241/d812f161-7e8a-4456-b0bd-d222befc3201.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/d812f161-7e8a-4456-b0bd-d222befc3201)** 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.