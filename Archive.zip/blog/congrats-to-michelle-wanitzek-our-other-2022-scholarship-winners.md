[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# The 2022 Design Scholarship Winners & Their Incredible Projects!

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 6 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/221207_Scholarship%20Winners%20Blog/blog-1440x800_Scholarship%20Winner%201.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fcongrats-to-michelle-wanitzek-our-other-2022-scholarship-winners)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=The%202022%20Design%20Scholarship%20Winners%20&%20Their%20Incredible%20Projects!&url=https%3A%2F%2Fblog.vectorworks.net%2Fcongrats-to-michelle-wanitzek-our-other-2022-scholarship-winners&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fcongrats-to-michelle-wanitzek-our-other-2022-scholarship-winners)

At Vectorworks, [providing you with a host of resources and services](../../../net/vectorworks/blog/what-can-design-students-get-from-vectorworks.html) isn't all we do to support the beginning of your design journey.

Each year, we award young designers scholarships for projects in the architecture, interior design, landscape, and entertainment industries. And, after over 1,000 submissions, we're so very excited to announce this year's winners of the [2022 Design Scholarship!](https://www.vectorworks.net/scholarship/winners)

Congrats to all of the winners, and we can't wait to see all of the wonderful work you'll do for years to come!

## Michelle wanitzek's "Nomad coworking" project

Taking home this year's coveted Richard Diehl Award, our grand prize, is Michelle Wanitzek for her project, "Nomad Coworking."

The winning project, which was submitted by Wanitzek for her master's thesis at Fakultät Gestaltung Wismar, features a coworking space and coffeeshop in a listed monument — a site identified for its architectural or historical significance — and focuses on the increasing importance of alternative and flexible workspaces. The design tackled a challenging task — working with a historical monument's intricacies and structural limits while simultaneously preserving the protected façade and showcasing the transformation for experiential value.

“With a progressive idea of what monument protection means, Michelle designed an infrastructure in the middle of Wismar’s Old Town, which is suitable to revitalize the city and capable of giving the monument a contemporary purpose,” said the [University of Wismar](https://www.hs-wismar.de/) Dean of the Faculty of Design Prof. Dipl.-Ing. Oliver Hantke, judging panel member. “Her concept of multi-layered use picks up on current trends in the construction industry including sustainability and efficiency strategy, utilizing historical buildings, revitalizing small-town structures, new forms of working environments, and providing communication structures to strengthen social cohesion.”

“It is a great honor to win the Richard Diehl Award with my thesis project, especially because I never expected this success,” said Wanitzek. “It means a lot to me to show that interior design is much more than most people realize. It’s about how we want to live and how we can utilize the architecture that already surrounds us. I think in today’s world, there should be an increased focus on repurposing existing buildings and I hope this award will increase awareness of the practice.”

![blog-1440x800_Scholarship Winner 2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221207_Scholarship%20Winners%20Blog/blog-1440x800_Scholarship%20Winner%202.png?width=1440&height=800&name=blog-1440x800_Scholarship%20Winner%202.png)

## Even More vectorworks design scholarship winners

Wanitzek wasn't the only young designer we wanted to honor this year, either! 

The selected winners represent a wide range of countries worldwide including Canada, Denmark, France, Germany, Japan, the Netherlands, Poland, Turkey, Switzerland, the United Kingdom, and the United States. An expert [panel of international judges](https://www.vectorworks.net/scholarship/judges?utm%5Fmedium=pr&utm%5Fsource=coverage&utm%5Fcampaign=scholarship&utm%5Fcontent=1222-design-scholarship-winners) evaluated all submissions on five main criteria: design, technology, originality, presentation, and writing.

![blog-1440x800_Scholarship Winner 1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221207_Scholarship%20Winners%20Blog/blog-1440x800_Scholarship%20Winner%201.png?width=1440&height=800&name=blog-1440x800_Scholarship%20Winner%201.png)

Congratulations to this year's winners:

### **Architecture Winners**:

* “Timber: Material Explorations and Speculations” by Ahmed Helal, City College of New York
* “Salt Market” by Claudia A Crespo Castro, University of Puerto Rico Río Piedras - School of Architecture
* “The Conservative Pubs of Hierarchy”’ by Nicoleta Rugina, Birmingham City University
* “Working and Living in Symbiosis“ by Ildut Lesteven, Ecole Nationale Supérieur d'Architecture Paris Val-de-Seine
* “Ubuntu – Small Town, Big House” by Yui Hasegawa and Yori Mihara, Musashino Art University
* “Food Forms” by Blanka Dominika Major, Severin Jann, and Valentin, Ribi ETH Zürich
* “Everything Remains the Same” by Fabian Moser, Niels Striby, Merve Simsek, Helene Merkle, and Thomas Ederer, Karlsruhe Institute of Technology

### **Interior Design Winners**:

* “Marylebone Proper Hotel” by Sara Riofrio, Solent University
* “Vitra Stant Design” by Sila Simsek and Edanaz Topaktaş, Hacettepe University
* “Agricultural Childcare Center 'Het Snuitje'” by Jannie Dircks, Jan des Bouvrie Academy - Saxion Deventer
* “Pet Ceremony Hall” by Cai Rou Wang, Osaka University of Arts

### **Landscape Winners**:

* “Site, Sight, Insight” by Chui Shan Tsang, University College London
* “Ingolstadt - On the Maelstrom into a Challenged Future” by Lea Jaud, University of Copenhagen
* “Rising with the Phoenix: The Next Generation of Blue-Green Infrastructural Design in its Re-Integration with Social & Cultural Realms” by Lok Tim Chan, Cornell University
* “Rain Park” by Marta Szar, University of Technology in Cracow
* “Nature in a Grid- Transformation of a Ruin” by Simeon von Russow, Berlin University of Applied Sciences (BHT)

### **Entertainment Winners**: 

* “Shakespeare’s Women” by Brock Keeler, University of Victoria
* “Blood Wedding Reimagined” by Kane Hollingsworth, Nottingham Trent University
* “Songs for a New World” by Martin Benesh, State University of New York at New Paltz
* “Art exhibition ‘Lokhalle Mainz’” by Celina Rau, Technische Hochschule Mittelhessen
* “Francine Vasse Theater: Renovation of the Scenic Networks” by Pierre Pino, Gabriel Guist'hau College

![blog-1440x800_Scholarship Winner 3](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221207_Scholarship%20Winners%20Blog/blog-1440x800_Scholarship%20Winner%203.png?width=1440&height=800&name=blog-1440x800_Scholarship%20Winner%203.png)

Winners received the equivalent of up to $3,000 USD in their local currency, free Vectorworks educational software licenses for their schools and complimentary virtual workshop training. As the Richard Diehl Award winner, Wanitzek received an additional prize package including the equivalent of $7,000 USD in local currency and professional networking opportunities.

To see more images of Wanitzek and the other winners' projects, click the button below to browse the Vectorworks Design Scholarship web gallery: 

[![VIEW THE AWARD-WINNING PROJECTS](https://no-cache.hubspot.com/cta/default/3018241/4e4316d2-b93b-47c1-8720-9a2ee27d72ac.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/4e4316d2-b93b-47c1-8720-9a2ee27d72ac) 

_All images courtesy of Michelle Wanitzek._ 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.