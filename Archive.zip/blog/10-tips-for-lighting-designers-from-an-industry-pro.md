[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# 10 Tips for Starting or Advancing Your Career as a Lighting Designer

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/2023-signature-image-ent.jpeg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2F10-tips-for-lighting-designers-from-an-industry-pro)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=10%20Tips%20for%20Starting%20or%20Advancing%20Your%20Career%20as%20a%20Lighting%20Designer&url=https%3A%2F%2Fblog.vectorworks.net%2F10-tips-for-lighting-designers-from-an-industry-pro&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2F10-tips-for-lighting-designers-from-an-industry-pro)

As a multiple Tony Award® winner, simply calling Donald Holder a lighting design expert is an understatement.

Holder is an artist with work spanning theater, opera, dance, and even architecture. His work is evidence enough that he’s someone who understands the power of design and light.

Plus, he has tons of great advice for other lighting designers! Keep on reading for his 10 tips. 

## 1\. Find Ways to “See” Light

Holder’s first piece of advice is to observe the world around you and the light you see. Sunsets, sunrises, dawn, moonlight, and more can inspire your next lighting designs. 

## **2\. Watch the Classics**

They’re classics for a reason. 

Whether they’re classics of the stage or screen, Holder thinks you should spend time watching the best works of the last 50 to 60 years. 

## 3\. Study Your Peers

Once you’re done watching classics like _Citizen Kane_ or _Hamilton_, Holder encourages you to go out and observe the work of your peers. 

![blog-1440x800_10 Tips for Lighting Designers 5](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230216_10%20Tips%20for%20Lighting%20Designers/blog-1440x800_10%20Tips%20for%20Lighting%20Designers%205.png?width=1440&height=800&name=blog-1440x800_10%20Tips%20for%20Lighting%20Designers%205.png)_Image courtesy of Joan Marcus, Don Holder Lighting Design, Inc._ 

It can be modern cinema, local theater, or touring shows — just remember you can learn a lot from your peers.

## 4\. Examine Other Disciplines

Holder encourages lighting designers to also check out the work of other visual artists, whether they be painters, photographers, or creators through any other medium. According to Holder, when you look at art from the likes of Rembrandt and Vermeer, you can learn a good deal about light. After all, visual arts tend to feature the manipulation of light and perspective.

He says that doing so will give you a “new awareness of light” and will have a “profound and lasting influence on the work you do as a lighting designer.

## 5\. Study the Impact of Light on Objects

Another piece of advice from Holder, and one you can follow regardless of where you are in your career, is to study the impact of light on objects. The lighting designer said, “Study how man-made or artificial light plays on the surface of objects: the differences in color, shadows, and angles between reading lamps at home, the streetlights outside, the light in your classroom or office, etc.”

[RELATED | Our Case Study on Don Holder and _The Bridges of Madison County_](https://www.vectorworks.net/en-US/customer-showcase/tony-award-winner-lights-the-bridges-of-madison-county)

_![blog-1440x80010 Tips for Lighting Designers 6](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/23021610%20Tips%20for%20Lighting%20Designers/blog-1440x80010%20Tips%20for%20Lighting%20Designers%206.png?width=1440&height=800&name=blog-1440x80010%20Tips%20for%20Lighting%20Designers%206.png)Image courtesy of Joan Marcus, Don Holder Lighting Design, Inc._ 

## 6\. Read, Read, and Read Some More

Holder thinks that you should read “as much as you can.” And, there’s plenty out there to read about. You can read about other lighting designers, you can read industry news, or maybe you could read [Joseph Oshry’s _Studies of Light In the World and on the Stage_.](https://www.amazon.com/Studies-Light-World-Joseph-Oshry-ebook/dp/B08RQPY14S?ref%5F=ast%5Fauthor%5Fdp)

## 7\. Develop Your Imagination

Another one of Holder’s tips for lighting designers is to sharpen your strongest tool: your imagination.

He said, “Become as articulate and knowledgeable as you can about as many subjects as possible. Study art, art history, politics, history, literature, music theory, and composition. Learn to play an instrument. Any or all of the above will feed your mind and develop your imagination and creativity.”

## 8\. Lean on Those Around You

One of our favorite pieces of advice from the multiple-Tony-award winner is continuing to talk with those closest to you, whether it be family, friends, or colleagues. Leaning on those you love and respect will give you the chance to discuss some of the recent works you’ve seen or read. But, perhaps more importantly, you can talk with them about your work, its challenges, or whatever you need to talk about to stay at your best!

If you’re looking to connect with local designers, build your network, or learn new skills, [we suggest checking out Vectorworks Community Groups](https://www3.vectorworks.net/community-group).

![Community-Groups-Email](https://blog.vectorworks.net/hs-fs/hubfs/Community-Groups-Email.jpg?width=1440&height=720&name=Community-Groups-Email.jpg)

## 9\. Hone Your Communication Skills 

Holder also believes you should place care and attention into your communication skills. As Holder put it, “Excellent communication is crucial in order to become a successful lighting designer.”

Well said.

## 10\. Keep Searching for and Learning New Skills

Holder’s final tip for you is to never stop searching for new ways to improve your design skills.

If you’re looking for ways to gain design skills and learn about new [Vectorworks Spotlight](https://www.vectorworks.net/spotlight) features, we recommend checking out Vectorworks University. Click the button below to browse our selection of free webinars and other courses:

[![BROWSE VECTORWORKS UNIVERSITY](https://no-cache.hubspot.com/cta/default/3018241/80cc3a4d-d8da-4e1e-87d3-d9a3e929e246.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/80cc3a4d-d8da-4e1e-87d3-d9a3e929e246) 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.