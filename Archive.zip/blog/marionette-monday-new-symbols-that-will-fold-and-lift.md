[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Marionette Monday: New Symbols That Will Fold and Lift

 Posted by [Rowena Winkler](https://blog.vectorworks.net/author/rowena-winkler) | 2 min read time 

![Scissor Lift.png](https://blog.vectorworks.net/hubfs/Blog%20Images/180226_Marionette%20Mon%20Lifts%20Cranes%20NanaWall/Scissor%20Lift.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fmarionette-monday-new-symbols-that-will-fold-and-lift)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Marionette%20Monday:%20New%20Symbols%20That%20Will%20Fold%20and%20Lift&url=https%3A%2F%2Fblog.vectorworks.net%2Fmarionette-monday-new-symbols-that-will-fold-and-lift&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fmarionette-monday-new-symbols-that-will-fold-and-lift)

To help you get through your case of the Mondays, here are some new Marionette objects specifically created in response to user comments on the [Vectorworks Forum](https://forum.vectorworks.net/?%20utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=marrionettemon022618).

“We plan to release new Marionette content every six to eight weeks,” said Sarah Barrett, architect product specialist at Vectorworks, Inc. “This content is based on user wishes and will live in the Forum for now as we continue to collect feedback.”

Let’s take a look at these recent releases, and how they can enhance your drawings.

## Object 1: NanaWall Door

**![NanaWall.png](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/180226_Marionette%20Mon%20Lifts%20Cranes%20NanaWall/NanaWall.png?width=1024&name=NanaWall.png)**

_NanaWall door Marionette symbol._

[This NanaWall object](https://forum.vectorworks.net/index.php?/files/file/110-nanawall-wa67/?%20utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=marrionettemon022618) simulates the [WA67 Aluminum Clad Wood Folding NanaWall door](https://www.nanawall.com/products/wa67) — a popular architectural feature in the western part of the US. Users can set the walls to be any length, as well as set the width and height of the panel sides.

## Object 2: Scissor Lift

![Scissor Lift.png](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/180226_Marionette%20Mon%20Lifts%20Cranes%20NanaWall/Scissor%20Lift.png?width=1024&name=Scissor%20Lift.png)_Scissor lift Marionette symbol._

[This scissor object](https://forum.vectorworks.net/index.php?/files/file/108-scissor-lift/?%20utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=marrionettemon022618) is meant to look automated and includes different symbols for each different part of the lift. Users can place this symbol in their drawings and set the height via a slider in [the Object Info palette](http://app-help.vectorworks.net/2018/eng/VW2018%5FGuide/Objects%5Fedit1/The%5FObject%5FInfo%5FPalette%5FData%5FTab.htm?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=marrionettemon022618).

## Object 3: JLG Condor Lift

**![JLG Condor Lift.png](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/180226_Marionette%20Mon%20Lifts%20Cranes%20NanaWall/JLG%20Condor%20Lift.png?width=1024&name=JLG%20Condor%20Lift.png)**

_JLG Condor lift Marionette symbol._

[The JLG Condor lift object](https://forum.vectorworks.net/index.php?/files/file/109-jlg-condor-60/?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=marrionettemon022618) is a type of articulating boom lift with seven different rotation or extension articulations. Users can place different parts of the lift as symbols in their drawings, and then set the angle for each different articulation via a slider in the Object Info palette.

_Special thanks to [Vectorworks Spotlight ](http://www.vectorworks.net/spotlight?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=marrionettemon022618)_ _user Scott Barnes, lighting console programmer and owner of_ [_i-light design_](https://www.instagram.com/ilight2000/)_, for creating the two lift symbols that form the basis of the second and third objects featured in this post._

### Want to know more about Marionette objects in Vectorworks software?

**[![Check out the Marionette Space in the Vectorworks Forum](https://no-cache.hubspot.com/cta/default/3018241/df7189e6-c627-4cdd-9e45-32befa4fe7a1.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/df7189e6-c627-4cdd-9e45-32befa4fe7a1)** 

 Topics: [Tech Tips and Workflows](https://blog.vectorworks.net/topic/tech-tips-and-workflows), [Production & Lighting Design](https://blog.vectorworks.net/topic/production-lighting-design) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.