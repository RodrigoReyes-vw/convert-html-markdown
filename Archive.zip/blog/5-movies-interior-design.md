[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# 5 Films to Inspire Great Interior Design

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/211015_ARCH%20Signature%20Project/21_AICB%20Building_A1-S03-10.jpeg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2F5-movies-interior-design)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=5%20Films%20to%20Inspire%20Great%20Interior%20Design&url=https%3A%2F%2Fblog.vectorworks.net%2F5-movies-interior-design&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2F5-movies-interior-design)

As awards season approaches, many great films are coming to the silver screen. _Belfast_, _King Richard_, _Dune,_ and _tick, tick … Boom!_ are all making headlines. But, there are plenty of already-released movies that we think every designer should check out.

In this post, we’ll discuss five movies with great interior design. 
1. _The Grand Budapest Hotel_
2. _The Shining_
3. _Her_
4. _The Great Gatsby_
5. _Parasite_

## Wes Anderson’s _The Grand Budapest Hotel_

Any of Wes Anderson’s films could have been included in this list. Films like _The French Dispatch, Fantastic Mr. Fox_, and _The Royal Tenenbaums_ are so unique and visually dense that the word “quirky” — which is often used to describe Anderson’s aesthetic — doesn’t do them justice.

However, it’s [_The Grand Budapest Hotel_](https://www.youtube.com/watch?v=mXRztrOK47I) that’s the ripest for design inspiration.

Since the movie takes place in two decades, the 1930s and 1960s, we’re able to see how color, layout, and other design elements can make the same space feel completely different.

In the 1930s, the hotel is accented with rich purples and powerful reds. It feels regal, charming, and cozy.

In the 1960s, on the other hand, the hotel is more corporate and sterile, with a color scheme that somehow feels more dated than the one used 30 years before.

“The set design really captures the transition between the 1930s and 1960s design style, down to every last detail like color and textiles,” said Nicole Cave, interior designer, BID.

## Stanley Kubrick’s _The Shining_ 

Maybe there’s just something about hotels in film.

Much like The Grand Budapest Hotel, [_The Shining_](https://www.youtube.com/watch?v=S014oGZiSdI)’s Overlook Hotel is just as much a character in the film as any of the actors. The hotel is absolutely iconic, namely the geometric carpet that grounds the hallways of the hotel.

The wild pattern is a testament to the power of taking a risk with your design. “When designing, taking risks with colorful textiles and wallpaper — like in _The Shining_ — can really make your design pop,” said Cave. “In this film, you see plain walls with a very bold carpet choice in the main hallway. This makes the space feel more lively.”

Remember: all work and no play makes you a dull designer.

## Spike Jonze’s _Her_

There’s plenty of futuristic, ultra-modern design that you can find in movies. And even though Spike Jonze’s [_Her_](https://www.youtube.com/watch?v=ne6p6MfLBxc) takes place in the future, its fashion and design are more retro than they are science fiction.

If you’re into mid-century modern trends, you’re sure to love the design of this movie. Specifically, Joaquin Phoenix’s character’s bright and colorful office. “The bold choice of color used in the office space makes for a fun and bright atmosphere,” remarked Cave.

Ultimately, _Her_’s interior design is a reminder of how cyclical design can be. The styles of yesterday are sure to be the trends of tomorrow.

## Baz Luhrmann’s _The Great Gatsby_

Based on one of the most stylish novels of all time, [_The Great Gatsby_](https://www.youtube.com/watch?v=nIewKn6EnAs) should be your go-to reference for a lavish design.

_Gatsby_ features dramatic lighting, flowers, and an epic amount of detail that all work together to exude opulence. “_The Great Gatsby_ captures the connection between a luxurious lifestyle and luxurious design,” said Cave. “This can be seen in the architectural elements, and the choice in grand textiles.”

Even the gold pattering on the film’s movie poster is striking enough to kick start your next design project in [Vectorworks Architect](https://www.vectorworks.net/architect).

## Bong Joon-ho’s _Parasite_

Like the hotels of _Grand Budapest_ and _The Shining_, the homes in _[Parasite](https://www.youtube.com/watch?v=5xH0HfJHsaY)_ are not just where the story takes place, but important parts of the story itself.

The Kim family’s small, dark, and partially underground home is in stark contrast to the modern, bright, and spacious home of the Park family. This difference helps tell Bong Joon-ho’s story of classism.

While the sleek, modern lines of the Park family’s home _is_ really beautiful, what you should take with you into your next project is how thoughtful, intentional design can help tell a great story. “Every space is unique, and each project should tell their own story. Just like the homes in _Parasite_,” Cave said.

If you’re wanting _even more_ interior design inspiration, click the button below to check out “Top 6 Netflix Shows for Interior Design Inspiration.”

[![TOP 6 DESIGN NETLFIX SHOWS](https://no-cache.hubspot.com/cta/default/3018241/9dfe98b8-3713-404c-86c9-64b991cad020.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/9dfe98b8-3713-404c-86c9-64b991cad020) 

_The mentioned films are rated PG-13 or R. Viewer discretion is advised._

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.