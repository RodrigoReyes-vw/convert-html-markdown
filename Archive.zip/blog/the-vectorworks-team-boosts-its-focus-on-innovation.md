[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# The Vectorworks Team Boosts its Focus on Innovation

 Posted by [Chloe Jefferson](https://blog.vectorworks.net/author/chloe-jefferson) | 4 min read time 

![P1133382.jpg](https://blog.vectorworks.net/hubfs/P1133382.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fthe-vectorworks-team-boosts-its-focus-on-innovation)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=The%20Vectorworks%20Team%20Boosts%20its%20Focus%20on%20Innovation&url=https%3A%2F%2Fblog.vectorworks.net%2Fthe-vectorworks-team-boosts-its-focus-on-innovation&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fthe-vectorworks-team-boosts-its-focus-on-innovation)

While [Vectorworks](http://www.vectorworks.net/?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=fallinnovationexpo110917) fosters a culture of innovation throughout the year, once in a while it helps to give even the most deep-rooted tenets a boost. Last week, the Vectorworks team gathered together for our Fall Innovation Expo. This event consisted of keynotes, presentations, and interactive workshops that were meant to inspire new ideas for products and services the company can potentially create for our users. By the end of the week, team members from all departments collaborated and shared their innovative ideas in over 35 group and individual presentations.

The Expo kicked off with some inspiring words from our CEO, Dr. Biplab Sarkar, who announced the grand challenge: to create a brand-new product using technology from our existing software and resources. "Innovation is what sets us apart from the competition,” said Sarkar, before passing off the mic to [Dr. Darin Eich](http://darineich.com/), our innovation facilitator. Eich is a keynote speaker who provides leadership and innovation workshops and seminars for associations and conferences.

![P1133501.jpg](https://blog.vectorworks.net/hs-fs/hubfs/P1133501.jpg?width=640&name=P1133501.jpg)

_Darin Eich (top left) during one of our various workshops_

During the expo, Eich took us through an innovation program that was centered around interactive workshops. The workshops were designed to take groups through the idea development process by systematically tackling a challenge relevant to us. In our case, we wanted to “Seek to Understand,” or use our design thinking to reiterate how important it is for us to always be thinking about our customers and what they want to see from our company in the future.

![P1133382.jpg](https://blog.vectorworks.net/hs-fs/hubfs/P1133382.jpg?width=620&height=465&name=P1133382.jpg)

_Iskra Nikolova, quality assurance specialist, brainstorming with her workshop group_

The training sessions with Eich involved a little bit of lecture, but the majority of time was spent on interactive workshops that helped warm up our innovation thinking caps.

Dave Donley, director of product technology and the Fall Innovation Expo organizer, was extremely happy with the outcome of this event. “You look around the room now and see dozens of posters filled with innovative ideas,” he said. “Throughout the entire expo, you could feel the optimistic energy in the room as our company worked on the next big thing.”

![P1133569.jpg](https://blog.vectorworks.net/hs-fs/hubfs/P1133569.jpg?width=620&height=465&name=P1133569.jpg)

_Dave Donley, Vectorworks director of product technology_

We also heard from Principle Architecture’s Daniel Irvine, an architect who has worked in a curatorial, design, and conceptual capacity on several critical projects about Vancouver’s built landscape. He is involved in community, institutional, and civic architecture and exhibition design, and was one of our many speakers at this year's [Vectorworks Design Summit.](http://www.vectorworks.net/design-summit?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=fallinnovationexpo110917)

During his keynote, Irvine discussed his experience using Vectorworks when designing the “[Vancouver Transformations](http://principlearchitecture.ca/work/#/wood-exhibition/)” project, in which his firm designed a museum exhibit that explores the history of Vancouver through its relationship with wood. Our software allowed him to share a clear visual of the project with his clients, and his team used our Marionette graphical scripting capabilities to efficiently navigate the many iterations that arose during the design process. “It was like having a robot friend doing the work you dread,” said Irvine, regarding his seamless design process.

![Screen Shot 2017-11-08 at 10.36.53 AM.png](https://blog.vectorworks.net/hs-fs/hubfs/Screen%20Shot%202017-11-08%20at%2010.36.53%20AM.png?width=620&height=629&name=Screen%20Shot%202017-11-08%20at%2010.36.53%20AM.png)

_Daniel Irvine, intern architect at Principle Architecture, during his keynote speech_

During a lunch-and-learn event, the Vectorworks team also had the pleasure of meeting with Virginia artist [Heather Clark,](http://www.biomestudio.com/) who works at the intersection of design, technology, and innovation. Clark has worked on design projects in the [Frederick](http://www.skystagefrederick.com/), D.C., and Virginia areas, all related to the human relationship to the built environment, sustainability, and energy efficiency.

The last day of the expo showcased presentations from Vectorworks groups and individuals. Some ideas had been marinating for months, while others were sparked during the facilitated workshops earlier in the week.

![P1133380.jpg](https://blog.vectorworks.net/hs-fs/hubfs/P1133380.jpg?width=620&height=465&name=P1133380.jpg)

_A group of Vectorworks employees working on their presentation_

Overall, the Fall Innovation Expo was a huge success. Employees from every department had a chance to share innovative ideas they believe will better the company and our customers, and it was a great way to refresh the culture of innovation we nurture year round.

[![Be sure to check #VectorworksInnovation to see what we’ve been up to.](https://no-cache.hubspot.com/cta/default/3018241/655b5fd5-1b30-40cd-b924-0b297d8f2d64.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/655b5fd5-1b30-40cd-b924-0b297d8f2d64) 

 Topics: [Tech Tips and Workflows](https://blog.vectorworks.net/topic/tech-tips-and-workflows) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.