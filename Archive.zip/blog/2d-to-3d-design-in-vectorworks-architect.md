[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# From Sketch to BIM — All in Vectorworks

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/080521_SketchToBIM/blog-1440x800-6.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2F2d-to-3d-design-in-vectorworks-architect)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=From%20Sketch%20to%20BIM%20—%20All%20in%20Vectorworks&url=https%3A%2F%2Fblog.vectorworks.net%2F2d-to-3d-design-in-vectorworks-architect&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2F2d-to-3d-design-in-vectorworks-architect)

In an architect’s workflow, easy access to the right tools makes all the difference. So, why spread them out? Why leave your tools scattered across several applications?

Perhaps, you’re currently drafting in AutoCAD, designing in SketchUp, and using Revit for BIM. This siloed approach adds extra steps — and therefore, time — to your design process. The more time it takes ultimately means more time before a rendering or presentation package is in your client’s hands, as well.  

But by using [Vectorworks Architect](https://www.vectorworks.net/en-US/architect), an all-in-one design program, you can go from 2D sketches to 3D BIM in just one place! You’ll find true freedom in your design process, from start to finish.

## 2D to 3D Design — All in Vectorworks

Sketching in 2D is a great way to begin your most exciting, creative ideas. Even the greatest designs begin with just a simple line, shape, or drawing on a piece of paper. In Vectorworks, you can sketch with limitless potential or import your early hand drawings to kick off the design file.

Once you have your 2D sketches, Vectorworks makes it easy to make your ideas come to life as 3D models. You have so many possibilities when making these models. [You can create solid models, sculpt curves, and so much more](../../../net/vectorworks/blog/the-best-3d-modeling-for-interior-architecture.html)!

![sketch-to-BIM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/080521_SketchToBIM/blog-1440x800-6.png?width=665&name=blog-1440x800-6.png)

Simply push and pull your 2D geometry to make them solid models.These 3D modeling tools are useful in creating massing models and objects like shelves, tables, detailed moulding, and other basic geometry.

If your design requires curved details, take it to the next level using NURBS or subdivision modeling. NURBS (Non-uniform Rational Basis Spline) modeling in Vectorworks is a way to create curvy, fluid objects that can be controlled precisely from a singular point that lies on the design’s geometry, allowing the object to be documented precisely.

![nurbs5](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/080521_SketchToBIM/nurbs5.jpeg?width=525&name=nurbs5.jpeg) ![Infinito Seating Bench](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/080521_SketchToBIM/Infinito%20Seating%20Bench.png?width=528&name=Infinito%20Seating%20Bench.png) 

Build soft cushions, art pieces, or whatever you can imagine with subdivision modeling. This modeling can let you follow your ideas far outside of the rigid confines of solid modeling. When using subdivision modeling, you’re able to manipulate a cage around the geometry, not just control points attached to the geometry like with NURBS.

And, if you need to embed data into your model styles, you have parametric objects at your disposal in Vectorworks. You can design walls, slabs, doors, and other objects that can easily be used for BIM documentation. Plus, reports and worksheets are dynamically linked to geometry, so documentation is really simple.

## BIM Documentation and Collaboration

You may not associate [BIM](https://www.vectorworks.net/en-US/architect/bim) with creativity, but the two ideas find harmony in Vectorworks. For example, a sinuous NURBS object is easily documentable thanks to the near-automatic documentation that comes with an advanced BIM software. This process then frees up time for you to express your true creativity.

BIM documentation in Vectorworks also allows for better collaboration. You can easily share all your ideas and important data with anyone involved in the build through common file sharing formats like DWG, RVT, and IFC.

So, if you’re keeping track, you can complete your _entire_ workflow in Vectorworks. The moment you’re inspired, you can swiftly and expressively sketch. From here, bring your objects to life with a variety of 3D modeling capabilities. And, your data will be documented in real-time with BIM processes.

[![SIMPLIFY MY WORKLFOW](https://no-cache.hubspot.com/cta/default/3018241/1b53fbc3-11c1-4bdf-aaea-e2b312a232c5.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/1b53fbc3-11c1-4bdf-aaea-e2b312a232c5) 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.