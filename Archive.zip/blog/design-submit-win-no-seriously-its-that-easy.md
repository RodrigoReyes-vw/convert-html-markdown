[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Design. Submit. Win. — No, Seriously, It’s That Easy

 Posted by [Leslie Briggs](https://blog.vectorworks.net/author/leslie-briggs) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/5236_2011-scholarship-announcement-blog-post-image-opti.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fdesign-submit-win-no-seriously-its-that-easy)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Design.%20Submit.%20Win.%20—%20No,%20Seriously,%20It’s%20That%20Easy&url=https%3A%2F%2Fblog.vectorworks.net%2Fdesign-submit-win-no-seriously-its-that-easy&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fdesign-submit-win-no-seriously-its-that-easy)

You put your all into your schoolwork, so why not get rewarded for it?

We’re not just talking about an A on a project, either. The prize for the annual Vectorworks Design Scholarship is up to $10,000 USD, professional recognition, and an addition to your resume that proves your designs are a step above the rest.

![5236_2011-scholarship-announcement-blog-post-image-opti](https://blog.vectorworks.net/hs-fs/hubfs/5236_2011-scholarship-announcement-blog-post-image-opti.jpg?width=731&name=5236_2011-scholarship-announcement-blog-post-image-opti.jpg)

Starting on December 1, the Vectorworks Design Scholarship opens for undergraduate and graduate students all over the world in [majors](https://www.vectorworks.net/scholarship/resources?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=120120scholarship) related to architecture, landscape architecture and design, entertainment, and interior design fields to submit recent, completed work. You can submit your designs until March 31, 2021, at which point they will go through two rounds of review by our esteemed panel of judges. [Judging criteria](https://www.vectorworks.net/ebooks/scholarship-rubric-eng-us?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=120120scholarship) are as follows:

* Design
* Technology
* Concept & originality
* Presentation, and
* Communication of design vision.

Sounds pretty easy, right?

All you have to do now is complete the simple application. Give us a quick description of the heart of your individual or group project and attach your work. After that, you can relax until winners are announced on June 16, 2021.

First-round winners in the US will receive $3,000 USD\* for tuition, fees, housing, textbooks, you name it — if it’s for school it likely qualifies! Not to mention you’ll also benefit your classmates by winning _free_ [Vectorworks design software](https://www.vectorworks.net/designer?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=120120scholarship) for your school and free virtual training for faculty and students.

First-round winners will then be automatically entered into the second round where they may win the grand prize Richard Diehl Award, which is an additional $7,000 USD and the added design software for their school and training for faculty and students.

“I entered the Vectorworks Design Scholarship to demonstrate my ability to design a stage, present it with clarity, create video content, find audio tracks and show off all my skills in software like After Effects, Vision, and MAonPC,” said Kristopher Clemson, founder of [Bifröst Lighting LLC](http://www.bifrostlighting.com/) and last year’s first entertainment [Richard Diehl award winner](https://www.vectorworks.net/scholarship/past-winners?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=120120scholarship).

“Winning the scholarship helped to get my career started and I encourage all students to enter the contest because not only is the scholarship money helpful, but it’s also an amazing opportunity to get your foot in the door into your industry, whether you attend a well-known school or not.”

Connect with us on social media using the #FundMyVision hashtag.

Why waste another second?

[![START YOUR APPLICATION](https://no-cache.hubspot.com/cta/default/3018241/0a71ff29-efb5-4c47-b62a-e191eb4a06a2.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/0a71ff29-efb5-4c47-b62a-e191eb4a06a2) 

\*First-round localized prize amounts may apply in countries outside of the US. Please check the [scholarship webpage](https://www.vectorworks.net/scholarship?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=120120scholarship) for more details.

 Topics: [Vectorworks Design Scholarship](https://blog.vectorworks.net/topic/vectorworks-design-scholarship) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.