[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# An Introduction to Annotation with Data Tags

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Data%20Tag%20Layout%20Constraints.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fwhat-you-need-to-know-about-using-data-tags-in-vectorworks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=An%20Introduction%20to%20Annotation%20with%20Data%20Tags&url=https%3A%2F%2Fblog.vectorworks.net%2Fwhat-you-need-to-know-about-using-data-tags-in-vectorworks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fwhat-you-need-to-know-about-using-data-tags-in-vectorworks)

The annotation capabilities in Vectorworks software go beyond just labeling. These capabilities are referred to as “smart markers” because often, they’re dynamically linked to the objects they’re labeling, meaning an update to one also updates the other.

Data tags, for example, are truly a game-changer when it comes to managing and displaying data in your projects. They not only save you time by automatically pulling existing data from objects, but they also offer an unparalleled level of customization. With the ability to create custom data tag styles, add constraints, and report formulas, the possibilities are endless.

Let’s explore what you can do with data tags.![Data Tags in a Plan Drawing](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2024%20Blog%20Images/4_Data%20Tags/Data%20Tags%20in%20a%20Plan%20Drawing.png?width=1606&height=1232&name=Data%20Tags%20in%20a%20Plan%20Drawing.png)

#### The Versatility of Data Tags

###### Reusability

Data tags can be used as generic labels or as object-specific labels. In either case, you can save a data tag style to your Resource Manager for reuse on future projects. By saving a data tag as a resource, you can share it across your entire office, making the documentation process more efficient and ensuring consistency from project to project.

![Data Tag Default Content](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2024%20Blog%20Images/4_Data%20Tags/Data%20Tag%20Default%20Content.png?width=2118&height=1216&name=Data%20Tag%20Default%20Content.png)

###### Customization

You can easily tailor data tags to suit your needs. Vectorworks’ wide range of default data tag styles is likely to contain options that suit your project requirements. However, if you’re looking for additional customization, you have plenty to choose from.

You’re able to customize the layout of data tags by taking advantage of the full spectrum of object attributes such as color fill, gradients, opacity, drop shadows, and line type, which truly make your documentation pop.

![Data Tag with Drop Shadow](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2024%20Blog%20Images/4_Data%20Tags/Data%20Tag%20with%20Drop%20Shadow.png?width=2138&height=1084&name=Data%20Tag%20with%20Drop%20Shadow.png)

[To create your own data tag style](https://app-help.vectorworks.net/2024/eng/VW2024%5FGuide/Annotation2/Creating%5Fdata%5Ftag%5Fstyles.htm?rhsearch=dynamic%20text&rhhlterm=dynamic%20text), either duplicate an existing style to customize or create an entirely new one with the **Create Data Tag Style** command. To use this command, simply select an object, go to the Tools menu, and select **Create Data Tag Style**. A dialog box will appear with all the objects relevant data listed. Select the information you want to report, format it with labels and geometry, then click OK.

![Create Data Tag Style Command](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2024%20Blog%20Images/4_Data%20Tags/Create%20Data%20Tag%20Style%20Command.png?width=2826&height=2098&name=Create%20Data%20Tag%20Style%20Command.png)

###### Intelligence & Automation

One of the key benefits of data tags is their ability to dynamically interact with the data they’re reporting. This allows you to make changes to your object and see the change reflected faithfully in the linked text of the data tag. To accomplish this, create a Dynamic Text object by selecting text and clicking **Use Dynamic Text** in the **Object Info palette** (OIP). Once your text object is dynamic, you can edit the dynamic text to report specific data from the object, as well as format that data to report the way you want.

Additionally, when you select a data tag associated with an object, that object will become highlighted, allowing you to visually identify the object you’re annotating.

###### Report Anything

You can use data tags to annotate any type of information imaginable, including formulas and formatted data. Other data sources they can pull include record formats and IFC data, meaning no matter how you choose to embed data into an object, you’re able to take advantage of the power of data tags. You also have the option to push data back to an object, such as formulas, incrementing values, and manually entered data.

#### Level Up Your Annotation Skills

To learn more about annotating your project documentation with data tags, check out our free guide that details an entire data tags workflow on Vectorworks University.

[![LEVEL UP WITH DATA TAGS](https://no-cache.hubspot.com/cta/default/3018241/9cdeed7c-6ad5-434e-bc1d-c08327921b11.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/9cdeed7c-6ad5-434e-bc1d-c08327921b11) 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.