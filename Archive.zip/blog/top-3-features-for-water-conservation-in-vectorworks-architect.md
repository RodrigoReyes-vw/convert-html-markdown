[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Water Management 101 in Vectorworks Architect

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2023%20Blog%20Images/5_BLDG%20Water%20Conservatin/Screenshot%202023-05-12%20at%2011.26.49%20AM.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Ftop-3-features-for-water-conservation-in-vectorworks-architect)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Water%20Management%20101%20in%20Vectorworks%20Architect&url=https%3A%2F%2Fblog.vectorworks.net%2Ftop-3-features-for-water-conservation-in-vectorworks-architect&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Ftop-3-features-for-water-conservation-in-vectorworks-architect)

Architects hold a crucial role in designing structures that cater to the needs of clients while also contributing towards the betterment of the environment.

With the world's pressing issue of water scarcity, it’s vital to explore methods in which we can conserve this valuable resource. Thankfully, Vectorworks design software contains a range of features that aid in reaching this goal.

In this article, you’ll read about three Vectorworks features you can put to work to design for water conservation in your projects.

#### FEATURE #1 – Content Libraries

One way you can have an impact on the environment is by selecting water-efficient plumbing fixtures and systems to go into the building. With Vectorworks, you can find tons of symbol resources within the Resource Manager such as toilets, showerheads, faucets, dishwashers, and washing machines.

The Resource Manager contains plenty of eco-friendly appliances that you can easily insert into your projects. But how do you include and document important information such as water consumption for these fixtures?

Custom records can be attached to your symbols to accurately report that information. 

#### FEATURE #2 – WORKSHEETS 

If you're designing to meet specific goals for a sustainable or green building, reporting project data is crucial. To do this accurately, take advantage of worksheets in Vectorworks.

With worksheets, you can calculate the total water use of the building by quantifying the number of plumbing fixtures and multiplying by the water-use values determined by the custom record of each fixture.

One way you can use worksheets is to report on roof area and annual/monthly rainfall. This prepares you to design more effective water harvesting systems. François Lévy used this method to determine the necessary sizes for water-catching basins in his webinar, “Sustainable Resources for Small-Scale BIM.”

![mikes house 4](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/5_BLDG%20Water%20Conservatin/mikes%20house%204.png?width=906&height=700&name=mikes%20house%204.png)

If you’re looking for ways to work better with data in Vectorworks, our post, “[3 Ways to Maximize Your Data Use for BIM](../../../net/vectorworks/blog/3-ways-to-maximize-data-for-bim-vectorworks.html),” has you covered.

#### FEATURE #3 – SITE MODELING

One of the most impactful design strategies for water conservation is related to the project’s site. We’ve already mentioned harvesting rainwater, and there’s a lot more you can do regarding the site, especially using Vectorworks’ site modeling tools.

You can find more information about [sustainable site design in this blog post](../../../net/vectorworks/blog/tips-for-saving-water-increasing-water-quality.html).

![Screenshot 2023-04-28 at 2.20.16 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/5_BLDG%20Water%20Conservatin/Screenshot%202023-04-28%20at%202.20.16%20PM.png?width=5120&height=2680&name=Screenshot%202023-04-28%20at%202.20.16%20PM.png)

By modeling the site to mitigate water runoff, you can make the site more water efficient. You can do this by using bioswales, berms, and other methods explored in our free course, “[Integrating Design Technology for Water-Efficient Landscapes](https://university.vectorworks.net/mod/scorm/player.php?scoid=1124&cm=2595&currentorg=articulate%5Frise).”

#### BONUS TIP – OPTIMIZING BUILDING ORIENTATION

We just couldn’t conclude this post without mentioning building orientation. It’s not quite a Vectorworks feature all on its own, but it’s a topic worth mentioning.

A building’s position on the site can play a big role in its water efficiency. Optimizing the building’s orientation reduces the necessary size of heating and cooling systems, which will reduce overall water consumption and, of course, energy consumption. You can use the Heliodon tool to create solar animations to accurately account for sun patterns in your design.

Looking for more tips about designing sustainable buildings with Vectorworks Architect? Meet your goals with early-phase energy modeling, which you can learn more about below.

[![LEARN MORE](https://no-cache.hubspot.com/cta/default/3018241/749fa1cb-4e39-4dc0-9f19-80b6cb661c0a.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/749fa1cb-4e39-4dc0-9f19-80b6cb661c0a) 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.