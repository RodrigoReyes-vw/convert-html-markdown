[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Designing for the UK's Biggest Music Festivals

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 6 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/221026_Ben%20Instep%20Siyan/Siyan_BBC_blog-1440x800.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fwhy-you-should-use-mvr-siyan-bbc-radio-festival)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Designing%20for%20the%20UK's%20Biggest%20Music%20Festivals&url=https%3A%2F%2Fblog.vectorworks.net%2Fwhy-you-should-use-mvr-siyan-bbc-radio-festival&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fwhy-you-should-use-mvr-siyan-bbc-radio-festival)

Ben Inskip, the designer for the UK-based lighting rental company, [Siyan](https://siyan.co.uk/), is something of a [Vectorworks Spotlight](https://www.vectorworks.net/spotlight) superfan, sharing his use of the software with everyone in his firm.

He's expanded his firm's use of Vectorworks Spotlight and My Virtual Rig (MVR,) [the open-file-format developed by the GDTF Group](https://gdtf-share.com) for the seamless transfer of your 3D model and fixtures from Vectorworks to previz applications and lighting consoles, across the firm.

This expanded use makes for a much more collaborative environment according to Inskip, "We're all on the smae page now, so our video deparment or riggers can hop into a file and add their contributions. All our output comes from one project file so it's consistent."

Continue reading to learn how Ben Inskip uses Vectorworks Spotlight on projects like BBC Radio 1’s Big Weekend and eight stages across the Reading & Leeds festival. and other Vectorworks features to design more efficiently than ever before!

#### File Referencing for Quick Updates

One of the ways Inskip and his colleagues save time drafting massive shows and festivals is by using Spotlight’s file referencing capabilities alongside Siyan’s favorites library.

The designers upload title blocks, sheets, and even symbol objects from said favorites library to all of their designs, and — if Inskip wants to make any changes to these elements — the changes are automatically made in every single file. According to Inskip, this process saves him and his team lots of time, especially with making minor tweaks to festival designs that they do year after year — like BBC Radio 1’s Big Weekend and eight stages across the Reading & Leeds festival.

![bw 1.13-2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221026_Ben%20Instep%20Siyan/bw%201.13-2.jpg?width=1440&height=1200&name=bw%201.13-2.jpg)

#### Algorithms-Aided Design to Automate Parts of a Lighting Design Workflow

Alongside file referencing, the team at Siyan have also been experimenting with Marionette as a time-saving practice. “I love it!” Inskip exclaimed as he shared how he and his team members use the feature set to reclass components of their designs. “I can write code, but Marionette makes complex automations accessible and speeds up tasks for the whole team.”

[Marionette, if you’re unfamiliar, is a algoritms-aided design tool used to procedurally generate unique objects or functions based on a user-defined script](../../../net/vectorworks/blog/what-is-marionette-a-look-at-vectorworks-algorithmic-modeling-tool.html). An algorithm in a program like Marionette is best used when trying to automate an otherwise tedious process, like the reclassing that Siyan uses it for.

![2021-08-29-Siyan-Reading-Festival-24_No Credit Needed](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221026_Ben%20Instep%20Siyan/2021-08-29-Siyan-Reading-Festival-24_No%20Credit%20Needed.jpg?width=1440&height=960&name=2021-08-29-Siyan-Reading-Festival-24_No%20Credit%20Needed.jpg)

Just like Grasshopper or Dynamo, Marionette is a way to bring greater automation and customization to its parent software. Unlike traditional text-based scripting, Marionette uses a _graphical_ scripting interface, meaning you don’t need to know a scripting language to use it.

Algorithms-aided design is a great way to expedite a workflow. It’s as easy as defining your criteria with a default library of easy-to-understand nodes or creating your own custom nodes.

[\-> CLICK HERE TO LEARN MORE ABOUT MARIONETTE](https://university.vectorworks.net/mod/scorm/player.php?a=360&currentorg=articulate%5Frise&scoid=720)

#### Using MVR to Design Like Never Before

A third way Inskip has modernized his design process is with the MVR file format, which he began using at the same time he started in Vectorworks Spotlight.

MVR is an open-file-format container that packages the GDTF files for all of the lighting fixtures in your design, along with a complete 3D model and data describing the positions and 3D elements. This allows you to easily conduct your previz with Vision and communicate directly from your Vectorworks design to your console.

![Screenshot 2022-10-22 at 14.03.59](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221026_Ben%20Instep%20Siyan/Screenshot%202022-10-22%20at%2014.03.59.png?width=1440&height=903&name=Screenshot%202022-10-22%20at%2014.03.59.png)

The Siyan team use the file format to share their designs from Vectorworks with [Depence](https://www.syncronorm.com/multimedia-fountain-control-visualization) and a [GrandMA3 console](https://www.malighting.com/grandma3/).

“It was appealing to say, ‘Alright, I can export this one file and it can go straight into Depence and MA.’ And, with a few tweaks, I have console control of my rig in a visualizer and I can start programming or creating presentation material.”

#### Why You Should Also Be Using MVR

In 2018, Vectorworks partnered with [MA Lighting](https://www.malighting.com/) and [Robe](https://www.robe.cz/) to bring to the industry a new open-standard format known as the General Device Type Format (GDTF). The format has really taken off, with unified support from many of the biggest brands in the entertainment industry.

[\-> RELATED: WHY WE SUPPORT GDTF AND MVR](../../../net/vectorworks/blog/why-vectorworks-gdtf-mvr.html)   

To build on that momentum, we introduced MVR, the file format Inskip and [countless other world-class designers have started to use](https://gdtf-share.com/news/2022%5F10%5F10%5FAn%5FAbsolute%5FGame%5FChanger%5FHow%5FGDTF%5FRevolutionized%5Fa%5FDesigners%5FWorkflow). 

Your individual GDTF files are packaged together, along with your entire Vectorworks design, to create an MVR file. With MVR, you can easily transfer all the information and geometry of your design to a previz app and a control console that uses an on-board visualizer.

MVR has everything packed into the file, so you — and ultimately the production you're working on — won't have to be bogged down by extra files and folders, saving you time and letting you move on to your next project. 

Watch the following video to learn more about the game-changing file format:

If you enjoyed this story, and you want to learn more about how the MVR file formats can revolutionize your design workflow, click below:

[![STREAMLINE YOUR WORKFLOW WITH MVR](https://no-cache.hubspot.com/cta/default/3018241/1ce322de-8988-4d95-aa80-87bf0484ca06.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/1ce322de-8988-4d95-aa80-87bf0484ca06) 

_All images courtesy of Ben Inskip and Siyan._ 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.