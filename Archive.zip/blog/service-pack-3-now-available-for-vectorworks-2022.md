[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Service Pack 3 Now Available for Vectorworks 2022

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/2108-launch-email-header-general-2x-Aug-26-2021-08-26-37-42-PM.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fservice-pack-3-now-available-for-vectorworks-2022)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Service%20Pack%203%20Now%20Available%20for%20Vectorworks%202022&url=https%3A%2F%2Fblog.vectorworks.net%2Fservice-pack-3-now-available-for-vectorworks-2022&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fservice-pack-3-now-available-for-vectorworks-2022)

This year’s third service pack update introduces some exciting functionality to [Vectorworks 2022](../../../net/vectorworks/blog/vectorworks-2022-now-available-for-download.html) and Vectorworks Cloud Services.

The updates focus on re-engineering of web viewing and the Nomad app, new storage integrations with the Vectorworks Cloud, updates to Datasmith file exchange for a direct link to Twinmotion, and support for .gITF within the MVR export from Vectorworks Spotlight.

The service pack is available as a downloadable update for all U.S. English-based versions of Vectorworks 2022\. To install, select “Check for Updates” from the Vectorworks menu (Mac) or Help menu (Windows). You can update the Nomad app through the Apple App Store or the Google Play store. Contact [tech@vectorworks.net](../../../net/vectorworks/blog/index.html) with any technical questions.

Read on for more information about these updates!

## Significant Re-Engineering Provides a Better Experience on Cloud and Mobile Platforms

Vectorworks Nomad and the web view feature in Service Pack 3 employ the Unity platform for some game-changing new functionality. This enables a consistent interface and access to all the same features whether using Nomad's 3D model viewer or exporting a web link.

### Developer’s Comment:

| This has allowed us to implement critical improvements that deliver powerful 3D and AR viewers through Nomad and enhanced 3D model viewing and navigation through Vectorworks’ web view. We’re excited to bring these updates to you and provide you with amazing performance boosts for large, complex design models for better presentations and interactive experiences. |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |

Additional Cloud Services updates include:

* Key enhancements to Vectorworks Cloud Services include a new storage integration with OneDrive, improved integrations with Google Drive, and a direct connection from the Nomad mobile app to the iOS Files app. You can now access and process files directly from your preferred cloud storage solution, making it easier to work with existing file structures.
* Region-specific cloud storage will improve Cloud sync speeds, file upload speeds, and download speeds. This also enables EU-based customers to comply with GDPR data residency requirements.
* [Redshift render styles](../../../net/vectorworks/blog/renderworks-renderings-powered-by-maxon.html) are now available when processing file renderings in the Vectorworks Cloud.
* The latest LIDAR technology in iOS devices can now be used to scan and produce point clouds from your mobile devices.

## **Simplified Direct Link with Twinmotion for Time Savings in Syncing Model Changes**

Until this service pack release, syncing changes to the Vectorworks model with the Twinmotion render didn't happen in real time. This update to the Datasmith Direct Link tool in Vectorworks means you can now immediately send model changes to Twinmotion in real time with the Auto Sync option.

Additionally, the Datasmith export now supports data and light information in the Unreal Engine editor for more data-rich and detailed models.

[Read more about the link between Vectorworks and Twinmotion](../../../net/vectorworks/blog/your-guide-to-rendering-with-twinmotion.html).

Vectorworks customers can get a FREE Twinmotion license through March 31, 2022\. See this offer and others by visiting the [Vectorworks customer portal](https://sso.vectorworks.net/accounts/login/?next=https%3A//customers.vectorworks.net/offers%3FhsCtaTracking%3Dfb3c4578-6886-4f1a-8381-b8a9d42b8b46%257C4ecdfeef-60dd-4eb0-bec8-37c22338f59e).

## Stay on the Cutting Edge of Entertainment Project Workflows with .gITF Support

Supporting the latest .gITF/.glb file format modernizes [MVR workflows](../../../net/vectorworks/blog/why-vectorworks-gdtf-mvr.html) and allows you to meet DIN Spec 15800:2022 standards.

The update also broadens the adoption of the MVR file format for a wider opportunity for collaboration and easy project information exchange.

Service Pack 3 also includes several updates to entertainment workflows:

* Workflow enhancements for ConnectCAD
* Additional quality fixes for Vectorworks Spotlight
* Support for PosiStageNet (PSN) in Vision

You can read more about these fixes in the [tech bulletin](https://forum.vectorworks.net/index.php?/articles.html/articles/tech-bulletins/vectorworks-2022-sp3/).

## Download Service Pack 3 Today

The service pack is available as a downloadable update for all U.S. English-based versions of Vectorworks 2022\. To install, select “Check for Updates” from the Vectorworks menu (Mac) or Help menu (Windows). Check the tech bulletin for more information on Service Pack 3.

[![Read the Tech Bulletin](https://no-cache.hubspot.com/cta/default/3018241/ac0af01e-c80a-4d8f-9e71-0f3a407ecb91.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/ac0af01e-c80a-4d8f-9e71-0f3a407ecb91) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.