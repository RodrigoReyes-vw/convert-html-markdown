[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Vectorworks and Bluebeam: The Latest AEC Power Couple

 Posted by [Kamica Price](https://blog.vectorworks.net/author/kamica-price) | 2 min read time 

![Vectorworks-PDF-in-Bluebeam-with-Space-Data.png](https://blog.vectorworks.net/hubfs/Blog%20Images/031918_Bluebeam%20Integration/Vectorworks-PDF-in-Bluebeam-with-Space-Data.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-and-bluebeam-the-latest-aec-power-couple)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Vectorworks%20and%20Bluebeam:%20The%20Latest%20AEC%20Power%20Couple&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-and-bluebeam-the-latest-aec-power-couple&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-and-bluebeam-the-latest-aec-power-couple)

Project review and approval is now fast, easy, and paperless! We have partnered with [Bluebeam, Inc.](https://www.bluebeam.com/au), a leading developer of innovative technology solutions for the AEC industries, to bring a new integration between [Vectorworks Cloud Services](http://www.vectorworks.net/cloud-services?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=bluebeam03192018) and Bluebeam Studio, which supports a modern, online review and approval process for digital construction drawings and 3D models.

![Vectorworks-PDF-in-Bluebeam-with-Space-Data.png](https://blog.vectorworks.net/hubfs/Blog%20Images/031918_Bluebeam%20Integration/Vectorworks-PDF-in-Bluebeam-with-Space-Data.png)_A Vectorworks PDF in Bluebeam with space data_

What’s more, we are the first BIM software company to connect our cloud services via the Bluebeam Studio API, allowing project team members to host real-time, online markups and review sessions.

The new integration creates a streamlined, cloud-based process for designers, architects, contractors, and owners to collaborate on PDF drawings and models. Vectorworks users can publish drawing sets as data-rich 2D PDFs or models as 3D PDFs to Vectorworks Cloud Services, where they can launch a Bluebeam Studio Session and then invite participants to compare, mark up, and collaborate in real time using the tools in Bluebeam Revu. Marked-up PDFs can then be saved back to Vectorworks Cloud Services for easy storage and file management.

![Bluebeam-Studio-Integration-Setup-in-Vectorworks-Cloud.png](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/031918_Bluebeam%20Integration/Bluebeam-Studio-Integration-Setup-in-Vectorworks-Cloud.png?width=620&height=349&name=Bluebeam-Studio-Integration-Setup-in-Vectorworks-Cloud.png)_Vectorworks and Bluebeam Studio integration through Vectorworks Cloud Services_

“In a traditional drawing review process, PDF files are typically exchanged by email, then printed and manually marked up,” said Daniel Monaghan, VP of marketing at Vectorworks. “By moving to a cloud-based review workflow, collaboration among project team members becomes easier and helps avoid mistakes, and ultimately allows projects to run more smoothly by reducing review time and costs. By making it easy to share and review files digitally, we’re helping to connect design and construction workflows in ways no other BIM program can offer.”

This new integration is available at no charge to all Vectorworks Service Select maintenance program members. A Bluebeam Studio Prime subscription is required to enable the integration with Bluebeam Studio.

Want to learn more about the new integration? 

[![Watch the Movie](https://no-cache.hubspot.com/cta/default/3018241/b9e5c952-37d2-49d9-8e06-1d751371b7bb.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/b9e5c952-37d2-49d9-8e06-1d751371b7bb) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.