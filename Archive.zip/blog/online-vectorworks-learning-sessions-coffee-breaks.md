[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Live Coffee Breaks Now Available to All Vectorworks Customers

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 2 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/210915_Launch/blog-1440x800-1.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fonline-vectorworks-learning-sessions-coffee-breaks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Live%20Coffee%20Breaks%20Now%20Available%20to%20All%20Vectorworks%20Customers&url=https%3A%2F%2Fblog.vectorworks.net%2Fonline-vectorworks-learning-sessions-coffee-breaks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fonline-vectorworks-learning-sessions-coffee-breaks)

You read that headline correctly! Vectorworks Coffee Breaks are no longer available to only Service Select members. Get your fix of caffeine and Vectorworks alike.

## What are Vectorworks Coffee Breaks?

Vectorworks Coffee Breaks are short, casual online sessions that give you the opportunity to learn about different Vectorworks topics. You'll also be able to interact with Vectorworks trainers and ask questions throughout the sessions. Coffee Breaks are 100% online, so you can add to your skills without leaving your desk.

Below are three of the many great Coffee Breaks we've already held:

* [The Stair Tool](https://university.vectorworks.net/course/view.php?id=1929)
* [Data Tags](https://university.vectorworks.net/course/view.php?id=268)
* [Alligned Hardscapes and Landscape Areas with a Site Model](https://university.vectorworks.net/course/view.php?id=1658)

![2208-launch-press-release-image](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2023%20Blog%20Images/1_Roadmap/2208-launch-press-release-image.png?width=2000&height=1125&name=2208-launch-press-release-image.png)

## When Will Vectorworks Coffee Breaks Take Place?

At least two coffee breaks are offered per month, every other Thursday. Additionally, these sessions will be offered twice on their scheduled day to include as many time zones as possible. Coffee Breaks for the architecture, interior, landscape, and entertainment design industries have already been — and will continue to be — offered. Topics more general to our software and its capabilities are also offered.

Click the button below to see upcoming Coffee Breaks:

[![UPCOMING COFFEE BREAKS](https://no-cache.hubspot.com/cta/default/3018241/198bbd41-2ee2-4ae3-ba5d-d9cf356dae3a.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/198bbd41-2ee2-4ae3-ba5d-d9cf356dae3a) 

## Watching coffee breaks on demand

Despite the live sessions being opened now to all customers, Service Select members still have the opportunity to watch the sessions on demand! So, if you miss a Coffee Break you desperately wanted to attend, don't worry. Coffee Breaks can be rewatched [here](https://university.vectorworks.net/course/index.php?mycourses=0&search=UK+Content&tagfilter%5Bcategory%5D=0&tagfilter%5Btype%5D=206&tagfilter%5Bdifficulty%5D=0&categorysort=default&mycourses=0&search=VSS#coursestab).

Vectorworks Service Select is the best way to get the most out of your Vectorworks software with the best available price. Below are just some of the additional benefits you'll enjoy as a Service Select member:

* More Cloud Service storage (which has now increased to 100GB with [Vectorworks 2023 SP3](../../../net/vectorworks/blog/vectorworks-2023-service-pack-3-released.html))
* Priority technical support
* Upgrade to new releases with no additional charge
* Unlimited access to our on-demand training portal
* Access to new Symbol Libraries, textures, and more
* Classroom and online training discounts

Not yet a part of the Service Select community? [Click here](https://www.vectorworks.net/service-select)!

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.