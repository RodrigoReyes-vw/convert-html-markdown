[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# How to Simulate Vehicle Movement in Vectorworks

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 6 min read time 

![](https://blog.vectorworks.net/hubfs/2310-vw-partner-network-autoturn-promotion-partnership-linkedin-landscape.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fautoturn-online-vectorworks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=How%20to%20Simulate%20Vehicle%20Movement%20in%20Vectorworks&url=https%3A%2F%2Fblog.vectorworks.net%2Fautoturn-online-vectorworks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fautoturn-online-vectorworks)

Many building, landscape, and live event projects need to account for vehicle circulation and maneuverability. Sites can be deemed unsafe if they don’t have proper vehicle flow planned.

AutoTURN Online by Transoft Solutions is the best in the industry for conducting vehicular swept path analysis and simulated vehicle movement. In Vectorworks, the built-in [AutoTURN Online](https://autoturnonline.com/) connection is an efficient way to help analyze vehicular movement for the proposed site without leaving the Vectorworks interface.

First, you’ll need to create a free AutoTURN Online account. You can do so [here](https://autoturnonline.com/). Until April 30, 2024, you can get free access to all available vehicles for use in your Vectorworks projects. Make sure to [visit the Customer Portal](http://customers.vectorworks.net/) for more information.

There are a few things to consider when setting up your Vectorworks drawing to send to AutoTURN Online. Let’s get into it!

#### **Preparing the Vectorworks Drawing for Analysis with AutoTURN Online**

Your Vectorworks drawing likely contains more detailed linework than necessary for simulation. AutoTURN Online only needs the linework (or image thereof) of boundaries in the area where analysis is required. Additionally, AutoTURN Online is a 2D-only application, which means it’ll only use the Top/Plan linework representations from the Vectorworks file.

You can send up to 30,000 objects to AutoTURN Online, but to avoid performance issues, you’ll want to send only the necessary linework from your drawing. Do this by toggling visibility settings of designated classes and layers or by manual selection.

In other words, it’s more than OK for your Vectorworks drawing to be quite basic. Analysis is the name of the game here, not visuals.

You can also send a background image of the Vectorworks drawing to use for additional context in AutoTURN Online. Do note, however, that this is strictly an image whose linework can’t be used for simulation. You'd have to draw a vehicle path over the image in AutoTURN Online to simulate in this case. 

#### **Represent Vehicle Paths with Polylines or Polygons in Vectorworks**

If you’re planning to create a path-follow simulation, which requires an existing path for the simulated vehicle to follow, create the path in Vectorworks using polygons or polylines. Join all portions of the path into a single object with the **Compose** command.

#### **Sending the Drawing to AutoTURN Online**

Once you’ve isolated which geometry to send to AutoTURN Online, you’re almost ready for analysis. The next step is to send the design to AutoTURN Online using the **Send Design to AutoTURN** **Online** command.

Here’s where to find that command in the Vectorworks industry products:

* Vectorworks Architect: AEC > AutoTURN Online.
* Vectorworks Landmark: Landmark > AutoTURN Online.
* Vectorworks Spotlight: Spotlight > Event > AutoTURN Online.
* Vectorworks Design Suite: AEC > AutoTURN Online.

After clicking the send command, a web browser will open to AutoTURN Online within the Vectorworks interface and you'll have a chance to double-check that you're sending the right geometry. You’ll need to log in or create an AutoTURN Online account at this point.

#### **Creating a Path-Follow Simulation**

A path follow simulation requires a pre-defined path for the selected vehicle to travel. As mentioned before, it's recommended that the path is defined in Vectorworks before sending to AutoTURN Online.

To create a path-follow simulation in AutoTURN Online:

1. Click the **Generate Path Follow Simulation** tool**.**
2. Click to select the path polyline.
3. Click to indicate the direction of the vehicle.
4. Click to create the path follow simulation along the polyline path.

You can always select the path and click **Delete** to start over.

####  Creating an Arc Path Simulation

An arc path simulation involves drawing a path using the currently selected vehicle’s properties and constraints. The flexible simulation allows you to experiment by drawing in real time.

To create an arc path simulation in AutoTURN Online:

1. Click the **Generate Arc Path Simulation** tool**.**
2. Click to set the vehicle’s starting location and rotation, then drag the mouse, clicking to create vertices along the path and using the mouse to indicate travel direction.
3. Right click and select **Finish** to create the arc path simulation.

You can always select the arc path and click **Delete** to start over.

#### **Other Analysis Options in AutoTURN Online**

The possibilities are truly endless with what you can analyze in AutoTURN Online. It all depends on the needs of your project!

A master planner might simulate parking for large vehicles to ensure they can maneuver enough to fit into tight spots. An architect might want to include analysis with their proposal to show that the building leaves plenty of space for parking. Or an event planner might verify that large commercial vehicles are able to get close enough to the event space to unload.

All of these operations and more can be accomplished with the methods above. 

#### **Making Design Decisions Based on AutoTURN Online Analysis**

Following your simulation, AutoTURN Online will indicate issues in red.

If your analysis yields issues, close the AutoTURN Online web browser and adjust the design. AutoTURN Online will give you direction on what needs to be changed, such as areas where the path exceeds maximum vehicle turning angles.

With changes made in Vectorworks, resend the design to AutoTURN Online and perform another simulation. Once you reach a satisfactory analysis, click **Close and Get Analysis.**

And that’s how you can access and use AutoTURN Online to simulate vehicle movement! For a more in-depth exploration of using AutoTURN Online with Vectorworks, make sure to check out the free webinar below.

[![WATCH NOW](https://no-cache.hubspot.com/cta/default/3018241/343ba5c6-fc46-4a2a-87db-60cd1c32761c.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/343ba5c6-fc46-4a2a-87db-60cd1c32761c) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.