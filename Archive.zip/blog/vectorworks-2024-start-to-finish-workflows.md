[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Vectorworks 2024 | Start-to-Finish Workflows

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2023%20Blog%20Images/8_Launch1/2308-vectorworks-2024-launch-press-release-image-3.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-2024-start-to-finish-workflows)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Vectorworks%202024%20|%20Start-to-Finish%20Workflows&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-2024-start-to-finish-workflows&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-2024-start-to-finish-workflows)

Continue reading to see some of the highlights from the imminent release of Vectorworks 2024\. More information will be revealed once the new version is available.

---

“Vectorworks 2024 represents a significant move forward in integrating our tools into specific design workflows. By taking a holistic and high-level approach, we work hard to ensure that our software aligns seamlessly with the natural processes of designers. From ideation to final execution, this latest version has been carefully crafted to ensure new tools and existing features work together harmoniously to diminish disruptions and enhance productivity.”

 **\- Biplab Sarkar, Vectorworks CEO**  

---

#### All Designers

* Vectorworks 2024 delivers an updated UI that saves you time and allows for easier customization.
* The redesigned **View** and **Mode** bars bring a wide range of tools to the forefront for easy access.
* You can save custom viewport settings as "styles" for easy transferability.
* The new ability for bi-directional data reference from Excel files enhances collaborative data capabilities.
* Improvements to **Shaded Rendering** allow you to assess your designs more confidently with improvements to shadow casting and the addition of camera settings that allow you to define depth of field, exposure, and bloom for real-world camera-like effects.
* Project Sharing in Vectorworks Design Suite products has been rebuilt to ensure project data and geometry is always current. **Project Sharing+** tracks every change, every time, and substantially improves reliability regardless of team or project size.

#### Architects and Interior Designers

* Threshold and sill geometry has been improved to accurately fit with wall closures and and to contain more options to control interior and exterior conditions.
* Door handing standardization allows for more accurate geometry and data.
* Materials can be assigned to door and window objects for greater graphic control.
* Parametric handrails and guardrails can be created from other building objects, such as stairs, slabs, and ramps, granting the flexibility to create more custom configurations.
* New parametric cabinet objects for interiors projects enable greater customization and more interactive placement.

#### Landscape Architects and Designers

* We’ve introduced a new, automated **Fence** tool, allowing the following in 2D and 3D:  
    
   * Integrated posts, gates, and terrain options like sloped or stepped.  
   * Accurate material reporting for documentation purposes.

#### Lighting and Live Event Designers

* A new **Equipment Lists** feature provides automated solutions to the complex task of unifying equipment and inventory tracking. It streamlines the preproduction process by planning and documenting all necessary equipment for a show or production.
* The ConnectCAD Share Reports command allows designers to upload design data to [Vectorworks Cloud Services](https://www.vectorworks.net/en-US/cloud-services), ensuring that project partners and installers have access to the most up-to-date information. These reports are viewable on any device.

---

“Continuing our tradition of excellence, Vectorworks 2024 embodies our quality initiative, emphasizing solutions to complex problems. We believe in the power of comprehensive workflows that address the challenges faced by designers and can’t wait to share more on the exciting improvements in quality that await our users in the new version.”

\- Darick DeHart, chief product officer at Vectorworks

---

#### Get Ready for the Release

Vectorworks 2024 will also include advanced automation and problem-solving capabilities, as well as significant quality enhancements.

The upcoming English language release is expected to be available in September 2023 to active Vectorworks Service Select members and subscription customers. For the most up-to-date news on the launch of Vectorworks 2024, subscribe to our blog and follow @Vectorworks.

[![SUBSCRIBE TO OUR BLOG](https://no-cache.hubspot.com/cta/default/3018241/cd91dbed-8a9b-40d9-907d-1f9be9ad08bd.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/cd91dbed-8a9b-40d9-907d-1f9be9ad08bd) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.