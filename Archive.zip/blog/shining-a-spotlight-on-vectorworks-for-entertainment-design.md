[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Shining a Spotlight on Vectorworks for Entertainment Design

 Posted by [Leslie Briggs](https://blog.vectorworks.net/author/leslie-briggs) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/072120-AutoCADtoSpotlight1.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fshining-a-spotlight-on-vectorworks-for-entertainment-design)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Shining%20a%20Spotlight%20on%20Vectorworks%20for%20Entertainment%20Design&url=https%3A%2F%2Fblog.vectorworks.net%2Fshining-a-spotlight-on-vectorworks-for-entertainment-design&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fshining-a-spotlight-on-vectorworks-for-entertainment-design)

We know how much time it takes to switch between design platforms; it requires a lot of upfront consideration of your design process as well as some trial and error, something that may take months. That’s why we want to make this as easy as possible. Let us show you all the ways [Vectorworks Spotlight](https://www.vectorworks.net/en-US/spotlight?utm%5Fcampaign=makethemove&utm%5Fmedium=website&utm%5Fsource=intext&utm%5Fcontent=072120entautocadtospotlight) can be the design tool you need to enhance your workflow with this handy guide, which provides an in-depth look at Spotlight and its all-in-one design features.

![072120-AutoCADtoSpotlight1](https://blog.vectorworks.net/hs-fs/hubfs/072120-AutoCADtoSpotlight1.png?width=936&name=072120-AutoCADtoSpotlight1.png)

###### **Flexible File Import**

Vectorworks provides you with the tools you need to go from concept to a fully finalized design and getting started has never been easier. Whether you’re starting from a hand-drawn or computer-designed sketch, you’ll be able to easily import your project into Spotlight and get moving.

You can import designs via PDF and use Vectorworks to measure and accurately scale your drawing. Better yet, gone are the days of manually tracing your 2D drawing in a program. With Vectorworks, you can break your file down into its component lines and geometry, and these lines can be used to create objects like walls and lighting pipes from source shapes already available within Vectorworks. 

Vectorworks Spotlight also supports the import of tons of different file types including DWG, Rhino, 3Ds, OBJ, MVR, and more! No need to worry about losing files from other platforms.

![072120-AutoCADtoSpotlight2](https://blog.vectorworks.net/hs-fs/hubfs/072120-AutoCADtoSpotlight2.png?width=936&name=072120-AutoCADtoSpotlight2.png)

###### **Quick Collaboration**

Vectorworks makes sharing your hard work and collaborating on projects just as simple as importing your work. Spotlight comes readily equipped with [Project Sharing](/topic/project-sharing?utm%5Fcampaign=makethemove&utm%5Fmedium=website&utm%5Fsource=intext&utm%5Fcontent=072120entautocadtospotlight) capabilities, enabling you and other members of the production team to work on the same file at the same time. With Dropbox and other cloud-based file sharing integrations, there's no more constantly sending files back and forth! Even when you’re working offline, you can make your changes as needed and upload new versions on your schedule.

###### **Event Data Management**

The entertainment design world is always moving, and we know it can be tedious to constantly keep tabs on data — whether it’s ensuring data files are up-to-date, matching up spreadsheet and software data, or guaranteeing a complete data export. With Vectorworks, you no longer have to worry about all the moving pieces of your data management workflows.

Instead, all of your model’s data are stored in one convenient worksheet within Vectorworks! When you make a change in your model, the change reflects everywhere, including worksheets and viewports. Worksheets can also be immediately refreshed, guaranteeing you’re always viewing and editing the most recent version.

###### **Design Anything**

The world of entertainment design is at your fingertips. Vectorworks Spotlight means you can design, model, and document your design ideas using precise drafting and 3D modeling capabilities.

Our 3D modeling capabilities include:

* Push/pull modeling.
* Complex surfaces and curvature.
* 3D sculpting and deforming.
* Precise solids modeling.
* Algorithms-aided Design.
* And a host of entertainment-focused design features.

###### **Create Powerful Presentations**

Sharing your ideas with clients is an important part of design work. With Vectorworks, you have all the capabilities you need in one software program to create immersive presentation boards and accurately communicate your ideas with clients.

You can render a walkthrough of your model, create AR and VR presentations, or take advantage of customizable rendering styles to make your work truly unique and eye-catching.

###### **Getting Started**

Vectorworks is here for you. We understand the investment you’ll make when purchasing Spotlight and it is our mission to ensure you get the most out of your software as quickly as possible.

If you’re ready to make the switch to Vectorworks Spotlight, use our detailed guide for more on:

* Getting up and running quickly.
* User interface.
* File management.
* The Resource Manager.
* Symbols and styles.
* Referencing.
* Collaboration.
* Versatile viewports.
* Printing and publishing.

[![READ THE FULL GUIDE](https://no-cache.hubspot.com/cta/default/3018241/c36124bc-b91f-4362-8494-2cff5212c2d6.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/c36124bc-b91f-4362-8494-2cff5212c2d6) 

 Topics: [Production & Lighting Design](https://blog.vectorworks.net/topic/production-lighting-design) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.