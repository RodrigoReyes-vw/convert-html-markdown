[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# 3 Reasons Why You Need this Real-Time Rendering Webinar

 Posted by [Guest Author](https://blog.vectorworks.net/author/guest-author) | 3 min read time 

![sykesville_lumion_hr-1](https://blog.vectorworks.net/hubfs/sykesville_lumion_hr-1.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2F3-reasons-why-you-need-this-real-time-rendering-webinar)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=3%20Reasons%20Why%20You%20Need%20this%20Real-Time%20Rendering%20Webinar&url=https%3A%2F%2Fblog.vectorworks.net%2F3-reasons-why-you-need-this-real-time-rendering-webinar&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2F3-reasons-why-you-need-this-real-time-rendering-webinar)

_By Michael Brightman, Assoc. AIA, M.Arch, founder of Brightman Designs_

By now, you’ve likely heard about [last week’s announcement](https://www.vectorworks.net/news/press-releases/vectorworks-inc-announces-lumion-live-sync-rendering-linked-panoramas-and-my-virtual-rig-advancement?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=michaelbrightman032919) regarding Lumion’s LiveSync plug-in that’s available in Vectorworks. I’ve used Lumion — a popular real-time rendering application — for six years, and I’m a trainer by trade. On Thursday, April 11 at 2 p.m. ET, I’ll join Vectorworks Product Marketing Specialist Tony Kostreski PLA ASLA, for a webinar you won’t want to miss.

Why? 

Because this is your chance to be one of the first to see and learn about all the new features and time savers that have been built into the Lumion plug-in.

## Reason 1: Get Revved Up About New Rendering Capabilities

The number one reason to attend this webinar is to see the latest and coolest thing in rendering. You’ll learn how to easily manage design changes and quickly complete your work, and still provide stunning presentations to clients.

![sykesville_lumion_hr](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190329_Michael%20Brightman/sykesville_lumion_hr.jpg?width=3840&name=sykesville_lumion_hr.jpg)

## Reason 2: With Lumion You’ll be on Easy Street, Promise

As part of this webinar, I’m going to show how easy it is to do the Lumion LiveSync with Vectorworks. I’ll be demonstrating with Tony, someone recently unfamiliar with using Lumion as a tool, and who’s now a pro. With my coaching, you’ll feel confident that you can simply push a button to drop your Vectorworks model into Lumion for a new way to visualize your project.

For an exclusive preview of the new technology, watch this video below.

## Reason 3: Score Tips and Tricks

What’s a webinar without learning some highly coveted tips? In addition to getting great ideas for how to prepare a Vectorworks project to use in Lumion, I’ll walk you through new options in visualization styles that LiveSync enables for use in presentations. You’ll leave the webinar with savvy understanding of quickly creating stills, animations, virtual tours, and more.

## Final Thoughts

My best advice for success is to invest in the tools and training that you need, and it will pay off tenfold down the road. Lumion LiveSync with Vectorworks is that tool. All you need is to join me for an hour of your day and take advantage of this free webinar. You won’t regret it.

[![Sign Up](https://no-cache.hubspot.com/cta/default/3018241/d2f0cf1e-24f6-471c-bca6-61c194824158.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/d2f0cf1e-24f6-471c-bca6-61c194824158) 

\*Currently, Lumion and the LiveSync plug-in are available on the PC (Windows), and the plug-in is available for English, Dutch, Japanese, and German language users on the [Lumion website](https://support.lumion.com/hc/en-us/articles/360016412674-Download-Lumion-LiveSync-for-Vectorworks).

### About the Author

**![Michael Brightman](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190329_Michael%20Brightman/Michael%20Brightman.jpg?width=323&name=Michael%20Brightman.jpg)**

Michael Brightman earned a bachelor’s degree in Science and a master’s degree in Architecture from Kent State University in Ohio. He founded Denver-based Brightman Designs in 2013\. At Brightman Designs, Michael’s goal is to provide his customers with core support services based on real-world design expertise, advanced visualization resources, and collaborative training. Learn more at [brightmandesigns.com](https://brightmandesigns.com/).

 Topics: [Partner Products](https://blog.vectorworks.net/topic/partner-products) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.