[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Modeling and Presentation Qualities = Better Design

 Posted by [Guest Author](https://blog.vectorworks.net/author/guest-author) | 7 min read time 

![](https://blog.vectorworks.net/hubfs/Image%204_Site_Model_Contour_Sculpting.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-modeling-and-presentation-qualities-bring-unique-characteristics-to-vectorworks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Modeling%20and%20Presentation%20Qualities%20=%20Better%20Design&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-modeling-and-presentation-qualities-bring-unique-characteristics-to-vectorworks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fhow-modeling-and-presentation-qualities-bring-unique-characteristics-to-vectorworks)

_\*This article originally ran on [AECCafe's website](https://www10.aeccafe.com/blogs/guest/2020/01/22/how-modeling-and-presentation-qualities-bring-unique-characteristics-to-vectorworks/). It's written b_ _y Vectorworks CEO Dr. Biplab Sarkar._

_![Vectorworks CEO Dr. Biplab Sarkar](https://blog.vectorworks.net/hs-fs/hubfs/Image%201BSarkarDG1(891x1100)%5B1%5D.jpg?width=340&name=Image%201BSarkarDG1(891x1100)%5B1%5D.jpg)_

Anyone familiar with [Vectorworks](https://www.vectorworks.net/en-US?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=012820bldgaeccafebiplab) knows our business is building design and BIM software solutions that are intuitive, powerful, and practical for professionals around the world. It’s the unique and versatile workflows we offer for all phases of design that separate us from other BIM authoring applications. Using best-in-class 3D technology, intuitive data management, and unmatched graphical representation, our products provide architecture firms the freedom to model anything while seamlessly documenting and presenting it with the precision and artistic touch they require.

**![Vectorworks Aerial View](https://blog.vectorworks.net/hs-fs/hubfs/Image%202_aerial%20view-in%20process%201.jpg?width=1459&name=Image%202_aerial%20view-in%20process%201.jpg)**

_**Courtesy of Vectorworks, Inc.**_

#### The Many Types of Modeling in Vectorworks 

3D modeling is at the center of what enables BIM workflows to pay off for the design process, and when 3D modeling techniques are coupled with intuitive software interfaces, you gain true modeling freedom for your projects. Let’s take a look at the seven types of modeling in Vectorworks that help you model any project.

With **solid modeling**, the modeled objects aren’t just an arrangement of surfaces, but rather solid objects. Solid modeling generally creates more accurate models and allows for retrieval of data, such as volume, area, etc. Vectorworks also supports non-uniform rational basis spline (**NURBS**) modeling, which is a mathematical model generally used in computer graphics for creating curves and surfaces. The benefit of NURBS is that it offers flexibility and precision for analytic and modeled shapes. Here’s an example of why you need NURBS in your arsenal of 3D modeling, so that you can easily make items that have curvy elements.

![Surface Array, NURBS, Subdivision in Vectorworks](https://blog.vectorworks.net/hs-fs/hubfs/Image%203_Screen%20Shot%202020-01-08%20at%202.34.12%20PM.png?width=2884&name=Image%203_Screen%20Shot%202020-01-08%20at%202.34.12%20PM.png)

**Subdivision modeling** — also known as cage modeling — lets designers make multi-faceted surfaces appear smoother. The best example of this capability is Pixar films. In fact, we use Pixar’s OpenSubdiv libraries. The main benefit of subdivision modeling is that you can explore organic shapes through sculpting; it’s comparable to clay modeling. Not only does subdivision modeling allow you to create organic shapes, but it provides you with a different means to explore design alternatives.

Additionally, Vectorworks allows for mesh modeling. There are a number of tools available to help manage and simplify meshes for more effective editing and manipulation. Mesh modeling helps create and manipulate complex geometry that are composed of multiple planar polygons. Meshes are most common in Vectorworks when importing models from other 3D modeling programs and to help convert objects into another type.

In Vectorworks, **site modeling** creates a triangulated irregular network (TIN), which in essence, is a smart mesh. Site models can be created from survey data or even a contour map. Not only are you modeling site conditions, but you have many tools available to let you explore site modifications. 3D site sculpting tools are used to directly push and pull site contours or push and pull a number of site vertices.

![Image 4_Site_Model_Contour_Sculpting](https://blog.vectorworks.net/hs-fs/hubfs/Image%204_Site_Model_Contour_Sculpting.jpg?width=692&name=Image%204_Site_Model_Contour_Sculpting.jpg)_Example of site model contour sculpting._ 

**Smart object modeling** or [BIM modeling](https://www.vectorworks.net/en-US/architect/bim?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=012820bldgaeccafebiplab) is an intuitive way to start progressing your design into intelligent building objects such as windows, doors, columns, floors, roofs and stairs. In [Vectorworks Architect](https://www.vectorworks.net/en-US/architect?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=012820bldgaeccafebiplab) these smart parametric objects become essential to the application of data into your building model, and are what result in automation of document creation.

![Image 5_Modeling options](https://blog.vectorworks.net/hs-fs/hubfs/Image%205_Modeling%20options.png?width=2674&name=Image%205_Modeling%20options.png)

_The many different types of modeling in Vectorworks design and BIM software._ 

Further, **Algorithms-Aided Design (AAD)** and modeling can play a beneficial role once you understand all other modeling techniques, and when you want aspects of your design to be automated. [Marionette](https://www.vectorworks.net/training/marionette?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=012820bldgaeccafebiplab) is our built-in AAD tool that is incredibly helpful for repetitive tasks. Using graphical scripts and nodes popularized by programs like Grasshopper, Marionette allows you to visually create script networks directly within Vectorworks Architect which can be used to generate model variations, unique geometry, or even smart parametric plugin objects for your BIM process. The two images directly below are examples from a project by our German customer, [moveart GmbH](http://www.moveart.swiss/), who used Marionette to create the unique forms.

![Moveart Playsculpture](https://blog.vectorworks.net/hs-fs/hubfs/Moveart%20Playsculpture.jpg?width=800&name=Moveart%20Playsculpture.jpg)

_MoveART Playsculpture | Courtesy of Norbert Roztocki_

_![Moveart Playsculpture image 2](https://blog.vectorworks.net/hs-fs/hubfs/Moveart%20Playsculpture%20image%202.jpg?width=800&name=Moveart%20Playsculpture%20image%202.jpg)_

_MoveART Playsculpture | Courtesy of Norbert Roztocki_

#### How Presentation Qualities Elevate Your Vectorworks Designs 

3D and parametric modeling are one part of the equation for successfully designing your building information model, and graphic presentation and documentation quality are the others. In Vectorworks, we have 2D illustration capabilities including image import, crop, rescaling and stacking objects. We also have an extensive list of brand colors, line styles, tiles, hatch mapping, drop shadows, image effects and sketch effects. Moreover, Vectorworks offers different levels of rendering styles:

* Pencil/sketch
* Color/cartoonish
* Photorealistic
* White model that allows you to see shapes and forms

![Image 8_2d patterns](https://blog.vectorworks.net/hs-fs/hubfs/Image%208_2d%20patterns.png?width=2912&name=Image%208_2d%20patterns.png)

_Example of drop shadows and gradients in Vectorworks. Courtesy of Vectorworks, Inc._

Data visualization allows you to quickly change an objects’ attributes by using data parameters that allow you to view everything while you’re designing. An example of this is if doors lack fire protection, they’ll turn red to immediately alert you of the necessary change. And, you can immediately see the impact your design changes make to your BIM model.

![Image 9_data-visualization](https://blog.vectorworks.net/hs-fs/hubfs/Image%209_data-visualization.jpg?width=2400&name=Image%209_data-visualization.jpg)

When you want to take your presentations to the next level, creating an immersive experience is a great route to take. The web view and Virtual Reality feature offers ambient occlusion that helps to create more detailed and realistic designs, while our [Augmented Reality](https://www.youtube.com/watch?v=jOE2OH1D7ow) feature lets designers view a 3D, virtual version of their model in the context of the real world. Further, Vectorworks Cloud Services can be used to generate presentations of designs with an intuitive drag-and-drop interface. Presentations include [interactive 360-degree rendered panoramas ](https://www.youtube.com/watch?v=f6AeSvNl3yE&feature=youtu.be)that can be linked together. These three types of immersive experiences will support designers with the tools to effectively convey design intent to clients, collaborators and consultants, so that designs can be more easily understood and decisions and revisions can be communicated.

We continually improve our modeling technologies and intuitive interfaces by incorporating tools and processes that allow for direct editing on objects much like site sculpting and subdivision modeling. We believe that it is imperative to provide designers with a direct editing environment that supports the iterative process that design goes through on every project. 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.