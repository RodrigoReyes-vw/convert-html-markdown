[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# An Overview of Project Sharing in Vectorworks Software

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2022%20PVW%20Images/03_Project%20Sharing/blog-1440x800%20copy%203.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fan-overview-of-project-sharing-in-vectorworks-software)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=An%20Overview%20of%20Project%20Sharing%20in%20Vectorworks%20Software&url=https%3A%2F%2Fblog.vectorworks.net%2Fan-overview-of-project-sharing-in-vectorworks-software&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fan-overview-of-project-sharing-in-vectorworks-software)

Project Sharing is Vectorworks’ multi-user environment that allows you and your teammates to work on the same file at the same time no matter where you are in the world.

Because Project Sharing is supported in the Vectorworks Cloud, the capability grew in popularity with the COVID-19 pandemic that forced many project teams to work remotely.

This blog will cover a few tips for using Project Sharing successfully. You’ll also find a guide to Project Sharing should you want to dive deeper.

## Setting Up a Project Sharing File

Any existing or new Vectorworks document can be turned into a file that’s ready for Project Sharing. Simply press the Project Sharing command in the File menu.

![3-FileProjectSharing](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/03_Project%20Sharing/3-FileProjectSharing.png?width=373&name=3-FileProjectSharing.png)

Ensure that the file is accessible by all team members on a shared network location. You can use your own server or a variety of cloud storage options like Vectorworks Cloud Services, Dropbox, Google Drive, Rezilio, or OneDrive.

Once the document is marked as a Project Sharing document, any subsequent time you open it will essentially open a clone of the original Project File. The clones are referred to as Working Files. All work happens in the Working Files, not the original Project File.

Team members can then “check out” objects, design layers, or sheet layers to work on. It’s not unlike checking out books at a public library. Once an element is checked out, it remains exclusive until a Close and Release command is performed.

![5-CloseAndRelease](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/03_Project%20Sharing/5-CloseAndRelease.png?width=381&name=5-CloseAndRelease.png)

To merge changes back into the overall Project File, use the Save and Commit command in the File menu. This will update the Project File with your changes, and teammates will be able to see your changes in their working files by clicking Refresh.

![4-SaveAndCommit](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/03_Project%20Sharing/4-SaveAndCommit.png?width=372&name=4-SaveAndCommit.png)

Working files contain all the same geometry and data as the Project File, though Permissions can limit team members from making certain changes. Permissions vary from team to team and from project to project; for a closer look at setting up permissions, [click here](https://app-help.vectorworks.net/2022/eng/VW2022%5FGuide/ProjectSharing/The%5FProject%5FSharing%5Fdialog%5Fbox.htm).

## Strategically Organize Layers

Working Files behave the exact same as regular Vectorworks documents. To get to work, you check out either objects or entire layers. Depending on your teamwork approach, you may find that modifying the project’s overall layer structure allows you to get more specific in the way work is assigned.

As an example: If a team member is tasked with creating a finish plan and schedule, an additional design layer for just space objects can be created to allow this person to work concurrently with someone working on an interior partition layout.

Consider the structure of your team and needs of the project as you set up the Project Sharing file. You can always revise the layer structure once the project has been started if you think of a better means of organization.

For more information on general model setup and creating templates, refer to the [Model Setup](https://university.vectorworks.net/course/view.php?id=354) tutorial on Vectorworks University.

## Useful Features in the Project Sharing Dialog Box

### Layers Tab

The Layers tab allows you to see which layers are available, which layers are checked out by others (shown in gray text), and which layers you have checked out yourself (shown in blue text). The project administrator can designate layers as master layers within this tab.

![46-PSDialogLayers](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/03_Project%20Sharing/46-PSDialogLayers.png?width=650&name=46-PSDialogLayers.png)

### Objects Tab 

This tab allows you to see all checked-out individual objects. You can see the owner, object type, layer, class, and object ID for each object.

![PSDialogObjects](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/03_Project%20Sharing/PSDialogObjects.png?width=650&name=PSDialogObjects.png)

### History Tab

The History tab contains a compilation of all change history to the Project File so you can track the multitude of changes that occur in a multiuser environment.

You can search this tab by keyword to find what you’re looking for. The project’s entire history can be exported with the Export command, which will generate a CSV file than can then be imported into data processing applications like Excel or Numbers.

![48-PSDialogHistory](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/03_Project%20Sharing/48-PSDialogHistory.png?width=650&name=48-PSDialogHistory.png)

### Users Tab

Here you can see a list of the entire project team. The tab will show usernames, full names, permission levels, and associated colors. The project administrator can edits permission levels from this tab.

![49-PSDialogUsers](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/03_Project%20Sharing/49-PSDialogUsers.png?width=650&name=49-PSDialogUsers.png)

## Dive Deeper into Project Sharing

 If you’re looking for more information, the architect team at Vectorworks wrote a detailed document with everything you need to know about using Project Sharing. 

[![Read: "Introduction to Project Sharing: the Multiuser Environment"](https://no-cache.hubspot.com/cta/default/3018241/5f6b0641-93b6-4c99-91ae-3e4c6e450ae6.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/5f6b0641-93b6-4c99-91ae-3e4c6e450ae6) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.