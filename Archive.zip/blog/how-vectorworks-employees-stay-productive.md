[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Brain Breaks | How Vectorworks Employees Stay Sharp, Creative

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/220209_VW%20Brain%20Breaks/IMG_9848.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-vectorworks-employees-stay-productive)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Brain%20Breaks%20|%20How%20Vectorworks%20Employees%20Stay%20Sharp,%20Creative&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-vectorworks-employees-stay-productive&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fhow-vectorworks-employees-stay-productive)

Remote work is becoming more and more popular. And while it tends to offer a better work-life balance, remote work can sometimes make it challenging to stay productive. After all, you’re in the comfort of your own home!

Each Vectorworks team member has their own ways to stay sharp and creative throughout the day. In this post, we’ll look at some of the unique “brain breaks” our coworkers take.

###### Annabel Carr – Director of Australian Operations – Australia

![Annabell Carr](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220209_VW%20Brain%20Breaks/Annabell%20Carr.jpg?width=300&name=Annabell%20Carr.jpg)

“Now that I work remotely, I miss our office chatter, the comradeship of colleagues, the chance to join workmates for lunch, and the freedom to get up and move about the office.

At home, these opportunities and interactions take more deliberate planning. I find that disconnecting from all electronics and taking a walk through the neighborhood is an excellent refresher. When at home, taking small breaks to water the house plants, tend to the garden, or play with your pets provides mindful relief from work while achieving something caring and productive. 

Take the opportunity to check in on colleagues’ well-being too – when all we do is Zoom and Slack about Vectorworks it’s easy to miss little life updates or overlook the signs that someone is struggling and might need help. Having a colleague check in just to say, ‘Hi, how are you coping?’ might provide just the boost you need to get you through the afternoon slog or open a dialogue about the kind of support you need to stay healthy and productive in your job.” 

###### Claire Hsieh – Marketing Programs Coordinator – Canada

![IMG_4343](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220209_VW%20Brain%20Breaks/IMG_4343.jpg?width=450&name=IMG_4343.jpg)

“Working from home can sometimes take a toll on my motivation, so I try to do something fun every day. One thing I’ve enjoyed doing is planning out my upcoming meal, whether that be lunch or dinner.

One of my all-time favorite dishes is beef noodle soup. The warm broth always serves as a comfort food when I feel a bit homesick. Just the other night, I prepared my mom’s signature beef noodle soup for dinner. As you can tell, I’m a bit of a foodie, so knowing what I’m eating next helps me speed through the day!”

###### Janet Coppage – Employee Experience Specialist – United States

![2019 prof pic](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220209_VW%20Brain%20Breaks/2019%20prof%20pic.jpg?width=317&name=2019%20prof%20pic.jpg)

“I’m rarely stationary. My job dictates that I move around the office most of the day, delivering mail and packages, deploying IT equipment, working on an event, solving problems, and making sure the building and its systems are in good shape for the welfare and happiness of our employees. The nature of my job keeps me productive because something new always requires attention!

If I need a break to re-charge, I take a walk outside or listen to music. The weekly Dance Party (a time for Vectorworks employees to get up and get grooving) is one of my favorite refresh breaks, too.

When I need a creative boost, collaborating with my team and looking at ideas on the internet are my go-to resources.”

###### Martyn Horne – Director of Digital Practice and Strategy – United Kingdom

![Martyn Biog Photo Umberella](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220209_VW%20Brain%20Breaks/Martyn%20Biog%20Photo%20Umberella.jpg?width=338&name=Martyn%20Biog%20Photo%20Umberella.jpg)

“I’ve been doing T’ai Chi for about 25 years. I started teaching a small class when I got my first instructor-level belt about 15 years ago. When the pandemic first started, we ran 10-minute T’ai Chi tasters every day for the first few weeks in the Vectorworks UK team just to bring everyone together, get them moving and give them something to focus on other than the pandemic.

I usually practice at the beginning or end of each day. But once you know some basic moves, even a five-minute break can help take your mind off a particularly tricky issue, get you breathing properly again and get your muscles moving and stretching!”

###### Selin Aydin – Software Engineer – United States

![IMG_9848](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220209_VW%20Brain%20Breaks/IMG_9848.jpg?width=450&name=IMG_9848.jpg)

“I like to use a Pomodoro kind of technique where I work for a solid hour-or-so then I take a 10 minute break where I get off my desk. I’ll get coffee, walk around my office, water my plants, or something like that. During my lunch break, I take a walk with my dog. Spending some time with her is always the most refreshing break.”

Subscribe to [_Planet Vectorworks_](../../../net/vectorworks/blog/index.html) to see more stories about the people and culture of Vectorworks!

[![SUBSCRIBE TO PLANET VECTORWORKS](https://no-cache.hubspot.com/cta/default/3018241/8a5d9ee2-9088-47b9-9883-9f473a72fd34.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/8a5d9ee2-9088-47b9-9883-9f473a72fd34) 

 Topics: [News](https://blog.vectorworks.net/topic/news) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.