[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Creating Virtual Presentations of Your Interior Designs

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/230727_INT%20Vectorworks%20Cloud%20Services/cloud-presentations-benefit-3.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fgo-beyond-still-renderings-with-vectorworks-cloud-services)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Creating%20Virtual%20Presentations%20of%20Your%20Interior%20Designs&url=https%3A%2F%2Fblog.vectorworks.net%2Fgo-beyond-still-renderings-with-vectorworks-cloud-services&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fgo-beyond-still-renderings-with-vectorworks-cloud-services)

Presentations and how you pitch your ideas to clients are a tremendously important part of your design practice.

You can create stunning still renderings of your interiors using a variety of options inside of [Vectorworks Architect](https://www.vectorworks.net/en-US/architect). But did you know you can also create immersive, virtual presentations of your projects using [Vectorworks Cloud Services](https://www.vectorworks.net/en-US/cloud-services)?

Continue on to learn more about creating such presentations with Vectorworks Cloud Services.

#### Exporting Vectorworks with Efficiency

Your workflow for creating immersive presentations begins after you’ve fully created your 3D model and applied all relevant textures and lighting. If you want to check your model for any imperfections before exporting it to the Vectorworks Cloud, you can do a quick “test rendering” using **Shaded** render mode.

Next, you’ll want to create a rendered panorama.

To create a rendered panorama, set up your view the way you want the panorama to appear. This can be from a saved view, or you can set these up manually right before exporting to the cloud. 

Having your panoramic images rendered on the cloud is especially helpful because it frees up you and your machine to move on to the next task on your to-do list.

![Panorama-Saved views](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230727_INT%20Vectorworks%20Cloud%20Services/Panorama-Saved%20views.png?width=1440&height=827&name=Panorama-Saved%20views.png)

To export views and begin the rendering process, select **File** \> **Export** \> **Export Panorama**.

![Panorama Export Menu](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230727_INT%20Vectorworks%20Cloud%20Services/Panorama%20Export%20Menu.png?width=1440&height=810&name=Panorama%20Export%20Menu.png)

---

**BONUS TIP:** Use a naming convention when exporting your panoramas, specifying either their order in the presentation (1,2,3 …) or location within your model (Entrance, Office…etc.)

---

#### Creating Presentations

Once your files have successfully exported to the cloud, you can start a new presentation by creating either boards or tours using your panoramas.

Boards are flat presentations that allow you to pin different media formats to the board. Tours, on the other hand, are 360-degree walkthroughs made by linking together your panoramic images. 

Tours allow your clients to feel as though they’re in your design. They’re also useful if a client is struggling to connect with plan, drawings, or still renders. Giving an immersive view of a project will allow for a greater emotional connection to your design.

![Image of Tour - With resource selector on the side](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230727_INT%20Vectorworks%20Cloud%20Services/Image%20of%20Tour%20-%20With%20resource%20selector%20on%20the%20side.png?width=1440&height=900&name=Image%20of%20Tour%20-%20With%20resource%20selector%20on%20the%20side.png)

To get working on building out a new tour, in an exisiting presentation file, locate and assign published panoramas in the tour editor. This point in your workflow is also a great time to reorder your rendered panoramas in the order you want your tour to flow.

Plus, you can create multiple groups of tours within a presentation if you're working on a larger project.

Drag the other panoramas onto previewed panorama file to create a new pin for each one. To maintain a graphical standard, save your pin styles after tweaking the appearance in any way you'd like. This will save time when you later create more presentations.

If you have time, creating a tour map that shows the location of all your pinned panoramas is a nice touch. 

[For more on creating presentations, click here](https://cloud.vectorworks.net/portal/help/pages/create-presentations/?app=WEB).

#### Sharing Presentations

Another great advantage of Vectorworks Cloud Services is the ability to easily share your presentations with clients and collaborators. You can share presentations by direct email, QR code, or even a custom link.

To share a presentation:

1. Open a presentation to view the list of slides, and then select the **More Actions**.
2. Select **Share Link**.
3. From there, you can do one of the following:
* Select the **Compose** button to send the link via email. Enter one or more email addresses, edit the subject and the body of the email, and select **Send**. An email with a link is sent from the address [donotreply@vectorworks.net](../../../net/vectorworks/blog/index.html).
* Select the **Copy link** button to copy the link to your clipboard. You can paste the link into another email application or chat message, or post it on social media, or use it to create a Hyperlink object in Vectorworks, for example. You can also click on this link to see the start page that your client or collaborator will see when they open the link you shared with them.
* Select the **QR code** button, and then select the **Copy** button to copy the image to your clipboard.

![Sharing of cloud presentation](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230727_INT%20Vectorworks%20Cloud%20Services/Sharing%20of%20cloud%20presentation.png?width=1440&height=900&name=Sharing%20of%20cloud%20presentation.png)

Your clients and consultants can even review your designs away from a desktop, if needed. Cloud presentations can be viewed on mobile devices via a web-based link!

And, if your project has any edits or changes made after initially sharing it, simply export out new panoramas as you did before. Then, you can replace them in the existing tour.

#### Do More with Vectorworks Cloud Services

There’s even more you can use Vectorworks Cloud Services.

[The Nomad mobile app](https://apps.apple.com/us/app/vectorworks-nomad/id506706850), for example, allows you to browse and annotate PDFs, panoramas, and more generated from your Vectorworks files through Vectorworks Cloud Services.

![blog-1440x800_NOMAD Hero-2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230629_Nomad%20Apple%20PDFKit/blog-1440x800_NOMAD%20Hero-2.png?width=1440&height=800&name=blog-1440x800_NOMAD%20Hero-2.png)

To read more about Nomad, and how it uses cutting-edge technology from Apple, click the button below:

[![WHAT'S NEW WITH NOMAD FOR iOS](https://no-cache.hubspot.com/cta/default/3018241/3d3f0edc-9675-4a97-8499-fce06dcc134a.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/3d3f0edc-9675-4a97-8499-fce06dcc134a) 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.