[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Garden of Nervure: How One Firm Brought Life to Luxury Apartments

 Posted by [Leslie Briggs](https://blog.vectorworks.net/author/leslie-briggs) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/112320_2021SignatureProject_Landmark/PLACEMEDIA1.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fgarden-of-nervure-how-one-firm-brought-life-to-luxury-apartments)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Garden%20of%20Nervure:%20How%20One%20Firm%20Brought%20Life%20to%20Luxury%20Apartments&url=https%3A%2F%2Fblog.vectorworks.net%2Fgarden-of-nervure-how-one-firm-brought-life-to-luxury-apartments&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fgarden-of-nervure-how-one-firm-brought-life-to-luxury-apartments)

Since 1990, Japanese landscape architecture firm [PLACEMEDIA](http://placemedia.net/?lang=en) has maintained a crucial ideology — that landscape architects, while specialists, must incorporate the perspectives of all project stakeholders in order to deliver a successful design.

One such project that showcases this collaborative spirit is the Taicang Yuqin Garden in Taicang City, China. The master project, a luxury housing development would not be complete without an equally luxurious landscape — and architecture firm Sakakura Associates Architects and Engineers invited PLACEMEDIA to devise a plan for the land between apartment buildings.

![PLACEMEDIA1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/112320_2021SignatureProject_Landmark/PLACEMEDIA1.jpg?width=1440&name=PLACEMEDIA1.jpg)

_Taicang Yuqin Garden | Courtesy of PLACEMEDIA Landscape Architects Collaborative and Eiichi Kano_

## The Gardens at Yuqin Gardens

The Taicang Yuqin Garden sits in the green space between the high-rise buildings of the Yuqin Gardens apartments, creating a beautiful outdoor space for residents, ample pathways for pedestrians, and the perfect cover for an underground parking garage.

Designed for a sustainable community that values green space, PLACEMEDIA’s design hinges on their concept of a “Green Island,” reflective of the nearby Yangtze River Delta. Each of these slightly elevated “islands” is surrounded by lush greenery in the adjacent lowlands. Each of the garden’s tiny islands is connected by a series of pathways that creates the illusion of veins of a leaf, connecting each “island” in the garden and each building of the apartment complex.

As the trees and shrubbery grow and flower, they will provide shade and outdoor scenery as well as clean air for the community. Taicang Yuqin Garden is a forward-looking green space — sustainably designed and implemented for resilience and sustainability so the landscape can thrive well into the future.

![PLACEMEDIA2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/112320_2021SignatureProject_Landmark/PLACEMEDIA2.jpg?width=1440&name=PLACEMEDIA2.jpg)_Taicang Yuqin Garden | Courtesy of PLACEMEDIA Landscape Architects Collaborative and Eiichi Kano_

## Establishing a Collaborative Workflow

A hallmark feature of many landscape projects is collaboration with architects for the building elements on the site. PLACEMEDIA worked closely with Sakakura Associates Architects and Engineers on the overall scheme of the Taicang Yuqin Garden, ensuring a harmony between landscape and buildings.

But any project comes with roadblocks, and one for PLACEMEDIA was overseas constraints — “Many materials that can be procured domestically are not available overseas, so it’s necessary to review the selection of materials and specifications to suit the local conditions, and it’s necessary to give detailed instructions,” said Yuta Kobayashi, associate at PLACEMEDIA.

“For plants in particular, since there are differences in local weather and climate, as well as differences in tree planting and production techniques, we made many trips to the Chinese planting fields to select plants, communicated with local planters, and sometimes made decisions on changing tree species,” he said.

Envisioning the site is not only a 2D process for PLACEMEDIA. In fact, their use of 3D modeling helped them visualize the controlled line of sight throughout the space and create a sense of scale. Furthermore, PLACEMEDIA could easily show their designs to project stakeholders and quickly get feedback on everything from the shapes of each “island” to the look and placement of outdoor furniture.

![PLACEMEDIA3](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/112320_2021SignatureProject_Landmark/PLACEMEDIA3.jpg?width=1440&name=PLACEMEDIA3.jpg)

_Taicang Yuqin Garden | Courtesy of PLACEMEDIA Landscape Architects Collaborative and Eiichi Kano_

## What Does Creativity Mean to You?

In the spirit of the theme of the #Vectorworks2021 launch, “simplicity to design the complex,” we asked each featured company the same question: What does creativity mean to you?

“I believe that creativity is the ability to create something that does not yet exist in this world. It means designing forms and programs that create new values for the natural environment and the life cycles of the people living in the given site and surrounding area,” said Kobayashi

“In order to achieve these goals, I would like to value relationships with people from many different fields and industries, and to collaborate with them while expanding our knowledge of each other's fields.”

“The way people think about outdoor spaces is about to change significantly,” he continued. “Although there has been much talk of extreme weather conditions that are becoming more and more pronounced year by year, there has been no significant change in society. However, the impact of the COVID-19 that has spread throughout the world has forced us to change our lifestyle and our behavior toward society and the environment.

“We, as landscape architects, are facing a turning point to think seriously about how to improve the relationship with the land, the region and the environment, and we feel that it is a mission of our profession to be the first to create a better society_._”

_Continue reading with our other signature projects: [Ülemiste railway terminal – 3+1 architects](../../../net/vectorworks/blog/from-hand-model-to-bim-why-creativity-means-building-in-context.html), [Hamilton: the Exhibition – David Korins Design](../../../net/vectorworks/blog/a-conversation-with-the-design-team-behind-the-scenes-of-hamilton-the-exhibition.html), and [ActiveCampaign Headquarters – Eastlake Studio](../../../net/vectorworks/blog/the-office-everyone-wishes-they-had.html)._

 Topics: [Landscapes](https://blog.vectorworks.net/topic/landscapes) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.