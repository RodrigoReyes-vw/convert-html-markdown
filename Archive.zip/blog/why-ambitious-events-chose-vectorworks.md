[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# How an Events Industry Veteran Switched from AutoCAD to Vectorworks

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/220223_Brian%20Wajda/Wajda%201.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fwhy-ambitious-events-chose-vectorworks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=How%20an%20Events%20Industry%20Veteran%20Switched%20from%20AutoCAD%20to%20Vectorworks&url=https%3A%2F%2Fblog.vectorworks.net%2Fwhy-ambitious-events-chose-vectorworks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fwhy-ambitious-events-chose-vectorworks)

The word “experienced” is insufficient in describing Brian Wajda’s career in the entertainment and live events industry.

Until 1999, Wajda traveled the world as a drummer, playing with REO Speedwagon, Air Supply, and more. He’s also recorded over 50 original songs of his own.   

Then Wajda moved behind the scenes, transitioning to a career in production. Since then, he’s put together an impressive 20-plus years in the industry, working as a producer, technical director, manager, show caller, and more. 

Now, with a mind-blowing resume in his back pocket, Wajda is going at it alone.

In 2020, Wajda started his own production company, [Ambitious Events](https://www.ambitiousevents.net/). Based in Orlando, Florida, Ambitious Events specializes in providing an all-encompassing service for high-level events. From design to technical direction, Wajda — with the help of the occasionally outsourced professional — does it all.

## Switching from AutoCAD to Vectorworks

At his previous employer, Wajda was still working with AutoCAD and progeCAD. When evaluating switching design software, Wajda left no stone unturned. He began talking to owners of large AV companies, lighting designers, set designers, and many other design professionals. “I was interested in talking to people that make a living doing drawings. What were they using, and what were their experiences?” he said.

The answers were overwhelming; Wajda’s colleagues knew that [Vectorworks](https://www.vectorworks.net/spotlight) was the best all-in-one solution for design, documentation, and presentation.

The founder of Ambitious Events noticed the advantages of Vectorworks. Wajda could now include information such as weight, patch data, fixture location, and other specifications of equipment into his design. 

Wajda was also excited by the idea of creating his own [3D models](../../../net/vectorworks/blog/the-best-3d-modeling-for-interior-architecture.html) — something he didn't do in AutoCAD. “It’s invaluable having 3D elements that mimic what I’ll be doing with the show,” he said. “I can determine perfect stage placement, angles of the stage, and other details you just can’t get from an overhead view.”

![Wajda 1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220223_Brian%20Wajda/Wajda%201.png?width=1440&name=Wajda%201.png)

Now, for the first time, Wajda could create designs with rich graphics and detailed information all on his own. Planners, executives, and other stakeholders who don’t have the same industry experience as Wajda would clearly see his vision for an event.

## Designing a High-Level Project While Learning Vectorworks

Despite an already impressive understanding of Vectorworks’ potential, Wajda was hesitant about switching to a new design software. “I’d been working in AutoCAD for 20 years,” he admitted. “So, it’s the old ‘can’t teach an old dog new tricks’ kind of thing. I resisted early on because it was different.”

Such apprehension is to be expected. Change makes us uncomfortable as humans, but it’s a necessary force that drives us forward and allows us to grow. Credit to Wajda, who was committed enough to growth to embrace change and switch to Vectorworks.

In addition to his foresight, Wajda had a team of Vectorworks specialists to help ease his [transition to the software](../../../net/vectorworks/blog/switching-to-vectorworks-in-6-actionable-steps.html). Thanks to this support, he took to the software quickly. Wajda found Vectorworks so easy to use, in fact, that he began working on a high-level project as part of his onboarding.

The project was an event for a large restaurant cooperation, and it was to take place in a ballroom. After his first onboarding session, Wajda had a sketch of the ballroom and its floorplan, adding details like custom stone columns, large wall sconces, and valences.

The ballroom has its own stage, but Wajda decided to build a lower stage out in front. “It’s not really appropriate for a stage to be almost six feet tall. You’d be talking down to people,” he said.

Wajda then added a 15-by-45-foot presentation screen before moving on to lighting fixtures. “My trainer also showed me how to mount light fixtures to a truss, so they’d work in a 3D environment,” he explained.

![Wajda 2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220223_Brian%20Wajda/Wajda%202.png?width=1400&name=Wajda%202.png)

Amazingly, after just three sessions, Ambitious Events had a design ready to show the client.

## Brian Wajda’s Free Webinar

Thanks to a desire to learn, grow, and create his own thriving design company, Wajda has acquired a wealth of Vectorworks-related knowledge. You can learn from him with a free webinar from [Vectorworks University](https://university.vectorworks.net).

In the webinar, Wajda discusses:

* The importance of his Vectorworks onboarding process.
* The value of 3D modeling and rendering.
* The importance of drawing with detail-rich objects.
* And much more!

Click the button below to watch:

[![WATCH "SWITCHING TO VECTORWORKS FOR LIVE EVENTS"](https://no-cache.hubspot.com/cta/default/3018241/d77bdd0f-d60e-405b-8a1e-a08742bfcc09.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/d77bdd0f-d60e-405b-8a1e-a08742bfcc09) 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.