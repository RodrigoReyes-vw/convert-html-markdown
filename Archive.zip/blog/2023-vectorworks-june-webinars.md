[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# June Webinars | Now Available On Demand

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/230614_June%20Webinars%20Register/blog-1440x800_Nomad%20App%20LAND.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2F2023-vectorworks-june-webinars)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=June%20Webinars%20|%20Now%20Available%20On%20Demand&url=https%3A%2F%2Fblog.vectorworks.net%2F2023-vectorworks-june-webinars&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2F2023-vectorworks-june-webinars)

Are you a designer in the architecture, landscape, or entertainment design industries? Do you want to stay up-to-date with the latest trends and technologies in your field?

We're hosting a series of webinars that'll help you take your designs to the next level. These webinars cover embodied carbon, photogrammetry and point capture, a My Chemical Romance tour, and the possibilities of [Unreal Engine](https://www.unrealengine.com/). 

So why wait? Sign up for Vectorworks' upcoming webinars today and start honing your craft like never before.

#### Understanding Your Project’s Carbon Footprint

_Aired June 20 | Approved for 1 AIA HSW LU_

[The Vectorworks Embodied Carbon Calculator (VECC) provides you with the ability to assess embodied carbon emissions through a project’s lifecycle](../../../net/vectorworks/blog/calculate-embodied-carbon-with-this-vectorworks-worksheet.html). The analysis looks at individual materials, a project’s lifecycle stages, and benchmarks for set targets.

During the webinar, you'll hear of standards, guidance, and legislation that drive the embodied carbon to the front of the sustainable construction conversation. Luka Stefanovic, ACIAT, industry specialist, will also demonstrate assessing the carbon footprint of a design with built-in tools that enable regular evaluations during the design process. With the Vectorworks Embodied Carbon Calculator, you’ll have the power to gather metrics and make informeddecisions as you look to achieve carbon-reducing targets.

![vimeo-thumbnail-1080x1920-9](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230614_June%20Webinars%20Register/vimeo-thumbnail-1080x1920-9.png?width=1440&height=810&name=vimeo-thumbnail-1080x1920-9.png)

[CLICK HERE TO REWATCH THE ARCHITECTURE WEBINAR](https://university.vectorworks.net/mod/scorm/player.php?a=574&currentorg=articulate%5Frise&scoid=1148).

#### Photogrammetry & Point Clouds with the Nomad App

_Aired June 22_ 

Explore the potential of photogrammetry and point cloud capture for landscape projects using Nomad, a Vectorworks app for iPhone, iPad, and Android devices.  
  
In this webinar, you'll dive into the fundamentals of these technologies, including how they work and what they can achieve. You’ll see how Nomad can act as a companion for capturing site inventory, participate in the design phase, and be used for as-built documentation.   
  
This video will also cover practical tips and best practices for using Nomad to generate 3D models from photos and capture point clouds with the iPhone's internal LiDAR scanner.

![blog-1440x800_Nomad App LAND](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230614_June%20Webinars%20Register/blog-1440x800_Nomad%20App%20LAND.png?width=1440&height=800&name=blog-1440x800_Nomad%20App%20LAND.png)

[CLICK HERE TO REWATCH THE LANDSCAPE WEBINAR](https://university.vectorworks.net/course/view.php?id=2703). 

#### Modeling Techniques for My Chemical Romance Tour

_Aired June 28_

In a career spanning over 25 years in lighting, set, and production design, A.J. Pen has refined his ability to bring an artist’s vision to life.

In this webinar, the founder and CEO of Penlight, Inc. shares a modeling tip he’s developed using basic 3D polygons and custom textures created with alpha channel transparency. Pen used this technique to bring My Chemical Romance’s “Foundations” tour to life, modeling set pieces to meet a quick turnaround.

![rise-cover-image-1680x1120-9](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230614_June%20Webinars%20Register/rise-cover-image-1680x1120-9.png?width=1440&height=960&name=rise-cover-image-1680x1120-9.png)

[CLICK HERE TO REWATCH THE ENTERTAINMENT WEBINAR](https://university.vectorworks.net/course/view.php?id=2707).

#### demystifying bim collaboration

_Aired June 6_ 

Collaborating using a Building Information Model (BIM) can be done in a variety of ways, and there isn’t just one tool or one method available. These varied collaboration workflows depend on the needs of your project and the skill levels of your team members involved. 

One key factor of BIM collaboration is the ability for each team member to use the software of choice that fits their tasks and can offer collaboration opportunities with others. To serve this, flexible design tools and open standards can provide ways to work with others while removing the need to use (or learn) unfamiliar software with limited, rigid workflow options. 

This webinar will demystifies the options for BIM collaboration so you can make an informed decision about the best method for your needs on any given project.

![blog-1440x800_BLDG Webinar](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221121_November%20Webinar%20Blog/blog-1440x800_BLDG%20Webinar.png?width=1440&height=800&name=blog-1440x800_BLDG%20Webinar.png)

[CLICK HERE TO REWATCH THE CANADA WEBINAR](https://university.vectorworks.net/course/view.php?id=2392).

#### Unreal Engine & Vectorworks for Live Events

_Aired June 29_ 

Patrick Wambold, Senior Solution Architect at Epic Games, has worked for the likes of Fortnite, Rocket League, Coachella, Tomorrowland, and the Super Bowl.

In this informative webinar, Wambold will dissect a portion of the 2022 Fortnite Championship Series Invitational to explore using Vectorworks and Unreal Engine for a live esports event. He will also cover exporting from Vectorworks using the GDTF, MVR, and Datasmith file formats to import designs into Unreal Engine and MA3.

![FNCSBlurFullFrame-blur-2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230614_June%20Webinars%20Register/FNCSBlurFullFrame-blur-2.jpg?width=1440&height=810&name=FNCSBlurFullFrame-blur-2.jpg)

[CLICK HERE TO REWATCH THE U.K. WEBINAR](https://university.vectorworks.net/course/view.php?id=2620).

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.