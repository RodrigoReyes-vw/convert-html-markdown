[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# A Closer Look at Our 2020 Landmark Featured Design

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![landmark-sig-image-blog](https://blog.vectorworks.net/hubfs/Blog%20Images/191114_Landmark%20Signature%20Project/landmark-sig-image-blog.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fa-closer-look-at-our-2020-landmark-signature-design)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=A%20Closer%20Look%20at%20Our%202020%20Landmark%20Featured%20Design&url=https%3A%2F%2Fblog.vectorworks.net%2Fa-closer-look-at-our-2020-landmark-signature-design&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fa-closer-look-at-our-2020-landmark-signature-design)

A sensational triumph of landscape architecture, Singapore’s Jewel Changi Airport saw a redesign that transformed it into one of the most eye-catching and awe-inspiring hubs we’ve ever seen. 

![TH050619_Safdie_Jewel_3616](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/191114_Landmark%20Signature%20Project/TH050619_Safdie_Jewel_3616.jpg?width=600&name=TH050619_Safdie_Jewel_3616.jpg)

_View of the Jewel Changi Airport. Courtesy of PWP Landscape Architecture._

The redesign occurred because of air travel’s position as a staple of modern life. The [Federal Aviation Administration](https://www.faa.gov/air%5Ftraffic/by%5Fthe%5Fnumbers/) reports that it oversees an average of 44,000 flights daily, adding up to a staggering 16,100,000 flights yearly. With air travel’s popularity comes the need for airports to evolve. It’s not a stretch to say airports can incite feelings of dread — especially considering the necessity of arriving hours early, so as not to get brick walled by the often lengthy security check-in process. An airport should not incite fear, dread, or worry; naturally, this is never the intention for those who design airports, but it’s hard to escape the feeling that an airport is a place entirely transitionary, not a destination in itself. It’s hard not to see your time at the airport as a waste, as merely a means to an end. 

The [Jewel Changi Airport](https://www.jewelchangiairport.com/) is different, though. Instead of the bland colors and uniformity we’ve come to expect from airports, the 1.7 million-square-foot Changi Airport appears a feat of architecture and landscape design, a destination in-and-of itself for citizens of Singapore and world travelers alike. The mezzanine is bordered by a shopping mall, restaurants, a movie theater, a hotel, and other tourist attractions, rebuking that all too familiar notion that time spent in transit can’t be enjoyable.

  
We’ve selected the Jewel Changi Airport as our [2020 Vectorworks Landmark](https://www.vectorworks.net/en-US/landmark?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=landsignature111419) featured project to demonstrate what’s possible in landscape architecture and design. The imagery captures your gaze, making you question whether you’re actually looking at an airport instead of a climate-controlled forest reserve.

![landmark-sig-image-blog](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/191114_Landmark%20Signature%20Project/landmark-sig-image-blog.jpg?width=600&name=landmark-sig-image-blog.jpg)

_View of the Jewel Changi Airport. Courtesy of PWP Landscape Architecture._

The project brief, according to [an article in Architectural Record Magazine](https://www.architecturalrecord.com/articles/14153-jewel-changi-airport-by-safdie-architects), was to increase the airport’s capacity from 65 million to 135 million by 2030\. It called for an “attraction,” too, the nature of which was left to the design experts. They had full freedom in that regard. Moshe Safdie of [Safdie Architects](https://www.safdiearchitects.com/) responded in kind by proposing a “mythical garden,” the Record states.

What resulted was a 130-feet-tall waterfall that pumps around 10,000 gallons of water per minute down through the airport’s interior into a renewable reservoir below. This feature may remind you of the gaping reservoirs in the [9/11 Memorial](https://www.vectorworks.net/en-US/customer-showcase/minimalistic-design-with-enormous-impact?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=landsignature111419), designed by [Peter Walker and Partners (PWP) Landscape Architecture](http://www.pwpla.com/).

![911 memorial](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/191114_Landmark%20Signature%20Project/911%20memorial.jpg?width=228&name=911%20memorial.jpg)

_View of the 9/11 Memorial. Courtesy of PWP Landscape Architecture._

And although PWP didn’t design Jewel Changi Airport’s waterfall itself, their familiarity with water flow and surrounding environments made them a perfect fit to design the airport’s interior landscape. 

The verdant surroundings have been named Shiseido Forest Valley, containing over 900 trees and around 60,000 shrubs. On the airport’s topmost level, walking trails allow travelers to traverse misty rock falls and enjoy the scenery from above. According to the airport’s website, there’s an intricate hedge maze with a watchtower at its center that lets dedicated maze-goers see the maze’s layout from above once they reach the end.

![190625 L5D + FV Landscape Plan UPDATE](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/191114_Landmark%20Signature%20Project/190625%20L5D%20+%20FV%20Landscape%20Plan%20UPDATE.jpg?width=600&name=190625%20L5D%20+%20FV%20Landscape%20Plan%20UPDATE.jpg)

_2D drawing of the Jewel Changi Airport. Courtesy of PWP Landscape Architecture._

The Jewel Changi Airport is such a marvel that it makes you wonder how its uniform, revolutionary design could be done by over 10 different project groups. That’s what’s so great about the evolution of design technology — never before has it been so easy to engage in a seamless collaboration process that exceeds what could once be considered impassable communication boundaries.

###### Wondering what goes into coordinating a seamless project?   
See what BIM for landscape architecture has to offer.

[![SHOW ME](https://no-cache.hubspot.com/cta/default/3018241/45c250de-b9f2-4ba4-a8e9-23f7f65a982e.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/45c250de-b9f2-4ba4-a8e9-23f7f65a982e) 

 Topics: [Landscapes](https://blog.vectorworks.net/topic/landscapes) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.