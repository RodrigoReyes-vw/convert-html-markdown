[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# 3 Traits of Effective Leaders in BIM

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/231117_Women%20in%20BIM/blog-1440x800_Women%20in%20BIM-2.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Flead-with-empathy-ann-deng-women-in-bim)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=3%20Traits%20of%20Effective%20Leaders%20in%20BIM&url=https%3A%2F%2Fblog.vectorworks.net%2Flead-with-empathy-ann-deng-women-in-bim&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Flead-with-empathy-ann-deng-women-in-bim)

Ann Deng, a leader in the landscape architecture industry, champions the fostering of diversity and the offering of unwavering support for women in the field of Building Information Modeling (BIM). She shared her leadership mentality on an episode of the Women in BIM podcast titled “Working Smarter, Not Harder.”

As a senior associate for McGregor Coxall, Deng understands the value of BIM and how the workflows can be leveraged for better results. But, as many experience with their foray into BIM, change can be uncomfortable. She has several strategies she implements in her role at McGregor Coxall to not only help colleagues get familiar with BIM in Vectorworks, but also to nurture an excellent, diverse team.

![Women in BIM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/231117_Women%20in%20BIM/Women%20in%20BIM.jpg?width=1440&height=963&name=Women%20in%20BIM.jpg)

#### Work-Life Balance

As a mother, work-life balance is crucial for Deng. With more than half of the firm’s leaders being working parents, Deng stressed the importance of implementing policies and dynamics that cater to their needs. In this way organizations can create a supportive and inclusive environment that allows working parents to thrive both personally and professionally.

While she acknowledges the prevalent cultural expectation to toil relentlessly and constantly strive for more, Deng firmly believes that positive changes can be brought forth through enhanced communication and effective leadership. Notably, she emphasizes the utmost importance of serving as a stellar role model for fellow women in the industry.

#### Embracing Technology & Overcoming Resistance to Change

Deng is a big believer in the power of technology. Her joy for digital design is matched by her enthusiasm for mentoring others in their BIM journey.

One of the main hurdles faced in this digital transformation journey is the resistance to change among team members. Deng indicated that many individuals hesitate to embrace new technologies due to fear and a lingering attachment to traditional university education.

However, she emphasized that overcoming this resistance is crucial for the advancement of the industry. Setting examples, allowing people to make and learn from their mistakes, and showcasing the benefits of digital tools and processes helps organizations slowly break down these barriers and foster a culture of innovation.

#### Lead with Empathy

If you were to describe Deng’s leadership approach with a single word, “empathetic” would certainly be a contender. The need for empathy comes from several points in Deng’s journey to becoming a leader at McGregor Coxall.

First, as a mother, she knows how difficult it can be to balance work and home life, which gives her a great understanding of the needs of working parents.

Another aspect of her journey that led to her empathetic mindset was having to learn digital landscape architecture from the ground up. She’s aware of the process of getting acclimated and, therefore, is better prepared to nurture a team along the same or a similar journey.

By acknowledging the variety of personal backgrounds that make up an office, Deng can better cater her decision-making to foster an effective, balanced team.

#### Listen to the Full Conversation on the Women in BIM Podcast

Deng discussed her leadership style along with other aspects of being a woman in the BIM industry on the Women in BIM (WIB) podcast. You can check out the entire conversation on [Spotify](https://open.spotify.com/episode/2qVG8TwS1R6JB1FodPYLjA?si=zieAqM9DTG2eRTddtuhNqg), [Apple Music](https://podcasts.apple.com/ua/podcast/working-smarter-not-harder/id1619055060?i=1000628544821), or [Soundcloud](https://soundcloud.com/womeninbim/the-right-workflows?utm%5Fsource=clipboard&utm%5Fcampaign=wtshare&utm%5Fmedium=widget&utm%5Fcontent=https%253A%252F%252Fsoundcloud.com%252Fwomeninbim%252Fthe-right-workflows) by visiting episode 23, “Working Smarter, Not Harder.”

 Topics: [Landscapes](https://blog.vectorworks.net/topic/landscapes) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.