[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Employee in the Spotlight: Helping a Community in 360 Degrees

 Posted by [Samantha Hyatt](https://blog.vectorworks.net/author/samanthahyatt) | 2 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/171115_Gunther/Gunther_Discoveries.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Femployee-in-the-spotlight-helping-a-community-in-360-degrees)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Employee%20in%20the%20Spotlight:%20Helping%20a%20Community%20in%20360%20Degrees&url=https%3A%2F%2Fblog.vectorworks.net%2Femployee-in-the-spotlight-helping-a-community-in-360-degrees&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Femployee-in-the-spotlight-helping-a-community-in-360-degrees)

Our Vectorworks family is full of amazing people who work hard every day. However, making our software and services great isn’t all they do. Gunther Miller, quality assurance manager, was recently featured in [Howard Magazine](http://www.baltimoresun.com/news/maryland/howard/howard-magazine/bs-mg-ho-360-ellicott-city-20171009-story.html) (a publication of The Baltimore Sun Media Group) for donating his time to help local businesses that are reopening after severe flood damage.

![Gunther_Discoveries.png](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/171115_Gunther/Gunther_Discoveries.png?width=621&height=317&name=Gunther_Discoveries.png)

A 360-degree photo taken by Miller for the vintage store, Discoveries, in Ellicott City.

Old Ellicott City, the downtown area near our headquarters in Maryland, which includes many local, eclectic shops and restaurants, suffered the most damage. Many of these businesses spent months with closed doors as they dealt with the damage. Miller, who lives in the area, came up with a way to help reopening businesses after receiving a 360-degree camera for his birthday.

Using the camera, he shoots 360-degree images of building interiors for business owners who have recently reopened and posts them on his website, [360 Ellicott City](http://www.360ellicottcity.com/). The owner of each shop or restaurant is then free to use the pictures in marketing and on social media platforms. The photos give potential customers an immersive experience to see what it would be like to visit, eat, and shop in these places.

![Gunther _MissFIT.png](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/171115_Gunther/Gunther%20_MissFIT.png?width=621&height=317&name=Gunther%20_MissFIT.png)

An immersive view of Miss FIT in Ellicott City. 

“I’m just a 10-minute walk from the historic area, and consider the business owners of old Ellicott City my neighbors,” Miller says. “Initial recovery efforts were kick started by community donations and volunteer cleanup. I wanted to help my neighbors on some level that was unique and hopefully beneficial.”

Interested in giving your customers a similar 360-degree experience? Check out our video on the new rendered panorama feature in [Vectorworks 2018](http://www.vectorworks.net/en/2018?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=gunther111517). 

[![Watch Video](https://no-cache.hubspot.com/cta/default/3018241/a5eb199f-c554-4d54-b982-00be55357bac.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/a5eb199f-c554-4d54-b982-00be55357bac) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.