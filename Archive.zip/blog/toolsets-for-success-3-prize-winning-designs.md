[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Toolsets for Success: 3 Prize-winning Designs

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 3 min read time 

![stipendium-architektur-3](https://blog.vectorworks.net/hubfs/Blog%20Images/180824_Vectorworks%20Scholarship%20Roundup%20/stipendium-architektur-3.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Ftoolsets-for-success-3-prize-winning-designs)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Toolsets%20for%20Success:%203%20Prize-winning%20Designs&url=https%3A%2F%2Fblog.vectorworks.net%2Ftoolsets-for-success-3-prize-winning-designs&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Ftoolsets-for-success-3-prize-winning-designs)

Vectorworks loves supporting student designers. Our Design Scholarship does just that — it’s a chance for students to win a substantial cash prize along with recognition in the realm of design.

Take a look at these 2017 winners from Germany and Austria and the Vectorworks tools that brought them their glory.

###### **Alexander Drachenberg**

Drachenberg, then a [University of Wuppertal](https://www.uni-wuppertal.de/en/) student, submitted a project he calls[ “The Other Place.”](https://alexanderdrachenberg.com/the-other-place)

![drachenberg-scholarship](https://blog.vectorworks.net/hs-fs/hubfs/052719_2017%20Scholarship/drachenberg-scholarship.jpg?width=1200&name=drachenberg-scholarship.jpg)

_Alexander Drachenberg’s “The Other Place,” a 2017 Vectorworks Design Scholarship winner._ 

_Image courtesy of Alexander Drachenberg._

The building extends the width of the inner harbor in Hamburg, Germany, serving as both a bridge and a museum. Drachenberg’s vision was to create a space that “intends to be a kind of amplifier of this virtual-physical reality,” he writes on his website. “The Other Place” is an interactive museum which “reflects on the multiple diverse identities of the digital world.”

![stipendium-architektur-3](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/180824_Vectorworks%20Scholarship%20Roundup%20/stipendium-architektur-3.jpg?width=864&name=stipendium-architektur-3.jpg)

_Alexander Drachenberg, a 2017 Scholarship winner. Image courtesy of Alexander Drachenberg._ 

With [Vectorworks Designer](https://www.vectorworks.net/en/designer?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=2017Scholarship052819), Drachenberg cited his appreciation of the[ ever-growing content library](http://app-help.vectorworks.net/2019/eng/VW2019%5FGuide/ResourceManager/Resources.htm?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=2017Scholarship052819), adding that it let efficiency thrive. “I can start with everything from detail to the site plan with little effort,” he said.

###### **Florian Rothermel**

Rothermel, a graduate of [Karlsruhe Institute of Technology](http://www.kit.edu/english/index.php), wanted his project to showcase his interest in the relationship between natural power and human structures. So he designed a railway station in the Alps called “[Bergwärts](http://ebooks.computerworks.eu/vectorworks/stipendium/2017/rothermel-d-a/mobile/index.html#p=14).”

_![rothermel-scholarship](https://blog.vectorworks.net/hs-fs/hubfs/0527192017%20Scholarship/rothermel-scholarship.jpg?width=550&name=rothermel-scholarship.jpg)_

_Florian Rothermel, whose project “_[_Bergwärts_](http://ebooks.computerworks.eu/vectorworks/stipendium/2017/rothermel-d-a/mobile/index.html#p=14)_” was recognized in the 2017 Vectorworks Design Scholarship. Image courtesy of Florian Rothermel._

Rothermel used Vectorworks’ powerful 3D capabilities to visualize his design from the onset. The software offered him an intuitive space to generate a remarkable rendering from 2D schematics.

###### **Sophia Rodermund**

We recognized Sophia Rodermund, a [Hochschule Ostwestfalen-Lippe University of Applied Sciences](https://www.th-owl.de/en/international.html) graduate, for her interior design work on “[Dormouse – Staying in the Old Barn](http://ebooks.computerworks.eu/vectorworks/stipendium/2017/rodermund-d-a-ch/mobile/index.html#p=5).”

![Sophia Rodermund](https://blog.vectorworks.net/hs-fs/hubfs/052719_2017%20Scholarship/Sophia%20Rodermund.jpg?width=550&name=Sophia%20Rodermund.jpg)_Sophia Rodermund, who won the 2017 Vectorworks Design Scholarship in the interior design category. Image courtesy of Sophia Rodermund._

“During the design process, it is possible to quickly and easily switch between different modes of presentation, and to easily make changes and adjustments to the drawings,” she said of her use of Vectorworks. “That's exactly the advantage for me.”

For help with your submission, check out [Vectorworks Cloud Services](https://www.vectorworks.net/cloud-services?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=2017Scholarship052819), which lets you access, review, and share projects in an intuitive, easy-to-use cloud network.

###### **Will we see your design next?**

[![SUBMIT NOW](https://no-cache.hubspot.com/cta/default/3018241/343430d8-614c-4399-9173-a6914479ea2d.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/343430d8-614c-4399-9173-a6914479ea2d) 

 Topics: [Academic](https://blog.vectorworks.net/topic/academic), [Vectorworks Design Scholarship](https://blog.vectorworks.net/topic/vectorworks-design-scholarship), [BIM (Architecture)](https://blog.vectorworks.net/topic/bim-architecture), [Interiors](https://blog.vectorworks.net/topic/interiors) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.