[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# How Hamilton + Aitken Architects Maximize Natural Light

 Posted by [Guest Author](https://blog.vectorworks.net/author/guest-author) | 6 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/190722ChadHamilton/Chad_Office.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-hamilton-aitken-architects-maximize-natural-light)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=How%20Hamilton%20+%20Aitken%20Architects%20Maximize%20Natural%20Light&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-hamilton-aitken-architects-maximize-natural-light&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fhow-hamilton-aitken-architects-maximize-natural-light)

\*_[This article was originally published to ArchDaily on July 15, 2019](https://www.archdaily.com/919991/sustainable-school-design-how-hamilton-plus-aitken-architects-maximize-natural-light-using-vectorworks)._ 

---

“When we started out, our goal was to change the world, to do something that would really make a difference to the lives of people,” said Chad Hamilton, AIA LEED AP BD+C, Principal Architect of [Hamilton + Aitken Architects (H+AA)](http://haarchs.com/?utm%5Fmedium=website&utm%5Fsource=archdaily.com). “And education is one of the things that really determines how people live the rest of their lives. “So, for us it’s just awonderful feeling, to improve kids’ educational spaces.”

Whether working on schools, civic buildings, higher education, or other projects, the award-winning, San Francisco-based firm focuses on how each of these buildings will be used to enhance and enrich the lives of others.

Sustainable design also plays a major role in the projects H+AA undertakes. One of their most recent projects was the renovation for the Burlingame Intermediate School, south of San Francisco. The new additions support this school district’s concept for delivering education and resolves the physical challenges of a sprawling campus. 

Chad Hamilton has made design for education his focus for over twenty-five years. He is fascinated by the way different people learn, which motivates him as he leads diverse clients and user groups through the complexities of designing facilities for 21st-century learning. He also believes that the intersection of education and sustainability is critical to determine our path forward as a society, and that design is the key to unlock the future.

For the Burlingame Intermediate School, stakeholders spoke of creating a “heart” for the school, campus, and community, which was achieved by creating a new quad. The building is a bridge to the other parts of the campus, physically linking upper and lower campuses, and surrounding pathways are furnished with nooks and seating for socializing.

The design maximizes natural daylighting, while minimizing glare and solar heat gain. Windows and clerestories bring in abundant north light, while deep overhangs and fixed sunshades screen classrooms from direct light.

[ ](https://www.archdaily.com/919991/sustainable-school-design-how-hamilton-plus-aitken-architects-maximize-natural-light-using-vectorworks/5d153c18284dd1a2a00002e3-sustainable-school-design-how-hamilton-plus-aitken-architects-maximize-natural-light-using-vectorworks-image "Save image") 

[![Outdoor learning area. Image courtesy of Hamilton + Aitken Architects.](https://images.adsttc.com/media/images/5d15/3c18/284d/d1a2/a000/02e3/newsletter/Image_2.jpg?1561672713)](https://www.archdaily.com/919991/sustainable-school-design-how-hamilton-plus-aitken-architects-maximize-natural-light-using-vectorworks/5d153c18284dd1a2a00002e3-sustainable-school-design-how-hamilton-plus-aitken-architects-maximize-natural-light-using-vectorworks-image) 

_Outdoor learning area. Image courtesy of Hamilton + Aitken Architects._ 

“For us, a lot of the design process begins with thinking about light,” said Hamilton. “Light is an incredible motivator for learning spaces. It’s been demonstrated that students learn better and faster in spaces with natural daylighting. So, we like to bring as much natural daylighting in as we can.”

This building has a sawtooth roof with clear story windows that bring light in, and the classrooms toward the north side have large north facing windows. They also have a secondary light source away from the windows, a series of skylights.

“The space can be used with no lights on at all on a nice day,” Hamilton continued. “And then there’s a glass prow, and that prow aligns with the ridge line. So, the roof shape of this building seems unusual, but it’s all about bringing the light into the spaces."

[ ](https://www.archdaily.com/919991/sustainable-school-design-how-hamilton-plus-aitken-architects-maximize-natural-light-using-vectorworks/5d153c60284dd1a2a00002e5-sustainable-school-design-how-hamilton-plus-aitken-architects-maximize-natural-light-using-vectorworks-image "Save image") 

[![Upper hillside entrance. Image courtesy of Hamilton + Aitken Architects.](https://images.adsttc.com/media/images/5d15/3c60/284d/d1a2/a000/02e5/newsletter/Image_3.jpg?1561672787)](https://www.archdaily.com/919991/sustainable-school-design-how-hamilton-plus-aitken-architects-maximize-natural-light-using-vectorworks/5d153c60284dd1a2a00002e5-sustainable-school-design-how-hamilton-plus-aitken-architects-maximize-natural-light-using-vectorworks-image) 

_Upper hillside entrance. Image courtesy of Hamilton + Aitken Architects._ 

“When we look at our core architectural software we’re looking for something that’s easy to use, and that’s extremely accurate,” said Hamilton. “With [Vectorworks](https://www.vectorworks.net/en?utm%5Fcampaign=scholarship&utm%5Fcontent=july2019&utm%5Fmedium=intext&utm%5Fsource=archdaily), we can study the daylighting impact on our classrooms, and we can orient windows and shading so that classrooms get plenty of light without glare.”

One of their favorite tools within [Vectorworks Architect](https://www.vectorworks.net/en/architect?utm%5Fcampaign=scholarship&utm%5Fcontent=july2019&utm%5Fmedium=intext&utm%5Fsource=archdaily) is the [Heliodon tool](https://www.youtube.com/watch?t=6s&utm%5Fmedium=website&utm%5Fsource=archdaily.com&v=0%5Fdqn87iLgk), which simulates the position of the sun for light and shadow studies. By using this tool, the H+AA team can visualize and quantify how the sun affects their building, how much glass is appropriate for a given orientation, how to mitigate heat gain depending on climate, and so forth. You can also create a solar animation to study the light and shadow over a course of time.

[ ](https://www.archdaily.com/919991/sustainable-school-design-how-hamilton-plus-aitken-architects-maximize-natural-light-using-vectorworks/5d153ba5284dd1a2a00002df-sustainable-school-design-how-hamilton-plus-aitken-architects-maximize-natural-light-using-vectorworks-image "Save image") 

[![Use of the Heliodon tool. Image courtesy of Vectorworks, Inc.](https://images.adsttc.com/media/images/5d15/3ba5/284d/d1a2/a000/02df/newsletter/Image_4.jpg?1561672603)](https://www.archdaily.com/919991/sustainable-school-design-how-hamilton-plus-aitken-architects-maximize-natural-light-using-vectorworks/5d153ba5284dd1a2a00002df-sustainable-school-design-how-hamilton-plus-aitken-architects-maximize-natural-light-using-vectorworks-image) 

_Use of the Heliodon tool._ 

“The Heliodon tool is very cool,” said Hamilton. “You can look at the solar impact at different seasons, you can look at it in the middle of the summer, you can look at it in the middle of winter. It also lets us look at shadows. What we need to do with shadows is use roof overhangs or sun shades to modulate how the light comes into the building, so we can minimize heat gain, thus maximize natural lighting.”

The Heliodon tool is georeferenced and accurately generates shadows for your project based on its location. If you don’t see your locale in the extensive pull-down list, you'd just add your country and town, and its latitude and longitude.

Plus, with Vectorworks' built-in rendering package, you can either view solar animations interactively on the fly or export standalone movies, either from a fixed vantage point or from a top view. Roof overhangs and window placements can then be tested, refined, and validated to minimize summer heat gain and maximize passive heating potential in the winter.

“To create a ‘good looking’ building, things need to line up in a certain way to feel resolved,” said Hamilton. “With three-dimensional design and BIM software like Vectorworks, we can really see problems that we haven’t solved yet, quickly find alternative solutions, and come up with a really good solution that pleases everybody.”

 Topics: [Project Highlight](https://blog.vectorworks.net/topic/project-highlight) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.