[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# December Tech Roundup: The Best of 2019

 Posted by [Kamica Price](https://blog.vectorworks.net/author/kamica-price) | 2 min read time 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fdecember-tech-roundup-the-best-of-2019)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=December%20Tech%20Roundup:%20The%20Best%20of%202019&url=https%3A%2F%2Fblog.vectorworks.net%2Fdecember-tech-roundup-the-best-of-2019&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fdecember-tech-roundup-the-best-of-2019)

Every month, we give you a roundup of our latest and greatest tech tips. To celebrate the end of the year, here’s a look back at our best roundups from 2019.

## Lumion and Navigation Graphics Options

In April, we announced a partnership with Lumion for the LiveSync plug-in — the first partner plug-in to use a new Vectorworks Graphics Sync (VGS) API. We also shared a video on navigation graphics options that give you the best overall visual performance without having to spend on new hardware.

[![Show Me More](https://no-cache.hubspot.com/cta/default/3018241/6526d900-c498-4c07-8136-b8c0391fd0a4.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/6526d900-c498-4c07-8136-b8c0391fd0a4) 

## Visibility Tool and Custom Selection Scripts

**We turned the heat up in July with two videos: one on the Visibility tool, which grants flexibility in toggling visibility on classes and layers, and the other on custom selection scripts, an easy way to customize what geometry groups you select — plus, [a new workflow document](https://www.vectorworks.net/ebooks/strategic-planning-guide-adopting-bim-in-landscape-architecture-vectorworks-landmark?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=decembertechroundup121919) on the strategic [adopti](/landscape-architecture-is-evolving?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=decembertechroundup121919)[on](//blog.vectorworks.net/landscape-architecture-is-evolving?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=decembertechroundup121919) [of ](//blog.vectorworks.net/landscape-architecture-is-evolving?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=decembertechroundup121919)[BIM](//blog.vectorworks.net/landscape-architecture-is-evolving?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=decembertechroundup121919) for landscape architecture.**

**![custom-selection-scripts-blog-1](https://blog.vectorworks.net/hs-fs/hubfs/custom-selection-scripts-blog-1.jpg?width=1440&name=custom-selection-scripts-blog-1.jpg)**

[![Let Me See](https://no-cache.hubspot.com/cta/default/3018241/3eead92f-b301-4a65-9689-6e7c95d0a1af.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/3eead92f-b301-4a65-9689-6e7c95d0a1af) 

## Vectorworks 2020

September brought the release of [Vectorworks 2020](https://www.vectorworks.net/en-US/2020?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=decembertechroundup121919) and a first-hand collection of tech tips on the newest features — list browser direct editing, IFC referencing, a video camera object, and hardscape alignment.

![IFC-Referencing-Resize](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190919_Sept%20Tech%20Roundup/IFC-Referencing-Resize.jpg?width=1440&name=IFC-Referencing-Resize.jpg)

[![Read More](https://no-cache.hubspot.com/cta/default/3018241/f1b46ae9-b7d2-4da7-8e48-cc2a91c6eb8a.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/f1b46ae9-b7d2-4da7-8e48-cc2a91c6eb8a) 

## Walkthrough Animations and Door & Window Improvements

Vectorworks 2020 features also came with videos on walkthrough animations so you can share realistic 3D walkthroughs with project stakeholders. Version 2020 also brought improvements to the Door and Window tools, granting you greater control.

![walkthrough-animation](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/191017_October%20Tech%20Roundup/walkthrough-animation.jpg?width=1440&name=walkthrough-animation.jpg)

[![Learn More](https://no-cache.hubspot.com/cta/default/3018241/824de7d8-9e3a-434b-85f8-13b39c94eec3.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/824de7d8-9e3a-434b-85f8-13b39c94eec3) 

## The Data Manager

Last month’s tech roundup presented a comprehensive guide to the new Data Manager feature, which is sure to simplify your BIM workflows by gathering all of your data into one place. Plus, [three new ebooks](/workflow-wednesday-3-guides-youll-wish-you-read-sooner?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=decembertechroundup121919) on data visualization, styled objects, and leveraging BCF for IFC-based workflows.

![blog-images-nov-18](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/191121_November%20Tech%20Roundup/blog-images-nov-18.jpg?width=1440&name=blog-images-nov-18.jpg)

[![More Please](https://no-cache.hubspot.com/cta/default/3018241/72ab5673-3b04-4b89-99f3-696ce12aa5a7.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/72ab5673-3b04-4b89-99f3-696ce12aa5a7) 

Cheers to a year full of tech tips and here’s to more in 2020!

Give yourself the gift of expertise this holiday season. Head over to [Vectorworks University](/introducing-vectorworks-university-your-one-stop-shop-for-training?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=decembertechroundup121919), your one-stop shop for tech tips, training, tutorials, guides, and more!

[![Take Me There](https://no-cache.hubspot.com/cta/default/3018241/71056ce0-941a-40c2-baa8-dc2381fa9f47.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/71056ce0-941a-40c2-baa8-dc2381fa9f47) 

 Topics: [Product Launch](https://blog.vectorworks.net/topic/product-launch), [Partner Products](https://blog.vectorworks.net/topic/partner-products), [Tech Tips and Workflows](https://blog.vectorworks.net/topic/tech-tips-and-workflows), [BIM (Landscape)](https://blog.vectorworks.net/topic/bim-landscape) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.