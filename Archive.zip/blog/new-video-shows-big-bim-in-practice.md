[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Inside the BIM Process That Led to Scott Headquarters

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 2 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/171212_IttenBrechbuhl_Video/EF_03_16006_Pump%20Track_02_I+B_Scott%20Office%20Building_ine.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fnew-video-shows-big-bim-in-practice)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Inside%20the%20BIM%20Process%20That%20Led%20to%20Scott%20Headquarters&url=https%3A%2F%2Fblog.vectorworks.net%2Fnew-video-shows-big-bim-in-practice&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fnew-video-shows-big-bim-in-practice)

In this video, the team at [Itten+Brechbühl AG](https://www.ittenbrechbuehl.ch/en) discusses how successful implementation of a Big BIM process has transformed the way the firm approaches design — and solidified their name as a leading architecture firm in Switzerland.

CEO Christoph Arpagaus says that the particular strengths of Itten+Brechbühl AG are “the size and efficiency of the firm,” explaining that these things in tandem allows the firm to tackle large and complex projects effectively.

“In my experience, BIM strengthens the role of the architect by allowing for stronger coordination, stronger process control, and the ability to pull all the pieces of the project together,” said Susanne Keller of Itten+Brechbühl AG.

Did you happen to read our blog about that very topic? If you’re wondering what exactly Keller means, this is the blog for you.

[![READ: BIM OPTIMIZATION WITH VECTORWORKS ARCHITECT](https://no-cache.hubspot.com/cta/default/3018241/e608b6d5-3034-49c3-9da5-16ff3a35c0d1.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/e608b6d5-3034-49c3-9da5-16ff3a35c0d1) 

It’s no surprise that Itten+Brechbühl AG are finding extraordinary success with the BIM workflows in Vectorworks Architect. The advantages over a traditional 2D workflow are clear — coordinated files, the ability to extract information and drawings from the model with ease, automation of repetitive design tasks, and a much stronger way to collaborate.

One result of the firm’s BIM process is the Scott Headquarters, the head office of Scott Sports, a leading sports retail chain. You saw the project in the video — it’s a massive structure with over 600 office spaces that span almost 26,000 m2. That’s not to mention the façade, which seems to ebb and flow by way of its geometric window awnings, leaving you to wonder how such a marvel was conceived.

The building features a central atrium that stands as tall as the structure itself. According to the firm’s website, the atrium is accessed “via an impressive staircase leading from the entrance to the auditorium in one flowing motion along a curved wall.

Itten+Brechbühl AG received several awards for the project, including a 2021 Architizer A+ Award in the Mid Rise category. [Read more about the project and how the firm applies a sophisticated BIM process](https://www.vectorworks.net/en-US/customer-showcase/collaboration-with-3d-bim-models).

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.