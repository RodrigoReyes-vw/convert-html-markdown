[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Geiger Furniture | Masters of Vectorworks Fundamentals

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 7 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/210801_Geiger%20Furniture%20Case%20Study/Geiger%203-1.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-geiger-furniture-uses-fundamentals-to-create-custom-designs)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Geiger%20Furniture%20|%20Masters%20of%20Vectorworks%20Fundamentals&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-geiger-furniture-uses-fundamentals-to-create-custom-designs&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fhow-geiger-furniture-uses-fundamentals-to-create-custom-designs)

[Geiger Furniture](https://www.geigerfurniture.com/), part of the [MillerKnoll](https://newleaderinmoderndesign.com) group, designs high-quality contract furniture that expertly achieves both style and function. Geiger’s wood-centric designs can be found in Fortune 500 companies, esteemed law firms, and higher education buildings across the United States.

The furniture company offers casegoods, storage pieces, desks, tables, seating, and accessories — all with custom capabilities. [According to their site](https://www.geigerfurniture.com/about/), Geiger Furniture is rooted in community, finds its foundation in craft, and drives for quality.  

Heading up product development for Geiger are Brian Fuller, senior product development manager, and John Leach, program manager of new product development. Between the two of them, Fuller and Leach have roughly 42 years of experience in the furniture industry.

![Brian Fuller21](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210801_Geiger%20Furniture%20Case%20Study/Brian%20Fuller21.jpg?width=400&name=Brian%20Fuller21.jpg)

![John Leach small](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210801_Geiger%20Furniture%20Case%20Study/John%20Leach%20small.jpg?width=400&name=John%20Leach%20small.jpg)

_Brian Fuller (top) and John Leach (bottom) head up product design and development for Geiger._

The two hold an uncompromising trust in [Vectorworks Fundamentals](https://www.vectorworks.net/en-US/fundamentals/buy) for their design and coordination needs. Such commitment yields designs that give clients exactly what they want.

###### ![Geiger 1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210801_Geiger%20Furniture%20Case%20Study/Geiger%201.png?width=600&name=Geiger%201.png)A Unique Workflow

Before a Geiger Furniture piece ends up in a lobby, office, or conference room, it begins with Vectorworks Fundamentals. “Right from the product brief, we’re using Vectorworks as a design tool, and it really sets us up for how we disseminate information throughout the rest of the process."

The Geiger team follows two workflows, the first of which is for product design. Geiger works with [several world-class designers](https://www.geigerfurniture.com/about/our-designers/); and, when one of these designers has an idea for a new product, they present it to Fuller and Leach.

After the presentation, collaboration is the name of the game. Leach uses Vectorworks Fundamentals to draft technical drawings of the designer’s vision. “I find one of Vectorworks' biggest strengths is CAD-accurate technical illustration. It’s beautiful for that.”

These drawings serve as connection between Geiger and the designer. According to Fuller, their goal is one of service: to be an “advocate of the designer.”

![Geiger 2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210801_Geiger%20Furniture%20Case%20Study/Geiger%202.png?width=580&name=Geiger%202.png)

As is the case with many designers, Fuller views designing a new product as the beginning, not the end-goal. In fact, he compares it to parenthood, recognizing its longevity and need for care. After the new product is developed into a technical drawing, it’s passed to one of Geiger’s many Product Application Specialists. These specialists are well-versed in both Vectorworks and the sophisticated Geiger library.

“Essentially, the Product Application Specialists, who all use Vectorworks, are responsible for putting together all these parts and pieces that we’ve designed,” said Fuller. These specialists are doing such work thanks to the extensive library of toolsets that Leach has created using Vectorscript.

Once the specialists are finished with the design in Vectorworks, it’s ready to be converted to manufacturable engineering drawings that are ready for production.

The second workflow the Geiger team follows is for an existing product. When a customer interested in a Geiger piece decides on material, color, and other specifications, a Product Application Specialist then translates the design specs using Vectorworks Fundamentals. From here, a back-and-forth dialogue can take place between the specialist and a designer to verify details. After the technical drawing of the design is finished, it’s rendered using our integrated rendering feature set, Renderworks®, or an external partner rendering software for photorealistic representations.

Fundamentals is also used for Geiger’s customer materials. Leach said, “We’re using Vectorworks throughout the entire process. From design inception to order-entry, to install drawings, and further out.”

Start-to-finish use of Vectorworks makes up the Geiger workflow, said Leach. “Our business model is centralized on Vectorworks. Geiger is so custom-centric. We need a program powerful enough to be able to change parameters and change a product, so we can create not only a standard product but a custom product as well.”

###### Informed Customization and Communication

In its most boiled-down essence, Fuller and company use Vectorworks Fundamentals as a means of communication. Given the collaborative nature of Geiger’s workflows, they come across designers, engineers, and architects who’re using variety of software. But, thanks to Vectorworks’ file-sharing capabilities, the Geiger team can [import and export files](https://university.vectorworks.net/mod/scorm/player.php?a=335&currentorg=articulate%5Frise&scoid=670) without disrupting their work.

Not only is Fundamentals used to communicate with other professionals, but potential customers too. Fuller spoke about the importance of Vectorworks renderings when working with customers and clients: “It’s great for showing materiality and other details. You can say, ‘Hey, this is what we think you want. Does this look like what you want?’”

Leach is largely responsible for Geiger’s extensive customized toolsets, scripts, plug-in managers, and symbols library. According to Fuller, Leach’s role is a crucial to the Geiger Furniture process.

![Geiger 3](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210801_Geiger%20Furniture%20Case%20Study/Geiger%203.png?width=638&name=Geiger%203.png)

The level of detail Leach provides in creating these intelligent symbols seems to be the true key to Geiger’s ability to make a high-end, customizable product. Leach includes even the smallest details, such as how far a screw is going into a piece of wood or where there’s an opening for access to an electrical outlet.

These details allow for a conversation to take place throughout the furniture’s creation and placement. As Leach said, “It helps to have that level of detail. Otherwise, something’s going to go to engineering and they’re going to say, ‘Well, where does this go? How does this work?’”

Furthermore, Leach uses Vectorworks' powerful database to assign price and part numbers to symbols. Leach said that this data helps “drill down to a unique part a customer needs, based on the features and finishes that they’re selecting; and then, this data is driven into a specification process.”

###### Design Freedom is Fundamental

Geiger Furniture knows that Vectorworks is the go-to tool for the product design process. Fundamentals is a premier drawing and modeling tool with the flexibility you need to design and create anything you can imagine. Fundamentals offers 2D/3D capabilities and an easy-to-use modeling and documentation platform that works the way designers think. Subscribe and pay only for the length of time that you need a license.

[![GET FUNDAMENTALS TODAY](https://no-cache.hubspot.com/cta/default/3018241/0a16fff4-ede6-4a94-adff-ad30697ab5ea.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/0a16fff4-ede6-4a94-adff-ad30697ab5ea) 

_All images in this article are courtesy of Geiger Furniture._ 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.