[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# 3D Modeling Webinars for Interior Architects Using Vectorworks

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/220721_3%20Webinar%20for%20Interiors/Vectorworks%20Interiors_2.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Finteriors-vectorworks-webinars)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=3D%20Modeling%20Webinars%20for%20Interior%20Architects%20Using%20Vectorworks&url=https%3A%2F%2Fblog.vectorworks.net%2Finteriors-vectorworks-webinars&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Finteriors-vectorworks-webinars)

The more you learn, the more solutions you’ll have in your design tool belt.

In this post, you’ll find five webinars on 3D modeling that can also provide a boost to your interiors workflow.

#### Iterative design for interior architecture

Given the iterative nature of interior architecture, you need a software that gives you the flexibility to explore design options throughout every stage of your project.

Watch Kesoon Chance, senior industry specialist — interior architecture, and Luis M. Ruiz, senior architect product specialist, for advanced techniques for spatial planning, modeling, visualization, and new approaches to develop your designs. 

[WATCH THE WEBINAR](https://university.vectorworks.net/course/view.php?id=2681).

![23_webinar_BLDG_May_vimeo-thumbnail-1080x1920](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230503_May%20Webinars/23_webinar_BLDG_May_vimeo-thumbnail-1080x1920.png?width=1440&height=810&name=23_webinar_BLDG_May_vimeo-thumbnail-1080x1920.png)

You’ll do the following in the webinar: 

* Investigate different processes for effectively working with embedded, custom, and imported geometry to improve the quality of your design.
* Discover how to set lighting options to explore various atmospheres helping you make an informed design decision.
* Examine rendering techniques to help experiment in the development of your design.
* Enhance your design story with multiple techniques for generating unique props and using advanced Vectorworks Cloud Services technologies.

#### Embracing Vectorworks for interior design

Brooklyn-based design firm Claudia Giselle Design LLC., prides itself in creating luxurious interior designs that prioritize health and wellbeing. Before switching to Vectorworks, the firm relied on multiple different drafting software. Now they’re creating 2D and 3D models as well as high-quality renderings in one designer friendly software.

Watch Catelyn Seifert, interior designer at Claudia Giselle Design LLC., discuss how her firm has adopted Vectorworks — from conceptual designs all the way through final presentations.

[WATCH THE WEBINAR](https://university.vectorworks.net/course/view.php?id=2532).

![blog-1440x800_BLDG March Webinar](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230310_March%20Webinars%20LP%20Blog/blog-1440x800_BLDG%20March%20Webinar.png?width=1440&height=800&name=blog-1440x800_BLDG%20March%20Webinar.png)

You’ll do the following in the webinar:

* Review a complete design workflow — from ideation to presentation in Vectorworks.
* Discover the firm’s learning journey with the help of Vectorworks University, YouTube, and tech support. Plus, how these resources continue to help the firm improve their skills.
* Learn how templated files can help save time and establish high drafting standards.
* Discover how class overrides, templates, and Renderworks styles can be used to increase productivity.

#### FREEFORM MODELING FOR INTERIOR DESIGNS

In this webinar, you'll learn various methods for creating custom millwork and casework objects in Vectorworks. You'll also see how to improve your interiors workflow by creating custom building elements such as bulkheads, furniture, and ceiling treatments.

[WATCH THE WEBINAR](https://university.vectorworks.net/course/view.php?id=486).

![Vectorworks Interiors_3](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220721_3%20Webinar%20for%20Interiors/Vectorworks%20Interiors_3.png?width=1440&name=Vectorworks%20Interiors_3.png)

You’ll do the following in the webinar:

* Identify best practices of modeling for designing custom millwork elements to get the best output for visualization and documentation.
* Explore workflows for designing and documenting custom furniture and exhibit design.
* Discover when to use different types of 3D geometry to achieve the best outcome for your designs.
* Determine when to apply color, texture, and lighting for best visualization effects.

#### Transforming Your Workflow for Interior Projects

This webinar follows Eastlake Studio and their journey to transform their entire design process from a traditional 2D workflow to a fully integrated data-driven 3D modeling process.

[WATCH THE WEBINAR](https://university.vectorworks.net/course/view.php?id=342).

![Vectorworks Interiors_2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220721_3%20Webinar%20for%20Interiors/Vectorworks%20Interiors_2.png?width=1440&name=Vectorworks%20Interiors_2.png)

You’ll do the following in the webinar:

* Discover how a 3D modeling approach helps solve common design problems.
* Understand how to transition from a traditional 2D workflow to new customizable workflow using new tools and technology.
* Learn techniques to take full advantage of your 3D model for communicating design intent effectively.
* Discuss lessons learned by implementing 3D workflows for your interiors projects.

#### Data-Driven 3D Modeling for Interiors

With more technology available to interior and architectural designers, the traditional approach to developing commercial projects is moving to exciting new places. 

Your workflow is no longer just about providing 2D drawings and details; great visualizations and smart take-offs can all be a part of your design process. In this presentation, you’ll learn how you can increase your efficiency and win more work with an integrated data-driven 3D modeling process.

[WATCH THE WEBINAR](https://university.vectorworks.net/course/view.php?id=2084).

![Vectorworks Interiors_1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220721_3%20Webinar%20for%20Interiors/Vectorworks%20Interiors_1.png?width=1440&name=Vectorworks%20Interiors_1.png)

You’ll do the following in the webinar:

* Discover how data-driven workflows can impact the project’s bottom line by integrating a more effective design process.
* Understand the use and benefits of interior-specific parametric tools that you need to optimize the creation of your design presentations and project documentation.
* Learn how to effectively set up and organize a project file to streamline the adoption of a 3D workflow.
* Explore the differences between 2D and 3D approaches for your design process and learn how you can better implement a 3D workflow for your firm.

#### MORE WEBINARS FOR YOU

For more webinars and tutorials, like the ones in this blog, click the button below:

[![BROWSE VECTORWORKS UNIVERSITY](https://no-cache.hubspot.com/cta/default/3018241/80cc3a4d-d8da-4e1e-87d3-d9a3e929e246.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/80cc3a4d-d8da-4e1e-87d3-d9a3e929e246) 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.