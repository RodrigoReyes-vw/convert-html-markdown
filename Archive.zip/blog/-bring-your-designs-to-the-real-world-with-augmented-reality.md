[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Bring Your Designs To The Real World With Augmented Reality

 Posted by [Samantha Hyatt](https://blog.vectorworks.net/author/samanthahyatt) | 2 min read time 

![vectorworks_ar_image_720-2](https://blog.vectorworks.net/hubfs/vectorworks_ar_image_720-2.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2F-bring-your-designs-to-the-real-world-with-augmented-reality)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Bring%20Your%20Designs%20To%20The%20Real%20World%20With%20Augmented%20Reality&url=https%3A%2F%2Fblog.vectorworks.net%2F-bring-your-designs-to-the-real-world-with-augmented-reality&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2F-bring-your-designs-to-the-real-world-with-augmented-reality)

Augmented reality (AR) has had a lot of attention lately — it is easily one of the hottest newest technologies of the last two years after the worldwide popularity of [Pokémon Go](//blog.vectorworks.net/2016/09/virtual-reality-going-mind-behind-vr-vectorworks-2017?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=nomadar011618). The technology’s ability to superimpose a computer-generated image on a real-world view is now available for consumer mobile devices, making immersive and compelling viewing available to everyone. And in response to the fast-moving development of this technology, tech companies are creating new workflows.

Today, we’re proud to announce we’re one of the first developers to add AR capabilities. Our free Vectorworks Nomad mobile app now offers a new viewing mode available on iOS devices that support Apple’s ARKit technology. While many third-party ARKit-based apps are available on the App Store, few exist for viewing CAD/BIM models. And, none allowed Vectorworks users to view their models in AR directly — until now.

![Vectorworks_Nomad_AR.png](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/181601_NomadAR/Vectorworks_Nomad_AR.png?width=621&height=466&name=Vectorworks_Nomad_AR.png) 

Trying out new office furniture at the Vectorworks headquarters.

Nomad already had a 3D model viewing mode that let the user orbit around a model or walk through a model. However, with this new viewing mode, users can view [Vectorworks](http://www.vectorworks.net/?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=nomadar011618) models at their actual size and in context with the real world to make design decisions before they are built. The AR viewing mode removes the barrier between the virtual model and the real world, helping users and clients to better understand the design at scale, as well as illustrate potential design problems and facilitate discussion about the design.

Learn more about the new AR functionality in the Nomad app with this video.

Vectorworks users are already embracing the new AR technology. “As a must-have companion to Vectorworks, Nomad with AR represents a defining moment in working interactively with models,” said Brian Goodridge, principal at [Thor Studios](http://www.thorstudiosinc.com/). “It’s a powerful tool when designing kitchens and custom cabinetry, because AR allows me to project my Vectorworks models into real-world spaces. Clients are now able to view and interact with my new kitchen designs inside their home before the cabinets are ever built.”

Download the free Nomad app from [iTunes](https://itunes.apple.com/us/app/vectorworks-nomad/id506706850?mt=8).

For further information on the AR capabilites: [![Check Out Our Press Release](https://no-cache.hubspot.com/cta/default/3018241/e6f06596-f614-4995-8583-6451e82baf12.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/e6f06596-f614-4995-8583-6451e82baf12) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.