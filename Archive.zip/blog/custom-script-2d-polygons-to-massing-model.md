[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Custom Marionette Script: 2D Polygon to Massing Model

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 2 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/200601%20Marionette%20Monday/4818-2005-marionette-monday-blog-post-landmark.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fcustom-script-2d-polygons-to-massing-model)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Custom%20Marionette%20Script:%202D%20Polygon%20to%20Massing%20Model&url=https%3A%2F%2Fblog.vectorworks.net%2Fcustom-script-2d-polygons-to-massing-model&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fcustom-script-2d-polygons-to-massing-model)

A common workflow in the early stages of landscape architecture/design is to represent structures with 2D geometry to provide the site with a frame of reference. You’d import 2D GIS shapefiles like roads, topography, and buildings, then maintain the geometry’s data in what Vectorworks calls “records.” 

When you're ready to work in 3D, though, manually converting shapefiles to massing models can be time-consuming. What if there were a way to automate it?

Well, there is. We’ve created a script that streamlines the creation of data\-rich massing models from shapefiles. Visit the forum post for a free download.

[![GET THE FILE](https://no-cache.hubspot.com/cta/default/3018241/7febdd29-3849-4f77-841d-862fe1c73bde.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/7febdd29-3849-4f77-841d-862fe1c73bde) 

The file contains a [Marionette](https://www.vectorworks.net/training/marionette?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=060120landmarionette) network that reads the record format information attached to a polygon and uses it to create the massing model. It also transfers all attached records to the massing model, keeping all your data on-hand. It’ll work with any data record and is highly customizable, so you can use the script for projects with different needs. The file also includes a worksheet that you can use to calculate floor usage data in multistory buildings.

![2D_to_Massing-Model](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/200601%20Marionette%20Monday/2D_to_Massing-Model.gif?width=600&name=2D_to_Massing-Model.gif) 

Wondering how this script was developed? [Learn more about algorithms-aided design with Marionette.](/what-is-marionette-a-look-at-vectorworks-algorithmic-modeling-tool?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=060120landmarionette) 

Join the conversation on social media using #MarionetteMonday. 

Exceptional design demands exceptional tools and platforms built to deliver absolute creative expression and maximum efficiency. At Vectorworks, we believe your design software should offer the freedom to follow your imagination wherever it may lead. See for yourself with a free 30-day trial of Vectorworks. [Click here](https://www.vectorworks.net/trial/form)  for more information. 

If you're still in school or a recent graduate and are looking for that all-in-one solution, check out Vectorworks' academic programs and see how you can get free or discounted software. [Click here](https://www.vectorworks.net/en-US/education) for more information.

Make the most of your software experience with [Vectorworks University](https://university.vectorworks.net/). Take classes online, sign up for one of our webinars, or schedule a training session. Beginners and experienced designers alike will gain new skills, fine-tune workflows, and dive into all you can do with Vectorworks. 

 Topics: [Tech Tips and Workflows](https://blog.vectorworks.net/topic/tech-tips-and-workflows) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.