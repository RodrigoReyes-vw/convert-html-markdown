[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# WATCH: Vectorworks Design Summit Virtual Presentations

 Posted by [Leslie Briggs](https://blog.vectorworks.net/author/leslie-briggs) | 2 min read time 

![](https://blog.vectorworks.net/hubfs/4930_2020-design-summit-virtual-summit-social-promotion-blog-1440x800.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fwatch-vectorworks-design-summit-virtual-presentations)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=WATCH:%20Vectorworks%20Design%20Summit%20Virtual%20Presentations&url=https%3A%2F%2Fblog.vectorworks.net%2Fwatch-vectorworks-design-summit-virtual-presentations&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fwatch-vectorworks-design-summit-virtual-presentations)

You’ve likely heard that [we’ve cancelled our Vectorworks Design Summit](/vectorworks-design-summit-cancelled-due-to-coronavirus-concerns?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=button&utm%5Fcontent=042320summitkeynote) due to COVID-19\. This decision comes with a heavy heart—but, even though we can’t be together in person, we still believe in the value the event brings to our users.

That’s why we’ve put together a virtual presentation by our CEO, Dr. Biplab Sarkar. In lieu of a standard in-person presentation, Dr. Sarkar will give this virtual keynote as a kickoff, a veritable start-your-engines to ring in the Design Summit. This keynote as well as other speaker presentations are available to you now, on-demand.

Dr. Sarkar covers a variety of topics, including partnerships, business strategies for 2020 and beyond, Vectorworks’ continued focus on BIM, and more. Check it out now, and celebrate the Design Summit with us as best we can!

![4930_2020-design-summit-virtual-summit-social-promotion-blog-1440x800](https://blog.vectorworks.net/hs-fs/hubfs/4930_2020-design-summit-virtual-summit-social-promotion-blog-1440x800.png?width=1441&name=4930_2020-design-summit-virtual-summit-social-promotion-blog-1440x800.png)

That’s not all—we’ve also released industry-specific presentations by our product experts.

Our architecture presentation is by Vectorworks Product Marketing Director, Rubina Siddiqui, Assoc. AIA. She discusses [Big BIM](https://www.vectorworks.net/en-US/architect/bim?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=042320summitkeynote) in architecture, touching specifically on the following:

* Continuous improvement for large models
* Optimizing workflows with Open BIM partners
* Sharing your successes with the world through presentation capabilities

Eric Gilbey, PLA, presents on [BIM in landscape architecture](http://www.vectorworks.net/en/start/bim-for-landscape?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=042320summitkeynote). Gilbey, Vectorworks' product marketing manager for the landscape industry, talks about the following topics:

* BIM made specifically for landscape architects
* Empowering landscape architects to have software choice
* Continuous investment in robust tools for the site

Our [interiors](https://www.vectorworks.net/en-US/start/interiors?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=042320summitkeynote) presentation is by Vectorworks Director of Digital Practice Strategy, Martyn Horne. He discusses the investments being made to best accommodate this industry and its users, primarily in the US, Japan, the UK, and Germany.

Brandon Eckstorm, Vectorworks’ product marketing manager for the entertainment industry, covers the power of 3D workflows in [Vectorworks Spotlight](https://www.vectorworks.net/en-US/spotlight?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=042320summitkeynote). This comes on the tails of many recent upgrades to the all-in-one entertainment workflow that includes event design, rigging design and analysis with [Braceworks](https://www.vectorworks.net/en/braceworks?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=042320summitkeynote), system design with [ConnectCAD](/connectcad2020-hits-entertainment-market?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=042320summitkeynote), and pre-visualization with [Vision](https://www.vectorworks.net/en/vision?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=042320summitkeynote).

These industry presentations are open access for _anyone_! It’s a learning opportunity you absolutely won’t want to miss. And if you can’t get enough, additional sessions will be available through Vectorworks University.

[![WATCH NOW](https://no-cache.hubspot.com/cta/default/3018241/fef62d7d-b19b-4108-bc45-de2b801c36c7.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/fef62d7d-b19b-4108-bc45-de2b801c36c7) 

 Topics: [Vectorworks Design Summit](https://blog.vectorworks.net/topic/vectorworks-design-summit), [COVID-19](https://blog.vectorworks.net/topic/covid-19), [BIM (Architecture)](https://blog.vectorworks.net/topic/bim-architecture), [BIM (Landscape)](https://blog.vectorworks.net/topic/bim-landscape), [Production & Lighting Design](https://blog.vectorworks.net/topic/production-lighting-design), [News](https://blog.vectorworks.net/topic/news) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.