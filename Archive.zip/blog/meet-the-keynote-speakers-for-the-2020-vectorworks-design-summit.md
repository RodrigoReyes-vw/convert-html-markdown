[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Meet the Keynote Speakers for the 2020 Vectorworks Design Summit

 Posted by [Kamica Price](https://blog.vectorworks.net/author/kamica-price) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/20200212_Design%20Summit%20Keynote%20Announcement/blog-images-feb-12.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fmeet-the-keynote-speakers-for-the-2020-vectorworks-design-summit)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Meet%20the%20Keynote%20Speakers%20for%20the%202020%20Vectorworks%20Design%20Summit&url=https%3A%2F%2Fblog.vectorworks.net%2Fmeet-the-keynote-speakers-for-the-2020-vectorworks-design-summit&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fmeet-the-keynote-speakers-for-the-2020-vectorworks-design-summit)

If these five reasons to attend the [Vectorworks Design Summit](https://www.vectorworks.net/design-summit?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=021320entkeynote) weren’t enough to convince you, here’s another reason to join us — we have two incredible keynote speakers.

[Already registered? Here’s what you can expect at the Design Summit.](/heres-what-you-missed-at-the-2018-vectorworks-design-summit?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=callout&utm%5Fcontent=021320entkeynote)

## The Design Keynote

This year, International Lighting Designer Roland Greil will take the stage as our first-ever entertainment design keynote speaker.

![keynote-speakers-r-greil-hs](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/20200212_Design%20Summit%20Keynote%20Announcement/keynote-speakers-r-greil-hs.jpg?width=300&name=keynote-speakers-r-greil-hs.jpg)_Woodroffe Bassett Design Lighting Designer Roland Greil_

As a lighting designer at [Woodroffe Bassett Design](https://www.woodroffebassett.com/), Greil has worked on large-scale productions for some of the biggest names in music such as [The Rolling Stones](https://rollingstones.com/), [Phil Collins](http://www.philcollins.com/), and [Adele](http://adele.com/home/). His most recent work includes lighting design for the current [Rammstein stadium tour](https://www.rammstein.de/de/) together with longtime collaborator Patrick Woodroffe.

![blog-images-feb-12](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/20200212_Design%20Summit%20Keynote%20Announcement/blog-images-feb-12.jpg?width=480&name=blog-images-feb-12.jpg)_The Rolling Stones No Filter Tour | Design by Woodroffe Bassett Design | Photo by Manfred H. Vogel_

In addition to his work in the concert and touring sector, Roland has been involved with TV shows like the Eurovision Song Contest, a variety of large-scale special events, as well as a number of corporate and theater productions.

He’s offered multiple lectures around the world, is the author of the book “Show Lighting,” and was nominated for multiple awards internationally, including the Parnelli, TPI, and Top Dog Tour awards.

You can catch his talk, “Design Efficiency in Complex Conditions,” on Friday, April 24 at 9 a.m.

Using examples from his own entertainment design work, Greil will explore how software-assisted collaboration with project stakeholders — creative and drafting departments, installation and construction professionals, project managers, and more — sets the stage for success, no matter the industry.

## The CEO Keynote

Vectorworks CEO Dr. Biplab Sarkar, having presented at every Design Summit since its inception in 2015, will continue the tradition on Thursday, April 23 at 9 a.m.

His talk, “Simplicity to Design the Complex,” will focus on Vectorworks’ strategies to see where the company and products are headed. He’ll speak on partnerships, acquisitions, emerging technologies, and how Vectorworks continues to adapt to an ever-changing world of intelligent design. 

![biplab-sarkar-resize](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/20200213_Design%20Summit%20Keynote%20Announcement/biplab-sarkar-resize.jpg?width=300&name=biplab-sarkar-resize.jpg)_Vectorworks CEO Dr. Biplab Sarkar_

[Who else is speaking?](https://www.vectorworks.net/design-summit/speakers?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=callout&utm%5Fcontent=021320entkeynote)

There’s still time to register for the ultimate training event where you’ll be able to take advantage of over 90 hours of training and more than 40 industry sessions and workshops. Did we mention there will be one-on-one tech support and networking events? Plus, it’ll be a ton of fun.

See you in San Diego!

[![I Want In](https://no-cache.hubspot.com/cta/default/3018241/4a19af40-4101-443f-b8ee-87640e0f36b2.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/4a19af40-4101-443f-b8ee-87640e0f36b2) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.