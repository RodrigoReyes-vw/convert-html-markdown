[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# June Webinars: BIM, Data-Driven Documentation, & House of Worship Market

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/060921_June%20Webinars/20-2007-us-webinar-land-september-rise-cover-image-1680x1120.jpeg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinars-june-2021)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=June%20Webinars:%20BIM,%20Data-Driven%20Documentation,%20&%20House%20of%20Worship%20Market&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinars-june-2021&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-webinars-june-2021)

Continue your education and earn accreditation with Vectorworks’ monthly webinars. Whether you are a beginner or experienced designer, you can gain new skills, fine\-tune workflows, and discover all you can do with Vectorworks. The more you know, the more you can create with Vectorworks.

## Architecture | Streamlining Workflows for Data-Driven Documentation

_Tuesday, June 15 | 2 pm EST_

Spend more time designing and less time documenting by transitioning from a 2D to a 3D workflow. The benefits go beyond visualization aspects of 3D modeling. Creating a Building Information Model (BIM) will allow you to largely automate your workflow because BIM objects have built-in data that can be extracted using documentation tools. Sarah Barrett, Associate AIA and Senior Architect Product Specialist of Vectorworks will be explaining the purposes of the tools as well as how to efficiently document your model. Join this webinar to maximize your data automation and leverage smart tools for documentation and drawing. 

This course is approved for 1 AIA LU elective. Also, attendees who are members of Canadian Associations AIBC, AAA, AANB, ALBNL, and NSAA are eligible for 1 core learning hour/unit.

[![Sign Me Up](https://no-cache.hubspot.com/cta/default/3018241/9a9ff2d1-0f8a-4024-bc16-b264ad342c36.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/9a9ff2d1-0f8a-4024-bc16-b264ad342c36) 

![2105-june-bldg-webinar-rise-cover-image-1680x1120](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/060921_June%20Webinars/2105-june-bldg-webinar-rise-cover-image-1680x1120.jpg?width=1680&name=2105-june-bldg-webinar-rise-cover-image-1680x1120.jpg) 

## Landscapes | The World According to BIM

_Thursday, June 24 | 2 pm EST_

Everyone is talking about BIM – big BIM, small BIM, BIM level 2\. But what should you think of before you start on your BIM journey? By making sure your project is in order, with the right structure and 

knowledge, you can make the transition into the World of BIM a whole lot easier. This webinar is focusing on the resources and structure you will be grateful to have in place when you approach your first BIM Execution Plan – it will show you how and why you should have templates prepared, how to work with libraries of resources, and how to ensure that you use all of Vectorworks’ tools when it comes to placing your project in the real world with help of GIS.

[![Sign Me Up](https://no-cache.hubspot.com/cta/default/3018241/93c004e8-fce3-4f40-8c56-d4e2d20ad0da.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/93c004e8-fce3-4f40-8c56-d4e2d20ad0da) 

![20-2007-us-webinar-land-september-rise-cover-image-1680x1120](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/060921_June%20Webinars/20-2007-us-webinar-land-september-rise-cover-image-1680x1120.jpg?width=1680&name=20-2007-us-webinar-land-september-rise-cover-image-1680x1120.jpg)

## Entertainment | Evolving the House of Worship Market

_Wednesday, June 23 | 2 pm EST_

As each generation has changed, so has the experience of Sunday church service. In some churches, services have become more technical involving a stage, lighting designs, and programming for special events. Join Andy Bentley, Central Production Director at Elevation Church, as he shares his journey as a lighting designer navigating a difficult industry. See Bentley’s tips and tricks on rendering, organization on files and sheet layers, and collaborating with internal teams.

[![Sign Me Up](https://no-cache.hubspot.com/cta/default/3018241/2a8c15ec-9416-4ad2-b2de-4cc75aa0d228.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/2a8c15ec-9416-4ad2-b2de-4cc75aa0d228) 

![2105-june-ent-webinar-rise-cover-image-1680x1120](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/060921_June%20Webinars/2105-june-ent-webinar-rise-cover-image-1680x1120.jpg?width=1680&name=2105-june-ent-webinar-rise-cover-image-1680x1120.jpg)

If you're still wanting more content to push your creativity, check out [last month's webinars](../../../net/vectorworks/blog/may-webinars-home-theaters-design-build-efficiency-av-design.html). In the month of May, we highlighted home theaters, design-build efficiency, and entertainment design. 

 Topics: [Tech Tips and Workflows](https://blog.vectorworks.net/topic/tech-tips-and-workflows), [BIM (Landscape)](https://blog.vectorworks.net/topic/bim-landscape), [Production & Lighting Design](https://blog.vectorworks.net/topic/production-lighting-design) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.