[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Architecture Around the World: Mexico, Colombia, and Argentina

 Posted by [Cozette Conrad](https://blog.vectorworks.net/author/cozette-conrad) | 4 min read time 

![blog-images-dec-3](https://blog.vectorworks.net/hubfs/blog-images-dec-3.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Farchitecture-around-the-world-mexico-colombia-and-argentina)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Architecture%20Around%20the%20World:%20Mexico,%20Colombia,%20and%20Argentina&url=https%3A%2F%2Fblog.vectorworks.net%2Farchitecture-around-the-world-mexico-colombia-and-argentina&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Farchitecture-around-the-world-mexico-colombia-and-argentina)

Latin America is home to countless architectural wonders, some thousands of years old and some paving the way for the future. Our new distribution partners at[ Aufiero Informática](https://www.aufieroinformatica.com/) are bringing Vectorworks to Mexico, Colombia, and Argentina, supporting Latin American designers as they create beautiful and meaningful projects across the globe.

Here are just a few things we love about design in these countries:

###### **Mexico**

Mexico City holds the current title of[ World Design Capital](http://wdo.org/programmes/wdc/wdcmexicocity2018/), granted by the World Design Organization for its role as a model city for tackling urbanization challenges and improving livability. Innovation, creativity, and passion drive designers to blend old and new in this global city.

![Palacio de Bellas Artes](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/191203_Spanish%20Launch/iStock-970997780.jpg?width=600&name=iStock-970997780.jpg)_Palacio de Bellas Artes in Mexico City. Image courtesy of iStock._

Mexico is also home to[ 35 UNESCO World Heritage Sites](https://whc.unesco.org/en/statesparties/mx), meeting the organization’s criteria “to represent a masterpiece of human creative genius,” and leading the Americas as the country ranking highest on the list. 

Ancient architectural wonders are only one aspect of Mexico’s design prowess. Modern, futuristic, and sustainable structures pervade the country. From[ unique contemporary museums](https://www.dezeen.com/2017/05/05/five-best-new-contemporary-museums-mexico-roundup/) to[ revitalized public spaces ](https://www.dezeen.com/2019/10/21/brick-arcade-mmx-earthquake-public-square-mexico/)to[ temporary structures with lasting impacts](https://www.dezeen.com/2019/10/23/gerardo-broissin-design-week-mexico-pavilion/), Mexican architects infuse their passion and talents into countless awe-inspiring projects.

###### **Colombia**

Colombia is also rife with charming structures from the past. But modern-day architects are revamping its cities one project at a time, complementing the old with the new to ensure a safe, clean, livable future.

Take Medellín for example. As one[ New York Times article](https://www.nytimes.com/2012/05/20/arts/design/fighting-crime-with-architecture-in-medellin-colombia.html) describes, “For some time now, if you asked architects and urban planners for proof of the power of public architecture and public space to remake the fortunes of a city, they’d point here.” The city’s leaders incorporate architecture into their plans for community development and education, linking improvement efforts to “glamorous infrastructure.” 

Bogotá, the country’s capital, is also home to[ several architecture and urban design projects](https://www.archdaily.com/893535/6-upcoming-projects-that-will-improve-the-quality-of-life-in-colombia) aimed at boosting quality of life. Successful improvement projects — like the[ TransMiCable](https://www.transmilenio.gov.co/TransMiCable/) public transit system — continue to inspire innovative entrepreneurs to revolutionize their city through creativity. One firm even developed a[ line of toys](https://www.archdaily.com/910650/giancarlo-mazzanti-develops-architectural-toy-series-inspired-by-bogota-pavilion) modeled after their design of the popular[ Bosque de la Esperanza](http://www.elequipomazzanti.com/en/proyecto/cazuca-2/) community sports center.

![Plaza Bolivar](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/191203_Spanish%20Launch/iStock-505774309.jpg?width=600&name=iStock-505774309.jpg)_Plaza Bolivar, the historic heart of Bogotá. Image courtesy of iStock._

###### **Argentina**

Argentina’s capital city, Buenos Aires, was recently chosen by the[ Bureau International des Expositions (BIE)](https://www.bie-paris.org/site/en/) to host[ Expo 2023](http://en.expo2023argentina.com.ar/) — as the first Latin American city to host a BIE convention. With a theme of “creative industries in digital convergence,” the Expo will last three months and attract millions of tourists, so the location is not chosen lightly.

Like Mexico and Colombia, Argentina’s aesthetic marries ancient and modern architecture to create a charming and livable space. Buenos Aires ranks 91st in the world for quality of life, making it the[ second Latin American city](https://www.archdaily.com/914434/these-are-the-20-most-livable-cities-in-latin-america-in-2019) on the list. You could fill an entire vacation with[ architectural sight-seeing](https://www.architecturaldigest.com/gallery/20-must-see-buenos-aires-landmarks) around Buenos Aires without running out of destinations.

![Argentine National Congress](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/191203_Spanish%20Launch/iStock-530301157.jpg?width=600&name=iStock-530301157.jpg)_Palace of the Argentine National Congress, a tourist stop in Buenos Aires. Image courtesy of iStock._

The trend of “architectural recycling” thrives in Buenos Aires, with designers giving new life to old buildings.[ Centro Cultural Kirchner](https://turismo.buenosaires.gob.ar/en/otros-establecimientos/cck), Latin America’s largest cultural center, was once a post office, while performance art venue[ Usina del Arte](https://turismo.buenosaires.gob.ar/en/otros-establecimientos/usina-del-arte) used to be a power plant.

We’re honored to work with Aufiero Informática to spread Vectorworks across these architecturally diverse, impressively innovative, and uniquely beautiful countries.

###### Designing in Latin America? **Vectorworks 2020 Versión en Español is available now.**

[![EMPIEZA A DISEÑAR](https://no-cache.hubspot.com/cta/default/3018241/5f9ee987-7f6c-437f-9e81-9ee598d9cec6.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/5f9ee987-7f6c-437f-9e81-9ee598d9cec6) 

 Topics: [Product Launch](https://blog.vectorworks.net/topic/product-launch) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.