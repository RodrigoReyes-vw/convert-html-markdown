[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Students, Don't Miss Your Chance to Win $10,000

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 2 min read time 

![Vectorworks Design Scholarship 2019 image](https://blog.vectorworks.net/hubfs/Vectorworks%20Design%20Scholarship%202019%20image.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fstudents-dont-miss-your-chance-to-win-10000)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Students,%20Don't%20Miss%20Your%20Chance%20to%20Win%20$10,000&url=https%3A%2F%2Fblog.vectorworks.net%2Fstudents-dont-miss-your-chance-to-win-10000&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fstudents-dont-miss-your-chance-to-win-10000)

Time is running out! Students, don’t forget to apply to the [2019 Vectorworks Design Scholarship](https://www.vectorworks.net/scholarship/?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=dontmissyourchance022519), where you could win $10,000 USD. You can even recycle old work — just make sure you submit by August 29, 2019 and answer the 3 short questions in 150 words or less. It’s that easy.

To spark your inspiration, read on to see a few past submissions and some advice from past winners.  

![Carrie-Submission](https://blog.vectorworks.net/hs-fs/hubfs/190225_Dont%20Miss%20Your%20Chance%20/Carrie-Submission.jpg?width=536&name=Carrie-Submission.jpg)

Submitted by the University of Cincinnati’s Wes Calkin, this stage lighting design was recognized in 2014.

![dudak](https://blog.vectorworks.net/hs-fs/hubfs/190225_Dont%20Miss%20Your%20Chance%20/dudak.jpg?width=433&name=dudak.jpg)

Stephanie Dudak of Philadelphia University designed this Dragon Boat Training Facility for Barbados Island in Norristown, PA.

![polozenko](https://blog.vectorworks.net/hs-fs/hubfs/190225_Dont%20Miss%20Your%20Chance%20/polozenko.jpg?width=468&name=polozenko.jpg)

This “socially seductive and environmentally productive” design, called BIGnature, designed by Natasha Polozenko of the Harvard Graduate School of Design, was recognized in 2015.

![Benno-Submission-e1494853406256](https://blog.vectorworks.net/hs-fs/hubfs/190225_Dont%20Miss%20Your%20Chance%20/Benno-Submission-e1494853406256.jpg?width=350&name=Benno-Submission-e1494853406256.jpg)

The Museum of Contemporary Arts in Bonn, by Benno Schmitz, a Beuth Hochschule für Technik Berlin student, won the 2015 grand prize. Schmitz’s advice: “Stop dreaming and just do it!

The way you communicate your work can be just as important as the work itself. Take some advice from Diego Bermudez, grand prize winner of the 2014 scholarship for his project, Circasia: Engaging the Creeks:

“The most important thing I conveyed is the impact my project would have on the community in Circasia,” Bermudez said. “Precisely detailing how my project could improve the ecology of the creeks and the quality of life for the townspeople is what I think gave my submission an edge.”![Circasia-Public-Space-1](https://blog.vectorworks.net/hs-fs/hubfs/190225_Dont%20Miss%20Your%20Chance%20/Circasia-Public-Space-1.png?width=536&name=Circasia-Public-Space-1.png)

In short, write about why your project _matters_. Show that your work can incite positive change.

Brush off and repurpose those old designs or create something entirely new. Even the most brilliant designs start with just an idea — so why not submit yours?

[![SUBMIT NOW](https://no-cache.hubspot.com/cta/default/3018241/55fa7082-48ad-4ecd-be1e-6db8f640fe8d.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/55fa7082-48ad-4ecd-be1e-6db8f640fe8d) 

 Topics: [Vectorworks Design Scholarship](https://blog.vectorworks.net/topic/vectorworks-design-scholarship) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.