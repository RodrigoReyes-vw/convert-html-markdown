[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Vectorworks Celebrates Hispanic Heritage Month

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/210824_WED/Screen%20Shot%202021-08-24%20at%2010.23.01%20AM.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-honors-hispanic-and-latino-music)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Vectorworks%20Celebrates%20Hispanic%20Heritage%20Month&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-honors-hispanic-and-latino-music&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-honors-hispanic-and-latino-music)

From September 15 to October 15, Vectorworks will proudly be observing National Hispanic Heritage Month. This month of celebration, [according to its official government site](https://hispanicheritagemonth.gov/), “Traditionally honors the cultures and contributions of both Hispanic and Latino Americans as we celebrate heritage rooted in all Latin American countries.”

Every culture celebrates itself in different ways. Food, religious holidays, and music are just some of the ways we can celebrate what makes us different. Mike Tello, a Vectorworks sales representative, finds music to be a great way to remember his heritage ... 

> “I was born and raised in Los Angeles, California to parents from Guadalajara, Mexico — the home of Mariachi!
> 
> I have many fond musical memories from my childhood. For example, every Saturday morning, I would wake up to Mexican folk songs by Vicente Fernandez, Pedro Infante, and Javier Solis. As my mother would clean the house or make breakfast, she would put a cassette of one of these artists in her Panasonic boombox she had in the kitchen. She would sing along beautifully to these songs.
> 
> Like my mother, I fell in love with music. So much so, in fact, that I sang ballads with a Mariachi band for a few years.
> 
> I still hold the music of my culture close to my heart. Nowadays, though, I usually listen to Mexican indie music like Natalia Lafourcade, La Santa Cecilia, and Christian Nodal.”

![Image from iOS (1)](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210910_Hispanic%20Heritage%20Month/Image%20from%20iOS%20(1).jpg?width=571&name=Image%20from%20iOS%20(1).jpg)

_An album featuring Tello. Our Vectorworks teammate is pictured second from bottom on the right side._

With music being so important to Latin American and Hispanic culture, the number of stars are aplenty. One Latin music legend is Marc Anthony. The singer is widely known around the world for albums like _Valio La Pena, 3.0,_ and _Opus_.

This past summer, Anthony hosted the “Una Noche” livestream.

The “Una Noche” livestream was designed with Vectorworks Spotlight and previsualized with Vision. And, if you’re curious how the livestream event came together, you can check out the on-demand webinar with Andres Albornoz, production manager at Garba Music Corp. and project manager for Marc Anthony and Sebastian Yatra, along with Andrés Campos, lighting designer.

[![WATCH THE ON-DEMAND WEBINAR](https://no-cache.hubspot.com/cta/default/3018241/f7587ec4-7387-41db-aecb-200472132ddb.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/f7587ec4-7387-41db-aecb-200472132ddb) 

At Vectorworks, we’re proud to spend the next month — and beyond — celebrating Hispanic and Latin American heritage and all the wonderful ways it’s impacted our lives. [Click here](https://www.nps.gov/subjects/npscelebrates/hispanic-heritage-month.htm) to read more about this special month. 

 Topics: [News](https://blog.vectorworks.net/topic/news) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.