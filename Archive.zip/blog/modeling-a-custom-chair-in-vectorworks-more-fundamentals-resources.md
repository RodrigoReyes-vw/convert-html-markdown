[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Vectorworks Fundamentals Learning Resources for You

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/221201_Fund%20Training%20Videos/blog-1440x800_FUND%20Training%20Videos.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fmodeling-a-custom-chair-in-vectorworks-more-fundamentals-resources)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Vectorworks%20Fundamentals%20Learning%20Resources%20for%20You&url=https%3A%2F%2Fblog.vectorworks.net%2Fmodeling-a-custom-chair-in-vectorworks-more-fundamentals-resources&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fmodeling-a-custom-chair-in-vectorworks-more-fundamentals-resources)

_Planet Vectorworks_ is one of the many Vectorworks resources at your fingertips, offering you news updates, tech tips, design inspiration, and more.

Our articles about [Vectorworks Fundamentals](https://www.vectorworks.net/fundamentals) are written to help you bring your design ideas to life with the CAD industry's most versatile software. For example, [“How to Make the Most of 2D Drafting in Vectorworks Fundamentals”](../../../net/vectorworks/blog/how-to-begin-2d-drawing-in-your-design-software.html) gives you ways to quickly create graphically rich 2D documentation. 

The flexible modeling tools in Vectorworks help you design anything you can imagine. Just take a look at [“How to Get Started with Modeling in Fundamentals,”](../../../net/vectorworks/blog/3d-modeling-in-vectorworks-fundamentals.html) which focuses on creating stunning 3D geometry. 

In this post, you’ll find videos, webinars, and training opportunities that will help you discover the possibilities of Fundamentals.

## Vectorworks Fundamentals Video Resources

[\-> Vectorworks Associate Certifications](https://university.vectorworks.net/local/programallocate/index.php?id=1)

Let’s start with the basics.

Our Associate Certification gives you a crash course like none other. If you’re new to Vectorworks Fundamentals, this comprehensive overview is where you’re going to want to start.Please note that you’ll need to sign in to your Vectorworks account to access this course. It’s easy to do! [Simply click here to create a username and password.](https://sso.vectorworks.net/accounts/login/?next=https%3A%2F%2Funiversity.vectorworks.net%2Flogin%2Findex.php)

Having an account will let you keep track of your [Vectorworks University](https://university.vectorworks.net/) progress and record an ongoing transcript of your accomplishments.

[\-> Vectorworks Hidden Treasures Seminar](https://university.vectorworks.net/course/view.php?id=464)

When using design software, it’s natural to wonder about other features you may not be using. Perhaps, you’ve only scratched the surface of what’s possible?

![Hidden Treasures](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221201_Fund%20Training%20Videos/Hidden%20Treasures.png?width=1440&height=738&name=Hidden%20Treasures.png)

In this seminar, our team will guide you through some of the hidden gems in Vectorworks. These tools and commands will change your perspective on how you use Vectorworks Fundamentals.

[Getting -> Started Vectorworks - Fundamentals](https://university.vectorworks.net/local/programallocate/index.php?id=2)

As the title suggests, this learning path is designed to help you get to know even more about Vectorworks Fundamentals. And, since not everyone learns the same, the path features multiple training courses and different formats. You’ll find starter guides, instructor-led live seminars, and on-demand courses.

Like the Associate Certification, you’ll need to sign in to your Vectorworks account to access this learning path.

[\-> Creating a Custom Chair in Vectorworks Fundamentals](https://www.youtube.com/watch?v=U3eMuCYZBVg)

Yes, the video shows you how to create a sleek, modern chair; but, more importantly, it shows you the limitless design possibilities that lay before you in Fundamentals. And for more videos like this, click below to subscribe to our YouTube channel:

[![SUBSCRIBE TO OUR CHANNEL](https://no-cache.hubspot.com/cta/default/3018241/81cf4d8b-a6a4-4960-b3c0-6ae4630ea216.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/81cf4d8b-a6a4-4960-b3c0-6ae4630ea216) 

These resources — along with the others on our YouTube page, Vectorworks University, and _Planet Vectorworks_ — can provide you with the new ideas and workflows to design without limits.

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.