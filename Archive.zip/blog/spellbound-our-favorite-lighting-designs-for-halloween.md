[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Spellbound: Our Favorite Lighting Designs for Halloween

 Posted by [Cozette Conrad](https://blog.vectorworks.net/author/cozette-conrad) | 2 min read time 

![Haunted-House-Resize](https://blog.vectorworks.net/hubfs/Haunted-House-Resize.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fspellbound-our-favorite-lighting-designs-for-halloween)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Spellbound:%20Our%20Favorite%20Lighting%20Designs%20for%20Halloween&url=https%3A%2F%2Fblog.vectorworks.net%2Fspellbound-our-favorite-lighting-designs-for-halloween&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fspellbound-our-favorite-lighting-designs-for-halloween)

Trick or treat! Unmask the processes used to design these spooky entertainment projects.

###### Dracula at the Royal Swedish Opera

Isak Gabre, former systems and project manager at the [Royal Swedish Opera](https://www.operan.se/), designed a chilling video projection to promote the opening of Dracula at the opera house. Using projection and sound technology, Gabre and his team gave the stately exterior a gothic revamp. Vines crawled up the sides of the stone façade, blood cascaded down, and men clung to the pillars in this creepy projection to celebrate the world premiere of the opera.

[![Read the Case Study](https://no-cache.hubspot.com/cta/default/3018241/749a8536-0173-4406-aa86-0fdeb60319b5.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/749a8536-0173-4406-aa86-0fdeb60319b5) 

###### Haunted Attractions by Radiance Lightworks

When it comes to ghastly entertainment design, look no further than Karyn Lawrence, senior lighting designer at [Radiance Lightworks](https://www.radiancelightworks.com/welcome). With several years of experience designing large-scale haunted attractions, Lawrence’s creations make guests’ hair stand on end. Check out her tips for thrilling lighting effects.

[![Read the Interview](https://no-cache.hubspot.com/cta/default/3018241/2799d805-f6e2-4f0a-b575-babb81132c7f.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/2799d805-f6e2-4f0a-b575-babb81132c7f) 

![Haunted-House-Resize](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/191031_Spooky%20Designs/Haunted-House-Resize.jpg?width=685&name=Haunted-House-Resize.jpg)Image courtesy of [Joey Gannon](https://www.flickr.com/photos/brunkfordbraun/).

###### Macbeth at the Denver Center for the Performing Arts

Double, double, toil, and trouble. Alex Jainchill, a freelance lighting designer based in Brooklyn, NY, was tasked to light the [Denver Center for the Performing Arts](https://www.denvercenter.org/)’ contemporary production of Macbeth. He relied on [Vision](https://www.vectorworks.net/vision?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=halloween103119) to previsualize the eerie design, fitting for something wicked.

[![Read the Blog](https://no-cache.hubspot.com/cta/default/3018241/ae5f8671-67a0-4a93-b7ac-db8468fd44c1.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/ae5f8671-67a0-4a93-b7ac-db8468fd44c1) 

If you’re wondering how to make blood-curdling designs like these, start with this rendering webinar on infusing realism into your designs. 

[![Show Me How](https://no-cache.hubspot.com/cta/default/3018241/7cf06f5f-1d32-45e4-978a-6a17b6156fd8.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/7cf06f5f-1d32-45e4-978a-6a17b6156fd8) 

Exceptional design demands exceptional tools and platforms built to deliver absolute creative expression and maximum efficiency. At Vectorworks, we believe your design software should offer the freedom to follow your imagination wherever it may lead. See for yourself with a free 30-day trial of Vectorworks. [Click here](https://www.vectorworks.net/trial/form) for more information.

If you're still in school or a recent graduate and are looking for that all-in-one solution, check out Vectorworks' academic programs and see how you can get free or discounted software. [Click here](https://www.vectorworks.net/en-US/education) for more information.

Make the most of your software experience with [Vectorworks University](https://university.vectorworks.net/). Take classes online, sign up for one of our webinars, or schedule a training session. Beginners and experienced designers alike will gain new skills, fine-tune workflows and dive into all you can do with Vectorworks.

###### Happy Halloween from Vectorworks!

![Freddy-is-Home](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/191031_Spooky%20Designs/Freddy-is-Home.jpg?width=689&name=Freddy-is-Home.jpg)

 Topics: [Project Highlight](https://blog.vectorworks.net/topic/project-highlight), [Production & Lighting Design](https://blog.vectorworks.net/topic/production-lighting-design) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.