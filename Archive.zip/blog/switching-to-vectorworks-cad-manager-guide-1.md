[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# CAD Manager's Guide to Switching: Why You Should Make the Move

 Posted by [Leslie Briggs](https://blog.vectorworks.net/author/leslie-briggs) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/blog-images-april-17.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fswitching-to-vectorworks-cad-manager-guide-1)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=CAD%20Manager's%20Guide%20to%20Switching:%20Why%20You%20Should%20Make%20the%20Move&url=https%3A%2F%2Fblog.vectorworks.net%2Fswitching-to-vectorworks-cad-manager-guide-1&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fswitching-to-vectorworks-cad-manager-guide-1)

We get that there’s a lot to consider when switching design platforms. It’s not a decision that comes without first weighing the pros and cons — and there can be many, from 2D/3D and [BIM](https://www.vectorworks.net/en-US/architect/features?filterBy=Capability&filterValue=Building+Information+Modeling?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=041620archmtm) design needs to workflows and collaboration nuances.

But there’s an overall consideration that should be top of mind for any CAD Manager, whether large or small firm, and that’s whether the software is truly built for your business purposes. In working with designers all over the world, we have the benefit of collaborating on a case by case basis to help them not just make this decision but make it as easy as possible when they’re ready to make the move.

It’s through those unique partnerships that we’re able to help design firms do effective product comparisons of Vectorworks and AutoCAD software.

Read on if you’re considering a switch or want a deeper look at what Vectorworks offers.

## Similarities between Vectorworks and AutoCAD

There's a natural hesitation in making a change. As a CAD manager, you've likely contemplated the inevitable learning curve and how changing software will impact your resources and your team's productivity. But so have we, and you might be surprised at the many similarities Vectorworks brings to your current design process that can keep you productive in the transition.

Much like AutoCAD, Vectorworks offers an expansive CAD drafting and modeling suite. You can use either software to create 2D line drawings, 3D models, and more.

But as you get started with Vectorworks software, you’ll immediately benefit from [the Vectorworks Resource Manager](https://app-help.vectorworks.net/2020/eng/VW2020%5FGuide/ResourceManager/Resource%5FManager%5FFile%5Fbrowser%5Fpane.htm?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=041620archmtm). The Resource Manager functions in much the same way as the Design Center in AutoCAD, so the transition will offer continuity between the interfaces.

Many familiar tools in AutoCAD are in Vectorworks software, too:

* Gradients and hatches: fill attributes and vector-based fill attributes that can be applied to any object (hatches in AutoCAD).
* [Renderworks](https://www.vectorworks.net/products/features/renderworks?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=041620archmtm) and sketch styles: preset options for artistic and realistic rendering mode (visual styles in AutoCAD).
* Renderworks Textures: texture share that can be applied to any 3D object (similar to materials in AutoCAD).
* Line Types: dash line definition (similar to linetypes in AutoCAD).
* Record Formats: custom data sets that can be attached to any object (property sets in AutoCAD).

You’ll also be able to share your work with your team with Vectorworks’ robust file referencing, import, and export capabilities. And our DWG referencing which means you can keep your DWG legacy files. 

## Differences between Vectorworks and AutoCAD

While much of what you’re used to in AutoCAD will remain the same after switching to Vectorworks, it’s important to note some differences between the design programs — it’s these differences that we think make switching software a long-term benefit to your business.

Vectorworks is notably an all-in-one design tool, purpose built for the industry you’re working in and other professionals you need to work with. Because of that, you can complete your entire workflow, start to finish, in Vectorworks, without switching platforms. You can’t do that with AutoCAD.

And when it comes to resource management, the benefit throughout your organization is that all of your resources are stored in a native Vectorworks file — duplicated and imported into the active file upon using them. The benefit? There’s no risk of accidentally editing the original source while building your designs.

This is the power of our Resource Manager interface — you can move and organize resources between your design files without needing to use other applications. Resource Manager won’t replace the CAD Manager Control Utility, so your company standards are managed and shared through user and workgroup folders. The takeaway here is improved efficiency within your process and/or team because your original files are simultaneously accessible in each of your projects. So, a single Vectorworks file can contain hundreds of resources and not slow you down.

## More Reasons to Move to Vectorworks

To help you maintain consistency with your projects when switching, you will want to create a custom template file. This will allow you to create files with office-specific standards, such as class and layer naming standards, sheet layers, and typical stories and story levels. These templates will save you time in the beginning stages of designs, allowing you to skip the tedium of setting up each individual file.

Vectorworks also offers strong rendering capabilities and graphic output so that your designs will come to life on your screen, allowing you to share [visual walkthroughs](https://www.youtube.com/watch?v=BCWV8Qzccnw?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=041620archmtm) of your models with project partners and clients. Vectorworks graphics capabilities also translate to a robust documentation toolset, meaning it’s never been easier to share ideas with others.

Learn more about making the move to Vectorworks:

[![DOWNLOAD THE CAD MANAGER GUIDE HERE](https://no-cache.hubspot.com/cta/default/3018241/46e33b35-864c-414a-a266-dea6cdfca16e.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/46e33b35-864c-414a-a266-dea6cdfca16e) 

Want to keep reading? Check out Part 2 to [learn more about importing and converting resources](/switching-to-vectorworks-cad-manager-guide-2?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=041620cadmgrswitch1), or Part 3 for a deeper dive into [managing your resources in Vectorworks](/switching-to-vectorworks-cad-manager-guide-3?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=041620archmtm).

 Topics: [Production & Lighting Design](https://blog.vectorworks.net/topic/production-lighting-design) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.