[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Top 6 Vectorworks 2022 Features for Interiors

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/210915_Launch/blog-1440x800-1.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Ftop-6-vectorworks-2022-features-for-interiors)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Top%206%20Vectorworks%202022%20Features%20for%20Interiors&url=https%3A%2F%2Fblog.vectorworks.net%2Ftop-6-vectorworks-2022-features-for-interiors&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Ftop-6-vectorworks-2022-features-for-interiors)

There’s a lot to talk about with the latest Vectorworks release! Version 2022 is our most exciting yet for so many reasons.

In this article, we’ll explore the top six features in [Vectorworks 2022](http://vectorworks.net/2022) for interiors professionals. 

* Next-gen technology.
* Maxon’s Redshift render mode.
* A direct link to Twinmotion and a FREE Twinmotion license.
* Per-face texture mapping.
* Wall component control.
* Direct stair editing.

###### The Cutting-Edge of Next-Gen Tech

Version 2022 introduced huge upgrades to the Vectorworks Graphics Module (VGM), which is now purpose-built to run on Metal for Mac or DirectX for Windows. It’s part of a modernization initiative, the specifics of which you can explore in our [development roadmap](https://www.vectorworks.net/public-roadmap).

The fact that Vectorworks is the [first major BIM application to run natively on Apple silicon Macs](../../../net/vectorworks/blog/5-things-the-new-macos-big-sur-optimized-with-m1-brings-to-vectorworks.html) is a huge deal. The software now runs two to four times faster.

But what exactly is faster?

Opening files, 3D navigation, panning, zooming, hidden-line rendering, object and tool selection, editing object parameters — it's all faster.

And faster operations means _design without limits™_. 😉

###### A New Rendering Mode

Our long-standing partnership with [Maxon](http://maxon.net), the creators of Cinema 4D, yields a new rendering mode in Vectorworks. Maxon's GPU-enabled Redshift render mode allows you to create stunning renderings without the need for additional plug-in software.

The render mode can amplify the visual effect of your design with features like lighting, reflections, volumetric effects, camera effects, and anti-aliasing.

That’s a big gain for interiors professionals. The ability to quickly render concepts in a way that’s visually captivating goes a long way in communicating ideas with clients and other stakeholders.

###### Direct Link to Twinmotion + FREE Twinmotion License

[Twinmotion](http://unrealengine.com/twinmotion), the best-in-class real-time rendering solution for Mac operating systems, is offering a FREE license to those who’ve installed Vectorworks 2022\. The offer is valid through March 31, 2022 and can be viewed in the Vectorworks customer portal [here](https://customers.vectorworks.net/offers) or on Twinmotion's site [here](https://www.unrealengine.com/en-US/twinmotion/vectorworks?sessionInvalidated=true). 

The offer highlights a new direct link between the two applications. Changes made in Vectorworks 2022 reflect immediately in the linked Twinmotion file, eliminating the need for the intermediate steps of exporting and importing.

###### Customization with Per-Face Texture Mapping

Vectorworks 2022 introduced the ability to map textures to different faces of the same solid modeling object with the ability to rescale and more.

The ability to freely customize the look of solid modeling objects is hugely beneficial for interiors professionals who’re often looking for simple and effective ways to incorporate their own personal styles.

The render tab of the Object Info palette has also been updated to let you easily view and manage textures on the object’s various faces.

###### Wall Component Control

Updates to the Wall tool allow you to define component wrapping at window and door openings for more realistic models and accurate 2D drawings. The round wall and straight wall objects have also been combined into a singular object type (wall), which helps with more accurate data and easier reporting.

Overall, this update gives you greater control in the process of defining walls.

###### Direct Stair Editing

The stair plug-in object has been updated to be much more interactive in Vectorworks 2022.

New rectangle and polygon modes make it so you can easily place a stair between walls or follow a floor opening without measuring distances — just draw a rectangle or path and your stair object is placed.

Tool settings let you control the stair’s length, width, and total rise without opening any dialog boxes. Not to mention you can also use control points to stretch and contract stairs to change length or curvature.

Try the new version for yourself! The webpage has all the information you need to get started.

[![Meet Vectorworks 2022](https://no-cache.hubspot.com/cta/default/3018241/0819809f-7527-4116-90d0-d3a0c80b3efd.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/0819809f-7527-4116-90d0-d3a0c80b3efd) 

 Topics: [Product Launch](https://blog.vectorworks.net/topic/product-launch), [Interiors](https://blog.vectorworks.net/topic/interiors) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.