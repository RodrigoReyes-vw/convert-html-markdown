[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Landscape Architecture Firms Take the Next Step with BIM

 Posted by [Jack O'Grady](https://blog.vectorworks.net/author/jack-ogrady) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/211304_Landscape%20Firms%20take%20next%20step%20with%20BIM/Picture-1.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Flandscape-architecture-firms-take-next-step-with-bim)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Landscape%20Architecture%20Firms%20Take%20the%20Next%20Step%20with%20BIM&url=https%3A%2F%2Fblog.vectorworks.net%2Flandscape-architecture-firms-take-next-step-with-bim&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Flandscape-architecture-firms-take-next-step-with-bim)

_This article was originally published by [Computerworks](https://www.computerworks.de/vectorworks-blog/details/planungsbueros-gehen-den-naechsten-schritt.html), a distributor of Vectorworks in Germany, and has been translated into English._ 

Landscape architects, architects, and urban planners working together in one information system is more important than ever. In the trade journal [Garten + Landschaft](https://www.garten-landschaft.de), [ComputerWorks](https://www.computerworks.de/startseite.html) CEO Alexander Meier explains how the design software [Vectorworks Landmark](https://www.vectorworks.net/en-US/start/bim-for-landscape) can enrich everyday work even more with [BIM](../../../net/vectorworks/blog/why-bim-is-taking-over-landscape-architecture.html).

![A BIM diagram of a public park, with labels for trees, grass, vines, an herb garden, a meadow, turnstiles, and benches. ](https://blog.vectorworks.net/hs-fs/hubfs/211304_Landscape%20Firms%20take%20next%20step%20with%20BIM/Picture-1.jpg?width=432&name=Picture-1.jpg)

A great advantage of BIM is the collaboration factor and the fact that landscape architects and urban planners can work together with other consultants and planning partners all in one information system. Meier explains:

“Many offices deal intensively with BIM and have implemented pilot projects in the past two years. The building construction sector is a little ahead of urban planners and landscape architects. But because of the overlaps and links in projects and the joint planning for government agencies, the participating firms have to develop BIM technology - which is what they do.”

###### Understanding BIM as an Information System

With BIM, plans contain not only visual information, but also other relevant data – such as population distribution and impact analysis – and therefore should be understood as an information system. This allows planners and clients to work more closely together, using BIM planning as a basis for decision-making as well as an implementation plan.

Thanks to the fully integrated BIM workflow in Vectorworks Landmark, everything from 2D to virtually accessible models can be planned in one program. The importance of data exchanges will also change in the future:

“In the beginning, users mainly transferred data via DXF files. In addition to the model data, they can also exchange basic data for the entire project life cycle. Since the municipalities have been working relatively securely with tendering software, this connection has also been important,” explains Meier.

“Planners can also use mobile devices specifically for data and information acquisition. For example, load the current plan status into the cloud and then call it up on site with site managers and customers on a tablet or smartphone, discuss it and, if necessary, change.”

![A BIM diagram of a building, with IFC datasets breaking down information on the path, fence, plants, railings, ramp, building, object and structure of the digital terrain model. ](https://blog.vectorworks.net/hs-fs/hubfs/211304_Landscape%20Firms%20take%20next%20step%20with%20BIM/Picture-2.jpg?width=432&name=Picture-2.jpg)

###### Implementing Process-oriented Planning

In general, appealing visualizations help communicate with everyone involved in the project, and the future for collaboration will likely continue to develop in this way. With increasing inquiries from municipalities and large planning offices, the trend continues to favor looking at urban and landscape planning in a more process-oriented manner. This means including more details that keep everyone well-informed and make for a more efficient design process.

Digital change means lifelong learning. This is why offices that allow their employees regular software training progress faster in project work. Meier:

“Even when introducing new software, it is advisable to provide more detailed training so that users can learn the software to the fullest. You will quickly become well versed in digital planning and are more motivated than users who have to proceed in the planning process using 'trial and error'.”

Those responsible should also be open to advice: “The various offices are at very different stages when it comes to digitizing their processes. As a service provider, we need transparent insight so that we can support the offices in implementing a process that actually works completely digitally – and does not stall halfway due to a missing interface,” Meier sums up.

[![Find Out More About BIM For Land](https://no-cache.hubspot.com/cta/default/3018241/29f061c8-7b24-44e0-a425-cfb6f13e72f5.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/29f061c8-7b24-44e0-a425-cfb6f13e72f5) 

 Topics: [BIM (Landscape)](https://blog.vectorworks.net/topic/bim-landscape) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.