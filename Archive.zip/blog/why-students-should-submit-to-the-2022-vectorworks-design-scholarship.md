[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# What Design Professionals are Saying About Our Design Scholarship

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/2202-scholarship-training-newsletter-750x428.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fwhy-students-should-submit-to-the-2022-vectorworks-design-scholarship)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=What%20Design%20Professionals%20are%20Saying%20About%20Our%20Design%20Scholarship&url=https%3A%2F%2Fblog.vectorworks.net%2Fwhy-students-should-submit-to-the-2022-vectorworks-design-scholarship&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fwhy-students-should-submit-to-the-2022-vectorworks-design-scholarship)

Are you an aspiring designer? Do you know a design student with tremendous potential?

If you answered “yes” to either of these questions, we’ve got some great news for you … [The 2022 Vectorworks Design Scholarship is now accepting submissions](../../../net/vectorworks/blog/now-accepting-submissions-for-the-vectorworks-design-scholarship.html), with prizes up to $10,000 USD! 

![2202-scholarship-training-newsletter-750x428](https://blog.vectorworks.net/hs-fs/hubfs/2202-scholarship-training-newsletter-750x428.jpg?width=1440&name=2202-scholarship-training-newsletter-750x428.jpg)

Read on to find out what design professionals, professors, and scholarship judges are saying about this exciting opportunity.

[![WIN UP TO $10,000](https://no-cache.hubspot.com/cta/default/3018241/20e15f26-4626-4cf6-b894-297f0ca071b9.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/20e15f26-4626-4cf6-b894-297f0ca071b9) 

## 2022 Vectorworks Design Scholarship Judges

For the 2022 Design Scholarship, several esteemed design professionals are looking forward to seeing your most inspiring designs.

The 2022 judges are\*:

* [Greg Upwall](../../../net/vectorworks/blog/why-choose-vectorworks-greg-upwall-guest-blog.html), [Studio Upwall Architects](http://www.studioupwall.com/)
* Claudia Tejada, [Claudia Giselle Design](https://claudiagiselle.com/)
* Pax Chagon, [Chagon Architecture](https://chagnonarch.com/)
* Anthony Caldwell, [UCLA](https://www.library.ucla.edu/destination/scholarly-innovation-lab-sil)
* Stephen Schrader, [Renta Urban Land Design](https://renta-la.com/)
* Kevin Crist, [Intrinsic Landscaping](https://www.intrinsiclandscaping.com/)
* Brian Barry, [Intrinsic Landscaping](https://www.intrinsiclandscaping.com/)
* Stephen Jones, [California State University - Sacremento](https://www.csus.edu/)
* Anne Militello, [Vortex Lighting, inc.](https://vortexlighting.com/)
* Jeff Ravitz, [Intensity Advisors](https://intensityadvisors.com/)
* Ann-Marie Powell, [Ann-Marie Powell Gardens](https://www.ann-mariepowell.com/)
* David Chadwick, [CAD User and Construction Computing Magazine](https://www.caduser.com/)
* David Farley, [David Farley Design](https://www.vectorworks.net/scholarship/www.davidfarleydesign.net)
* Mark Doubleday, [Mark Doubleday Lighting Design](http://www.markdoubleday.net/)
* Sophie Entwisle, [Pegasus Group](https://www.pegasusgroup.co.uk)
* Victoria Farrow, [Birmingham City, School of Architecture and Design](http://www.markdoubleday.net/)

\*More information on judges by country is available on [the scholarship website](https://www.vectorworks.net/scholarship).

## What Design Professionals Are Saying About the Scholarship

We aren’t the only ones who want to see what you’re creating.

Below, a few judges tell why they think you should submit your work to the design scholarship:  
  
> “I’m very excited about the Vectorworks scholarship opportunity for design students preparing to enter the worlds of architecture, lighting, scenic, landscape, and interior design. Being selected by the panel of industry-professional judges will certainly open doors and, in a sense, ‘certify’ the recipient's design skills and provide extensive coverage in trade media — not only for the winning individual or team, but their school as well. A full suite of Vectorworks software for the school is a further bonus.” 
> 
> ![Jeff Ravitz_Headshot](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220503_scholarship%202/Jeff%20Ravitz_Headshot.jpg?width=200&name=Jeff%20Ravitz_Headshot.jpg)

> \- **Jeff Ravitz, In** **tensity Advisors** 

> “The Vectorworks Design Scholarship contest is a chance to showcase your work — and highlight the program you’ve been studying in — and get that work in front of an array of experienced, accomplished architecture, interior, landscape, and lighting design professionals from all over the world who want to see your design and communication skills, understand your process, and be amazed by how you use the software to create and present your ideas.” 
> 
> ![Stephen Schrader_Headshot](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220503_scholarship%202/Stephen%20Schrader_Headshot.jpg?width=200&name=Stephen%20Schrader_Headshot.jpg)
> 
> \- Stephen Schrader, Renta Urban Land Design 
> 
> “Whether your field is architecture, landscape architecture, entertainment, or interior design, competitions have always played a significant part in the learning process.   
>  
> During my time in architecture school, competitions and scholarships were extremely important in helping propel my career forward. Today I always encourage my students to pursue these opportunities because you never know what doors they’ll open.”
> 
> ![Anthony Caldwell_Headshot](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220503_scholarship%202/Anthony%20Caldwell_Headshot.jpg?width=200&name=Anthony%20Caldwell_Headshot.jpg)
> 
> \- Anthony Caldwell, UCLA

## Everything You Need to Know About the Vectorworks Design Scholarship

Undergraduate or graduate students pursuing a degree related to architecture, interior design, landscape architecture, landscape design, or entertainment design are encouraged to submit.

This scholarship competition is an excellent opportunity for you — or a young designer you know — to take the next step in your design professional journey.

Regional winners are chosen from all qualified submissions. Based on your region, you can win up to $3,000 USD. All regional winners then have a chance to win our $7,000 USD grand prize, the Richard Diehl Award. In total, you could win up to $10,000 USD.

Note that submission dates and deadlines vary slightly based on the country and/or region where you’re located.

Click the button below to visit the scholarship’s submission page. Or, if you’re wondering about other ways Vectorworks supports students, [click here](../../../net/vectorworks/blog/what-can-design-students-get-from-vectorworks.html).

[![SUBMIT YOUR DESIGNS](https://no-cache.hubspot.com/cta/default/3018241/47efb80c-d8d1-43c4-978d-9a2eae111dcf.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/47efb80c-d8d1-43c4-978d-9a2eae111dcf) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.