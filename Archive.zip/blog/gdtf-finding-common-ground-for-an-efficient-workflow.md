[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# GDTF: Finding Common Ground for an Efficient Workflow

 Posted by [Guest Author](https://blog.vectorworks.net/author/guest-author) | 9 min read time 

![gdtf2](https://blog.vectorworks.net/hubfs/Blog%20Images/190815_GDTF%20Guest%20Blog/gdtf2.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fgdtf-finding-common-ground-for-an-efficient-workflow)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=GDTF:%20Finding%20Common%20Ground%20for%20an%20Efficient%20Workflow&url=https%3A%2F%2Fblog.vectorworks.net%2Fgdtf-finding-common-ground-for-an-efficient-workflow&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fgdtf-finding-common-ground-for-an-efficient-workflow)

_This article originally ran in_ [_PLSN Magazine’s August 2019 issue_](http://plsn.com/category/archives/august-2019/)_._ 

Back in the late 1980’s and early 1990’s, the digital era of the lighting industry had yet to define a standard for unifying data exchange between fixtures. Every manufacturer had its own proprietary control language and controller for programming their own fixtures. What that meant for shows back then was a different controller for each type of manufacturer was needed if mixed together in a rig.

This caught the attention of some industry professionals, and at USITT in 1986-1990, DMX512 was conceived and refined. Manufacturers didn’t begin to catch on to the need for a single common control language at first, and continued to push towards having their own controllers. Eventually however, consoles like the Wholehog 1 came on the scene and programmers began to demand a single control surface for all types of fixtures. Manufacturers of lighting fixtures began to listen, and slowly abandoned their proprietary languages in favor of using DMX as the primary control language. Today, of course, DMX512 is the industry standard, and newer protocols like sACN are becoming options as well.

There are still opportunities for forward-thinking companies to collaborate and make the lives of their end-users easier, however. Two recent game-changing initiatives to arrive on the scene are the General Device Type Format (GDTF) and My Virtual Rig (MVR). Jointly developed by [MA Lighting](https://www.malighting.com/), [Robe lighting](https://www.robe.cz/), and [Vectorworks, Inc.](https://www.vectorworks.net/en?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=gdtf082119), this new data exchange platform between lighting consoles, fixtures, and previz applications greatly improves the design to programming workflow. 

I had the opportunity to attend the GDTF session at the 2018 Vectorworks Design Summit, and later I spent some time with developers from MA Lighting for some additional information. And now, with the announcement in March 2019 of the availability of GDTF 1.0 and MVR, I’m certain that what we’re seeing is the beginning of a powerful new way of communication between devices. Let’s take a closer look at this exciting new data exchange platform.

## What is GDTF?

Before discussing the specifics, let me give you an example of why GDTF and MVR are powerful. As a lighting designer and programmer, I’m often in the seat of creating the lighting plot, the patch, the lighting paperwork, and the previz model. If you’ve been in those seats on a project, you likely know that there are constant updates to information across all platforms that have to be coordinated in each location. In the early days of lighting design and programming, that could mean updating the plot in one program, then opening the console and typing in the changes, then opening the paperwork files and updating the changes, then opening the previz model and making the changes, again and again until the rig is patched and all changes are complete. Very time consuming! Granted, consoles like the grandMA have come a long way from those days by being able to receive patch information from applications like Vectorworks via an XML file, and Vectorworks has certainly taken steps to allow for importing and exporting fixture data between apps like Lightwright. But these necessary steps have remained disconnected for the most part, and the workflow doesn’t readily flow between programs. Enter GDTF and MVR.

GDTF 1.0 and the My Virtual Rig (MVR) file format are used to create a two-way connection between planning, previz, and console systems. These file types are now fully implemented into Vectorworks 2019, Vision 2019, and grandMA3\. And the GDTF file format is currently supported by 20 other manufacturers including Robe, ETC, Martin, AVOLITES, SGM, and Green Hippo, to name a few.

## The Power of GDTF and MVR

GDTF is an open source, unified data exchange format stored in an XML file that contains valuable fixture information including:

* Fixture name
* Short fixture name
* Manufacturer
* Fixture description
* 3D model geometry (3DS)
* DMX mapping
* DMX modes- channels and channels functions
* Wheels
* Physical descriptions of emitters, filters, and color of the light
* Attribute groupings
* Date and user stamp on all uploaded GDTF files

The ideal situation is that each manufacturer of any type of lighting fixture will create its own approved GDTF files for each fixture and make them available on their websites; these files can then be imported into any application that supports GDTF (such as Vectorworks). The value to manufacturers in creating GDTF files is in retaining ownership of writing the fixture file and its details, rather than a third-party developer. This lends assurance that all the subtleties of a fixture are included in the file for seamless accessibility in connected applications.

![gdtf1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190815_GDTF%20Guest%20Blog/gdtf1.png?width=710&name=gdtf1.png)

_ROBE GDTF fixture files on the GDTF-share.com website._

_![gdtf2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190815GDTF%20Guest%20Blog/gdtf2.jpg?width=710&name=gdtf2.jpg)_

_The fixture builder on the GDTF-share.com website._ 

On the GDTF-share.com website, a web-based fixture builder is available for manufacturers to build their approved GDTF files. The files are then added to searchable online database for anyone to access. The web-based builder isn’t restricted to just manufacturers. Users can build and create GDTF files too.

MVR is an XML file that provides a complete 3D model with data describing the different fixtures’ locations in the scene and contains all the GDTF files for the lighting fixtures used in a design. When exported from Vectorworks, it can then be imported into any previz program that supports MVR, such as Vision, or a lighting console like grandMA3\. MVR files contain geometry for objects in the scene including:

* Fixture
* Focus point
* Truss
* Video screen
* Other scene objects

_![gdtf3](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190815GDTF%20Guest%20Blog/gdtf3.png?width=707&name=gdtf3.png)_

_The new MVR workflow._ 

So by using GDTF and MVR, the more efficient GDTF/MVR workflow looks like this:

1. Designer draws the lighting plot in Vectorworks;
2. Designer selects a Fixture Mode from the manufacturer approved GDTF for each fixture in the plot;
3. Designer exports the file as an MVR;
4. Designer (or programmer) imports the MVR into the Lighting Console, previz system, etc.

_![gdtf4](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190815GDTF%20Guest%20Blog/gdtf4.png?width=715&name=gdtf4.png)_

_Exporting the file as an MVR._

_![gdtf5](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190815GDTF%20Guest%20Blog/gdtf5.png?width=710&name=gdtf5.png)_

_The import screen on the grandMA3._

_![gdtf6](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190815GDTF%20Guest%20Blog/gdtf6.png?width=710&name=gdtf6.png)_

_The MVR export screen on the grandMA3\._ 

With the collaboration between Vectorworks, Robe, and MA Lighting, a new unified data exchange platform is taking shape in our industry. The advantages of moving toward incorporating this type of format enables us, as end users, to achieve a more efficient workflow. And in this business, we all know that time is money, so we are always scanning the horizon for ways to make our workflows and processes simpler and more efficient. And the lesson we’ve learned since those early days of DMX… if end users ask for these types of tools often enough, manufacturers will eventually embrace them. When that happens, the industry as a whole improves. So, the time is now to reach out to your favorite lighting manufacturers and start asking them to support GDTF… we’ll all be glad you did!

## See the full August issue of PLSN Magazine.

[![Read More](https://no-cache.hubspot.com/cta/default/3018241/e46eb909-912c-42e1-9a3c-19f855f6c934.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/e46eb909-912c-42e1-9a3c-19f855f6c934) 

For more info, visit the GDTF-share website at [gdtf-share.com](https://www.gdtf-share.com/).

For official documentation, please visit at <https://gdtf-share.com/wiki/GDTF%5FFile%5FDescription>. This site also offers GDTF and MVR file descriptions, GDTF tutorials, an MVR portable library, and more.

For manufacturers interested in participating, please email [info@gdtf-share.com](../../../net/vectorworks/blog/index.html) or post in the GDTF forum at <https://gdtf-share.com/forum/>.

## About the Author

![Vickie Claiborne](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/190815_GDTF%20Guest%20Blog/Vickie%20Claiborne.jpg?width=279&name=Vickie%20Claiborne.jpg)

In 2019, Vickie Claiborne joined the disguise team as a Senior Training and Support Specialist and recently completed a mini tour with Barbra Streisand using disguise. Previously, Vickie has worked at PRG as Lighting and Digital Media Product Specialist and at High End Systems as Programmer and Training Manager. She is also a contributing writer for PLSN magazine, covering topics related to programming and digital media; and in 2014, she published her first book, titled “Media Servers for Lighting Programmers.”

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.