[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# How to Present & Sell Your Entertainment Designs

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 6 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/230810_ENT%20Presenting%20and%20Selling/Cloud%20Services%20Presentations%20SS%201.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Ftech-tips-selling-your-vectorworks-spotlight-projects)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=How%20to%20Present%20&%20Sell%20Your%20Entertainment%20Designs&url=https%3A%2F%2Fblog.vectorworks.net%2Ftech-tips-selling-your-vectorworks-spotlight-projects&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Ftech-tips-selling-your-vectorworks-spotlight-projects)

In this blog post, you’ll learn several different ways in which you can better render and present your designs to event coordinators, producers, and numerous other potential clients.

#### Rapid Renderings with Shaded Render Mode

It’s sometimes difficult to justify expending computer resources for rendering when you haven’t even won a project yet. But, at the same time, there’s nothing your potential clients will marvel at more than a stunning rendering.

So, what’s the solution? It’s simple, really: [**Shaded Render** mode](../../../net/vectorworks/blog/quick-realistic-visualizations-in-vectorworks-spotlight.html)!

With this interactive and real-time rendering option, you can quickly create and save looks with colors, lighting, shading, and textures.

The Shaded Render mode supports glow textures, lit fog, gobos, texture bump, environmental effects, and reflections.

![blog-1440x800-5](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230615_ENT%20Shaded%20Render/blog-1440x800-5.png?width=1440&height=800&name=blog-1440x800-5.png)

With the speed of the feature and the ability to make adjustments in real-time, it’s a great way for you and the people you’re selling your designs to understand what a project will look like in person.

#### Textures to Reduce the Complexity of Your Models

Just as shaded renderings can be a compelling way for you to pitch design ideas to someone who doesn’t come from a technical background, you can also use textures to reduce the complexity of your 3D models.

In a traditional wireframe view, your model may be hard to read to the untrained eye. By simply applying [Renderworks textures](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Rendering1/Custom%5FRenderworks%5Foptions.htm?rhhlterm=renderworks&rhsearch=renderworks) to your soft goods, scenic elements, and more, you’ll be able to improve the realism of your model and clearly communicate your design intent.

To learn more about making the most of your 3D models with renderings and textures, click the button below to watch a free webinar:

[![“3D MODELS AND RENDERINGS FOR LIVE EVENTS”](https://no-cache.hubspot.com/cta/default/3018241/d416137c-5b02-4db0-96c5-75b02b632c82.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/d416137c-5b02-4db0-96c5-75b02b632c82) 

#### Animations from Saved Views 

For more interactive presentations of your plans for a production, try creating walkthrough animations from your saved views.

[To create saved views](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Structure/Creating%20saved%5Fviews.htm#h), perform one of the following:

* Select **View** \> **Save View**.
* Click the **Saved Views** menu from the **View** bar, and then click **Save View**.
* From the **Organization** dialog box, click the **Saved Views** tab, and then click the **New** button.
* Click the **Saved Views** tab in the Navigation palette, and then select the **New** command from the **Utility** menu.
* Once the **Saved Views** dialog box opens, specify the view options, the layer and class visibility settings, and define the view transition parameters when moving to the view being saved.

Then, with the [**Create Walkthrough Path from Saved Views** command](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/CameraViews/Creating%5Fa%5Fwalkthrough%5Fanimation%5Ffrom%5Fsaved%5Fviews.htm?rhhlterm=animation%20animations%20animating%20saved%20views%20view%20viewing&rhsearch=animations%20from%20saved%20views), you can create your walkthrough within the Create Walkthrough Path dialog box.

---

**Bonus tip:** Make sure your drawing **Projection** is set to a perspective view for use in an animation. You can use the **Walkthrough** or **Flyover** tools to change views.

---

#### Boards and Presentations with Vectorworks Cloud Services

One of the most effective tools you can use to present — and inevitably sell — your designs is with [Vectorworks Cloud Services](https://www.vectorworks.net/cloud-services).

[Once you’ve exported rendered panoramas to the Cloud](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/Export/Exporting%5Frendered%5Fpanoramas.htm?rhhlterm=exporting%20export%20exports%20panoramas%20panorama%20cloud&rhsearch=exporting%20panoramas%20to%20cloud), you can start a new presentation by creating either boards or tours using your panoramas.

Boards are flat presentations that allow you to pin different media formats to the board. Tours, on the other hand, are 360-degree walkthroughs made by linking together your panoramic images. 

Tours allow your clients to feel as though they’re in your design. They’re also helpful if a client struggles to connect with plans, drawings, or still renders. Giving an immersive view of a project will allow for a greater emotional connection to (and overall understanding of) your design.

![Cloud Services Presentations SS 1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230810_ENT%20Presenting%20and%20Selling/Cloud%20Services%20Presentations%20SS%201.png?width=1440&height=893&name=Cloud%20Services%20Presentations%20SS%201.png)

If the individual or team you’re presenting to doesn’t have access to Vectorworks, no problem! You can share presentations by direct email, QR code, or even a custom, web-based link.

[For more on creating presentations with Vectorworks Cloud Services, click here](https://cloud.vectorworks.net/portal/help/pages/create-presentations/?app=WEB).

#### Batch Publishing for “Paper” Packets

Lastly, you may be asked to provide preliminary paperwork like worksheets specifying equipment or vendors, lighting plots, or a rough 2D mockup of your scenic elements.

You can publish all of these things and more using the [**Publish** command](https://app-help.vectorworks.net/2023/eng/VW2023%5FGuide/PrintPublish/Batch%20publishing.htm?rhhlterm=publishing%20publish%20published&rhsearch=publsih).

The command lets you select multiple sheet layers, saved views, and worksheets to export, both from the pitch file you’re working on or from other folders.

![batch publishing](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/230810_ENT%20Presenting%20and%20Selling/batch%20publishing.png?width=1440&height=685&name=batch%20publishing.png)

For each item you wish to share as part of your presentation, you can set custom options such as color.

To make custom publishing faster, save the set of publishing options that you use most frequently!

To batch publish sheet layers, saved views, or worksheets:

* Set the visibility of layers and classes in the viewports and views. All visible and grayed layers are published. Invisible layers and classes are not printed or published to PDF or DWF; they can be published as invisible DXF/DWG layers, if the option is selected in the **DXF/DWG Export Options** dialog box.
* If you plan to use the cloud publishing feature, click **Sign In** on the upper-right corner of the Menu bar to sign in to Vectorworks. Then select **Cloud > Open Vectorworks Cloud Services Folder**, and place the files to be published in the folder. If you have enabled Dropbox integration, place the files in your Dropbox folder.
* Select **File** \> **Publish.**

#### More Tips on Rendering with Vectorworks Spotlight

Be sure to check out some of our other stories on rendering with Vectorworks Spotlight:

[READ | “A Rundown on Shaded Render Mode”](../../../net/vectorworks/blog/quick-realistic-visualizations-in-vectorworks-spotlight.html)

[READ | “Event Renderings with a Bigger Impact”](../../../net/vectorworks/blog/event-renderings-with-vectorworks-spotlight.html)

[READ | “Modeling, Rendering, & Reporting Models in Vectorworks Spotlight”](../../../net/vectorworks/blog/get-to-know-your-modeling-toolbelt-in-vectorworks-spotlight.html)

For more blog posts on tech tips, project highlights, and more, [click here to subscribe to our blog](/cs/c/?cta%5Fguid=cc369b40-e6d6-48b3-899f-c4a9bcd4cc2d&signature=AAH58kFbH3EujDKJJ%5FQTK2EbmkD5HeNc6g&pageId=118353753756&placement%5Fguid=cd91dbed-8a9b-40d9-907d-1f9be9ad08bd&click=fec62cb6-660e-4029-abd8-45578990c1d9&hsutk=430fb482b6da2472cc65fbe148bc55ca&canon=https%3A%2F%2Fblog.vectorworks.net%2Fmore-than-an-office-the-m-groups-approach-to-corporate-offices&utm%5Freferrer=https%3A%2F%2Fblog.vectorworks.net%2Ftopic%2Fbuildings&portal%5Fid=3018241&redirect%5Furl=APefjpGdCJEWCAlFaC7F-sImWMYmOKCMtUzgdKSSOzrD3IIopzBzOFNaSM6KifB7nsqUEdCYm0BMZkPlQjQi%5FnnMvlaTOPsX1xuEkj3qjKCGF9zZ6PMTDHQgqJZUdn%5F5wLGhDNU11u02OQ6R85qUftQWPd-UPIe5fa9tDe692tx1Elw9sirJU90rbSIu15rXi1NTS%5FtukhNlSnojMpK19nGKXI%5FfZjmhIvCe5YMprQhemGoVNIv27xX74VgGKefegG6c5a99z4fX3PKSq9txIZ92VMhJFfhHXPhOrqiYn2meLW9%5F7bxVql8&%5F%5Fhstc=183372985.430fb482b6da2472cc65fbe148bc55ca.1673638592075.1689887782166.1689960066284.339&%5F%5Fhssc=183372985.8.1689960066284&%5F%5Fhsfp=3379522993&contentType=blog-post).

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.