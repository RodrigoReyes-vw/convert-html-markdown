[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# A Conversation with the Design Team Behind the Scenes of Hamilton: the Exhibition

 Posted by [Leslie Briggs](https://blog.vectorworks.net/author/leslie-briggs) | 7 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/201021_SignatureBlogFundamentals/hamilton-the-exhibition.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fa-conversation-with-the-design-team-behind-the-scenes-of-hamilton-the-exhibition)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=A%20Conversation%20with%20the%20Design%20Team%20Behind%20the%20Scenes%20of%20Hamilton:%20the%20Exhibition&url=https%3A%2F%2Fblog.vectorworks.net%2Fa-conversation-with-the-design-team-behind-the-scenes-of-hamilton-the-exhibition&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fa-conversation-with-the-design-team-behind-the-scenes-of-hamilton-the-exhibition)

As part of our celebration for the release of Vectorworks 2021, we’re featuring some of our customers’ projects in our promotional materials. In case you missed it, our first blog featured a proposed [Ülemiste railway terminal designed by 3+1 architects](../../../net/vectorworks/blog/from-hand-model-to-bim-why-creativity-means-building-in-context.html). This time, we bring you Hamilton: The Exhibition, a 360-degree immersive experience in Chicago, IL.

See everything you need to know about #Vectorworks2021:

[![LEARN MORE ABOUT VECTORWORKS 2021](https://no-cache.hubspot.com/cta/default/3018241/3b1323ee-d934-44a5-8d33-df12408343ea.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/3b1323ee-d934-44a5-8d33-df12408343ea) 

Developed by the same designers who helped create the acclaimed Broadway sets, Hamilton: The Exhibition brings these sets to life in an interactive, room-by-room narrative for visitors from around the world.

**![hamilton-the-exhibition](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201021_SignatureBlogFundamentals/hamilton-the-exhibition.jpg?width=1440&name=hamilton-the-exhibition.jpg)**

_Hamilton: The Exhibition, Legacy Gallery | Courtesy of Korins and Drew Dockser_

###### **“Who Lives, Who Dies,** **Who Tells Your Story?” – George Washington, _Hamilton_**

In the five years since its debut on Broadway, the _Hamilton_ musical has dazzled audiences around the globe with an exciting new sound and a modern telling of America’s origin. Behind every great production, you’ll find a creative team responsible for the costumes, lighting, and set that all-together immerse audiences and hold them in the moment on stage.

Charged with bringing Lin-Manuel Miranda’s vision to life, [the David Korins design team](http://korinsstudio.com/) invites the audience to New York City in 1776, right at the birth of the American Revolution. The tiered set and multidirectional spinning stage allow for swift and dynamic scene changes demanded by the quick pace of the musical, keeping the focus of the audience on the storyline without scene change blackouts interrupting the narrative.

This seamless flow of the storyline inspired the structuring of Hamilton: The Exhibition. Temporarily housed in Chicago, IL, [the immersive experience](https://www.thedailybeast.com/lin-manuel-miranda-how-hamilton-the-exhibition-dives-deeper-into-history-than-the-musical?ref=scroll) was designed to encourage patrons to dive deeper into the history that inspired the musical and learn more about Alexander Hamilton and the birth of the United States. Visitors begin their journey with Hamilton in St. Croix, Nevis and follow his path to the battlegrounds of the Revolutionary War. And at each step of the way, they’re met with the best of the best when it comes to visual storytelling.

David Korins and his team designed the space from the beginning, using Vectorworks’ 3D-modeling capabilities to map out a visitor’s path through the exhibit and create spaces that evoke emotion.

![hamilton-the-exhibition(2)](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201021_SignatureBlogFundamentals/hamilton-the-exhibition(2).jpg?width=1440&name=hamilton-the-exhibition(2).jpg)

_Hamilton: The Exhibition, Legacy Gallery | Courtesy of Korins and Drew Dockser_

Amanda Stephens, Senior Associate Designer with David Korins Design and Assistant Designer for Hamilton: the Exhibition, explains it like this: “For instance, you've got this big furl of parchment that's spiraling up into the ceiling, which was really about all of these ideas and lofty goals that Hamilton had that were just swirling out into the world above him.”

###### **“Every Action is an Act of Creation” – Alexander Hamilton, _Hamilton_**

And lofty were the goals of the David Korins design team, too.

The team began by importing the stock drawings from the tent manufacturer and assembled them in 3D, essentially building the 35,000 sq. ft. exhibition space from scratch. The end goal for the design layout was to create a series of rooms that toured visitors through the events of Alexander Hamilton’s life chronologically, so that as people explore the exhibition, they mirror the journey of Hamilton and his companions.

[According to the New York Times](https://www.nytimes.com/2019/04/29/theater/hamilton-exhibition-chicago.html), the Hamilton exhibition explores themes of American history that Miranda admits he was unable to fully explore in the musical. An example is the room featuring silhouettes of those excluded from voting in the election of 1800\. 

“There were a lot of logistics in this that were unlike anything that we've dealt with before,” Stephens explains. In particular, developing a cohesive storyline across several different offset rooms was a huge focus for the David Korins design team.

Stephens says analyzing 3D models was crucial to creating each room’s individual vignettes. Designers could map out lights and speakers, hide them well into a design, and then use the models to visualize the space from the perspective of a visitor.

![hamilton-the-exhibition(3)](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201021_SignatureBlogFundamentals/hamilton-the-exhibition(3).jpg?width=1440&name=hamilton-the-exhibition(3).jpg)

_Hamilton: The Exhibition, Legacy Gallery | Courtesy of Korins and Drew Dockser_

“Being able to look at things in 3D really helps with lighting,” Stephens says. She adds that the team really wanted to control the visuals of the environment; they didn’t want to see lighting instruments or speakers, nor did they want visitors to see them. “So being able to look at placements of lighting fixtures and all of the technical stuff that you don't necessarily want to see in this type of environment was hugely helpful.”

This attention to detail when creating these scenes was made possible by the 3D modeling capabilities in Vectorworks. Stephens explains that these models helped create the necessary cohesion between rooms of the exhibition while also maintaining each of their individual functions.

“These were like little 360-degree mini sets, but they had to work together, right? You had to be able to get from one room to another,” she said. “We had to make a path. We had to figure out how those all fit together. And I think had we not blocked those out in some sort of 3D format, I think it never would have worked.”

[See how it works: check out a demo of the 3D modeling engine used for Hamilton: the Exhibition. ](https://www.youtube.com/watch?v=O0pHS2w4xQw)

###### **“If You Stand for Nothing, What Will You Fall for?” – Alexander Hamilton, _Hamilton_**

#Vectorworks2021 is all about finding the simplicity in your software so you can design your most complex ideas. A lot of times, it’s these complex ideas that inspire designers to begin with. So, what inspires designer Amanda Stephens?

“I've never been interested in the limelight as it were,” Stephens confesses. “I've never been interested in sort of being a name that somebody knows. It's not a goal. It's not interesting to me. … I really, really am in it for the art because that's the part that I really, really love. 

“I am interested in doing the best work that I can do to both serve the project and for me,” she continues. “I never want the scenery to outshine any other aspects \[of a production\]. I want everything to work as a whole and I want every design area and every part of the story to come together to make the best finished product that we can make. And that's always my goal.”

 Topics: [Product Launch](https://blog.vectorworks.net/topic/product-launch) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.