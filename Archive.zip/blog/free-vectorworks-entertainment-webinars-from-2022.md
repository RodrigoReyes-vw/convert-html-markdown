[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Recap: 4 Entertainment Webinars You Need to See

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/220517_May%20Webinar/blog-1440x800_May%20ENT%20Webinar.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Ffree-vectorworks-entertainment-webinars-from-2022)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Recap:%204%20Entertainment%20Webinars%20You%20Need%20to%20See&url=https%3A%2F%2Fblog.vectorworks.net%2Ffree-vectorworks-entertainment-webinars-from-2022&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Ffree-vectorworks-entertainment-webinars-from-2022)

Providing you with insightful learning and training opportunities is just as important to us as providing you [an all-in-one solution for design, documentation, and production.](https://www.vectorworks.net/spotlight)

So, let’s look back at the four entertainment webinars you and your fellow designers enjoyed most in 2022.

The four most popular entertainment webinars on [Vectorworks University](https://university.vectorworks.net/) in 2022 were:

1. 3D Models and Renderings for Live Events
2. Creating Efficient, Detailed Scenic Designs
3. Workflow Tips for More Collaborative Lighting Plans
4. Modeling to Schematics: Full AV Design Workflow

## 1\. 3D Models and Renderings for Live Events

![blog-1440x800_ENT October Webinar](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221020_October%20Webinar%20Blog/blog-1440x800_ENT%20October%20Webinar.png?width=1440&height=800&name=blog-1440x800_ENT%20October%20Webinar.png)

Our most popular entertainment webinar of 2022 is here to cover tons of tips for 3D modeling and rendering in Vectorworks. 

This webinar will help you:

* Understand how modeling in a 3D environment can bring your ideas to life
* Learn how rendering can help you best present your models
* See how textures can reduce the complexity of your models

[Click here to watch “3D Models and Renderings for Live Events.”](https://university.vectorworks.net/course/view.php?id=2366)

## 2\. Creating efficient, detailed scenic designs

![blog-1440x800_January ENT Webinar](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220119_Jan%20Webinar/blog-1440x800_January%20ENT%20Webinar.png?width=1440&height=800&name=blog-1440x800_January%20ENT%20Webinar.png)

_Image courtesy of Grant Van Zevern._

When it comes to stage production that is televised, no two projects are ever the same. And, that's why this case-study-style webinar with Grant Van Zevern explores best practices for flexible design with tips on file organization and the benefits of designing in 3D for the entertainment industry.

This webinar will help you:

* Learn non-standard file organization like setting up files using draft-specific layers and symbols, as well as architectural sectioning vs. single unit drafting
* See tips and tricks for designing industry-specific elements like drapery, lightboxes, and internal lighting in Vectorworks
* Explore workflow challenges when using Cinema 4D, Photoshop, AutoCAD, and others as well as their mitigations to discover industry best practices

[Click here to watch “Creating Efficient, Detailed Scenic Designs.”](https://university.vectorworks.net/course/view.php?id=745)

## 3\. Workflow Tips for More collaborative lighting plans

![blog-1440x800_December ENT Webinar](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/221215_December%20Webinars/blog-1440x800_December%20ENT%20Webinar.png?width=1440&height=800&name=blog-1440x800_December%20ENT%20Webinar.png)

_Image courtesy of Michael Harpur._

In this course, Michael Harpur, senior lighting technician in the Olivier Theatre at the National Theatre in London, shares his tips and tricks for getting the most out of your Vectorworks Spotlight files and symbols library. 

This webinar will help you:

* Understanding the advantages of creating venue-specific symbol libraries
* Organizing classes using a custom Vectorworks Spotlight template
* Using the Title Block feature in Vectorworks Spotlight to create rigging, designer, and hanging plots

[Click here to watch “Workflow Tips for More Collaborative Lighting Plans.”](https://university.vectorworks.net/course/view.php?id=2432)

## 4\. Modeling to Schematics: FUll av design workflow

![blog-1440x800_May ENT Webinar](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220517_May%20Webinar/blog-1440x800_May%20ENT%20Webinar.png?width=1440&height=800&name=blog-1440x800_May%20ENT%20Webinar.png)

Our fourth most popular entertainment webinar of the year reviews effective solutions to common design challenges you may face every day. Additionally, the course walks you through a complete AV design workflow — offering insight at every step of the way!

This webinar will help you:

* Learn to layout a new video playback and PA system in an existing venue
* Plan out camera placement within a singular and comprehensive software package
* Create rack layouts from devices, circuits, and equipment items that have corresponding schematic items

[Click here to watch “Modeling to Schematics: A Full AV Workflow.”](https://university.vectorworks.net/course/view.php?id=1948)

## WHAT WILL YOU LEARN NEXT?

For more free learning opportunities, click the button below and browse Vectorworks University:

[![BROWSE VECTORWORKS UNIVERSITY](https://no-cache.hubspot.com/cta/default/3018241/c18d3b62-956f-4e9f-9445-05efdbeaaaa3.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/c18d3b62-956f-4e9f-9445-05efdbeaaaa3) 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.