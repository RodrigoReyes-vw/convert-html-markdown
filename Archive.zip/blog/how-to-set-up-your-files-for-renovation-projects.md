[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Class & Layer Setup for Renovation Projects

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2022%20PVW%20Images/04_Renovation%20Projects/blog-1440x800%20copy%204.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-to-set-up-your-files-for-renovation-projects)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Class%20&%20Layer%20Setup%20for%20Renovation%20Projects&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-to-set-up-your-files-for-renovation-projects&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fhow-to-set-up-your-files-for-renovation-projects)

Modeling and documenting renovation projects differs from new building projects in some key ways.

Since there’s often three distinct phases in a renovation project, you’ll want to visually represent each of them. With Vectorworks Architect, you can visually represent the status of existing, demolition, and new construction with attributes such as line color, line type, fill color, and/or hatches.

There are multiple approaches you could take to managing the visual representation of renovation plans. In this blog, we'll highlight a method based on Vectorworks design layers and classes.

## Setting Up Classes

If you’d normally have one class for walls, in a renovation project you’d have three classes for walls — Wall-Demo, Wall-New, and Wall-Existing. Each class has its own attributes, and their visibility will be controlled in a viewport.

![Screen Shot 2022-03-03 at 3.34.29 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/04_Renovation%20Projects/Screen%20Shot%202022-03-03%20at%203.34.29%20PM.png?width=600&name=Screen%20Shot%202022-03-03%20at%203.34.29%20PM.png)

Vectorworks has the flexibility to customize naming conventions to meet AIA, Omniclass, Uniclass, or other CAD/BIM standards. The class naming system above is simplified for the purposes of demonstration.

Organizing the file into classes like this will allow you to use class overrides in viewports to graphically represent various objects at different phases of the project. For example, the first image shows a viewport with no class overrides and the second shows the same viewport with orange lines and fills representing items to be demolished, and with black-filled walls as existing items that will remain.

![Screen Shot 2022-03-03 at 3.46.48 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/04_Renovation%20Projects/Screen%20Shot%202022-03-03%20at%203.46.48%20PM.png?width=506&name=Screen%20Shot%202022-03-03%20at%203.46.48%20PM.png)

![Screen Shot 2022-03-03 at 3.47.53 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/04_Renovation%20Projects/Screen%20Shot%202022-03-03%20at%203.47.53%20PM.png?width=500&name=Screen%20Shot%202022-03-03%20at%203.47.53%20PM.png)

## Setting Up Design Layers

Design layers in Vectorworks are commonly used to organize your file by zones, types, or levels. Design layers are necessary to control the visibility of the model for generating floor plans, elevations, sections, and 2D details.

For a renovation project with two construction phases, you’ll want one layer per phase. Creating and using design layers like this allows you to visualize groups of objects by color so you can directly see which objects are existing, new, or scheduled to be demolished.

![Screen Shot 2022-03-30 at 3.23.29 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/04_Renovation%20Projects/Screen%20Shot%202022-03-30%20at%203.23.29%20PM.png?width=600&name=Screen%20Shot%202022-03-30%20at%203.23.29%20PM.png)

## Optimizing File Setup

There can be many variables in project types and markets, so it’s important for you and your firm to customize how you organize classes and design layers to suit your needs. Many firms will use a combination of classes and design layers to meet their specific workflow requirements.

The following chart is an example of how class and layer structure for floors might differ between a new construction project and a renovation project.

![Screen Shot 2022-03-30 at 3.24.02 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/04_Renovation%20Projects/Screen%20Shot%202022-03-30%20at%203.24.02%20PM.png?width=600&name=Screen%20Shot%202022-03-30%20at%203.24.02%20PM.png)

In this example, classes for walls, doors, and windows are duplicated and there’s a general demolition class. The reason for this is that door and window objects are inserted into wall objects, and because of this behavior you must classify them separately to obtain the correct visibilities when setting up your demolition and construction plans: for example, when an existing window is being replaced and inserted into an existing wall, you will need two windows, one to represent the demolished window and one to represent the new window. These two objects, if inserted in the same existing wall, need to be controlled by a different class to set the proper visibilities for demolition and new construction floor plans.

For more information and example files to follow along with the process, check out the “Model Setup for Renovation Projects” course on Vectorworks University:

[![Learn More About Setting Up Files for Renovation Projects](https://no-cache.hubspot.com/cta/default/3018241/50c9b4a8-6e6b-400a-beb6-e6e26d87326a.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/50c9b4a8-6e6b-400a-beb6-e6e26d87326a) 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.