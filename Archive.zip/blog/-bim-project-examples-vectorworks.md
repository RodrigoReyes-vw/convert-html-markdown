[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# 3 Architecture Firms that Harness the Power of BIM

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/220406_3%20BIM%20Projects/Flansburgh_3%20BIM.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2F-bim-project-examples-vectorworks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=3%20Architecture%20Firms%20that%20Harness%20the%20Power%20of%20BIM&url=https%3A%2F%2Fblog.vectorworks.net%2F-bim-project-examples-vectorworks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2F-bim-project-examples-vectorworks)

Building Information Modeling (BIM) has often been referred to as a “single source of truth” for your project. And with [Vectorworks Architect's](https://www.vectorworks.net/architect) BIM environment, you’re able to freely sketch, model, and document your design ideas with precision. BIM with Vectorworks also allows you to collaborate amongst stakeholders with a heightened level of detail.

For these reasons — and so many more — firms around the world have harnessed the power of BIM in their architectural designs. In this post, we’ll look at three projects to show you why you and your firm should also harness the power of BIM!

## IttenBrechbühl AG’s Scott Headquarters

![IttenBrechbuhl_3 BIM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220406_3%20BIM%20Projects/IttenBrechbuhl_3%20BIM.jpg?width=1440&name=IttenBrechbuhl_3%20BIM.jpg)

_Image courtesy of IttenBrechbühl._

In 2017, [IttenBrechbühl](https://www.ittenbrechbuehl.ch/) designed the headquarters of Scott Sports in Givisiez, Switzerland with the help of Vectorworks Architect’s BIM processes.

The firm’s goal was to create a forward-looking, precise design based on improved communication and coordination between those involved in the process — all on the basis of 3D models. Additionally, the firm used coordinated the naming and structure of levels and classes, stories, the definition of the project’s origin, the handling of .IFC data, as well as wall and door styles and symbols. This lead to a successful BIM collaboration. 

According to Marc Pancera, head of BIM at IttenBrechbühl, BIM emphasizes the advantages of communication via models, and it also avoids misunderstandings that can arise from 2D drawings. 

IttenBrechbühl may not have been able to collaborate and design as effectively if not for information-based modeling of Vectorworks Architect.

[Read the full story on IttenBrechbühl](https://www.vectorworks.net/customer-showcase/collaboration-with-3d-bim-models)

## Flansburgh Architects’ New Holbrook School

![Flansburgh_3 BIM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220406_3%20BIM%20Projects/Flansburgh_3%20BIM.jpg?width=1440&name=Flansburgh_3%20BIM.jpg)

_Image courtesy of Flansburgh Architects._

[Flansburgh Architects](http://flansburgh.com/?utm%5Fmedium=website&utm%5Fsource=archdaily.com), a Boston-based firm that specializes in educational architecture, implemented a BIM workﬂow for the design of a school for the town of Holbrook, Massachusetts. 

Until the Holbrook project, Flansburgh Architects had been using building information modeling among the internal design team for architectural documentation and coordination. To work effectively with external contractors and consultants, Flansburgh developed a BIM-centric process.

Brian Hores, AIA, BIM Manager shared how this process benefited the project. “We didn’t just flip a switch and suddenly we’re doing BIM,” said Hores. “We built upon past experience. It’s our goal to take the BIM process another step further with every new project.” Flansburgh Architects agree on what may be the biggest selling point for working in BIM — the fact that there can be one collaborative model with multiple kinds of data attached to it.

Flansburgh Architects did their architectural design in Vectorworks, then used .IFC to import, export, and reference ﬁles from all the consultants and subcontractors. Hores said they worked with engineers who developed structural and .MEP models in Revit, but they were still able to collaborate due to Vectorworks’ seamless integration and use of IFC.

The Holbrook School project proves that BIM workflows work best when data exchange is free and open — the AEC industry flourishes when architects, engineers, and construction professionals can all work in the software they prefer.

[Read the full story on Flansburgh Architects](https://www.vectorworks.net/en-US/customer-showcase/a-successful-transition-to-open-bim)

## A&Q Partnership’s Residential Housing

![AQ_3 BIM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220406_3%20BIM%20Projects/AQ_3%20BIM.jpg?width=1440&name=AQ_3%20BIM.jpg)

_Image courtesy of A&Q Partnership._

The third — and final — BIM project that we’ll be highlighting today is A&Q Partnership’s Eight Gardens at Watford.

The project aims to deliver over 1,200 new homes to the area. Alongside future plans for a primary school and community amenities like a dentist’s office, the Eight Gardens development is part of a much larger modernization of the area, according to the Watford Borough Council. 

With the various consultants on the project at various levels of experience with BIM, some not as familiar with BIM workflows as [A&Q Partnership](https://aqp.co.uk/), the initial appointments didn’t formally stipulate a BIM workflow. However, the teams were keen on developing the way they work, and so agreed to proceed as a BIM project even though it wasn’t obligatory.

“We offered that we’d develop it as a BIM job despite it not being contractually required, partly to help others in the learning process in adopting,” said Nick Lawrence, practice director, explaining how this left them in a “slightly strange position” at the beginning of the project, charting unfamiliar territory with some parties. The team got together and set expectations for each other, then followed through with a tight execution plan. A&Q Partnership worked with the .DWG files and .IFC files by referencing them into Vectorworks.

[Read the full story on A&Q Partnership](https://www.vectorworks.net/customer-showcase/residential-architecture-pathway-to-bim)

Implementing BIM isn’t as difficult as you may think, either. Many firms — both large and small — have successfully adopted building information modeling. Click the button below to view a free webinar on streamlining your workflow with BIM.

[![STREAMLINE YOUR WORKFLOW WITH BIM](https://no-cache.hubspot.com/cta/default/3018241/103e516e-1ad4-4244-93c7-d2be05362acb.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/103e516e-1ad4-4244-93c7-d2be05362acb) 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.