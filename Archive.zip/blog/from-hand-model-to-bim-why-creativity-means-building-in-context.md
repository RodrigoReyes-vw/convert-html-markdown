[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# From Hand Modeling to BIM, Why Creativity Means Building in Context

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/201005_ARCH%20Signature%20Project/5053-2009-launch-blog-signature-project-architect-1.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Ffrom-hand-model-to-bim-why-creativity-means-building-in-context)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=From%20Hand%20Modeling%20to%20BIM,%20Why%20Creativity%20Means%20Building%20in%20Context&url=https%3A%2F%2Fblog.vectorworks.net%2Ffrom-hand-model-to-bim-why-creativity-means-building-in-context&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Ffrom-hand-model-to-bim-why-creativity-means-building-in-context)

With [the release of #Vectorworks2021](https://www.vectorworks.net/2021?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=link&utm%5Fcontent=100520archsignatureblog), we’re featuring some of our customers’ projects in our promotional materials. The first is a railway terminal proposed for Ülemiste, a subdistrict of the Estonian capital Tallinn.

[![LEARN MORE ABOUT VECTORWORKS 2021](https://no-cache.hubspot.com/cta/default/3018241/80d36021-9e10-4b90-bc67-ce43fccdcd89.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/80d36021-9e10-4b90-bc67-ce43fccdcd89) 

Designed by [3+1 architects](https://www.threeplusone.ee/), this project has it all — eye-catching geometry, complements to the existing urban fabric, and a sophisticated process from start to finish.

When we spoke with the architects about their design process, they shared some valuable insights into how they developed such an alluring terminal.

![3+1 Architects Proposal for the Rail Baltica](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201005_ARCH%20Signature%20Project/5053-2009-launch-blog-signature-project-architect-1.jpg?width=600&name=5053-2009-launch-blog-signature-project-architect-1.jpg)

## The Railway Terminal in Ülemiste

3+1’s design submittal is provocative with its use of red tones; the block-like structure and strong leading lines draw the eye overhead to the central pedestrian room, where one will be able to watch as high-speed trams pass underneath. One of the key aspirations for the project was to develop a pedestrian-friendly build which can be viewed as a destination, not a step along the way.

![3+1 Architects proposal for Rail Baltica](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201005_ARCH%20Signature%20Project/5053-2009-launch-blog-signature-project-architect-2.jpg?width=600&name=5053-2009-launch-blog-signature-project-architect-2.jpg)

_Rendering courtesy of 3+1 architects._

Hanna-Liisa Mõtus of [3+1 architects](../../../net/vectorworks/blog/women-in-architecture-a-conversation-with-31-architects.html) reports[ a larger vision](https://www.threeplusone.ee/work/ulemiste-concept/) for this area in Ülemiste to be completed by 2045\. As an extension of the Tallinn airport’s development, 3+1’s planning indicates intentions for a dense urban [Smart City](../../../net/vectorworks/blog/the-future-is-here-this-smart-street-actually-responds-to-the-needs-of-people.html).

She calls the proposed terminal and its surroundings a “Gate of Estonia” — because of its prominent position in the Estonian capital, the area would be the first on-foot impression of the country for many travelers.

And so it’s no surprise to see such a substantial development project with a hefty timeline; by 2045, this area in Ülemiste would serve as Estonia’s welcoming committee, inviting travelers into the country through a modern, bright, commercial space. 

![3+1 Architects proposal for Rail Baltica](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201005_ARCH%20Signature%20Project/5053-2009-launch-blog-signature-project-architect-3.jpg?width=600&name=5053-2009-launch-blog-signature-project-architect-3.jpg)

_Rendering courtesy of 3+1 architects._

## A Concept #MadeWithVectorworks

Longtime [Vectorworks](https://www.vectorworks.net/en-US/architect?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=link&utm%5Fcontent=100520archsignatureblog) users, 3+1 architects view the software as crucial to the management of their design process. But before software, everything starts with a 2D hand sketch and physical 3D model.

“We always start with a physical model to analyze and understand volumes and the relationships of spaces,” said Ilmar Valdur, architect and partner at 3+1\. “3D modeling, 2D drawing, and hand modeling — it all works very much together.” He added that digital 3D modeling still happens on a 2D screen, and that experiencing true three dimensions is essential to the 3+1 process.

The practice is far from exclusive — for 3+1, hand drafting and digital modeling work together in harmony. As a design tool, 3+1 architect Karin Harkmaa said “Vectorworks makes it much easier and faster to explain and interpret ideas.”

![3+1 Architects drawing](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201005_ARCH%20Signature%20Project/5053-2009-launch-blog-signature-project-architect-4.jpg?width=600&name=5053-2009-launch-blog-signature-project-architect-4.jpg)

_Drawing courtesy of 3+1 architects._

When they started modeling their design idea in Vectorworks, the architects imported all the necessary landscape data and point clouds. They created two site models, one a large-scale contextual model and the other more narrowly focused on the terminal.

“Software is a tool for us to do our designing,” said Valdur. “Today, we’ve reached somewhat of a breaking point through BIM and 3D modeling — this software has a very special role to manage and to take control. It’s allowed us to take on much better and much more complex architecture in our small office.”

![3+1 Architects drawing](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/201005_ARCH%20Signature%20Project/5053-2009-launch-blog-signature-project-architect-5.jpg?width=600&name=5053-2009-launch-blog-signature-project-architect-5.jpg)

_Drawing courtesy of 3+1 architects._

There’s of course much more involved in a project than modeling. 3+1 relies on Vectorworks for collaboration and presentation, taking advantage of Project Sharing internally and IFC files externally.

“It’s important to create 2D presentations at every phase, and Vectorworks is very organized at that,” said Mõtus.

## What Does Creativity Mean to You?

Simplicity to design the complex — it’s what #Vectorworks2021 is all about. Software doesn’t have to get in the way of design and being creative. Design and creativity go hand-in-hand, which is why we thought it would be nice to hear how the architects at 3+1 define “creativity” — what exactly does it mean to be creative?

“Whether we’re working on an urban project, a private house, or a public building, I hope to make an impact for the client and users of the space,” said Mõtus. 

“Your surrounding environment impacts so much of everyday life, both emotionally and physically,” she added. “So for me it’s really important to understand the client’s context, their needs, and their behaviors and to delicately but also interestingly translate that into space and spatial relations. 

So, for me, creativity always grows out of the context of the client and users of the space.” 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.