[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Achieve Precision with SmartCursor Snapping

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 7 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2022%20PVW%20Images/07_Snapping/vw-twitter-gs-imagery.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fneed-help-with-snapping-in-vectorworks)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Achieve%20Precision%20with%20SmartCursor%20Snapping&url=https%3A%2F%2Fblog.vectorworks.net%2Fneed-help-with-snapping-in-vectorworks&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fneed-help-with-snapping-in-vectorworks)

Precision is key, whether it be for building, landscape, or entertainment projects.

Being precise from the very start of a project is easy with Vectorworks, and you’ll be much more accurate with an understanding of snapping settings. Read on to review what the various snapping modes do.

## How Does Snapping Work in Vectorworks?

Snapping is an automation that attracts your cursor like a magnet to a pre-defined position. It’s useful because you can place a drawing object exactly where you want it instead of guessing or fiddling with placement until you get it right. Most drawing or design software programs contain snapping settings.

In Vectorworks, the Status bar at the bottom right of your screen contains the range of snapping options. Each has its own use depending on your needs.

![SnappingBar](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/07_Snapping/SnappingBar.png?width=292&name=SnappingBar.png)

Snapping types can be used individually or combined for precise drawing. For example, enabling Snap to Objects and Snap to Grid allows you to find points that are both on an object and on an established grid. Snapping can also be combined with the Data bar input to find a specific snap point along a defined location in the drawing area.

Most snapping modes have settings that can be set from a popover that opens when you double-click, right-click, or click and hold the tool.Some of the snapping tools do not have additional parameters and are simply toggled on or off.

## What Each Snapping Mode Does

## Snap to Grid

When snap to grid is on, your cursor — referred to as the SmartCursor for its ability to give you a variety of visual feedback — snaps to set points on a defined grid. For example, if the grid is set to 1”, as the cursor moves over the grid, it automatically “catches” every inch. When you create a line, if no other snapping is active, the line’s first and last point will lie on the snap grid. Snap to grid is the only type of snapping that does not provide any sort of visual cues. If snap to grid is on, the cursor is always on the grid, unless other snaps are also selected which override snap to grid.

## Snap to Object

When snap to object is on, the SmartCursor finds specific parts of an object, such as corners, endpoints, midpoints, or centers of 2D objects and arc edges, as well as meshes, extrudes, sweeps, spheres, 3D polygons, 3D planar faces, and walls, floors, roofs, roof faces, loci, and columns. Cues display near the cursor to identify the location.

## Snap to Angle

Snap to angle only applies to the second point of a two-point object, such as when drawing a line or polygon. When snapping to angles, the SmartCursor finds the angles specified in Angle Snap Settings, and by default, the SmartCursor also finds angles relative to the horizontal and vertical axes. Snap to Angle can also detect a plan rotation angle in Vectorworks Design Suite.

## Snap to Smart Point

When smart points snapping is on, you can temporarily remember a point where the cursor paused for a set length of time, or where a special shortcut key was pressed. Once a smart point has been defined, you can align to it horizontally, vertically, or at a specific angle using temporary extension lines and SmartCursor cues.

## Snap to Smart Edge

When smart edge snapping is on, the SmartCuror finds points on, or at a certain distance away from, a specified edge. The edges of linear 2D geometry, arc and polyline curve segments, and 3D segments and curves are recognized as smart edges. Once a smart edge has been defined, you can align to it horizontally, vertically, or at a specific angle using extension lines and SmartCursor cues.

To set a smart edge, slowly move the cursor over a 2D object edge for the set number of seconds or press the T key while over an edge. Dotted extension lines indicate that the smart edge has been set. Up to two smart edges can be set, and then the oldest edges are replaced. A smart edge can be released by moving the cursor slowly over the edge or pressing the T key over the edge again.

## Snap by Distance

When distance snapping is on, the SmartCursor finds points at a selected distance along a straight or curved line, polygon edges, wall edges, and other linear objects.

The SmartCursor measures from each endpoint to the center of the line. If a line is 10 units long and the distance is set to 6 units, the distance will not be found at all, since it is longer than half a line. Similarly, any fraction greater than 1/2 the length of the object or less than 0 cannot be used.

## Snap to Intersection

When snap to intersection snapping is on, the SmartCursor finds the intersection between two objects or between the parts of an object.

## Snap to Tangent (2D Only)

The Snap to Tangent option uses the SmartCursor to locate tangents on circular arc geometry when drawing. It’s a convenient way to create reference points from circles and arcs.

## Snap to a Working Plane (3D Only)

When Snap to Working Plane snapping is on, the SmartCursor snaps a point not on the working plane to its shadow point on the working plane. If you click on a 3D object, the snap is projected to a point on the working plane. This snapping temporarily overrides other snapping which might interfere with the ability to constrain snapping to the working plane. This is useful for drawing and moving 3D objects aligned to the working plane.

## Get More Tips on Drawing Features in Vectorworks

The range of snapping options give you the flexibility and precision to draw anything you can imagine. You can read more about snapping modes on Vectorworks Help. And if you’re looking for a sure-fire way to up your Vectorworks skills, consider our Core Certification Course:

[![GET CERTIFIED IN VECTORWORKS](https://no-cache.hubspot.com/cta/default/3018241/b087c237-1991-4c15-a7d5-5de904d5f196.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/b087c237-1991-4c15-a7d5-5de904d5f196) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.