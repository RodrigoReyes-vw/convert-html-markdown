[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Entertainment Industry Updates in Vectorworks 2023

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/220822_ENT%20Launch%202023/blog-1440x800.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fspotlight-and-connectcad-updates-vectorworks-2023)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Entertainment%20Industry%20Updates%20in%20Vectorworks%202023&url=https%3A%2F%2Fblog.vectorworks.net%2Fspotlight-and-connectcad-updates-vectorworks-2023&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fspotlight-and-connectcad-updates-vectorworks-2023)

Vectorworks 2023, centered around accelerating your design process, is coming soon!

Continuous improvements to [Vectorworks Spotlight](https://www.vectorworks.net/spotlight) and [ConnectCAD](https://www.vectorworks.net/connectcad) will provide you with upgrades to your most important tools, helping you meet the demands of the revitalized entertainment industry.  

Check out the video below with Scott Parker, Spotlight product planner, for a glimpse into what Vectorworks 2023 will offer you. Then, read on to learn about other features and updates that are on their way.

## Easier Rigging Design 

Rigging design and planning will also be easier than ever before in Vectorworks Spotlight 2023.

![Screen Shot 2022-08-22 at 1.51.42 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220822_ENT%20Launch%202023/Screen%20Shot%202022-08-22%20at%201.51.42%20PM.png?width=1440&name=Screen%20Shot%202022-08-22%20at%201.51.42%20PM.png)

With an improved integration between hoist and bridle objects, you’ll be able to have a for more consistent and manageable documentation process. Also, increased control over the now symbol-based truss cross object will ease your workflow when working with trusses.

## Improved Lighting Devices

When working in 3D in Vectorworks 2023, you’ll have more intuitive control of your rotating lights.

The rotational gimbal lock of previous versions has been removed, giving you the freedom to better orient lighting devices when designing. Ultimately, this improvement will help you better communicate the rotational data in your paperwork.

## ConnectCAD Cable Riser Diagrams

Now let’s talk about some of the new features and upgrades coming to ConnectCAD.

Updates to the Cable tool will help you create cable riser diagrams and reports faster. The new ability to create these diagrams will also help you produce documentation that’s familiar to electrical contractors, allowing you to have faster responses to onsite changes and quickly evaluate costs.

## Additional ConnectCAD Workflow Improvements

Cable riser diagrams aren’t the only improvements you’ll find in ConnectCAD. You’ll also find the following:

* More intuitive class structuring and assignment
* The ability to specify device locations in a schematic layout for more automated equipment lists in layout
* More intelligent list choice generation
* The capability to add devices from a project to the database
* And more!

Time is money in the live events industry, and the upcoming version of ConnectCAD will let you take your design process to a whole new level.

## What Else is Coming with Vectorworks 2023?

We’ve recently published stories previewing some of the exciting features and updates that will be a part of the upcoming release:

[READ: User Experience Updates in Vectorworks 2023](../../../net/vectorworks/blog/sneak-peek-user-experience-updates-in-vectorworks-2023.html)

[READ: BIM Feature Updates in Vectorworks 2023](../../../net/vectorworks/blog/bim-updates-in-vectorworks-2023.html)

To be notified about other Vectorworks 2023 features as we share them, be sure to click the button below and subscribe to _Planet Vectorworks._

_[![SUBSCRIBE FOR VECTORWORKS 2023 UPDATES](https://no-cache.hubspot.com/cta/default/3018241/7fac1a1e-9f0d-494d-8e87-ff9537016edb.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/7fac1a1e-9f0d-494d-8e87-ff9537016edb)_ 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.