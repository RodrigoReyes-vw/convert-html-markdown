[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Introducing the Vectorworks Diversity and Inclusion Committee

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/20210916_DI%20Committee/2109-dei-committee-goals-blog-image.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fget-to-know-the-vectorworks-diversity-and-inclusion-committee)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Introducing%20the%20Vectorworks%20Diversity%20and%20Inclusion%20Committee&url=https%3A%2F%2Fblog.vectorworks.net%2Fget-to-know-the-vectorworks-diversity-and-inclusion-committee&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fget-to-know-the-vectorworks-diversity-and-inclusion-committee)

Diversity is about recognizing, respecting, and valuing the range of different ethnicities, genders, colors, ages, races, religions, national origins, sexual orientations, and persons with disabilities.

Diversity includes an infinite range of unique characteristics and experiences. These can be communication style, career path, life experience, educational background, geographic location, income level, marital status, military experience, parental status, and other variables that influence personal perspectives.  

“At Vectorworks, our employee population has always been diverse,” said Tania Salgado-Nealous, Vectorworks’ chief human resources officer. “Without any intention, over the years we have expanded our team with employees from all over the world. We currently have team members from over 14 countries, and we all come from different cultural, educational, personal, and professional backgrounds.”

Despite such diversity, there was a clear need for action that represented the natural evolution of Vectorworks. As Salgado-Nealous put it, we needed to “purposely work on initiatives that will allow us all to live out our values of collaboration and inclusion.” Today, **we’re proud to announce our new Diversity and Inclusion Committee!**

Our committee’s mission statement is divided into three parts, THE WHO, THE WHY, and THE HOW.

> THE WHO
> 
> _Vectorworks is an energetic and dedicated team spread across several offices on multiple continents._ _We create software translated into 11 languages for use by more than 685,000 designers across the globe. Diversity and inclusion are essential to our success._ 
> 
> THE WHY
> 
> _We celebrate the strength we gain when our employees, partners, customers, and community members around the world bring their full selves when working together. We fuel growth and unleash creativity by fostering inclusivity through mutual respect, compassion, and acceptance. We seek to remove limitations and advance equity by embracing diversity of identities and life experiences._ 
> 
> THE HOW
> 
> _The committee propels strategic initiatives with measurable outcomes that bring meaningful change to our own community and the communities we serve. Continual reflection and evaluation of our priorities and methods ensure the committee’s efforts evolve._

 The Diversity and Inclusion Committee has already decided upon three different ways to serve.  

The first path of action is for the Diversity and Inclusion Committee to allocate resources and sponsor projects that benefit underserved peoples, groups, and/or communities around the globe. The second — and more localized — approach would be for the committee to organize [service opportunities](../../../net/vectorworks/blog/vectorworks-volunteer-maryland-food-bank.html) near our Columbia, Maryland headquarters. The third course of action is internal education for all Vectorworks team members on matters of diversity, equity, and inclusion.

As we determine what specific projects we’ll be sponsoring, serving, and/or educating on, we’ll also be sharing them publicly. So, be sure to stay up to date on all things Planet Vectorworks. 

###### Meet the Team

Below are the inaugural members of Vectorworks’ Diversity and Inclusion Committee.

Leadership:

Rubina Siddiqui – Coordinator

Tabitha Harvey – Treasurer

Emilee Romano – Secretary

Committee Members:

Liz Pickering

Eric Stinnett

Justin Van Hassel

Kristen Bailey

Lee Draminski

Eric Gilbey

Tom White

Krystal Harris

Ishan Dey

Why did Vectorworks team members want to join the Diversity and Inclusion Committee? For some, the committee is an opportunity to share their unique perspectives. For example, Kristen Bailey, lead technical writer for technical publications, acknowledged how few women hold senior positions in the engineering sector.

“I think I’d bring a useful perspective. I’ve done a bit of research on ways gender equity can be promoted in technical fields, and I’d be happy to do more. I’ve also worked to educate myself on anti-racism and implicit bias more broadly and am interested in working on systems that increase equity,” Bailey said.

![2109-dei-committee-goals-blog-image(2)](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/20210916_DI%20Committee/2109-dei-committee-goals-blog-image(2).jpg?width=607&name=2109-dei-committee-goals-blog-image(2).jpg)

The committee also serves as a vehicle that can push forward the change members want to see in the world. Eric Stinnett, account associate, said, “I’ve recently had some conversations about the diversity of designers within entertainment design, and I’ve started an initiative to provide support and mentorship for new designers from HBCUs, as well as other people of color. I believe this committee would be a great place to continue that important work.”

While we’re so proud to now have a committee dedicated to diversity and inclusion, we recognize that this is only the start of our work. We’re excited for the many meetings, discussions, and actions to come.

Also, be sure to check out our core values page to learn more about the beliefs that drive us forward.

[![OUR CORE VALUES](https://no-cache.hubspot.com/cta/default/3018241/a7fa355a-ee94-49bb-9e4f-d78c262fac72.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/a7fa355a-ee94-49bb-9e4f-d78c262fac72) 

 Topics: [News](https://blog.vectorworks.net/topic/news) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.