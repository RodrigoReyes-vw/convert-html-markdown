[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Importing Revit Files into Vectorworks Landmark

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2022%20PVW%20Images/04_Importing%20Revit%20to%20Landmark/2203-landezine-advertorial-vectorworks-revit-import-feature.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-to-import-.rvt-and-.rfa-files-into-vectorworks-landmark)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Importing%20Revit%20Files%20into%20Vectorworks%20Landmark&url=https%3A%2F%2Fblog.vectorworks.net%2Fhow-to-import-.rvt-and-.rfa-files-into-vectorworks-landmark&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fhow-to-import-.rvt-and-.rfa-files-into-vectorworks-landmark)

Picture your history of site design work. How often have you collaborated with architects who use Revit?

Was your answer “at least once?” Then you’re probably skeptical of how well other design solutions can handle RVT and RFA files.

Fortunately, Vectorworks Landmark boasts some practical and reliable features for collaborating via Revit files. In this blog, you’ll see an overview of Vectorworks’ capabilities for interoperability with Revit and get access to a guide written by our landscape industry specialists.

## Importing Revit Files into Vectorworks Landmark

So, you’re ready to start designing in Landmark and the consulting architects send you a Revit file. To import, select File > Import > Import Revit, then select the file you’d like to import. This will display a the RVT/RFA Import Options menu that presents you with a variety of checkbox options to customize the import, such as: 

1. Import active view only, import 3D model view only, or import 2D and 3D views
2. Create native Vectorworks objects on import
3. If not creating native Vectorworks objects, import Vectorworks mesh objects, groups of 3D polygons, or Vectorworks solid objects
4. Import textures and texture mapping

Take advantage of the ability to import native Vectorworks objects as you’ll be able to easily edit their data and linked [documentation](../../../net/vectorworks/blog/tutorial-series-documentation.html).

Upon import, you’ll notice that a Vectorworks design layer was created for each Revit level. You can manage these layers as you normally would, whether that be toggling visibility settings or simultaneously editing graphical attributes of all geometry in the layer.

[![Get Yours Today! Revit Interoperability with Vectorworks Landmark: A Guide](https://no-cache.hubspot.com/cta/default/3018241/cd01326f-23e6-4613-af60-e3e432a62e3f.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/cd01326f-23e6-4613-af60-e3e432a62e3f) 

## Creating a Digital Terrain Model from Revit Source Data

With the building in your design layer, you’re probably ready to start on your digital terrain model, known as a site model in Vectorworks. If you have imported terrain source data from Revit, you can easily use it to create an intelligent site model in Vectorworks Landmark. Select Landmark > Create Site Model > Create Model from Source Data. You’ll see the Site Model Settings menu where you can edit information like minimum/maximum elevation and contour intervals/multipliers.

 With the site model created, you can visit the Graphic Properties menu to colorize different elevations and slopes. You’ll have a well-defined, customizable site model with this method.

## Importing Revit Family (RFA) Objects with Maintained Data Records

Aside from your consultants, you may have acquired manufacturer-created content in the Revit Family (RFA) format. If manufacturers supplied you with .RFA files for various objects like site furniture, you could easily import them into Vectorworks Landmark’s drag-and-drop interface with their data records maintained. Select File > Import > Import Revit (Batch). This will bring up a menu where you can individually select objects for import or choose to import all objects in a selected folder.

![2203-landezine-advertorial-import-revit-batch](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/2022%20PVW%20Images/04_Importing%20Revit%20to%20Landmark/2203-landezine-advertorial-import-revit-batch.jpg?width=700&name=2203-landezine-advertorial-import-revit-batch.jpg)

For documenting these objects, attached Revit data is easily accessible in the Object Info palette.

## More Information on Exporting, Referencing, and Collaborating via Revit Files

The information in this blog touches on the standard workflow for importing Revit files. If you’re wondering about exporting and referencing or have any other questions about collaborating with professionals who use Revit, consult this guide written by our landscape industry specialists!

[![Read: Revit Interoperability with Vectorworks Landmark: A Guide](https://no-cache.hubspot.com/cta/default/3018241/c68a76aa-774c-4ff8-9f9b-b82d84e7907c.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/c68a76aa-774c-4ff8-9f9b-b82d84e7907c) 

 Topics: [Landscapes](https://blog.vectorworks.net/topic/landscapes) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.