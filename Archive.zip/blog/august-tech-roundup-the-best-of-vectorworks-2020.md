[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# August Tech Roundup: The Best of Vectorworks 2020

 Posted by [Kamica Price](https://blog.vectorworks.net/author/kamica-price) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/200827_Tech%20Roundup/walkthrough-animation_resized.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Faugust-tech-roundup-the-best-of-vectorworks-2020)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=August%20Tech%20Roundup:%20The%20Best%20of%20Vectorworks%202020&url=https%3A%2F%2Fblog.vectorworks.net%2Faugust-tech-roundup-the-best-of-vectorworks-2020&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Faugust-tech-roundup-the-best-of-vectorworks-2020)

The end of August signals a new software release around the corner, but this doesn’t mean we say goodbye to [Vectorworks 2020](https://www.vectorworks.net/en-US/2020?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup). In fact, the power of our current version and its usability are key reasons to still talk about the benefits of its features, so you can make the most of your design time with Vectorworks. Here’s a look back at the best tech tips from Vectorworks 2020.

## The Launch

[Last September](/meet-vectorworks-2020-clearly-insightful.-simply-powerful?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup), Vectorworks 2020 arrived with a strong emphasis on data and usability. This focus brought improved design workflows with new features that delivered quality improvements and better BIM capabilities. Top features include:

* [List browser direct](https://university.vectorworks.net/mod/page/view.php?id=235?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup)[ editin](https://university.vectorworks.net/mod/page/view.php?id=235?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup)[g](https://university.vectorworks.net/mod/page/view.php?id=235?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup)
* [IFC Referencing](https://university.vectorworks.net/mod/page/view.php?id=231?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup)
* [Video Camera object](https://university.vectorworks.net/mod/page/view.php?id=286?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup)
* [Hardscape Alignment](https://university.vectorworks.net/mod/page/view.php?id=218?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup)
* [Walkthrough ](https://university.vectorworks.net/mod/page/view.php?id=288?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup)[A](https://university.vectorworks.net/mod/page/view.php?id=288?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup)[nimation](https://university.vectorworks.net/mod/page/view.php?id=288?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup)s
* [Door and Window tools](https://university.vectorworks.net/mod/page/view.php?id=216?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup)

**![walkthrough-animation_resized](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/200827_Tech%20Roundup/walkthrough-animation_resized.jpg?width=600&name=walkthrough-animation_resized.jpg)**_A closer look at walkthrough animations._

## Managing Data Your Way

The Data Manager simplifies your BIM workflows by gathering all data in one place to define data mappings and create data sheets from the same dialog. With this feature, you’re able to create your own workflow based on your needs, requirements, and processes.

_Bonus tip_: This feature combined with the [Data Visualization](https://university.vectorworks.net/mod/scorm/player.php?scoid=282&cm=356&currentorg=articulate%5Frise?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup) capabilities gives you efficient quality control of building information models with Vectorworks.

![blog-images-nov-18](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/200827_Tech%20Roundup/blog-images-nov-18.jpg?width=600&name=blog-images-nov-18.jpg) [![Learn More](https://no-cache.hubspot.com/cta/default/3018241/04888bad-ff36-4033-a399-2c28b9391da7.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/04888bad-ff36-4033-a399-2c28b9391da7) 

## More Performance Improvements and Key Updates

In March, we released [Service Pack 3](/introducing-service-pack-3-what-it-means-for-you?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup) for Vectorworks 2020 which brought quality and performance enhancements, along with new partner integrations.

![Enscape](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/200827_Tech%20Roundup/Enscape.png?width=600&name=Enscape.png)_Courtesy of Enscape_

The new real-time rendering connection available through [Enscape](https://enscape3d.com/) allows Windows users to quickly produce high-quality, compelling live-linked renderings in their Vectorworks model. 

_Bonus tip_: The Enscape free beta is available to users through October 2020.

Additionally, improved [GDTF data workflows](/gdtf-becomes-entertainment-standard-with-din-spec-15800?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup) allow files to be directly imported into [Spotlight](https://www.vectorworks.net/en-US/spotlight?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup) and managed directly from the Resource Manager.

![GDTF](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/200827_Tech%20Roundup/GDTF.png?width=600&name=GDTF.png)_Improved support for GDTF and MVR now enables a fully connected workflow between Vectorworks Spotlight, Vision, and consoles that support these open file formats._

The NBS Chorus integration allows you to manage, modify, and verify BIM specifications. Users can open a web palette in Vectorworks, letting them work concurrently with their model and NBS Chorus. 

_Bonus tip:_ An active [Vectorworks Service Select](https://www.vectorworks.net/service-select?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=intext&utm%5Fcontent=082720techroundup) membership is required for this function.

[![Learn More](https://no-cache.hubspot.com/cta/default/3018241/33996ec4-f627-447a-aa9f-fb3b0a7a0b00.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/33996ec4-f627-447a-aa9f-fb3b0a7a0b00) 

Vectorworks 2020 brought an approachable suite of new features to help you visualize data in a whole new way. Data modeling is here to stay, so with each new version, like the upcoming Vectorworks 2021 release, you can expect continued development to ensure you’re able to make impactful decisions. 

Want to see what’s in store for Vectorworks 2021? Get a behind-the-scenes look at the upcoming enhancements by checking out our [Teaser Tuesday blogs](/topic/teaser-tuesday?utm%5Fcampaign=blog&utm%5Fmedium=planetvectorworks&utm%5Fsource=cta&utm%5Fcontent=082720techroundup). Be sure to join the #Vectorworks2021 conversation with us on social media. 

 Topics: [Product Launch](https://blog.vectorworks.net/topic/product-launch), [BIM (Architecture)](https://blog.vectorworks.net/topic/bim-architecture), [Partner Products](https://blog.vectorworks.net/topic/partner-products), [Tech Tips and Workflows](https://blog.vectorworks.net/topic/tech-tips-and-workflows), [Production & Lighting Design](https://blog.vectorworks.net/topic/production-lighting-design) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.