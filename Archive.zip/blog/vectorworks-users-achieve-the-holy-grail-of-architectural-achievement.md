[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Vectorworks Users Reach the Holy Grail of Architectural Achievement

 Posted by [Chloe Jefferson](https://blog.vectorworks.net/author/chloe-jefferson) | 6 min read time 

![nimbus-by-squirrel-design](https://blog.vectorworks.net/hubfs/nimbus-by-squirrel-design.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-users-achieve-the-holy-grail-of-architectural-achievement)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Vectorworks%20Users%20Reach%20the%20Holy%20Grail%20of%20Architectural%20Achievement&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-users-achieve-the-holy-grail-of-architectural-achievement&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-users-achieve-the-holy-grail-of-architectural-achievement)

In the UK, designing a Paragraph 55 project can be difficult, but getting permission to produce it is next to impossible. Recently, award-winning architectural practice (and Vectorworks user) [Squirrel Design](http://www.squirrel-design.co.uk) made the impossible possible with not one, but _two_ Para 55 projects: The Nimbus in Cornwall, England and [Hux Shard](http://www.huxshard.uk/paragraph-55/hux-shard-paragraph-55/) in Devon, England. These projects have set this father-and-son firm apart from the rest.

**![nimbus-by-squirrel-design](https://blog.vectorworks.net/hs-fs/hubfs/nimbus-by-squirrel-design.jpg?width=626&name=nimbus-by-squirrel-design.jpg)**_Rendering of the Nimbus project in Cornwall, England._

## About the Firm

Michael O’Connor, his son, Alex O’Connor, and Darrell Willcocks form the core of this successful firm. The Squirrel Design team has been based in [Dartmoor National Park](http://www.dartmoor.gov.uk/enjoy-dartmoor/places/towns-and-villages) for the last 30 years and focuses on contemporary design of large, residential projects in prestigious locations. The firm’s location has given the team a wealth of additional skills, knowledge, and experience working with Listed Buildings, Ancient National Monuments, and conservation work.

The Squirrel Design team has always pushed architectural boundaries with creativity, ensuring each design is better than the last. With the help of [Vectorworks software](http://www.vectorworks.net/en?utm%5Fcampaign=blog&utm%5Fsource=intext&utm%5Fmedium=planetvectorworks&utm%5Fcontent=squirreldesign062618) and trainer Jonathan Reeves of [JR Architecture Ltd](http://www.jra-vectorworks-cad.co.uk/), they continue to find success. We recently spoke with Michael O’Connor about his experiences.

Reeves has served as a helpful resource for Squirrel Design. “The great thing about Jonathan is that he understands what we are doing, why we are doing it, and how we are using the software for our architectural processes,” said O’Connor.

“It is comforting to know that Jonathan is just a phone call away if we need him,” he added, describing the invaluable assistance Jonathan provides. 

O’Connor has used Vectorworks since its first incarnation the 1980s and said the program’s compatibility with Mac computers and its ability to create detailed, 3D images was exactly what the firm needed. When he realized how much quicker, easier, and more accurate the Vectorworks drawings were compared to hand sketches, he was sold. “I couldn’t wait to get started,” he said.

He originally looked at other programs, such as AutoCAD and ARCHICAD, but decided Vectorworks better suited the firm’s needs. “At that time, AutoCAD was really clunky and better suited for engineering or manufacturing purposes,” he explained. 

Today, the design team often sketches out ideas and quickly moves into 3D modeling in the software. “We get the shape and form of the building in Vectorworks and it starts coming together,” said O’Connor. The team then adds details in Vectorworks. “In this early stage, we use the sketch rendering mode in the program for the first round of presentation, so it still looks like it’s in a concept stage, and we use that to talk to clients and planners,” he adds. But the team greatly benefits from working in 3D, as all the modeling information is available in the design from the beginning.

## About the Para 55 Projects

Paragraph 55 refers to a set of requirements within the UK’s National Planning Policy Framework that allows for building a home in the countryside if the design is “of exceptional quality or innovative nature.”

Squirrel Design’s two approved Para 55 projects, the Hux Shard and the Nimbus, are both extremely complex designs, and the firm needed a presentation tool that was robust enough to accurately and impressively share them. Vectorworks played an important role in the high level of presentation to obtain approval for such projects.

“The presentation was key to getting the concepts out of our heads and in front of the planners, designers, public, and Design Review Panel,” said O’Connor. “For this, Vectorworks was particularly useful, especially with its advanced 3D visualization features.”

Another benefit of using Vectorworks on the Hux Shard project was the ability to use one 3D model for elevations, layouts, and communication with the engineers, landscape architect, and interior designer.

![Screen Shot 2018-06-25 at 11.44.56 AM](https://blog.vectorworks.net/hs-fs/hubfs/Screen%20Shot%202018-06-25%20at%2011.44.56%20AM.png?width=1189&name=Screen%20Shot%202018-06-25%20at%2011.44.56%20AM.png) 

_An inside view of the Hux Shard project._

He explained that obtaining permissions for a Para 55 house is like the Holy Grail of architectural achievement, which is why being granted two in succession is such a huge win for Squirrel Design. “It truly puts you into the premier architectural league,” he said.

Completing a Para 55 project comes with a number of tests, one of which requires the design to “reflect the highest standards of architecture.”

“To get a building off the ground, we are not going to take any shortcuts,” said Michael. “We will see it all the way through.” This mindset proved instrumental when their projects were deemed both architecturally outstanding _and_ innovative, with a focus on sustainability. Rather than sucking energy from the country and negatively impacting wildlife habitats, these buildings will improve the biodiversity around them and actually produce more energy than it consumes.

![Screen Shot 2018-06-25 at 11.46.47 AM](https://blog.vectorworks.net/hs-fs/hubfs/Screen%20Shot%202018-06-25%20at%2011.46.47%20AM.png?width=1212&name=Screen%20Shot%202018-06-25%20at%2011.46.47%20AM.png)

_An inside view of the Nimbus project._

O’Connor describes the Hux Shard as “a sculpture in the countryside. When you’re approaching it, you don’t even realize that it’s a house.” It is important for architects to be able to share where their Para 55 design concept inspiration came from. “The Hux Shard structure was influenced by the tors (rocky outcrops) in our Dartmoor base, while the Nimbus concept was inspired by the mining history in Cornwall, which is why it will mostly be made from corrugated iron and natural stone,” explained O’Connor.

The firm is also building a legacy of design in the next generation of architects. The firm provides work experience to students from Atrium Studio School in Devon, which focuses on the built environment, and the Para 55 projects become part of the educational process.

![Screen Shot 2018-06-25 at 11.48.47 AM](https://blog.vectorworks.net/hs-fs/hubfs/Screen%20Shot%202018-06-25%20at%2011.48.47%20AM.png?width=1306&name=Screen%20Shot%202018-06-25%20at%2011.48.47%20AM.png)_The proposed floor layout for the Hux Shard project._ 

Congrats to Squirrel Design on this impressive achievement. We look forward to seeing what comes next for this inventive firm.

To learn more about Squirrel Design and its Paragraph 55 projects, visit the firm's [website](https://www.squirrel-design.co.uk/).

[![Learn More About Vectorworks](https://no-cache.hubspot.com/cta/default/3018241/666ef466-31a3-481d-b850-eb8f013132db.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/666ef466-31a3-481d-b850-eb8f013132db) 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.