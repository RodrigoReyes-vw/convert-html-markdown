[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Download Now | Vectorworks 2024 Update 3

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2023%20Blog%20Images/10_VW24%20Update%201/2308-vectorworks-2024-launch-signature-images-design-suite%20%281%29.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fupdates-improvements-in-vectorworks-2024-update-3)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Download%20Now%20|%20Vectorworks%202024%20Update%203&url=https%3A%2F%2Fblog.vectorworks.net%2Fupdates-improvements-in-vectorworks-2024-update-3&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fupdates-improvements-in-vectorworks-2024-update-3)

When it comes to your design processes and software, there’s always room for improvement. Achieve a superior design workflow with the release of Vectorworks 2024 Update 3.

Continue reading to learn what the latest update has in store for you and your designs.

#### For Landscape Architects & Designers

With the release of Vectorworks 2024 Update 3, you can look forward to including even more detail, data, and imagery in your designs, documents, and presentations in [Vectorworks Landmark](https://www.vectorworks.net/landmark?utm%5Fmedium=pr&utm%5Fsource=coverage&utm%5Fcontent=vectorworks-2024-update-3).

The new **[PlantMaster plugin](https://plantmaster.com/)** grants those with an active PlantMaster subscription the ability to use their vast library for detailed plant reports and visually stunning representations.

The plugin from the [Vectorworks Partner Network member](https://www.vectorworks.net/community/partner-network?utm%5Fmedium=pr&utm%5Fsource=coverage&utm%5Fcontent=vectorworks-2024-update-3) can be easily installed by accessing the “Install Partner Products” palette inside Vectorworks.

Additionally, the optimized DWG export for **Landscape Area objects** helps you exchange DWG files while ensuring accuracy and precision.

#### For Architects

To cater to your distinct needs as an architect, Vectorworks 2024 Update 3 includes better support of corner windows with defined wall closures for more accurate BIM models.

The **Callout tool** has also been enhanced to work with rotated plans. It allows you to annotate plan drawings intuitively and accurately.

#### For Lighting & Live Event Designers

Significant developments to the My Virtual Rig (MVR) import and export function deliver better support for **Project Sharing**, Gobo images, Seating Sections, and other data such as shutter information, color name, and fixture position, so you can easily exchange higher-quality files. [The General Device Type Format](https://gdtf-share.com/) (GDTF) import function has also undergone advancements, allowing easier access to fixtures and their data.

[RELATED | “MVR, AN OPEN STANDARD FOR THE ENTERTAINMENT INDUSTRY”](../../../net/vectorworks/blog/din-spec-15801-mvr.html)

With Vectorworks 2024 Update 3, [rigging experts using Braceworks](../../../net/vectorworks/blog/brace-yourself-3-tips-on-starting-in-braceworks.html) can expect improvements in generating reports. Braceworks reports are now even more consistent and readable with a higher visual quality.

You’ll also find a performance boost when working with truss objects. Inserting truss objects in files with multiple light objects and other complex geometry is faster and provides a much smoother modeling experience.

#### For All Designers

Regardless of your design discipline, Vectorworks 2024 Update 3 offers support for dimension-type data fields in the **Title Block Border**. This improvement gives you greater flexibility in reporting project information in the title block. Plus, adding import/export support for Revit 2024 files improves the file exchange process with collaborators using the most current version of Revit.

#### How to Install the Update

This update is available to download for all currently released English-based versions of Vectorworks 2024\. To install the update, select **Check for Updates** from the **Vectorworks** menu (Mac) or the **Help** menu (Windows).

#### More on the Update 

For a full list of improvements in Vectorworks 2024 Update 3, click the button below:

[![LEARN MORE](https://no-cache.hubspot.com/cta/default/3018241/d2265b9c-ebd0-4ffb-bf47-62afc89d436e.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/d2265b9c-ebd0-4ffb-bf47-62afc89d436e) 

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.