[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Download Now | Start-to-Finish Workflows in Vectorworks 2024

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 6 min read time 

![vectorworks 2024 design suite](https://blog.vectorworks.net/hubfs/Blog%20Images/2023%20Blog%20Images/9_Launch2/blog-1440x800%20%288%29.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fdownload-vectorworks-2024-today)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Download%20Now%20|%20Start-to-Finish%20Workflows%20in%20Vectorworks%202024&url=https%3A%2F%2Fblog.vectorworks.net%2Fdownload-vectorworks-2024-today&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fdownload-vectorworks-2024-today)

That’s right — Vectorworks 2024 is here. Continue reading to see how the suite of updates will unleash your creativity.

---

“Our goal is to empower designers with tools and resources that boost their creativity. With Vectorworks 2024, we have taken this mission to new heights through groundbreaking new features, user experience enhancements, and a strong focus on quality and performance. These advances will significantly accelerate our users' design experiences, from the initial spark of an idea to the ultimate realization of a project.”

\- Steve Johnson, Vectorworks chief technology officer

---

#### For All Designers

Vectorworks 2024 includes substantial advancements in core technology that are designed to save you time. 

###### Modernized User Interface

One of these advancements is the modernized user interface. That’s right — Vectorworks has a whole new look! You might notice the reorganized View and Mode bars, which now provide quicker access to commonly used tools.

###### Viewport Styles

You’ll find a new option to save custom viewport settings as styles, which allows for easy transfer between viewports, reduction of errors, and increased efficiency.

###### Shaded Rendering Shadows & Camera Effects

Improvements to Shaded rendering allow you to achieve higher levels of realism and confidently assess your designs with improved shadow casting and camera settings.

###### Excel Referencing

Referencing Excel files’ data enhances connectivity and collaborative data capabilities.

###### Re-Engineered Section Viewport Rendering

Re-engineered section viewport rendering makes it so you can navigate rendered sections or clipped models faster than ever before.

###### 3D Dragger Visual Improvements

3D Dragger visual improvements grant incredible design freedom when transforming models. You'll notice better cues to understand different modes of editing and creating with the 3D Dragger.

###### DWG Import/Export Optimization

Optimization of DWG import/export capabilities eliminates the tedious task of file cleanup. 

#### For Architects and Interior Designers

The new version of Vectorworks Architect significantly upgrades your BIM workflows with features and tools that save time while you design and help reduce errors in the modeling and documentation process.

###### Newly Redefined Parametric Railing & Cabinet Objects

We’ve introduced new parametric railing object that creates handrails and guardrails that can be associated with other building objects, such as stairs, slabs, and ramps. Additionally, new parametric cabinet objects enable a greater range of cabinet configurations, more interactive placement and generation, easier editing, and greater customization.

###### Wall Tool Improvements

Improvements to the Wall tool allow you to stay in your creative flow, switch linear and curved wall modes seamlessly, and apply multiple configurations of wall component returns to inserted objects, offering flexibility with less effort.

###### Improvements to Wall, Slab, & Roof Texturing

Additional improvements to wall, slab, and roof texturing make applying textures to these architectural objects simpler, freeing you to focus on a project’s more complex construction details.

###### Structural Member Improvements

With new structural member improvements, you’ll gain more significant control over 2D and 3D attributes, material, shape, and size for styled and instance-based parameters. And with control of auto-joining, you can streamline your documentation with these objects.

#### For Landscape Architects and Designers

Improved visual and presentation capabilities, plus a new automated Fence tool, help you take your creativity to the next level. 

###### New Fence Tool

The automated Fence tool saves significant time while designing in 2D or 3D and reduces the chance of errors in material specifications.

###### Landmark Color Palette

The new Landmark Color Palette provides an efficient, nature-focused color selection experience. You can easily access the specific colors you need to communicate design intent. 

###### Site Model Analysis Legends

Legends for Site Model Analysis also offer the ability to communicate design decisions promptly and effectively. You’ll have better control over the graphical output of site model snapshots with the ability to include a legend to help clients better understand annotations. In addition, a highly customizable color scale ensures that you can include critical information about slope ranges and elevation values.

#### For Lighting and Live Event Designers

The latest improvements from Vectorworks 2024 bring everyday quality and performance improvements to your lighting and live event workflows, reducing the amount of manual work you have to do to accurately deliver designs to clients and collaborators.

###### Equipment Lists

The new Equipment Lists feature streamlines your equipment and inventory tracking process, giving you the tools to plan and document equipment in the preproduction process without having to leave Vectorworks.

###### ConnectCAD Share Reports Command

For AV design professionals using [ConnectCAD](https://www.vectorworks.net/en-US/connectcad), the Share Reportscommand will now upload your design data to [Vectorworks Cloud Services](https://www.vectorworks.net/en-US/cloud-services) as a configurable worksheet to view in a web browser on any mobile device.

###### Unified 3D Rack Workflow

Additionally, the new unified 3D Rack workflow in ConnectCAD will save you time by giving you the ability to quickly design and edit equipment racks in 3D with required 2D objects being created automatically.

#### How to Get Started with Vectorworks 2024

Click the button below for more information and to see the new version in action. Make sure to join the conversation on social media with #Vectorworks2024.

[![LEARN MORE](https://no-cache.hubspot.com/cta/default/3018241/dda2de3e-9b90-457f-88e3-34e50f6acc30.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/dda2de3e-9b90-457f-88e3-34e50f6acc30) 

_The release of localized language versions will begin in October and conclude in the first quarter of 2024\. Contact your local Vectorworks distributor for more information on availability in other markets. If you’re a [Vectorworks Service Select](https://www.vectorworks.net/service-select) or [subscription](http://customers.vectorworks.net/subscriptions) customer, you can download Vectorworks 2024 when the product is released in your local market._

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.