[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Celebrate Halloween with a Gothic-Inspired Vectorworks Design

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 8 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/211018_Gothic%20Facade/Gothic%20Opera%203.jpeg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-gothic-fa%C3%A7ade-halloween-design)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Celebrate%20Halloween%20with%20a%20Gothic-Inspired%20Vectorworks%20Design&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-gothic-fa%C3%A7ade-halloween-design&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-gothic-fa%C3%A7ade-halloween-design)

With Halloween right around the corner, a ghostly mood is in the air. That’s right — now is the time for pumpkins, goblins, ghouls, and vampires.

Perhaps the most famous vampire of them all, Dracula, was the inspiration behind a gothic installation at the Royal Swedish Opera House in 2017\. The spooky spectacle was designed with [Vectorworks Spotlight](https://www.vectorworks.net/spotlight). 

###### Vectorworks Spotlight Brings a Gothic Façade to Light

In the daylight, it stood as a beautiful piece of architecture, but at night, the [Royal Swedish Opera](https://operavision.eu/en/contributors/royal-swedish-opera) house was transformed into Dracula’s gothic castle. 

With the use of projection and sound technology, Isak Gabre, the then-systems and project manager at the Royal Swedish Opera, and his team gave the house’s stately exterior an impressive revamp. Vines crawled up the sides of the stone façade, blood cascaded down to mask the pale exterior, and men climbed the opera’s pillars during this eerie projection to promote the world premiere of Victoria Borisova-Ollas’ opera, _Dracula_.

![Gothic Opera 1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211018_Gothic%20Facade/Gothic%20Opera%201.jpg?width=1440&name=Gothic%20Opera%201.jpg)

###### Introducing: Isak Gabre, Spotlight Expert

Gabre and his team use Vectorworks Spotlight for every show. 

“My work is mainly as a light board operator, and we do renderings or openGL as far into the process as possible, inserting all scenery models into the Opera House model in Vectoworks, where we can see the scenery on the actual stage and in the actual house,” said Gabre. 

“For all the shows, we make drawings and insert models from set designers and our workshops into Vectorworks for the setup of scenery and fixtures. Then we use the built-in export function to export scenery drawings. And we use the Spotlight plugin for grandMA2 to export show specifics into the lighting control system.”

The program’s visualization capabilities are some of the most beneficial aspects of Vectorworks Spotlight for Gabre and his team. And, today, it's even easier to exchange files between Vectorworks Spotlight and grandMA3, thanks to the [GDTF](https://gdtf-share.com) and MVR file formats.

“We usually don’t have the time to do creative experimenting on stage,” said Gabre. “If the clients can be shown their own models and design together with an accurate model of the theater right in Vectorworks, rather than on paper, and have the ability to look at angles and entrances and set design on screen, or through VR or AR, that’s a great benefit for us.”

###### Vectorworks Plays a Lead Role in Saving Time

Gabre’s expertise with Vectorworks Spotlight helped him execute the exterior projections for Dracula in a short time frame.

“We had about five weeks from the first production meeting until the show’s premiere,” said Gabre. “Our marketing department wanted to make the premiere special and started brainstorming with my department manager, Patrik Becker, who has a great deal of experience with projections and cinema. He suggested that they should go for a façade projection.”

![Gothic Opera 2](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211018_Gothic%20Facade/Gothic%20Opera%202.jpg?width=1440&name=Gothic%20Opera%202.jpg)

Luckily for Gabre and his team, the show was already in rehearsal and had several projections that could be used for the façade. Because of the tight time frame, the content designers from [Goodbye Kansas Studios](https://goodbyekansasstudios.com/) had to go with the original plan and storyboard. “Their experience in the field saved us a lot of trial and error,” said Gabre. “They knew what would work and what not to spend time on and basically delivered a final content version that we used straight off, without doing on-site editing.”

Incorporating Vectorworks Spotlight into his workflow not only helped Gabre execute the designs, it also helped him to quickly move through the process of acquiring permits. 

“It took me one or two hours to make all the permit application drawings that we needed,” said Gabre. “We didn’t have to send different versions back and forth with the city officials, as they found every detail and all information in the first draft. Vectorworks saved us a lot of time and helped make very clear what we wanted to do with this projection.”

###### A Cast of Collaborators 

Gabre worked with several teams of people on this project. The sound design was made in-house by Andrea Rea and Sebastian Lönberg, and the projections were executed by an in-house staff member who turned them on every day and locked them up every night. Colleagues from Goodbye Kansas Studious generated storyboards and created the content for the projections. [Scenteknik AVL AB ](https://scenteknik.se/)supplied the four Barco HDX20 projectors, the lenses, and purpose-built containers for the project, and [Stage & Event Light ](https://www.stageeventlight.se/)supplied the Martin Viper Performance with outdoor housing and SGM P5 washes.

Gabre appreciated the software’s ability to seamlessly collaborate with other programs. 

“No matter who we’re going to send files to or get files from, there’s always an import or an export function within Vectorworks,” he said. “So, we can still work with every other part of our chain, even if someone uses a different software.”

“With a project like this, there was a lot of pressure on all parties involved, partly thanks to the nature of the price tag linked to this kind of projection mapping,” said Gabre. 

By using Vectorworks to make the drawings and plans as precise as possible, the team was able to share accurate information and visualizations with all collaborators. “That meant that we managed to do it right on the first try and didn’t have to spend time or energy redoing or changing the setup.”

“In a more traditional theater like the Royal Opera House, this kind of technically advanced mapping is not included in our everyday work,” said Gabre. “Therefore, the drawings and renderings we made not only allowed us to share information with the collaborators, but also with the in-house staff to give them an idea of what we were working on and aiming for.”

![Gothic Opera 3](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/211018_Gothic%20Facade/Gothic%20Opera%203.jpg?width=1440&name=Gothic%20Opera%203.jpg)

###### The Reviews are In

When all the hard work was done and the team’s visions were realized, you could see pedestrians stopping by, busses and cars coming to full halt — all just to watch the dramatic spectacle.

“It was a huge hit,” said Gabre. “The marketing department said that nothing we’ve ever done has given us this much publicity. My favorite part about working on the projection façade was that it’s not that often that you do a production like that. It’s kind of rare, and it involves a little bit of experimenting along the way. It was really fun!”

From the in-house staff to spectators on the street, all were impressed with how the projection mapping came out. You might say they were truly “sucked in” by its effect.

###### Vectorworks 2022: Create Scary-Good Designs

You can create equally captivating lighting and sound designs with the newest release of Vectorworks. [Vectorworks 2022](../../../net/vectorworks/blog/vectorworks-2022-now-available-for-download.html) features better file performance, highly responsive tools, and more:

* Versions 2022 of Vectorworks Spotlight, Braceworks, ConnectCAD, and Vision have greater consistency between tools as well as functionality focused on simplifying processes like cable and power planning.
* This latest release also delivers many usability enhancements such as better controls on the camera tool, a position name field for truss, and context menus for shifting data.
* Improved placement and direct editing of objects in Schematic Views makes day-to-day documentation in Vectorworks Spotlight faster and more intuitive.

Click the button below to see how you can get 2022 now!

[![Meet Vectorworks 2022](https://no-cache.hubspot.com/cta/default/3018241/0819809f-7527-4116-90d0-d3a0c80b3efd.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/0819809f-7527-4116-90d0-d3a0c80b3efd) 

 Topics: [Production & Lighting Design](https://blog.vectorworks.net/topic/production-lighting-design) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.