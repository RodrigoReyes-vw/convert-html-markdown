[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Fill Your Designs with These Trending Colors

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 4 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/240227_INT%20Color%20of%20the%20Year%202024/Kyrlon%20%2B%20Sherwin%20Williams.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2F2024-colors-of-the-year-vectorworks-design)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Fill%20Your%20Designs%20with%20These%20Trending%20Colors&url=https%3A%2F%2Fblog.vectorworks.net%2F2024-colors-of-the-year-vectorworks-design&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2F2024-colors-of-the-year-vectorworks-design)

Using trending colors is a great way to keep your designs fresh and your clients excited.

In this post, we’ll showcase Color of the Year selections from some of the most popular color manufacturers in the world. You’ll also learn how to easily create custom palettes featuring these colors in [Vectorworks Architect](https://www.vectorworks.net/architect).

#### Major Color Manufacturer’s 2024 Colors of the Year 

[2023’s Color of the Year selections](../../../net/vectorworks/blog/2023-colors-of-the-year-vectorworks-palette.html) focused on hues found in nature. This trend continues into this year, but as Kesoon Chance, an interior architecture expert, pointed out, “2024’s colors are leaning more towards refreshing one’s spirits and calmness.”

![2024 Colours of the Year transition3](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/240227_INT%20Color%20of%20the%20Year%202024/2024%20Colours%20of%20the%20Year%20transition3.gif?width=1440&height=809&name=2024%20Colours%20of%20the%20Year%20transition3.gif)

As you can see from the GIF above, blue, soft, and natural tones like [Krylon’s](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwiOjcGLsaaEAxV3G9AFHeI2CYsQFnoECBYQAQ&url=https%3A%2F%2Fwww.krylon.com%2Fen%2Fcolors%2Fcolor-of-the-year%2F2024&usg=AOvVaw3HP34u3I2ur4a9gz9lw43s&opi=89978449) “Bluebird” or [Valspar’s](https://www.marthastewart.com/valspar-2024-color-of-the-year-renew-blue-7644613) “Renew Blue” dominate this year’s crop of fashionable colors.

Other Colors to be on the lookout for in 2024 include:

* [Behr](https://www.google.com/aclk?sa=l&ai=DChcSEwj%5FvKissKaEAxXxN9QBHXSkDu8YABADGgJvYQ&gclid=Cj0KCQiAoKeuBhCoARIsAB4WxtcfuGcgpy8p7ilWCZFTaenx0RHLhYiQbUF278wA7Xig39oLgZ7rPagaAtsPEALw%5FwcB&sig=AOD64%5F3T1x3ylyYy9tHEbhIf7c9jEyE4UA&q&adurl&ved=2ahUKEwj95KKssKaEAxWQ38kDHaXYBrEQ0Qx6BAgKEAE) “Cracked Pepper”
* [Benjamin Moore](https://www.benjaminmoore.com/en-us/paint-colors/color/825/blue-nova) “Blue Nova”
* [Dulux](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwiPuu2BsaaEAxVLGtAFHVFRDlcQFnoECB0QAQ&url=https%3A%2F%2Fwww.dulux.co.uk%2Fen%2Fdulux-colour-of-the-year-2024&usg=AOvVaw1q1lhgpE6LZLHaPJaHYR17&opi=89978449) “Sweet Embrace”
* [Dunn Edwards](https://www.dunnedwards.com/press-releases/dunn-edwards-announces-2024-color-of-the-year-skipping-stones/) “Skipping Stones”
* [Dutch Boy](https://www.dutchboy.com/en/colors/color-of-the-year) “Ironside"
* [Glidden](https://www.glidden.com/2024-color-trends) “Limitless”
* [Pantone](https://www.pantone.com/color-of-the-year/2024#:~:text=Discover%20why%20PANTONE%2013%2D1023,and%20multimedia%20design%2C%20and%20more.) “Peach Fuzz”
* [Sherwin Williams](https://www.sherwin-williams.com/en-us/color/color-of-the-year/2024) “Upward”

The use of color, whether it be this year’s Color of the Year picks or another of your choosing, can be an effective emotive element of your next project — as Wassily Kandinsky, the celebrated painter and color theorist, wrote, “Color is a power which directly influences the soul.”

#### Create Custom Vectorworks Color Palettes with Trending Hues

Once you decide which of the 2024 Colors of the Year you want to include in your next project, you can create a custom color palette in Vectorworks Architect with the [**Color Palette Manager**](https://app-help.vectorworks.net/2024/eng/VW2024%5FGuide/Attributes/Managing%5Fcolor%5Fpalettes.htm?rhsearch=color%20palette%20manager&rhhlterm=color%20colors%20palettes%20palette%20managing%20manager%20manage).

These palettes are easy to create, and you have plenty of color code systems to choose from: Hex, RGB, CYMK, Grayscale, and the eyedropper tool. 

Additionally, Vectorworks hosts a wide range of manufacturer paint colors, like the ones mentioned above, available for instant use. 

![colour palette manager](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/240227_INT%20Color%20of%20the%20Year%202024/colour%20palette%20manager.png?width=700&height=450&name=colour%20palette%20manager.png)

With the **Color Palette Manager**, which is located under **Tools** \> **Utilities**, you’ll benefit from creating a cohesive design that uses the colors from a shared color palette. The **Color Palette Manager** is also useful for organizing and storing company brand colors.

For more on creating and editing custom color palettes, click the button below:

[![CUSTOM PALETTES IN VECTORWORKS ARCHITECT](https://no-cache.hubspot.com/cta/default/3018241/4e2d3020-cd99-4317-a8ee-5dae4307f975.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/4e2d3020-cd99-4317-a8ee-5dae4307f975) 

#### Stay Ahead of the Curve with NCS Colour Trends

Incorporating trending colors in your designs can spark inspiration, and looking even further into the future can do the same.

[NCS Colour](https://www.vectorworks.net/community/partner-network/find-partner/ncscolour), for example, inspires designers by releasing their Colour Trends reports. The Vectorworks Gold Partner recently launched [their 2025+ report](https://ncscolour.com/en-int/pages/trend-2025), which “promises a year of big contrasts.”

The four trend directions include [Gaia](https://ncscolour.com/en-int/pages/gaia), “a tribute to nature and water focusing on blue and green tones;” [On & Off](https://ncscolour.com/en-int/pages/on-off), in which “light and dark hues are combined by two chromatic colors that symbolize unity;” [Inner](https://ncscolour.com/en-int/pages/inner), a combination of tones “that evoke emotions of comfort, warmth, and joy;” and [Ethereal](https://ncscolour.com/en-int/pages/ethereal), a concept that blends “light and airy aesthetics with technology.”

![2310-vw-partner-network-ncs-colours-integration-post-tw-landscape](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/240227_INT%20Color%20of%20the%20Year%202024/2310-vw-partner-network-ncs-colours-integration-post-tw-landscape.png?width=1440&height=720&name=2310-vw-partner-network-ncs-colours-integration-post-tw-landscape.png)

With a NCS+ Pro paid subscription in Vectorworks 2024, you can work digitally with color to identify, define, and visualize color choices.

Here are a few things you need to know:

* NCS Colour concepts can help build mood and inspiration boards in the early design phases, helping you set the tone for a project.
* NCS+ Pro allows you to integrate color concepts into Vectorworks quickly and in an automated way, right into your Vectorworks Color Palette Manager. This saves time in developing color schemes and design iteration.
* You can install the plugin via the Install Partner Product command (**Help > Install Partner Products**) within the software.

To explore more of what’s new in Vectorworks 2024, [click here](https://www.vectorworks.net/2024).

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.