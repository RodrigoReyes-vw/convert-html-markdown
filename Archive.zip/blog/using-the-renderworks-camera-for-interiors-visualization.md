[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# What is the Renderworks Camera?

 Posted by [Carter Hartong](https://blog.vectorworks.net/author/carter-hartong) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/220329_Renderworks%20Camera/renderworks%20camera%20desk-1.jpg) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fusing-the-renderworks-camera-for-interiors-visualization)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=What%20is%20the%20Renderworks%20Camera?&url=https%3A%2F%2Fblog.vectorworks.net%2Fusing-the-renderworks-camera-for-interiors-visualization&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fusing-the-renderworks-camera-for-interiors-visualization)

Visualization methods in Vectorworks help bring your ideas to life and help communicate design intent with clients.

We’ve covered [rendering options](/vectorworks-webinars-on-rendering?hs%5Fpreview=cPZVQHjh-68597598006) in extensive detail on _Planet Vectorworks_, like the [Renderworks feature set](../../../net/vectorworks/blog/renderworks-renderings-powered-by-maxon.html) that you can use natively in Vectorworks, for example. But in this post, we’ll explore the Renderworks Camera object. 

Read on to learn how to utilize Renderworks Camera objects to create picture-perfect views.

## What is the Renderworks Camera?

The Renderworks Camera object is similar to a traditional camera. With the object, you can control your lens, aperture, and shutter speed to create any desired view of your model. You also have control over focal length aiding in the precision of your view.

Think of the object simply as a tripod you’re setting up in your model. Curious what the kitchen you designed looks like from the living room? What about a dining room from an adjacent hallway? Since you can put Renderworks Cameras anywhere in your design, you and your client are able to visualize the space from a whole new perspective.

Place as many camera objects in your design as you desire. Additionally, you’re able to share camera presets between files, as opposed to saved views when you’re only navigating a rendering.

The Renderworks Camera is also perfect for your next presentation because it reduces the time you need to spend in post-production applications.

## How to Set Up a Renderworks Camera

Follow the steps below to set up your Renderworks Camera object:

1. Select the object in the Visualization palette.\*
2. Click once to select where in your document you want the camera to be placed.\*
3. Click a second time to determine what the camera is looking at.\*
4. Adjust view angle to expand or contract field of view.\*
5. Reference the Object Info Palette (OIP) to precisely adjust many of the camera’s settings.
6. Once in the OIP, name your camera view. If you’re using more than one camera, we recommend naming the object based upon the view it’s providing.
7. Adjust Rotation, Camera Height, and Look To Height (tilt) in the OIP.

\*Please note that steps 1-4 take place in Top/Plan view.

[![FREE RENDERWORKS CAMERA WEBINAR](https://no-cache.hubspot.com/cta/default/3018241/3b816503-9641-4f54-9142-d5e60e8d7298.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/3b816503-9641-4f54-9142-d5e60e8d7298) 

## Renderworks Camera Effects

As we mentioned above, using the Renderworks Camera allows you to raise the overall quality of your renderings.

Renderworks Cameras can apply various physical Camera Effects to a rendered image, most often to viewports created from a camera. Below are some of the Camera Effects you can use to emulate realistic camera styles.

![renderworks camera desk-1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220329_Renderworks%20Camera/renderworks%20camera%20desk-1.jpg?width=1440&name=renderworks%20camera%20desk-1.jpg)

## Depth of Field

Depth of Field is a visual effect in which some objects — normally the objects you’re focusing on — appear sharp and clear, with other objects appearing blurred.

This effect can create greater emphasis on a specific element of your design. It can also help communicate the overall size of a given space.

![Screen Shot 2022-03-17 at 10.09.08 AM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220329_Renderworks%20Camera/Screen%20Shot%202022-03-17%20at%2010.09.08%20AM.png?width=1440&name=Screen%20Shot%202022-03-17%20at%2010.09.08%20AM.png)

## Exposure

Exposure allows you to control how much light is included in the render. Use this effect to create a dramatic image when presenting your next design to a client.

![Screen Shot 2022-03-17 at 10.10.28 AM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220329_Renderworks%20Camera/Screen%20Shot%202022-03-17%20at%2010.10.28%20AM.png?width=1440&name=Screen%20Shot%202022-03-17%20at%2010.10.28%20AM.png)

## Bloom 

Bloom is controlled with a simple percentage setting. The Bloom percentage in any rendering begins at a default value of zero.

For a realistic Bloom on your rendering, we recommend staying in between zero and 20 percent. Anything higher will give your design a more surreal appearance.

![Screen Shot 2022-03-17 at 10.11.33 AM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220329_Renderworks%20Camera/Screen%20Shot%202022-03-17%20at%2010.11.33%20AM.png?width=1440&name=Screen%20Shot%202022-03-17%20at%2010.11.33%20AM.png)

## Vignette

Vignette creates a faded blackness effect around the edges of your rendered image. Much like Exposure, Vignette can be used to create dramatic renderings that’ll leave your client speechless!

**![Screen Shot 2022-03-17 at 10.12.28 AM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220329_Renderworks%20Camera/Screen%20Shot%202022-03-17%20at%2010.12.28%20AM.png?width=1440&name=Screen%20Shot%202022-03-17%20at%2010.12.28%20AM.png)**

## Chromatic Aberration

The final Camera Effect you can use inside of the Renderworks Camera is Chromatic Aberration. This effect adds randomized distortions of color to a color, helping create a unique, stylized vision of your design.

![Screen Shot 2022-03-29 at 4.58.05 PM](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220329_Renderworks%20Camera/Screen%20Shot%202022-03-29%20at%204.58.05%20PM.png?width=3584&name=Screen%20Shot%202022-03-29%20at%204.58.05%20PM.png)

When using any of the aforementioned Camera Effects, be sure to select “Camera Effects” in the Edit Renderworks Style dialogue so that you can see the stunning effects. 

## Image Effects

In addition to the Camera Effects you can use on your Renderworks rendering, you can also apply several Image Effects. These take you one step further to creating presentation-ready renderings in a matter of seconds.

![Renderworks camera-1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220329_Renderworks%20Camera/Renderworks%20camera-1.png?width=1440&name=Renderworks%20camera-1.png)

The Image Effects help you make edits — not unlike the ones you’d make in a mainstream image editing app — all from inside Vectorworks.

The Image Effects you have access to in Vectorworks include:

* Exposure
* Contrast
* Highlights
* Shadows
* Saturation
* Temperature
* Blur and Sharpness
* Sepia
* Soft Edges

The Renderworks Camera object allows you to create one-of-a-kind renderings. The object also allows you to spend less on your rendering in post-production, streamlining the efficiency of your design workflow.

![Elevator Lobby-1](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/220329_Renderworks%20Camera/Elevator%20Lobby-1.jpg?width=1440&name=Elevator%20Lobby-1.jpg)

For further instructions on getting started with the Renderworks Camera object, click the button below and watch a free training video.

[![LEARN HOW TO USE VECTORWORKS CAMERA](https://no-cache.hubspot.com/cta/default/3018241/2dffe949-0e50-4430-ab75-348c06872934.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/2dffe949-0e50-4430-ab75-348c06872934) 

 Topics: [Buildings](https://blog.vectorworks.net/topic/buildings) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.