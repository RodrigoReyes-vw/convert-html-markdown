[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# Introducing Vectorworks 2022 | Design Without Limits™

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 5 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/210915_Launch/blog-1440x800.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-2022-now-available-for-download)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=Introducing%20Vectorworks%202022%20|%20Design%20Without%20Limits™&url=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-2022-now-available-for-download&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fvectorworks-2022-now-available-for-download)

_Editor's note: Vectorworks 2023 is here! [Read more about the latest version](../../../net/vectorworks/blog/vectorworks-2023-now-available.html)._

The 2022 version of Vectorworks design software delivered a robust suite of new features and improvements, all focused our tagline — _Design without limits™_.

What does the phrase mean?

It’s a comment on our development philosophy as well as the experience the software offers to designers.

It means that Vectorworks is driven by enabling design freedom and encouraging your creative ideas rather than getting in their way. Great design comes from the designer and not the design software, so it’s important that Vectorworks be built for the way the designer works.

> _Vectorworks 2022 is an invitation to embrace the exceptional flexibility and interoperability that is expected of our purpose-built, design-focused products._   
> _\- Vectorworks CEO Dr. Biplab Sarkar_

![GDP Architects | Asian Institute of Chartered Banks](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210915_Launch/2022-signature-image--arch-original.jpg?width=1440&name=2022-signature-image--arch-original.jpg)

_Asian Institute of Chartered Banks_ 

_Courtesy of [GDP Architects SDN BHD](https://www.gdparchitects.com/) and Adaptus Design System SDM BHD_

As part of our upgrades for 2022, Vectorworks Designer is now Vectorworks Design Suite — you’ll enjoy all the same features (and updates), just under a new name.

Now let’s look at what Vectorworks 2022 has in store! This article is an overview, and you can download more detailed notes about what’s new here:

[![READ THE WHAT'S NEW BROCHURE](https://no-cache.hubspot.com/cta/default/3018241/35fe6c54-bc9e-43c3-a84c-a464bff9e33e.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/35fe6c54-bc9e-43c3-a84c-a464bff9e33e) 

#### Next-Gen Tech

Focused development in core technologies and interfaces makes the software faster and more intuitive while providing the stability and accuracy required for maximum efficiency.

Vectorworks is the first major BIM application to run natively on Apple silicon processors. Testing of Vectorworks 2022 has shown speed increases of two to four times.

Other improvements in next-gen tech include:

* Full use of Metal on Mac and DirectX on Windows in the Vectorworks Graphics Module.
* A new Redshift render mode powered by [Redshift by Maxon](http://maxon.net/redshift).
* A new direct link to [Twinmotion](http://unrealengine.com/twinmotion).
* A redesign of the attribute and snapping palettes and new per-face texture mapping, which support an intuitive process for creating and visualizing designs.

#### BIM Workflows

Vectorworks 2022 offers improvements to 3D and BIM workflows for greater precision, control, and accuracy of visual models and their corresponding data.

* Updates to the worksheet database and Data Manager provide a consistent interface, better visual cues, a new search mode, and an improved formula bar with a new set of functions to help make generating targeted reports, schedules, and material take offs easy.
* Improvements to the stair tool for direct editing and modifying help simplify the process of [designing complex objects](../../../net/vectorworks/blog/the-best-3d-modeling-for-interior-architecture.html).
* Re-engineering and modernization of core architectural objects like wall components and data reporting support the creation of accurate BIM models.

#### Interoperability

Vectorworks takes pride in being a design hub and continues to invest in optimizing the most-used file formats, supporting value-added partner products, and ensuring that project teams and BIM collaboration remain unrivaled.

* Version 2022 includes improvements to the DWG file import to support Civil3D, as well as DWG and GIS georeferencing.
* IFC import/export capabilities are enhanced for improved quantity takeoffs and GIS workflows.

#### Landscape & GIS

As the [BIM platform of choice for landscape architecture](../../../net/vectorworks/blog/why-bim-is-taking-over-landscape-architecture.html), Vectorworks Landmark 2022 delivers more options for accurate modeling reflective of real-life design considerations.

* Improvements to the site model make it easier to define and report on soil layers.
* Updates to the Plant tool, hardscape objects, and integrations with Esri make it easier to produce landscape BIM models that leverage GIS workflows while meeting the demand to create sustainable sites.

![PWP Landscape Architects | Vancouver Convention Center Expansion](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210915_Launch/2022-signature-image-land-original.png?width=1440&name=2022-signature-image-land-original.png)

_Vancouver Convention Center Expansion | Courtesy of [PWP Landscape Architects Inc.](http://www.pwpla.com/)_

#### Entertainment

Our commitment to users in the entertainment industry is to invest first and foremost in re-engineering to better file performance and to provide highly responsive tools.

* Versions 2022 of Vectorworks Spotlight, Braceworks, ConnectCAD, and Vision have greater consistency between tools as well as functionality focused on simplifying processes like cable and power planning.
* This latest release also delivers many usability enhancements such as better controls on the camera tool, a position name field for truss, and context menus for shifting data.
* Improved placement and direct editing of objects in Schematic Views makes day-to-day documentation in Vectorworks Spotlight faster and more intuitive.

![Live Legends | Club One Third Beijing](https://blog.vectorworks.net/hs-fs/hubfs/Blog%20Images/210915_Launch/2022-signature-image-ent-original.jpg?width=1440&name=2022-signature-image-ent-original.jpg)

_One Third Beijing | Courtesy of [Live Legends](https://www.livelegends.com/)_ 

The English-language editions of Vectorworks Fundamentals, Architect, Landmark, Spotlight, Braceworks, ConnectCAD, and Vision 2022 are available today.

Localized English versions for Australia and New Zealand are expected to be available September 29, 2021\. Other localized language versions will begin to be released in October 2021 and conclude in the first quarter of 2022\. Check the webpage to see how you can get 2022 now:

[![MEET VECTORWORKS 2022](https://no-cache.hubspot.com/cta/default/3018241/57d206f6-cbf5-4136-960c-1d46da994022.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/57d206f6-cbf5-4136-960c-1d46da994022) 

Make sure to follow along with the release by visiting @Vectorworks on social media!

 Topics: [News & Events](https://blog.vectorworks.net/topic/news-events) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.