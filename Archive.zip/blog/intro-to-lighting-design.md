[ ![VectorWorks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-logo-full.svg) ![Vectorworks](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v%20(1).svg) ](https://www.vectorworks.net/) 

* [Buildings](https://www.vectorworks.net/architect)
* [Landscapes](https://www.vectorworks.net/landmark)
* [Entertainment](https://www.vectorworks.net/spotlight)
* [All Products](https://www.vectorworks.net/products)
* [Support](https://www.vectorworks.net/products)
* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net)

* [Log In](../../../net/vectorworks/blog/index.html)  
   * [Cloud Services](https://cloud.vectorworks.net/accounts/login)  
   * [Customer Portal](https://customers.vectorworks.net/)  
   * [Community Forum](https://forum.vectorworks.net/)  
   * [Student Portal](https://student.myvectorworks.net/)

Search 

[](https://www.vectorworks.net/en-US/search) 

[ Search](https://www.vectorworks.net/en-US/search) 

[← Return to Post List](../../../net/vectorworks/blog/index.html) 

# VIDEO | Introduction to Lighting Design

 Posted by [Alex Altieri](https://blog.vectorworks.net/author/alex-altieri) | 3 min read time 

![](https://blog.vectorworks.net/hubfs/Blog%20Images/2023%20Blog%20Images/4_Lighting%20Design%20Intro/blog-1440x800%20%282%29.png) 

* [![Share on LinkedIn](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-LI.png)](http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fblog.vectorworks.net%2Fintro-to-lighting-design)
* [![Share on Twitter](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-TW.png)](https://www.twitter.com/share?text=VIDEO%20|%20Introduction%20to%20Lighting%20Design&url=https%3A%2F%2Fblog.vectorworks.net%2Fintro-to-lighting-design&via=PMGTweets)
* [![Share on FaceBook](https://2659751.fs1.hubspotusercontent-na1.net/hubfs/2659751/michaelDemo/share-FB.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fblog.vectorworks.net%2Fintro-to-lighting-design)

If you’re looking for a step-by-step introduction to stage lighting with Vectorworks Spotlight, you’ve come to the right place.

From importing PDF and DWG files to placing truss towers and angling lighting fixtures, industry pro Brandon Eckstorm will walk you through the basics in this video.

Enough beating around the bush, though. Let’s jump into the video.

---

## **V** **IDEO SUMMARY**

* Before planning the lighting design, you need to draw out your stage plot or venue, which can be done from scratch in Vectorworks or by importing a DWG or PDF file. If you're importing non-vector PDFs, the Scale tool helps achieve an accurate scale.
* Draw or trace the room using the 2D Rectangle or 2D Polyline tool and adjust it in the Object Info palette. Then, use the Create Room command in Event Design toolset to set the wall height, rendering options, and add doors to create a complete 3D room with a floor and walls.
* To add doors and a stage, use the Door and Create Stage tools respectively.
* Once the venue is laid out, choose between single, two, or three-point front lighting to light the stage, with one light per zone being the easiest and fastest method. To reduce shadows on stage, consider using two lights per zone at 30-45 degrees off axis and a 45-degree down angle. If this isn't possible, aim for identical 20-degree angles. Three-point front lighting is another option for better visibility. As for adding a third light, tail it down slightly for a low angle fill to help remove unwanted shadows on the face.
* Next, hang fixtures using a truss tower in the back of the room. Start by assembling a 15-foot truss tower with a base and a 10-foot and 5-foot stick. Add a pipe and fixtures, using a 19-degree Leko for each focused position on stage. Duplicate the lights to the other side for a simple, focused front wash. You can use the Mirror tool to speed up this process.
* Lekos with shutters are good for a simple, focused front wash. To plan out the lights, draw a line at 45 degrees off axis, mirror it to the other side, and place the lights accordingly.
* Choosing fixtures depends on what’s available to you, what you’re comfortable with, and the fixture’s photometrics, which comes from the specifications of any fixture you’re looking up.
* The Draw Beam button in the Object Info palette can help visualize the light beams to ensure you’re achieving the desired angles.
* Backlighting provides depth to figures on stage, making them stand out more. Uplights behind the stage can make the stage more visually captivating.

Looking for more videos to improve your Vectorworks skills? Subscribe to our YouTube channel for more!

[![SUBSCRIBE](https://no-cache.hubspot.com/cta/default/3018241/3b160a9f-c82f-493f-9043-a058f709f894.png)](https://cta-redirect.hubspot.com/cta/redirect/3018241/3b160a9f-c82f-493f-9043-a058f709f894) 

 Topics: [Entertainment](https://blog.vectorworks.net/topic/entertainment) 

##  STAY IN THE KNOW 

 Our blog subscribers receive tech tips, user success stories, webinar opportunities, and important company announcements. 

### 

 By submitting this form, you agree that Vectorworks, Inc. and its authorized partners may contact you in regards to news, offers, and the use of our software, services, and platforms. Learn more about our privacy practices and your data on our Privacy page.\* 

##  TRY VECTORWORKS 

 Request your free trial to begin using Vectorworks. From 2D drawing to 3D modeling to fully integrated BIM, we provide new solutions to help you work faster and smarter. 

[Free Trial](https://www.vectorworks.net/en-US/products?showModal=trial-form) 

##  You Might Also Like 

[ Live Now: Improvements to Vectorworks 2023  3 min read time | Topics: News & Events ](../../../net/vectorworks/blog/live-now-bug-fixes-notable-updates-other-improvements-to-vectorworks-2023.html) 

[ Advice for You and Your Vectorworks Spotlight Workflow  10 min read time | Topics: Entertainment ](../../../net/vectorworks/blog/advice-for-you-and-your-vectorworks-spotlight-workflow.html) 

[ Inclusive Architecture | Mike's House by François Lévy  5 min read time | Topics: Buildings ](../../../net/vectorworks/blog/inclusive-architecture-mikes-house-by-françois-lévy.html) 

## Products

* [Fundamentals](https://www.vectorworks.net/fundamentals)
* [Design Suite](https://www.vectorworks.net/design-suite)
* [Architect](https://www.vectorworks.net/architect)
* [Landmark](https://www.vectorworks.net/landmark)
* [Spotlight](https://www.vectorworks.net/spotlight)
* [Vision](https://www.vectorworks.net/vision)
* [Braceworks](https://www.vectorworks.net/braceworks)
* [ConnectCAD](https://www.vectorworks.net/connectcad)

## Get Vectorworks

* [What's New in Latest Version](https://www.vectorworks.net/whats-new)
* [Service Select](https://www.vectorworks.net/service-select)
* [Software for Education](https://www.vectorworks.net/education)
* [Cloud Services](https://www.vectorworks.net/cloud-services)
* [Find a Distributor](https://www.vectorworks.net/international)

## Community

* [Open BIM](https://www.vectorworks.net/architect/open-bim)
* [Partner Network](https://www.vectorworks.net/community/partner-network)
* [Customer Showcase](https://www.vectorworks.net/customer-showcase)
* [Community Groups](https://www3.vectorworks.net/community-group)
* [Design Scholarship](https://www.vectorworks.net/scholarship)
* [Design Day](https://designday.vectorworks.net/)
* [Events](https://www.vectorworks.net/events/)
* [Blog](../../../net/vectorworks/blog/index.html)
* [Vectorworks University](https://university.vectorworks.net/)

## Company

* [Our Story](https://www.vectorworks.net/company)
* [News](https://www.vectorworks.net/news)
* [Leadership](https://www.vectorworks.net/company/leadership)
* [Public Roadmap](https://www.vectorworks.net/public-roadmap)
* [Become a Distributor](https://www.vectorworks.net/company/become-a-distributor)
* [Careers](http://careers.vectorworks.net/)
* [Contact Us](https://www.vectorworks.net/company/contacts)

[![Vectorworks, Inc.](https://blog.vectorworks.net/hubfs/Vectorworks_October2018/Images/vw-v.svg)](https://www.vectorworks.net/en) 

[Privacy](https://www.vectorworks.net/legal/privacy) | [Legal](https://www.vectorworks.net/legal/company) | [Nemetschek Group](https://www.nemetschek.com/en/) 

© 2024 Vectorworks, Inc. All Rights Reserved. Vectorworks, Inc. is part of the Nemetschek Group.